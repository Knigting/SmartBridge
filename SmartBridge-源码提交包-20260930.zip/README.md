# SmartBridge Education Training System

SmartBridge 是一套本地可运行的产教融合实训系统，包含平台管理端、企业端、教师端、学生端、统一登录、共享业务 API、MySQL 数据库以及 5 项本地 Skill 能力。

## Project structure

```text
smartbridge-education-training-system/
├─ apps/                         # Browser applications
│  ├─ admin/                    # Platform administration
│  ├─ company/                  # Enterprise workspace
│  ├─ teacher/                  # Teacher workspace
│  ├─ student/                  # Student workspace
│  ├─ login/                    # Unified login
│  └─ shared/                   # Shared browser adapters
├─ services/
│  ├─ api/                      # Express API, database access, web gateway
│  └─ skill-service/            # Parse, RAG, report, training and multimodal Skills
├─ data/training/                # Versioned training data and report definitions
├─ scripts/                      # Setup, start, stop and database scripts
├─ tools/                        # Verification and smoke-test utilities
├─ docs/                         # Architecture and delivery documentation
└─ reports/verification/         # Generated verification results
```

## Requirements

- Windows 10/11 64-bit
- Node.js 20+
- MySQL 8
- Edge, Chrome or another modern browser

Local ports: MySQL `3306`, API/web gateway `8080`, Skill service `8090`.

## Run

First-time setup:

```text
setup.cmd
```

Daily startup:

```text
start.cmd
```

Stop local services:

```text
stop.cmd
```

Open <http://127.0.0.1:8080/login/index.html> after startup.

## Demo accounts

All demo accounts use password `SmartBridge123!`.

| Role | Account |
|---|---|
| Platform administrator | `admin` |
| Enterprise user | `zhanggong` |
| Teacher | `lihuimin` |
| Student | `2024010156` |

## Verified capabilities

- 36 web pages render without blank pages, broken-resource markers or console errors.
- File upload, download, batch parsing, CSV/JSON export and HTML report download work locally.
- Five Skills are registered through 20 workflow bindings and call the real LLM (OpenAI-compatible endpoint, key pool with automatic failover) for parse summaries, RAG answers, report narratives and training-instruction interpretation. No simulated channels remain: the multimodal skill reports `not_configured` honestly because the current endpoint is text-only, and failed capability slots render an explicit failure card instead of a false "connected" badge. Configure the model in `services/skill-service/.env` (`LLM_BASE_URL` / `LLM_API_KEYS` / `LLM_MODEL`); verify end-to-end with `node tools/verify-live-models.js`.
- MySQL read, create, update, import, delete and audit operations are functional.

See [docs/local-development.md](docs/local-development.md) for operational details.
