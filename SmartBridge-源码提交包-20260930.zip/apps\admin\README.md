# Admin web application

The platform administration UI is served at `/admin/` by `services/api`.

It covers organization, project, resource, operation, data, privacy and platform settings. Shared business data is loaded through `/api/*`; opening these HTML files directly is unsupported.

Run the complete page check from the repository root:

```powershell
node tools/smoke-all.js
```
