(function(){
  document.addEventListener('DOMContentLoaded',async function(){
    await AdminStore.hydrate();
    var M=window.ADMIN_MOCK,U=window.AdminUI;
    var kpis=document.getElementById('kpis'),project=document.getElementById('project'),approvals=document.getElementById('approvals'),audits=document.getElementById('audits');
    if(kpis)kpis.innerHTML=M.kpis.map(function(k){return'<article class="card kpi col-3" style="--tone:'+k.tone+'"><span class="label">'+U.esc(k.label)+'</span><strong>'+k.value+'</strong><small>'+U.esc(k.sub)+'</small></article>'}).join('');
    if(project&&M.projects.length){var p=M.projects[0];project.querySelector('.grow b').textContent=p.name;project.querySelector('.grow p').textContent=p.id+' · '+p.company+' × '+p.school;project.querySelector('.metric-head span').textContent=p.progress+'%';project.querySelector('.progress i').style.width=p.progress+'%';project.querySelector('.notice').innerHTML='<b>当前风险</b><br>'+U.esc(p.risk)}
    if(approvals)approvals.innerHTML=M.approvals.slice(0,4).map(function(a){return'<button class="row" style="text-align:left;background:#fff" data-id="'+a.id+'"><div class="ico">'+a.type.slice(0,1)+'</div><div class="grow"><b>'+U.esc(a.title)+'</b><p>'+U.esc(a.applicant)+' · '+U.esc(a.time)+'</p></div>'+U.badge('pending')+'</button>'}).join('');
    if(audits)audits.innerHTML=M.audits.slice(0,8).map(function(a,i){return'<div class="event"><div class="event-dot">'+(i+1)+'</div><div><b>'+U.esc(a.actor)+' · '+U.esc(a.action)+'</b><p>'+U.esc(a.target)+' · '+U.esc(a.time)+'</p></div></div>'}).join('');
  });
})();
