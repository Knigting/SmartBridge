(function(){
  var M=window.ADMIN_MOCK,U=window.AdminUI;
  function layout(title,desc,actions,body){return'<div class="page-head"><div><h1>'+title+'</h1><p>'+desc+'</p></div><div class="actions">'+(actions||'')+'</div></div>'+body}
  function filterRows(input,rows,fields,paint){input.addEventListener('input',function(){var q=input.value.trim().toLowerCase();paint(rows.filter(function(r){return fields.some(function(f){return String(r[f]||'').toLowerCase().includes(q)})}))})}
  function details(title,items,notice){U.openDrawer(title,(notice?'<div class="notice '+(notice.kind||'')+'">'+notice.text+'</div>':'')+'<div class="detail-list">'+items.map(function(x){return'<div class="detail"><span>'+U.esc(x[0])+'</span><b>'+U.esc(x[1])+'</b></div>'}).join('')+'</div>')}
  function organizations(){
    var root=document.getElementById('pageContent');root.innerHTML=layout('组织与用户','管理学校、企业、账号、角色和数据范围。','<button class="btn btn-outline" id="importBtn">批量导入</button><button class="btn btn-primary" id="newOrg">新增组织</button>','<div class="card"><div class="tabs"><button class="tab active">组织 4</button><button class="tab">用户 5</button></div><div class="toolbar"><input class="field" id="orgSearch" placeholder="搜索组织、负责人或编号"><select class="select" id="orgType"><option value="">全部类型</option><option>学校</option><option>企业</option></select></div><div class="table-wrap"><table><thead><tr><th>组织</th><th>类型</th><th>负责人</th><th>成员</th><th>状态</th><th>创建时间</th><th>操作</th></tr></thead><tbody id="orgRows"></tbody></table></div></div><div class="card" style="margin-top:16px"><div class="card-head"><h2>重点账号与权限范围</h2><span>来自三端现有角色</span></div><div class="table-wrap"><table><thead><tr><th>用户</th><th>所属组织</th><th>角色</th><th>数据范围</th><th>状态</th><th>最近登录</th><th>操作</th></tr></thead><tbody id="userRows"></tbody></table></div></div>');
    function paintOrg(arr){document.getElementById('orgRows').innerHTML=arr.map(function(o){return'<tr><td class="name-cell"><b>'+o.name+'</b><small>'+o.id+'</small></td><td>'+o.type+'</td><td>'+o.owner+'</td><td>'+o.members+'</td><td>'+U.badge(o.status,o.status==='pending'?'待认证':null)+'</td><td>'+o.created+'</td><td><button class="btn btn-outline btn-sm" data-org="'+o.id+'">详情</button></td></tr>'}).join('')||'<tr><td colspan="7" class="empty">没有符合条件的组织</td></tr>'}
    function paintUsers(){document.getElementById('userRows').innerHTML=M.users.map(function(x){return'<tr><td class="name-cell"><b>'+x.name+'</b><small>'+x.account+'</small></td><td>'+x.org+'</td><td>'+x.role+'</td><td>'+x.scope+'</td><td>'+U.badge(x.status)+'</td><td>'+x.last+'</td><td><button class="btn btn-outline btn-sm" data-user="'+x.id+'">权限</button></td></tr>'}).join('')}
    paintOrg(M.organizations);paintUsers();filterRows(document.getElementById('orgSearch'),M.organizations,['name','owner','id'],paintOrg);document.getElementById('orgType').addEventListener('change',function(){paintOrg(M.organizations.filter(function(o){return!this.value||o.type===this.value},this))});
    root.addEventListener('click',function(e){var ob=e.target.closest('[data-org]'),ub=e.target.closest('[data-user]');if(ob){var o=M.organizations.find(function(x){return x.id===ob.dataset.org});details(o.name,[['组织编号',o.id],['类型',o.type],['负责人',o.owner],['成员数量',o.members],['状态',o.status]],{text:'组织停用前必须处理未完成项目与成员权限。',kind:'warning'})}if(ub){var x=M.users.find(function(v){return v.id===ub.dataset.user});details(x.name+' · 权限范围',[['用户编号',x.id],['账号',x.account],['角色',x.role],['所属组织',x.org],['数据范围',x.scope]],{text:'权限变更应采用最小权限原则，并记录审批人与原因。'})}});document.getElementById('newOrg').onclick=function(){U.toast('已打开新增组织草稿；正式保存需业务后端')};document.getElementById('importBtn').onclick=function(){U.toast('批量导入将进入后台任务并生成错误报告')}
  }
  function projects(){
    var root=document.getElementById('pageContent');root.innerHTML=layout('项目运营','统一治理企业需求、教师任务、学生提交和企业验收。','<button class="btn btn-outline" id="exportProjects">导出项目清单</button><button class="btn btn-primary" id="correctBtn">发起纠错单</button>','<div class="grid"><div class="card col-3 kpi" style="--tone:#eaf1ff"><span class="label">当前主项目</span><strong>1</strong><small>PRJ-0917-001</small></div><div class="card col-3 kpi" style="--tone:#fff4df"><span class="label">待审核需求</span><strong>2</strong><small>企业端已提交</small></div><div class="card col-3 kpi" style="--tone:#e8f8f1"><span class="label">任务阶段</span><strong>4</strong><small>1 完成 · 1 进行中</small></div><div class="card col-3 kpi" style="--tone:#fff0f2"><span class="label">风险学生</span><strong>2</strong><small>王浩宇 · 刘子豪</small></div></div><div class="card" style="margin-top:16px"><div class="toolbar"><input class="field" id="projectSearch" placeholder="搜索项目编号、名称、企业"><select class="select" id="projectState"><option value="">全部状态</option><option value="running">进行中</option><option value="pending">待审核</option></select></div><div class="table-wrap"><table><thead><tr><th>项目 / 需求</th><th>企业</th><th>承接学校</th><th>教师 / 班级</th><th>当前阶段</th><th>进度</th><th>风险</th><th>操作</th></tr></thead><tbody id="projectRows"></tbody></table></div></div>');
    function paint(arr){document.getElementById('projectRows').innerHTML=arr.map(function(p){return'<tr><td class="name-cell"><b>'+p.name+'</b><small>'+p.id+'</small></td><td>'+p.company+'</td><td>'+p.school+'</td><td>'+p.teacher+'<br><small>'+p.klass+'</small></td><td>'+U.badge(p.status,p.stage)+'</td><td style="min-width:120px"><div class="metric"><div class="metric-head"><span>'+p.progress+'%</span></div><div class="progress"><i style="width:'+p.progress+'%"></i></div></div></td><td>'+(p.risk==='无'?U.badge('success','无风险'):'<span style="color:var(--red)">'+p.risk+'</span>')+'</td><td><button class="btn btn-outline btn-sm" data-project="'+p.id+'">治理</button></td></tr>'}).join('')}
    paint(M.projects);filterRows(document.getElementById('projectSearch'),M.projects,['id','name','company','teacher','klass'],paint);document.getElementById('projectState').onchange=function(){paint(M.projects.filter(function(p){return!this.value||p.status===this.value},this))};root.addEventListener('click',function(e){var b=e.target.closest('[data-project]');if(!b)return;var p=M.projects.find(function(x){return x.id===b.dataset.project});details(p.name,[['编号',p.id],['企业',p.company],['学校',p.school],['教师',p.teacher],['班级',p.klass],['阶段',p.stage],['风险',p.risk]],{text:'管理员只处理流程异常和数据纠错，不代替教师评分或企业验收。',kind:'warning'})});document.getElementById('correctBtn').onclick=function(){U.toast('纠错单将记录修改前后值、原因和审批人')};document.getElementById('exportProjects').onclick=function(){U.toast('导出任务已加入后台队列')}
  }
  function resources(){
    var root=document.getElementById('pageContent');root.innerHTML=layout('内容资源','管理案例、模板、评分规则、知识条目和脱敏审核。','<button class="btn btn-outline" id="batchReview">批量审核</button><button class="btn btn-primary" id="newResource">新增资源</button>','<div class="grid"><div class="card col-8"><div class="toolbar"><input class="field" id="resSearch" placeholder="搜索资源名称、负责人"><select class="select" id="resType"><option value="">全部类型</option><option>案例</option><option>模板</option><option>评分规则</option><option>知识条目</option></select></div><div class="table-wrap"><table><thead><tr><th>资源</th><th>类型</th><th>负责人</th><th>范围</th><th>版本</th><th>状态</th><th>更新时间</th><th>操作</th></tr></thead><tbody id="resRows"></tbody></table></div></div><div class="card col-4"><div class="card-head"><h2>发布前检查</h2><span>4 项</span></div><div class="stack"><div class="row"><div class="ico">敏</div><div class="grow"><b>脱敏检查</b><p>企业名、设备编号、联系方式</p></div></div><div class="row"><div class="ico">权</div><div class="grow"><b>版权与授权</b><p>确认可复用范围和有效期</p></div></div><div class="row"><div class="ico">版</div><div class="grow"><b>版本留痕</b><p>旧版本只读，不覆盖历史证据</p></div></div><div class="row"><div class="ico">审</div><div class="grow"><b>发布审批</b><p>校级和平台级资源需要复核</p></div></div></div></div></div>');
    function paint(arr){document.getElementById('resRows').innerHTML=arr.map(function(r){return'<tr><td class="name-cell"><b>'+r.name+'</b><small>'+r.id+'</small></td><td>'+r.type+'</td><td>'+r.owner+'</td><td>'+r.scope+'</td><td>'+r.version+'</td><td>'+U.badge(r.status)+'</td><td>'+r.updated+'</td><td><button class="btn btn-outline btn-sm" data-res="'+r.id+'">审核</button></td></tr>'}).join('')}
    paint(M.resources);filterRows(document.getElementById('resSearch'),M.resources,['name','owner','id'],paint);document.getElementById('resType').onchange=function(){paint(M.resources.filter(function(r){return!this.value||r.type===this.value},this))};root.addEventListener('click',function(e){var b=e.target.closest('[data-res]');if(!b)return;var r=M.resources.find(function(x){return x.id===b.dataset.res});details(r.name,[['资源编号',r.id],['类型',r.type],['负责人',r.owner],['使用范围',r.scope],['版本',r.version],['更新时间',r.updated]],{text:'资源发布不会自动扩大原始项目的数据授权范围。'})});document.getElementById('batchReview').onclick=document.getElementById('newResource').onclick=function(){U.toast('已创建内容处理草稿')}
  }
  function privacy(){
    var root=document.getElementById('pageContent');root.innerHTML=layout('隐私授权','管理学生可见状态、企业申请、授权范围、有效期和访问记录。','<button class="btn btn-outline" id="privacyReport">导出隐私审计</button><button class="btn btn-primary" id="revokeBtn">发起撤权检查</button>','<div class="notice warning">管理员不能代替学生同意授权。企业只能查看学生明确授权且仍在有效期内的数据。</div><div class="card" style="margin-top:16px"><div class="toolbar"><input class="field" id="authSearch" placeholder="搜索学生、企业或授权编号"><select class="select" id="authState"><option value="">全部状态</option><option value="pending">待学生确认</option><option value="success">已授权</option><option value="failed">已拒绝</option></select></div><div class="table-wrap"><table><thead><tr><th>授权编号</th><th>学生</th><th>申请企业</th><th>授权范围</th><th>状态</th><th>有效期</th><th>访问次数</th><th>操作</th></tr></thead><tbody id="authRows"></tbody></table></div></div><div class="grid" style="margin-top:16px"><div class="card col-6"><div class="card-head"><h2>隐私治理规则</h2><span>强制执行</span></div><div class="stack"><div class="row"><div class="ico">1</div><div class="grow"><b>默认不可见</b><p>学生未主动开启时不进入企业候选人池。</p></div></div><div class="row"><div class="ico">2</div><div class="grow"><b>逐项授权</b><p>画像、作品、过程档案和联系方式分别授权。</p></div></div><div class="row"><div class="ico">3</div><div class="grow"><b>随时撤回</b><p>撤回后企业访问立即失效并留下审计记录。</p></div></div></div></div><div class="card col-6"><div class="card-head"><h2>访问异常</h2><span>最近 24 小时</span></div><div class="notice risk"><b>1 次越权下载已阻止</b><br>目标：PRJ-0917-001 / FILE-8012 · 来源：172.18.2.44</div></div></div>');
    function paint(arr){document.getElementById('authRows').innerHTML=arr.map(function(a){return'<tr><td>'+a.id+'</td><td>'+a.student+'</td><td>'+a.company+'</td><td>'+a.scope+'</td><td>'+U.badge(a.status,a.status==='pending'?'待学生确认':a.status==='failed'?'已拒绝':'已授权')+'</td><td>'+a.expires+'</td><td>'+a.access+'</td><td><button class="btn btn-outline btn-sm" data-auth="'+a.id+'">记录</button></td></tr>'}).join('')}
    paint(M.authorizations);filterRows(document.getElementById('authSearch'),M.authorizations,['id','student','company','scope'],paint);document.getElementById('authState').onchange=function(){paint(M.authorizations.filter(function(a){return!this.value||a.status===this.value},this))};root.addEventListener('click',function(e){var b=e.target.closest('[data-auth]');if(!b)return;var a=M.authorizations.find(function(x){return x.id===b.dataset.auth});details(a.id,[['学生',a.student],['企业',a.company],['范围',a.scope],['状态',a.status],['有效期',a.expires],['访问次数',a.access]],{text:'所有查看、下载与撤权动作都进入不可变审计日志。',kind:'warning'})});document.getElementById('privacyReport').onclick=function(){U.toast('隐私审计导出已加入后台队列')};document.getElementById('revokeBtn').onclick=function(){U.toast('将检查已过期、已撤回和组织停用后的残留权限')}
  }
  function operations(){
    var root=document.getElementById('pageContent');root.innerHTML=layout('系统运维','查看审批、后台任务、服务健康和不可变审计日志。','<button class="btn btn-outline" id="healthBtn">重新检测</button><button class="btn btn-primary" id="newNotice">发布平台公告</button>','<div class="grid"><div class="card col-4"><div class="card-head"><h2>服务健康</h2><span id="healthTime">检测中</span></div><div class="stack" id="healthList"><div class="row"><div class="ico">业</div><div class="grow"><b>业务 API</b><p>/api/health</p></div>'+U.badge('pending','检测中')+'</div></div></div><div class="card col-8"><div class="card-head"><h2>后台任务</h2><span>耗时操作不阻塞页面</span></div><div class="table-wrap"><table><thead><tr><th>任务</th><th>类型</th><th>发起人</th><th>进度</th><th>状态</th><th>开始时间</th></tr></thead><tbody>'+M.jobs.map(function(j){return'<tr><td class="name-cell"><b>'+j.name+'</b><small>'+j.id+'</small></td><td>'+j.type+'</td><td>'+j.owner+'</td><td><div class="progress"><i style="width:'+j.progress+'%"></i></div></td><td>'+U.badge(j.status)+'</td><td>'+j.started+'</td></tr>'}).join('')+'</tbody></table></div></div><div class="card col-6"><div class="card-head"><h2>待处理审批</h2><span>'+M.approvals.length+' 项</span></div><div class="stack">'+M.approvals.map(function(a){return'<div class="row"><div class="ico">'+a.type.slice(0,1)+'</div><div class="grow"><b>'+a.title+'</b><p>'+a.id+' · '+a.applicant+' · '+a.time+'</p></div><button class="btn btn-outline btn-sm" data-approve="'+a.id+'">处理</button></div>'}).join('')+'</div></div><div class="card col-6"><div class="card-head"><h2>审计日志</h2><span>只读</span></div><div class="timeline">'+M.audits.map(function(a,i){return'<div class="event"><div class="event-dot">'+(i+1)+'</div><div><b>'+a.actor+' · '+a.action+'</b><p>'+a.target+' · '+a.time+' · '+a.ip+'</p></div></div>'}).join('')+'</div></div></div>');
    /* 服务健康：实时检测真实组件，不再写死「PostgreSQL / 待配置」 */
    function loadHealth(){
      var box=document.getElementById('healthList');if(!box)return;
      AdminStore.get('health','/api/health').then(function(h){
        var time=document.getElementById('healthTime');
        if(!h){if(time)time.textContent='检测失败';box.innerHTML='<div class="row"><div class="ico">业</div><div class="grow"><b>业务 API</b><p>/api/health 未连接</p></div>'+U.badge('failed','未连接')+'</div>';return}
        if(time)time.textContent='最近检测 '+new Date().toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit'});
        box.innerHTML=
          '<div class="row"><div class="ico">业</div><div class="grow"><b>业务 API</b><p>'+U.esc(h.status)+' · 8080</p></div>'+U.badge('success','已连接')+'</div>'+
          '<div class="row"><div class="ico">库</div><div class="grow"><b>MySQL</b><p>'+U.esc(h.database)+' · 3306</p></div>'+U.badge('success','已连接')+'</div>'+
          '<div class="row"><div class="ico">能</div><div class="grow"><b>Skill 服务</b><p>'+(h.skill_connected?('已注册 '+h.skill_count+' 项 · 8090'):'8090 未连接')+'</p></div>'+U.badge(h.skill_connected?'success':'failed',h.skill_connected?'已接入':'未接入')+'</div>'+
          '<div class="row"><div class="ico">模</div><div class="grow"><b>运行模式</b><p>'+(h.demo_mode?'本地演示模式（按路径注入演示身份）':'正式模式（需登录）')+'</p></div>'+U.badge(h.demo_mode?'pending':'success',h.demo_mode?'演示':'正式')+'</div>';
      });
    }
    loadHealth();
    root.addEventListener('click',function(e){var b=e.target.closest('[data-approve]');if(!b)return;var a=M.approvals.find(function(x){return x.id===b.dataset.approve});details(a.title,[['审批编号',a.id],['类型',a.type],['申请人',a.applicant],['时间',a.time]],{text:'处理结果、理由和依据将写入审计日志。',kind:'warning'})});document.getElementById('healthBtn').onclick=function(){loadHealth();U.toast('已重新检测服务健康')};document.getElementById('newNotice').onclick=function(){U.toast('已打开公告草稿')}
  }
  function settings(){
    var s=M.settings,root=document.getElementById('pageContent');root.innerHTML=layout('系统设置','配置业务服务、会话策略、数据保留和审计周期。','','<div class="grid"><div class="card col-7"><div class="card-head"><h2>业务服务</h2><span>与三端共用</span></div><label style="display:block;margin-bottom:14px"><b>API 地址</b><input class="field" id="apiBase" style="display:block;width:100%;margin-top:7px" value="'+s.apiBase+'"></label><div class="notice">管理端与企业端、教师端、学生端连接同一业务服务、数据库和本地 Skill 网关。</div><div class="actions" style="margin-top:16px"><button class="btn btn-primary" id="saveApi">保存地址</button><button class="btn btn-outline btn-sm" id="testApi">检测连接</button></div></div><div class="card col-5"><div class="card-head"><h2>本地运行模式</h2><span>'+U.badge(AdminStore.mock()?'pending':'success',AdminStore.mock()?'离线演示':'真实本地服务')+'</span></div><p style="color:var(--ink-3)">通过 8080 业务后端和 8090 Skill 服务运行；接口异常会明确提示，不会伪装成功。</p></div><div class="card col-12"><div class="card-head"><h2>安全与数据策略</h2><span>修改需要二次确认</span></div><div class="grid"><label class="col-4"><b>会话有效期（分钟）</b><input class="field" style="display:block;width:100%;margin-top:7px" value="'+s.sessionMinutes+'"></label><label class="col-4"><b>业务数据保留（天）</b><input class="field" style="display:block;width:100%;margin-top:7px" value="'+s.retentionDays+'"></label><label class="col-4"><b>审计日志保留（年）</b><input class="field" style="display:block;width:100%;margin-top:7px" value="'+s.auditYears+'"></label></div><div class="actions" style="margin-top:16px"><button class="btn btn-primary" id="savePolicy">保存策略</button></div></div><div class="card col-12"><div class="card-head"><h2>本地 Skill 接入</h2><span>五项能力统一网关</span></div><div class="table-wrap"><table><thead><tr><th>接入域</th><th>用途</th><th>当前状态</th><th>管理原则</th></tr></thead><tbody><tr><td>Skill 能力</td><td>批量解析、自动操作、多模态、RAG、报告</td><td>'+U.badge('success','5 项已注册')+'</td><td>全部经 8080 网关调用 8090 本地服务</td></tr><tr><td>校内教学平台</td><td>任务下发与进度回填</td><td>'+U.badge('success','本地适配器')+'</td><td>写操作保留审批、回执和同步日志</td></tr><tr><td>硬件数据网关</td><td>设备工况与操作日志</td><td>'+U.badge('success','本地适配器')+'</td><td>本地可调用，外部硬件上线时替换连接配置</td></tr></tbody></table></div></div></div>');
    document.getElementById('saveApi').onclick=function(){AdminStore.setBase(document.getElementById('apiBase').value);U.toast('业务服务地址已保存')};document.getElementById('testApi').onclick=function(){AdminSkills.status().then(function(v){U.toast(v&&v.available===5?'连接正常：5 项 Skill 可用':'Skill 状态异常')}).catch(function(){U.toast('连接失败，请先运行一键启动登录')})};document.getElementById('savePolicy').onclick=function(){U.toast('安全策略变更将进入审计日志')}
  }
  /* ---------------- 数据维护：导出、新增、修改、导入、删除 ---------------- */
  var FIELD_LABEL={code:'编号/编码',name:'名称',title:'标题',type:'类型',status:'状态',owner_name:'负责人',username:'登录账号',display_name:'显示名',email:'邮箱',student_no:'学号',organization_id:'所属组织ID',academic_year:'学年',teacher_user_id:'教师ID',project_id:'项目ID',company_org_id:'企业组织ID',school_org_id:'学校组织ID',creator_user_id:'创建人ID',requirement_id:'需求ID',stage_no:'阶段序号',description:'描述',acceptance:'验收标准',duration_hours:'课时',due_at:'截止时间',started_at:'开始日期',progress:'进度',urgent:'加急',deliverables:'交付物',business_goal:'业务目标',task_stage_id:'阶段ID',student_user_id:'学生ID',assignment_id:'任务分配ID',attempt_no:'提交次数',note:'备注',score:'分数',comment:'评语',evidence_summary:'证据摘要',evaluator_user_id:'评价人ID',asker_user_id:'提问人ID',question:'问题',summary:'摘要',scope:'范围',version:'版本',role_name:'岗位名称',requester_user_id:'申请人ID',company_user_id:'企业用户ID',round_no:'轮次',result:'结论',user_id:'用户ID',body:'正文',level:'级别',href:'跳转',event_type:'事件类型',detail:'详情',owner_user_id:'负责人ID'};
  function dl(url){window.location.href=url}
  function api(path,options){return fetch(AdminStore.base()+path,Object.assign({headers:{Accept:'application/json'}},options||{})).then(function(r){return r.json().catch(function(){return{}})}).then(function(b){if(b&&b.code&&b.code!=='OK')throw new Error(b.message||b.code);return b&&b.data!==undefined?b.data:b})}
  function dataAdmin(){
    var root=document.getElementById('pageContent');
    root.innerHTML=layout('数据维护','导出业务数据、新增与导入记录，所有写操作进入不可变审计日志。','<button class="btn btn-outline" id="refreshData">刷新</button>','<div class="notice">数据集与字段由服务端白名单控制，不接受任意表名或列名。导出 CSV 带 BOM，Excel 打开不乱码；只读数据集（审计日志、Skill 运行记录、业务附件）只可导出。</div><div class="card" style="margin-top:16px"><div class="toolbar"><input class="field" id="dsSearch" placeholder="搜索数据集"></div><div class="table-wrap"><table><thead><tr><th>数据集</th><th>说明</th><th>记录数</th><th>可维护</th><th style="width:300px">操作</th></tr></thead><tbody id="dsRows"><tr><td colspan="5" class="empty">加载中…</td></tr></tbody></table></div></div>');
    var list=[];
    function paint(arr){
      document.getElementById('dsRows').innerHTML=arr.map(function(d){
        return '<tr><td class="name-cell"><b>'+U.esc(d.label)+'</b><small>'+U.esc(d.name)+'</small></td><td>'+U.esc(d.fields&&d.fields.length?d.fields.slice(0,5).map(function(f){return FIELD_LABEL[f]||f}).join('、')+(d.fields.length>5?' 等 '+d.fields.length+' 项':''):'只读')+'</td><td><b>'+d.rows+'</b></td><td>'+U.badge(d.editable?'success':'pending',d.editable?'可新增':'只读')+'</td><td><button class="btn btn-outline btn-sm" data-exp-csv="'+d.name+'">导出 CSV</button> <button class="btn btn-outline btn-sm" data-exp-json="'+d.name+'">查看 JSON</button>'+(d.editable?' <button class="btn btn-primary btn-sm" data-new="'+d.name+'">新增</button>':'')+'</td></tr>';
      }).join('')||'<tr><td colspan="5" class="empty">没有匹配的数据集</td></tr>';
    }
    function load(){
      api('/api/data/datasets').then(function(d){list=d;paint(list)}).catch(function(e){
        document.getElementById('dsRows').innerHTML='<tr><td colspan="5" class="empty">加载失败：'+U.esc(e.message)+'，请确认业务后端已启动</td></tr>';
      });
    }
    root.addEventListener('click',function(e){
      var csv=e.target.closest('[data-exp-csv]'),js=e.target.closest('[data-exp-json]'),nw=e.target.closest('[data-new]');
      if(csv){U.toast('正在导出 '+csv.dataset.expCsv);dl(AdminStore.base()+'/api/export/'+csv.dataset.expCsv+'?format=csv')}
      if(js){var name=js.dataset.expJson;api('/api/export/'+name+'?format=json&limit=20').then(function(d){
        U.openDrawer(name+' · 前 '+d.rows.length+' 条','<div class="table-wrap"><table><thead><tr>'+Object.keys(d.rows[0]||{}).map(function(k){return'<th>'+U.esc(k)+'</th>'}).join('')+'</tr></thead><tbody>'+d.rows.map(function(r){return'<tr>'+Object.keys(d.rows[0]).map(function(k){return'<td>'+U.esc(String(r[k]==null?'':r[k]).slice(0,40))+'</td>'}).join('')+'</tr>'}).join('')+'</tbody></table></div>');
      }).catch(function(err){U.toast('读取失败：'+err.message)})}
      if(nw){openCreate(nw.dataset.new)}
    });
    document.getElementById('refreshData').onclick=load;
    document.getElementById('dsSearch').addEventListener('input',function(){
      var q=this.value.trim().toLowerCase();
      paint(list.filter(function(d){return d.name.toLowerCase().includes(q)||d.label.includes(q)}));
    });
    function openCreate(name){
      var d=list.find(function(x){return x.name===name});if(!d)return;
      var fields=d.fields||[];
      U.openDrawer('新增 · '+d.label,
        '<div class="notice">带 * 为必填。用户数据集的 password 字段会被哈希存储，不保存明文。</div>'+
        fields.map(function(f){return'<label style="display:block;margin:10px 0"><b>'+U.esc(FIELD_LABEL[f]||f)+'</b><input class="field" style="display:block;width:100%;margin-top:6px" data-f="'+U.esc(f)+'" placeholder="'+U.esc(f)+'"></label>'}).join('')+
        '<div class="actions" style="margin-top:16px"><button class="btn btn-primary" id="doCreate">保存</button><button class="btn btn-outline" id="doImport">批量导入</button></div>'+
        '<div id="importBox" style="display:none;margin-top:16px"><b>批量导入（JSON 数组 或 CSV 首行表头）</b><textarea class="field" id="importText" rows="8" style="display:block;width:100%;margin-top:6px;font-family:monospace" placeholder=\'[{"name":"示例"}]\'></textarea><div class="actions" style="margin-top:10px"><button class="btn btn-primary btn-sm" id="doImportGo">开始导入</button></div></div>');
      document.getElementById('doCreate').onclick=function(){
        var payload={};Array.prototype.forEach.call(document.querySelectorAll('#drawerBody [data-f]'),function(i){if(i.value!=='')payload[i.dataset.f]=i.value});
        api('/api/data/'+name,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}).then(function(r){
          U.toast('已新增，ID：'+r.id);U.closeDrawer();load();
        }).catch(function(e){U.toast('新增失败：'+e.message)});
      };
      document.getElementById('doImport').onclick=function(){var b=document.getElementById('importBox');b.style.display=b.style.display==='none'?'block':'none'};
      document.getElementById('doImportGo').onclick=function(){
        var text=document.getElementById('importText').value.trim();if(!text)return U.toast('请输入 JSON 数组或 CSV');
        var body=text[0]==='['?{rows:JSON.parse(text)}:{csv:text};
        api('/api/import/'+name,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}).then(function(r){
          U.toast('导入完成：成功 '+r.created+' 条，失败 '+(r.failed||0)+' 条');U.closeDrawer();load();
        }).catch(function(e){U.toast('导入失败：'+e.message)});
      };
    }
    load();
  }
  var routes={organizations:organizations,projects:projects,resources:resources,privacy:privacy,operations:operations,data:dataAdmin,settings:settings};document.addEventListener('DOMContentLoaded',async function(){await AdminStore.hydrate();var p=document.body.dataset.page;if(routes[p])routes[p]()});
})();
(function () {
  function skillCard() {
    var root = document.querySelector('#pageContent .grid');
    if (!root || document.getElementById('skillServiceCard')) return;
    Array.from(document.querySelectorAll('.card-head h2')).forEach(function (heading) {
      if (heading.textContent === '后续能力接入') { heading.textContent = '五项 Skill 能力'; if (heading.nextElementSibling) heading.nextElementSibling.textContent = '统一网关已接入'; }
    });
    Array.from(document.querySelectorAll('tbody tr')).forEach(function (row) {
      var cells = row.querySelectorAll('td');
      if (cells.length >= 3 && cells[0].textContent.trim() === 'Skill 能力') cells[2].innerHTML = AdminUI.badge('success', '已接入');
    });
    var card = document.createElement('div');
    card.className = 'card col-12'; card.id = 'skillServiceCard';
    card.innerHTML = '<div class="card-head"><h2>SmartBridge Skills</h2><span id="skillServiceState">检测中</span></div>' +
      '<p style="color:var(--ink-3)">四端共用且仅启用五项能力：批量文件解析、实训系统操作、多模态识别、可追溯知识检索、可视化报告生成。</p>' +
      '<div class="actions"><button class="btn btn-primary" id="checkSkillService">检测 Skill 服务</button>' +
      '<button class="btn btn-outline" id="testSkillReport">生成运维报告</button></div>' +
      '<div class="notice" id="skillServiceDetail" style="margin-top:14px">通过业务后端统一网关调用，执行记录进入同一数据库。</div>';
    root.appendChild(card);
    function check() {
      var state = document.getElementById('skillServiceState'), detail = document.getElementById('skillServiceDetail');
      state.textContent = '检测中';
      AdminSkills.status().then(function (data) { var names = (data.skills || []).map(function (item) { return item.key + '（' + item.state + '）'; }); state.textContent = names.length === 5 ? '5/5 已注册' : '注册异常'; detail.textContent = '能力状态：' + names.join('、'); })
        .catch(function (error) { state.textContent = '服务未启动'; detail.textContent = error.message; });
    }
    document.getElementById('checkSkillService').onclick = check;
    document.getElementById('testSkillReport').onclick = function () {
      AdminSkills.report('平台运维概览', '运维', { metrics: [{ label: '组织数', value: (window.ADMIN_MOCK.organizations || []).length }, { label: '项目数', value: (window.ADMIN_MOCK.projects || []).length }, { label: '后台任务数', value: (window.ADMIN_MOCK.jobs || []).length }], evidence: [{ source: '平台管理系统本地数据库' }] })
        .then(function () { AdminUI.toast('真实 Skill 已生成运维报告'); check(); }).catch(function (error) { AdminUI.toast('生成失败：' + error.message); });
    };
    /* 报告 Skill 已导入训练样本（46 个样本 / 30 项指标 / 5 个报告期）。
       接入位只声明报告期，指标、趋势与口径校验全部由 Skill 的已校验档案给出，
       避免平台侧自己拼指标时口径走样。 */
    var reportCard = document.createElement('div');
    reportCard.className = 'card col-12'; reportCard.id = 'reportProfileCard';
    reportCard.innerHTML = '<div class="card-head"><h2>运营月报（按已校验报告期）</h2><span id="reportProfileState">读取中</span></div>' +
      '<p style="color:var(--ink-3)">报告类型与报告期交给报告 Skill 的已校验档案，直接输出金标准口径的指标与趋势，不需要平台侧自行拼指标。</p>' +
      '<div class="actions"><label style="display:flex;align-items:center;gap:8px"><b>报告期</b>' +
      '<select class="field" id="reportPeriod" style="min-width:160px"></select></label>' +
      '<button class="btn btn-primary" id="genPeriodReport">生成运营月报</button></div>' +
      '<div class="notice" id="reportProfileDetail" style="margin-top:14px">正在读取报告档案…</div>';
    root.appendChild(reportCard);
    AdminSkills.reportProfile().then(function (profile) {
      var state = document.getElementById('reportProfileState');
      var detail = document.getElementById('reportProfileDetail');
      var select = document.getElementById('reportPeriod');
      var periods = (profile && profile.periods) || [];
      var summary = (profile && profile.training_summary) || {};
      if (!periods.length) { state.textContent = '未导入'; detail.textContent = '报告档案为空，请先执行 Skill 训练数据导入。'; return; }
      state.textContent = '已校验 ' + periods.length + ' 个报告期';
      detail.textContent = '口径版本 ' + profile.version + ' · 样本 ' + summary.samples + ' 个 · 指标 ' + summary.metrics + ' 项 · 校验源 ' + (profile.sources || []).length + ' 份';
      select.innerHTML = periods.map(function (item) { return '<option value="' + U.esc(item) + '">' + U.esc(item) + '</option>'; }).join('');
    }).catch(function (error) {
      document.getElementById('reportProfileState').textContent = '未导入';
      document.getElementById('reportProfileDetail').textContent = error.message;
    });
    document.getElementById('genPeriodReport').onclick = function () {
      var period = document.getElementById('reportPeriod').value;
      if (!period) { AdminUI.toast('请先选择报告期'); return; }
      AdminSkills.report(period + ' 运营月报', '运营月报', { report_period: period }).then(function (env) {
        var o = (env && env.output) || {};
        var link = (o.download_url || '').replace(/^\//, AdminStore.base() + '/');
        document.getElementById('reportProfileDetail').innerHTML =
          '已生成：' + U.esc(o.title || '') + ' · 指标 ' + (o.metrics || []).length + ' 项 · 趋势图 ' + (o.charts || []).length + ' 个 · ' +
          (link ? '<a href="' + link + '" target="_blank" rel="noopener">下载 HTML 报告</a>' : '报告文件未返回');
        AdminUI.toast('运营月报已按报告期生成');
      }).catch(function (error) { AdminUI.toast('生成失败：' + error.message); });
    };
    check();
  }
  document.addEventListener('DOMContentLoaded', function () {
    if (document.body.dataset.page === 'settings' || document.body.dataset.page === 'operations') {
      var attempts = 0;
      var timer = setInterval(function () {
        attempts += 1; skillCard();
        if (document.getElementById('skillServiceCard') || attempts > 30) clearInterval(timer);
      }, 200);
    }
  });
})();
