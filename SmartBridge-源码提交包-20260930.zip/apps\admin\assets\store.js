(function(){
  var base=localStorage.getItem('admin_api_base')||'http://localhost:8080';
  var mock=location.protocol==='file:';
  var lastError=null;   /* 最近一次请求的真实失败原因（原实现一律吞成 null，排障无从下手） */
  function notifyFailure(url, err) { lastError={url:url,message:String((err&&err.message)||err||'未知错误'),time:new Date().toISOString()}; if (typeof window.dispatchEvent==='function' && typeof window.CustomEvent==='function') window.dispatchEvent(new window.CustomEvent('smartbridge:api-error',{detail:lastError})); return null; }
  /* AdminStore.action 在写失败时会用它，把服务端真实 message 透出，而不是「管理服务不可用」 */
  function remoteMessage(action) { return action + '失败：' + (lastError ? lastError.message : '管理服务不可用'); }
  function request(path,options){var ctrl=new AbortController(),timer=setTimeout(function(){ctrl.abort()},2500),target=base+path;return fetch(target,Object.assign({signal:ctrl.signal,credentials:'include',headers:{Accept:'application/json'}},options||{})).then(function(r){clearTimeout(timer);if(!r.ok){return r.text().then(function(t){var m='';try{var b=JSON.parse(t);m=(b&&(b.message||b.code))||''}catch(e){m=String(t||'').slice(0,120)}throw new Error(m?m+'（HTTP '+r.status+'）':'HTTP '+r.status)})}
    return r.json()}).then(function(j){return j&&j.data!==undefined?j.data:j}).catch(function(e){clearTimeout(timer);return notifyFailure(target,e)})}
  window.AdminStore={
    get:function(key,path){return request(path||('/api/admin/'+key)).then(function(v){return v!==null?v:(mock?window.ADMIN_MOCK[key]:null)})},
    hydrate:function(){
      var keys=['profile','kpis','organizations','users','projects','approvals','resources','authorizations','jobs','audits','settings'];
      return Promise.all(keys.map(function(key){return request('/api/admin/'+key).then(function(value){if(value!==null&&value!==undefined){window.ADMIN_MOCK[key]=value;return true}return false})}))
        .then(function(results){if(results.some(Boolean)){mock=false;var state=document.querySelector('.side-foot .state span');if(state)state.textContent='业务服务已连接'}return window.ADMIN_MOCK})
    },
    action: function (path, payload) { return request(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload || {}) }).then(function (v) { if (v !== null) return { live: true, data: v }; if (mock) return { live: false, data: { status: 'local_draft' } }; throw new Error(remoteMessage('管理服务调用')); }); },
    lastError:function(){return lastError},clearError:function(){lastError=null},
    base:function(){return base},setBase:function(v){base=String(v||'').replace(/\/$/,'');localStorage.setItem('admin_api_base',base)},mock:function(){return mock},setMock:function(v){mock=!!v;localStorage.setItem('admin_mock',String(mock))}
  };
})();
(function () {
  var base = '';
  function request(path, options) {
    return fetch(base + path, options || {}).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (body) {
        if (!response.ok) throw new Error(body.message || body.error || ('HTTP ' + response.status));
        return body.data || body;
      });
    });
  }
  window.AdminSkills = {
    base: function () { return base; },
    setBase: function () {},
    status: function () { return request('/api/skills/status'); },
    catalog: function () { return request('/api/skills/catalog'); },
    bindings: function () { return request('/api/workflows/bindings'); },
    trainingSystems: function () { return request('/api/skills/training/systems'); },
    trainingPlan: function (input) { return request('/api/skills/training/plan', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(input || {}) }); },
    multimodalStatus: function () { return request('/api/skills/multimodal/status'); },
    reportProfile: function () { return request('/api/skills/report/profile'); },
    parseBatch: function (files, purpose) {
      var form = new FormData(); Array.from(files || []).forEach(function (file) { form.append('files', file, file.name); });
      form.append('purpose', purpose || '平台资源批量解析');
      return request('/api/skills/parse-batch', { method: 'POST', body: form });
    },
    rag: function (query, scopes, projectId) {
      return request('/api/skills/rag/query', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ query: query, scopes: scopes || [], project_id: projectId || '', top_k: 5 }) });
    },
    report: function (title, kind, data) {
      return request('/api/skills/report', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ title: title, kind: kind, data: data || {} }) });
    }
  };
})();
