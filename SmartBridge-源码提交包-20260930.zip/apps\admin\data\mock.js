window.ADMIN_MOCK={
  profile:{name:'周启明',role:'平台管理员',org:'智训桥运营中心'},
  kpis:[{label:'入驻组织',value:4,sub:'学校 1 · 企业 3',tone:'#f0edff'},{label:'进行中项目',value:1,sub:'PRJ-0917-001',tone:'#eaf1ff'},{label:'待处理审批',value:4,sub:'2 项需今日处理',tone:'#fff4df'},{label:'风险事件',value:3,sub:'学生滞后 2 · 权限 1',tone:'#fff0f2'}],
  organizations:[
    {id:'ORG-S-001',name:'山东智能制造职业学院',type:'学校',owner:'李慧敏',members:33,status:'success',created:'2026-03-10'},
    {id:'ORG-C-001',name:'华明制造',type:'企业',owner:'张工',members:18,status:'success',created:'2026-03-12'},
    {id:'ORG-C-008',name:'云启数据科技',type:'企业',owner:'赵宁',members:9,status:'success',created:'2026-08-18'},
    {id:'ORG-C-011',name:'恒成软件',type:'企业',owner:'陈刚',members:12,status:'pending',created:'2026-09-22'}
  ],
  users:[
    {id:'U-1001',name:'李慧敏',account:'lihm@example.edu.cn',org:'山东智能制造职业学院',role:'教师',scope:'2024级数据科学班',status:'success',last:'今天 11:42'},
    {id:'U-1002',name:'陈晓雨',account:'2024010156',org:'山东智能制造职业学院',role:'学生',scope:'本人数据',status:'success',last:'今天 10:18'},
    {id:'U-1003',name:'张工',account:'zhang@huaming.example',org:'华明制造',role:'企业管理员',scope:'华明制造全部项目',status:'success',last:'昨天 18:06'},
    {id:'U-1004',name:'王浩宇',account:'2024010125',org:'山东智能制造职业学院',role:'学生',scope:'本人数据',status:'success',last:'今天 09:51'},
    {id:'U-1005',name:'赵宁',account:'zhaon@yunqi.example',org:'云启数据科技',role:'企业成员',scope:'已授权候选人',status:'success',last:'今天 09:35'}
  ],
  projects:[
    {id:'PRJ-0917-001',name:'设备点检台账整理与异常周报生成',company:'华明制造',school:'山东智能制造职业学院',teacher:'李慧敏',klass:'2024级数据科学班',stage:'过程监督',status:'running',progress:63,risk:'王浩宇、刘子豪进度滞后'},
    {id:'REQ-0916-002',name:'出入库报表自动化汇总',company:'恒成软件',school:'待匹配',teacher:'待指派',klass:'待绑定',stage:'需求审核',status:'pending',progress:8,risk:'企业认证待审核'},
    {id:'REQ-0915-003',name:'质量检测数据可视化看板',company:'云启数据科技',school:'待匹配',teacher:'待指派',klass:'待绑定',stage:'需求审核',status:'pending',progress:8,risk:'无'}
  ],
  approvals:[
    {id:'AP-2201',type:'企业认证',title:'恒成软件企业认证',applicant:'陈刚',time:'今天 09:24',level:'urgent',status:'pending'},
    {id:'AP-2202',type:'数据导出',title:'导出 2024级数据科学班过程档案',applicant:'李慧敏',time:'今天 08:50',level:'normal',status:'pending'},
    {id:'AP-2203',type:'案例复用',title:'设备点检台账案例进入校级模板库',applicant:'李慧敏',time:'昨天 16:12',level:'normal',status:'pending'},
    {id:'AP-2204',type:'权限变更',title:'张工申请项目验收权限',applicant:'张工',time:'昨天 14:05',level:'urgent',status:'pending'}
  ],
  resources:[
    {id:'RES-001',name:'设备点检台账整理（脱敏版）',type:'案例',owner:'李慧敏',scope:'校内',version:'v2.0',status:'success',updated:'2026-09-18'},
    {id:'RES-002',name:'周报统计与可追溯明细',type:'模板',owner:'李慧敏',scope:'项目',version:'v1.1',status:'success',updated:'2026-09-17'},
    {id:'RES-003',name:'设备点检验收评分表',type:'评分规则',owner:'华明制造',scope:'项目',version:'v1.0',status:'pending',updated:'2026-09-22'},
    {id:'RES-004',name:'温度阈值与边界判定',type:'知识条目',owner:'李慧敏',scope:'校内',version:'v1.0',status:'success',updated:'2026-09-16'}
  ],
  authorizations:[
    {id:'REQ-2041',student:'陈晓雨',company:'云启数据科技',scope:'匿名能力画像 + 阶段一去重规则作品',status:'pending',expires:'待学生确认',access:0},
    {id:'REQ-2038',student:'陈晓雨',company:'恒成软件',scope:'匿名能力画像',status:'pending',expires:'待学生确认',access:0},
    {id:'AUTH-2038',student:'候选 A',company:'华明制造',scope:'画像 + 作品 + 联系方式',status:'success',expires:'2026-10-31',access:6},
    {id:'AUTH-1988',student:'候选 D',company:'恒成软件',scope:'匿名画像',status:'failed',expires:'已拒绝',access:0}
  ],
  jobs:[
    {id:'JOB-5104',name:'PRJ-0917-001 成果包导出',type:'文件任务',owner:'张工',progress:76,status:'running',started:'11:28'},
    {id:'JOB-5103',name:'2024级数据科学班成员导入',type:'数据导入',owner:'周启明',progress:100,status:'success',started:'10:06'},
    {id:'JOB-5102',name:'企业验收提醒重发',type:'消息任务',owner:'系统',progress:100,status:'success',started:'09:42'},
    {id:'JOB-5101',name:'项目文件完整性校验',type:'维护任务',owner:'系统',progress:34,status:'running',started:'08:15'}
  ],
  audits:[
    {actor:'周启明',action:'审核企业认证资料',target:'恒成软件',time:'今天 11:36',ip:'10.20.4.18'},
    {actor:'李慧敏',action:'调整学生评价 78 → 82',target:'PRJ-0917-001 / 王浩宇',time:'今天 10:18',ip:'10.20.8.31'},
    {actor:'张工',action:'查看已授权候选人材料',target:'AUTH-2038',time:'今天 09:55',ip:'172.18.2.17'},
    {actor:'系统',action:'拒绝越权文件下载',target:'PRJ-0917-001 / FILE-8012',time:'今天 09:41',ip:'172.18.2.44'}
  ],
  settings:{apiBase:'http://localhost:8080',sessionMinutes:120,retentionDays:365,auditYears:3,mock:true}
};
