# Company web application

The enterprise workspace is served at `/company/` by `services/api`.

It covers requirement intake, project tracking, acceptance, artifacts, talent, reports, templates and messages. Skill calls use the shared `/shared/skill-adapter.js` adapter and the API gateway.

See `integration-points.md` for the capability map. Run `node tools/smoke-all.js` from the repository root for page verification.
