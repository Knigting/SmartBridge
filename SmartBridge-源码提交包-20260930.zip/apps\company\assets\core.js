/* ==========================================================================
   智训桥 SmartBridge · 企业端 —— 平台能力接入层（window.CORE）
   --------------------------------------------------------------------------
   本文件只做一件事：为命题要求的「五类平台核心自动化技能」与「两套校内实训
   系统」预留统一接入位。**能力本体不在这里实现** —— 后端写好之后，通过
   register() / registerSystem() 挂适配器接进来，页面与交互代码一行都不用改。

   它负责四件事：
     1) 声明统一契约：任何能力的入参与返回都是同一个 envelope 形状
        { skill, ok, code, mode, input, output, evidence[], meta }
     2) invoke() 统一派发；未接入时返回契约形状的 not_connected 结果，
        **绝不抛异常** —— 调用方直接当「这块数据暂时没有」处理，界面不空转
     3) 记录调用留痕 CORE.trace —— 这是「确实调用了平台能力」的证据链
     4) 内置 mock 通道：演示与离线可直接跑通，返回一律标 mode:'mock'，
        界面上显示为「模拟通道」，不会与真实对接混淆

   ── 后端接入方式（写后端时照抄）──────────────────────────────────────
     CORE.register('parse-batch', {
       connected: true,
       describe: 'POST /api/parse-batch',
       run(payload, ctx) {
         return fetch('/api/parse-batch', { method:'POST',
           headers:{'Content-Type':'application/json'},
           body: JSON.stringify(payload) }).then(r => r.json());  // → { output, evidence }
       }
     });

     两套校内实训系统各自注册（命题硬性要求第 2 条：≥2 套系统互通）：
     CORE.registerSystem('lms',  { connected:true, write(…){}, read(…){}, describe:'校内实训教学平台 HTTP API' });
     CORE.registerSystem('edge', { connected:true, write(…){}, read(…){}, describe:'实训硬件数据网关 MQTT/OPC-UA' });

     后端就绪后关掉模拟：CORE.setMock(false);

   ── 页面怎么用接入位 ──────────────────────────────────────────────
     页面只声明「哪儿用」，不写调用逻辑：
       <div data-cap="D2" data-skill="rag" data-args='{"query":"…"}'></div>
     shell.js 会自动调 CORE.call(skill, hookId, args) 并把结果画成接入位卡片。
     hookId 与 CORE.hooks 一一对应，可在「设置」页看到完整清单与状态。

   加载顺序：data/mock.js → assets/core.js → assets/store.js → assets/shell.js → 页面脚本
   ========================================================================== */
window.CORE = (function () {
  'use strict';

  var VERSION = '1.0.0';
  var nowISO = function () { return new Date().toISOString(); };

  /* ============================================================ 五类能力 */
  var SKILLS = {
    'parse-batch': {
      key: 'A', label: '文件批量解析', short: '批量解析',
      demand: '命题硬性要求第 1 条（必调技能之一）',
      contract: 'files: Array<{name,ext,size}> → { files:[{ name, type, rows|pages, fields[], text }] }',
      adapts: 'Word / Excel / PDF / 图片；单批 ≥ 2 份才算「批量」'
    },
    'training': {
      key: 'B', label: '实训系统自动操作', short: '跨系统操作',
      demand: '命题硬性要求第 1 条 + 第 2 条（≥2 套校内实训系统 / 硬件互通）',
      contract: '(system, {op:"write"|"read", action, payload|query}) → { system, action, ref|rows, evidence[] }',
      adapts: 'lms = 校内实训教学平台（任务下发 / 班级提交与成绩）；edge = 实训硬件数据网关（设备工况与操作日志）'
    },
    'multimodal': {
      key: 'C', label: '语音 / 图像多模态识别', short: '多模态',
      demand: '命题硬性要求第 1 条（必调技能之一）',
      contract: '{ kind:"image"|"audio", source, purpose } → { kind, text, fields, confidence, evidence[] }',
      adapts: '点检表拍照 → 表格结构化；仪表 / 实操照片 → 读数与步骤判定；语音 → 转写'
    },
    'rag': {
      key: 'D', label: 'RAG 知识库检索', short: 'RAG 检索',
      demand: '命题硬性要求第 1 条 + 创新点「企业工艺垂直知识库」',
      contract: '(query, { scopes:[], topK }) → { hits:[{ doc, page, snippet, score }], answer, evidence[] }',
      adapts: 'scopes：企业工艺文档库 / 岗位能力标准 / 学校课程标准 / 历史任务库 / 验收规范'
    },
    'report': {
      key: 'E', label: '数据可视化报告生成', short: '可视化报告',
      demand: '命题硬性要求第 1 条 + 交付物⑥「量化效益分析报告」',
      contract: '(data, { kind, format }) → { title, sections[], charts:[{ type, title, series }], file, evidence[] }',
      adapts: 'kind：量化效益 / 人才获取 / 执行进度 / 验收记录；format：html | pdf | docx'
    }
  };

  /* ============================================================ 两套校内实训系统
     命题硬性要求第 2 条：至少 2 套校内实训系统 / 实训硬件的数据互通与跨系统融合。
     本端按「一套真接 + 一套适配器接口」思路预留，当前均走模拟通道。 */
  var SYSTEMS = [
    {
      id: 'lms', label: '校内实训教学平台', kind: 'api', protocol: 'HTTP API',
      scope: '实训题库 · 任务下发 · 班级提交 · 成绩回填',
      contract: 'write: 下发转化后的实训任务包 · read: 拉班级提交进度与成绩',
      place: '接入位 B1 / B2',
      vendor: '某职业学院实训教学平台（演示）'
    },
    {
      id: 'edge', label: '实训硬件数据网关', kind: 'stream', protocol: 'MQTT / OPC-UA',
      scope: '数控实训台 · 机器人工作站 · 工业物联网采集端',
      contract: 'write: 下发固定样例与实训参数 · read: 拉设备工况与操作日志',
      place: '平台侧统一接入',
      vendor: '实训中心设备联网网关（演示）'
    }
  ];

  /* ============================================================ 接入位清单
     id    接入位编号，页面上以 data-cap="id" 声明
     skill 所属能力
     page  所在页面
     where 业务位置（用于设置页清单）
     wired true = 界面已留好调用点                                            */
  var HOOKS = [
    { id: 'A1', skill: 'parse-batch', page: 'demand.html',     where: '发起需求 · 上传多个班组的点检样表，一次解析出字段与行数', wired: true },
    { id: 'A2', skill: 'parse-batch', page: 'project.html',    where: '我的项目 · 资料区批量解析企业侧原始文档为需求卡草稿',     wired: true },
    { id: 'A3', skill: 'parse-batch', page: 'acceptance.html', where: '验收中心 · 成果包材料完整性批量检查（4 项必交材料）',      wired: true },

    { id: 'B1', skill: 'training',    page: 'project.html',    where: '我的项目 · 向校内实训教学平台下发转化后的实训任务包',    wired: true, sys: 'lms' },
    { id: 'B2', skill: 'training',    page: 'report.html',     where: '数据报告 · 从教学平台拉班级提交进度与成绩（跨系统回填）', wired: true, sys: 'lms' },
    { id: 'C1', skill: 'multimodal',  page: 'demand.html',     where: '发起需求 · 现场点检表照片识别为结构化表格',              wired: true },
    { id: 'C2', skill: 'multimodal',  page: 'acceptance.html', where: '验收中心 · 仪表 / 实操照片读数与步骤判定（客观正确性）',  wired: true },
    { id: 'C3', skill: 'multimodal',  page: 'demand.html',     where: '发起需求 · 一线主管语音口述需求转写为正文',              wired: true },

    { id: 'D1', skill: 'rag',         page: 'project.html',    where: '我的项目 · 技能与阶段对标岗位能力标准 / 学校课程标准',   wired: true },
    { id: 'D2', skill: 'rag',         page: 'acceptance.html', where: '验收中心 · 按企业验收规范与工艺文档逐条比对',            wired: true },
    { id: 'D3', skill: 'rag',         page: 'report.html',     where: '数据报告 · 检索历史同类任务工时，形成人工基线与效益对照', wired: true },
    { id: 'D4', skill: 'rag',         page: 'talent.html',     where: '人才对接 · 按岗位能力标准匹配候选人与待验证项',          wired: true },

    { id: 'E1', skill: 'report',      page: 'report.html',     where: '数据报告 · 生成《量化效益分析报告》（交付物⑥）',         wired: true },
    { id: 'E2', skill: 'report',      page: 'talent.html',     where: '人才对接 · 生成候选能力画像与证据摘要报告',              wired: true },
    { id: 'E3', skill: 'report',      page: 'report.html',     where: '数据报告 · 每周生成执行进度周报',                        wired: true }
  ];

  /* ============================================================ 适配器注册 */
  var adapters = {};   /* skillKey → { connected, run, describe } */
  var systems = {};    /* sysId    → { connected, write, read, describe } */
  var config = { mock: true, endpoint: '', timeout: 30000 };
  var trace = [];

  function register(skill, adapter) {
    if (!SKILLS[skill]) return false;
    adapters[skill] = adapter || null;
    return true;
  }
  function registerSystem(id, adapter) {
    if (!SYSTEMS.some(function (s) { return s.id === id; })) return false;
    systems[id] = adapter || null;
    return true;
  }
  function setMock(on) { config.mock = !!on; return config.mock; }
  function useEndpoint(url) { config.endpoint = String(url || ''); return config.endpoint; }

  /* ============================================================ 统一契约 */
  function envelope(skill, input, o) {
    o = o || {};
    return {
      skill: skill,
      version: VERSION,
      ok: !!o.ok,
      code: o.code || (o.ok ? 'ok' : 'not_connected'),
      mode: o.mode || 'none',                 /* live | mock | none */
      input: input || null,
      output: o.output || null,
      evidence: o.evidence || [],
      error: o.error || '',
      meta: {
        at: nowISO(),
        ms: o.ms == null ? 0 : o.ms,
        adapter: o.adapter || '',
        skillLabel: (SKILLS[skill] || {}).label || skill,
        hookId: o.hookId || ''
      }
    };
  }

  function record(env, hookId) {
    trace.push({
      at: env.meta.at, skill: env.skill, hook: hookId || '',
      mode: env.mode, ok: env.ok, code: env.code, evidence: env.evidence.length
    });
    if (trace.length > 200) trace.splice(0, trace.length - 200);
    return env;
  }

  /* ============================================================ mock 通道
     仅为演示与离线自测存在；每条都带 mode:'mock' 与 evidence，便于与真接区分。
     数据取自方案中的设备点检案例，与其它两端保持一致。 */
  var MOCK = {
    'parse-batch': function (input) {
      var files = (input && input.files) || [];
      var list = files.length ? files : [
        { name: '点检样表_一号线_第4周.xlsx', ext: 'xlsx', size: '842 KB' },
        { name: '点检样表_二号线_第4周.xlsx', ext: 'xlsx', size: '796 KB' },
        { name: '点检样表_三号线_第4周.xlsx', ext: 'xlsx', size: '911 KB' },
        { name: 'equipment-register-guide.docx', ext: 'docx', size: '134 KB' }
      ];
      var FIELDS = ['设备编号', '日期', '温度', '班组', '点检人', '备注'];
      return {
        output: {
          total: list.length,
          fields: FIELDS,
          files: list.map(function (f) {
            var n = String((f && f.name) || 'file');
            var ext = (n.split('.').pop() || '').toLowerCase();
            var sheet = /^(xls|xlsx|csv)$/.test(ext);
            var img = /^(jpg|jpeg|png|webp)$/.test(ext);
            return {
              name: n,
              type: sheet ? '表格' : (img ? '图片' : '文档'),
              rows: sheet ? (n.indexOf('一号线') > -1 ? 186 : n.indexOf('二号线') > -1 ? 174 : 203) : undefined,
              pages: img ? undefined : (sheet ? 3 : 6),
              fields: sheet ? FIELDS : (img ? [] : ['设备编号', '温度', '班组']),
              text: sheet ? '已抽出 6 个字段列，表头一致，可直接并入统一台账' : '已抽出正文段落与两处表格'
            };
          }),
          anomalies: [
            { type: '缺失值', count: 7, note: '温度列为空，需进入待核查清单' },
            { type: '单位混用', count: 12, note: '三号线部分班组使用华氏度' },
            { type: '重复记录', count: 3, note: '同一设备同一时段重复提交' }
          ]
        },
        /* evidence 只放真实存在的字段，避免出现空值占位；后端按同样约定返回即可 */
        evidence: list.slice(0, 4).map(function (f) {
          var n = String((f && f.name) || 'file');
          var ext = (n.split('.').pop() || '').toLowerCase();
          var e = { file: n };
          if (/^(xls|xlsx|csv)$/.test(ext)) { e.sheet = 'Sheet1'; e.range = 'A1:F203'; }
          else { e.page = 1; }
          return e;
        })
      };
    },

    'training': function (input) {
      var sys = (input && input.system) || 'lms';
      var op = (input && input.op) || 'read';
      var action = (input && input.action) || '';
      if (sys === 'edge') {
        return {
          output: {
            system: 'edge', op: op, action: action || 'read-device-log',
            rows: [
              { device: '数控实训台 CNC-02', metric: '主轴运行时长', value: '12.4 h', status: '正常' },
              { device: '机器人工作站 RB-11', metric: '示教轨迹点数', value: '38 点', status: '正常' },
              { device: '工业物联网网关 GW-07', metric: '采集点位在线率', value: '99.2%', status: '正常' },
              { device: '温度采集模块 TM-05', metric: '固定样例回放一致性', value: '5 / 5 通过', status: '通过' }
            ],
            receipt: '已与实训硬件数据网关建立只读会话（模拟）'
          },
          evidence: [{ system: 'edge', protocol: 'MQTT / OPC-UA', topic: 'training/edge/tm-05', note: '模拟通道 · 非真实对接' }]
        };
      }
      return {
        output: {
          system: 'lms', op: op, action: action || 'read-class-progress',
          ref: 'LMS-TASK-2026-0917-008',
          receipt: op === 'write'
            ? '任务包已登记到校内实训教学平台题库；对应班级已收到实训任务（模拟）'
            : '已拉取班级提交进度与成绩（模拟）',
          rows: [
            { cls: '机械设计 2203', submitted: 28, total: 32, avg: 88, status: '进行中' },
            { cls: '机械设计 2202', submitted: 26, total: 30, avg: 85, status: '进行中' },
            { cls: '机电一体化 2201', submitted: 31, total: 31, avg: 91, status: '已提交' }
          ]
        },
        evidence: [{ system: 'lms', protocol: 'HTTP API', endpoint: '/api/teaching/task-package', note: '模拟通道 · 非真实对接' }]
      };
    },

    'multimodal': function (input) {
      var kind = (input && input.kind) || 'image';
      if (kind === 'audio') {
        return {
          output: {
            kind: 'audio',
            text: '三号线的点检表里温度一会儿写摄氏度一会儿写华氏度，学生整理周报的时候老出错，想让他们统一一下。',
            fields: { 设备: '三号线', 问题: '温度单位混用', 期望: '统一单位并生成周报' },
            confidence: 0.86
          },
          evidence: [{ kind: 'audio', duration: '18.2s', note: '模拟通道 · 非真实转写' }]
        };
      }
      return {
        output: {
          kind: 'image',
          text: '现场点检表照片 → 识别出表头 6 列、数据行 28 行',
          fields: { 表头: '设备编号 / 日期 / 温度 / 班组 / 点检人 / 备注', 行数: '28', 单位混用: '是（℃ 与 ℉ 混排）' },
          confidence: 0.81
        },
        evidence: [{ kind: 'image', file: (input && input.source) || 'on-site-inspection-sheet-line-3.jpg', note: '模拟通道 · 非真实识别' }]
      };
    },

    'rag': function (input) {
      var q = (input && input.query) || '';
      var scopes = (input && input.scopes) || [];
      return {
        output: {
          query: q,
          scopes: scopes,
          answer: '已在企业工艺库、岗位能力标准与验收规范中命中相关条目，可用于校正技能标签与验收口径。',
          hits: [
            { doc: '设备点检作业指导书', page: 7, snippet: '温度超过 80℃ 判为异常；等于 80℃ 为边界正常值，边界值不得四舍五入。', score: 0.91, scope: '企业工艺文档库' },
            { doc: '设备数据维护岗 · 岗位能力标准', page: 3, snippet: '能按标准完成台账字段统一、异常识别与周报输出，错误率低于 3%。', score: 0.87, scope: '岗位能力标准' },
            { doc: '数据处理实务 · 课程标准', page: 12, snippet: '实训内容应覆盖数据清洗、异常判定、结果呈现三个层级。', score: 0.79, scope: '学校课程标准' },
            { doc: '历史任务库 · 点检台账类（11 条）', page: 1, snippet: '同类任务平均人工工时 15.2 小时/月，返修率 1.4 次/任务。', score: 0.74, scope: '历史任务库' }
          ]
        },
        evidence: [
          { doc: '设备点检作业指导书', page: 7 },
          { doc: '设备数据维护岗 · 岗位能力标准', page: 3 },
          { doc: '历史任务库 · 点检台账类（11 条）', page: 1 }
        ]
      };
    },

    'report': function (input) {
      var kind = (input && input.kind) || '量化效益';
      var d = (input && input.data) || {};
      var base = {
        '量化效益': {
          title: '设备点检台账整理 · 量化效益分析报告',
          sections: [
            { h: '结论摘要', p: '人工基线 15.2 小时/月，交付后 6.0 小时/月，节省 9.2 小时（—60.5%）；异常漏检由 4 项/月降至 0 项。' },
            { h: '口径说明', p: '工时取历史同类任务库中位值；异常漏检按企业抽检 200 条记录的复核结果统计。' },
            { h: '改进建议', p: '三号线温度单位混用待确认处理方式；建议下一版把“待核查”口径写入验收规范。' }
          ],
          charts: [
            { type: 'bar', title: '月度工时对照（小时）', series: [{ name: '人工基线', value: 15.2 }, { name: '交付后', value: 6.0 }] },
            { type: 'bar', title: '交付质量指标', series: [{ name: '固定样例通过率', value: 100 }, { name: '异常漏检（项/月）', value: 0 }, { name: '返修次数', value: 1 }] }
          ],
          metrics: [
            { k: '节省工时', v: '9.2 h/月', d: '人工 15.2 → 6.0' },
            { k: '异常漏检', v: '0 项/月', d: '抽检 200 条' },
            { k: '固定样例通过', v: '5 / 5', d: '边界值全部正确' },
            { k: '投入人力', v: '2 人', d: '企业侧仅需验收' }
          ]
        },
        '人才获取': {
          title: '候选人才能力画像与证据摘要',
          sections: [
            { h: '结论摘要', p: '4 名候选人中 2 名已完成授权；异常识别维度最高 92 分，2 人具备可立即投入条件。' },
            { h: '证据来源', p: '以本项目 4 个任务的提交记录、固定样例测试与返修轨迹为依据，非自评。' },
            { h: '面试建议', p: '重点确认“设备维护经验”等待验证项，避免以课堂表现替代岗位证据。' }
          ],
          charts: [
            { type: 'bar', title: '任务匹配度', series: [{ name: '候选A', value: 92 }, { name: '候选B', value: 81 }, { name: '候选C', value: 88 }, { name: '候选D', value: 76 }] },
            { type: 'bar', title: '证据充分度', series: [{ name: '独立完成', value: 3 }, { name: '可立即投入', value: 2 }, { name: '待验证项', value: 4 }] }
          ],
          metrics: [
            { k: '候选人数', v: '4 人', d: '2 人已授权' },
            { k: '最高匹配度', v: '92', d: '异常识别维度' },
            { k: '可立即投入', v: '2 人', d: '每周 ≥10 小时' },
            { k: '待验证项', v: '4 项', d: '建议面试确认' }
          ]
        },
        '执行进度': {
          title: '设备点检项目 · 执行进度周报',
          sections: [
            { h: '本周完成', p: '任务一（数据整理）已通过；任务二（规则实现）等待企业决策后恢复。' },
            { h: '待企业决策', p: '三号线温度单位混用，影响 1 个后续任务，其余任务不受影响。' },
            { h: '下周计划', p: '任务三（成果呈现）启动，按周输出统计与可追溯明细。' }
          ],
          charts: [
            { type: 'bar', title: '任务完成度', series: [{ name: '任务一', value: 100 }, { name: '任务二', value: 60 }, { name: '任务三', value: 0 }, { name: '任务四', value: 0 }] },
            { type: 'bar', title: '班级提交进度', series: [{ name: '2203', value: 88 }, { name: '2202', value: 87 }, { name: '2201', value: 100 }] }
          ],
          metrics: [
            { k: '整体进度', v: '43%', d: '6 / 14 步' },
            { k: '参与班级', v: '3 个', d: '85 人' },
            { k: '提交率', v: '89%', d: '85 / 96 人' },
            { k: '待企业决策', v: '1 项', d: '温度单位混用' }
          ]
        }
      };
      var r = base[kind] || base['量化效益'];
      return {
        output: {
          kind: kind,
          title: r.title,
          sections: r.sections,
          charts: r.charts,
          metrics: (r.metrics || []).map(function (m) { return m; }),
          dataset: d,
          file: 'SmartBridge-' + kind + '报告-2026-0917.html'
        },
        evidence: [{ kind: kind, source: '历史任务库 + 本项目过程档案', note: '模拟通道 · 非真实生成' }]
      };
    }
  };

  /* ============================================================ 统一派发 */
  function invoke(skill, payload, ctx) {
    var t0 = Date.now();
    var hookId = (ctx && ctx.hook) || '';
    var adapter = adapters[skill];
    try {
      if (adapter && (adapter.connected || adapter.run)) {
        return Promise.resolve(adapter.run(payload, ctx || {}))
          .catch(function (e) {
            return record(envelope(skill, payload, {
              ok: false, mode: 'live', code: 'error',
              error: String((e && e.message) || e), hookId: hookId, ms: Date.now() - t0
            }), hookId);
          })
          .then(function (res) {
            if (res && res.skill) return record(res, hookId);
            return record(envelope(skill, payload, {
              ok: true, mode: 'live', code: 'ok',
              output: res && res.output, evidence: (res && res.evidence) || [],
              adapter: (adapter && adapter.describe) || '已接入适配器',
              hookId: hookId, ms: Date.now() - t0
            }), hookId);
          });
      }
      if (config.mock && MOCK[skill]) {
        var out = MOCK[skill](payload, ctx || {});
        return Promise.resolve(record(envelope(skill, payload, {
          ok: true, mode: 'mock', code: 'mock',
          output: out && out.output, evidence: (out && out.evidence) || [],
          adapter: '内置模拟通道', hookId: hookId, ms: Date.now() - t0
        }), hookId));
      }
      return Promise.resolve(record(envelope(skill, payload, {
        ok: false, mode: 'none', code: 'not_connected',
        error: '该能力尚未接入后端实现', hookId: hookId, ms: Date.now() - t0
      }), hookId));
    } catch (e) {
      return Promise.resolve(record(envelope(skill, payload, {
        ok: false, mode: 'none', code: 'error',
        error: String((e && e.message) || e), hookId: hookId, ms: Date.now() - t0
      }), hookId));
    }
  }

  /* ============================================================ 便利方法 */
  function parseBatch(files, ctx) { return invoke('parse-batch', { files: files || [], endpoint: config.endpoint }, ctx); }
  function systemOp(sysId, op, payload, ctx) {
    return invoke('training', {
      system: sysId, op: op,
      action: (payload && payload.action) || '',
      payload: (payload && payload.payload) != null ? payload.payload : null,
      query: (payload && payload.query) != null ? payload.query : null
    }, ctx);
  }
  function multimodal(input, ctx) { return invoke('multimodal', input || {}, ctx); }
  function ragQuery(query, scopes, ctx) { return invoke('rag', { query: query || '', scopes: scopes || [], topK: (ctx && ctx.topK) || 5 }, ctx); }
  function reportGen(data, kind, ctx) { return invoke('report', { data: data || {}, kind: kind || '量化效益', format: (ctx && ctx.format) || 'html' }, ctx); }

  /* 页面统一入口：call(skill, hookId, args) —— 永不抛异常 */
  function call(skill, hookId, args) {
    args = args || {};
    try {
      switch (skill) {
        case 'parse-batch': return parseBatch(args.files || [], { hook: hookId, purpose: args.purpose });
        case 'training': return systemOp(args.system, args.op || 'read', args, { hook: hookId });
        case 'multimodal': return multimodal(args, { hook: hookId });
        case 'rag': return ragQuery(args.query, args.scopes, { hook: hookId });
        case 'report': return reportGen(args.data, args.kind, { hook: hookId, format: args.format });
        default:
          return Promise.resolve(envelope(skill, args, {
            ok: false, code: 'unknown_skill', error: '未知能力：' + skill, hookId: hookId
          }));
      }
    } catch (e) {
      return Promise.resolve(envelope(skill, args, {
        ok: false, code: 'error', error: String((e && e.message) || e), hookId: hookId
      }));
    }
  }

  /* ============================================================ 状态查询 */
  function skillState(key) {
    var a = adapters[key];
    if (a && (a.connected || a.run)) return { state: 'live', label: '已接入', cls: 'live' };
    if (config.mock && MOCK[key]) return { state: 'mock', label: '模拟通道', cls: 'mock' };
    return { state: 'none', label: '未接入', cls: 'none' };
  }
  function systemState(id) {
    var a = systems[id];
    if (a && (a.connected || a.read || a.write)) return { state: 'live', label: '已接入', cls: 'live' };
    if (config.mock) return { state: 'mock', label: '模拟通道', cls: 'mock' };
    return { state: 'none', label: '未接入', cls: 'none' };
  }
  function status() {
    var skills = Object.keys(SKILLS).map(function (k) {
      var s = skillState(k);
      return { key: k, meta: SKILLS[k], state: s.state, label: s.label, cls: s.cls,
        hooks: HOOKS.filter(function (h) { return h.skill === k; }) };
    });
    var sys = SYSTEMS.map(function (s) {
      var st = systemState(s.id);
      return { id: s.id, meta: s, state: st.state, label: st.label, cls: st.cls };
    });
    return {
      version: VERSION,
      mock: config.mock,
      liveSkills: skills.filter(function (s) { return s.state === 'live'; }).length,
      required: 3,
      skills: skills,
      systems: sys,
      hooks: { total: HOOKS.length, wired: HOOKS.filter(function (h) { return h.wired; }).length },
      calls: trace.length,
      note: config.mock
        ? '当前开启模拟通道：返回结果均为演示数据，界面上标为「模拟通道」，不代表已真实对接。后端就绪后调用 CORE.setMock(false) 即切换为真实通道。'
        : '已关闭模拟通道，全部能力走后端适配器。'
    };
  }

  var CORE = {
    version: VERSION,
    skills: SKILLS,
    systems: SYSTEMS,
    hooks: HOOKS,
    config: config,

    register: register,
    registerSystem: registerSystem,
    setMock: setMock,
    useEndpoint: useEndpoint,

    invoke: invoke,
    parseBatch: parseBatch,
    systemOp: systemOp,
    multimodal: multimodal,
    ragQuery: ragQuery,
    reportGen: reportGen,
    call: call,

    status: status,
    skillState: skillState,
    systemState: systemState,
    hook: function (id) {
      for (var i = 0; i < HOOKS.length; i++) if (HOOKS[i].id === id) return HOOKS[i];
      return null;
    },
    trace: trace,
    clearTrace: function () { trace.length = 0; }
  };

  return CORE;
})();
(function () {
  var source = '/shared/skill-adapter.js?v=20260924-1';
  if (document.readyState === 'loading') document.write('<script src="' + source + '"><\/script>');
  else {
    var script = document.createElement('script');
    script.src = source;
    document.head.appendChild(script);
  }
})();
