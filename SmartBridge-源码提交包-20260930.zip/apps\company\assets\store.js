/* ==========================================================================
   store.js —— 数据层：优先读 mycircle 本地共享服务，失败自动回落本地 Mock
   --------------------------------------------------------------------------
   用法：const data = await Store.get('candidates')
   切换服务：Store.setBase('http://192.168.1.20:8080')
   约定接口（与团队规范一致，字段 / 状态枚举统一）：
     GET  /api/company/profile            GET  /api/company/projects
     GET  /api/company/requirements       GET  /api/company/candidates
     GET  /api/company/acceptance         GET  /api/company/artifacts
     GET  /api/company/messages           GET  /api/meta/stages
     POST /api/company/requirements       POST /api/company/decisions
     POST /api/company/acceptance/decide
   --------------------------------------------------------------------------
   与 assets/core.js 的分工：
     store.js   负责「业务数据」—— 项目、候选人、消息、成果包。
     core.js    负责「平台能力」—— 五类自动化技能与两套校内实训系统。
   两者都遵循「远端优先、本地回落、绝不报错」，互不依赖。
   ========================================================================== */
(function () {
  var DEFAULT_BASE = 'http://localhost:8080';   /* ← mycircle 本地共享服务地址 */
  var LS_BASE = 'mycircle_base';
  var LS_SETTINGS = 'company_settings';

  var cache = {};
  var base = localStorage.getItem(LS_BASE) || DEFAULT_BASE;
  var online = false;

  function localSettings() {
    try { return JSON.parse(localStorage.getItem(LS_SETTINGS) || '{}'); } catch (e) { return {}; }
  }
  function saveSettings(patch) {
    var next = Object.assign({}, window.MOCK.settings, localSettings(), patch);
    localStorage.setItem(LS_SETTINGS, JSON.stringify(next));
    window.MOCK.settings = next;
    if (next.apiBase && next.apiBase !== base) setBase(next.apiBase);
    return next;
  }

  /* 记录最近一次请求的真实失败原因。
     以前 request() 把所有异常一律吞成 null，页面只能显示「业务服务不可用」，
     后端到底返回了 400 参数错误还是 500 数据库错误完全被掩盖，排障只能靠猜。
     现在把服务端返回的 message 抓出来，写操作失败时原样透给用户。 */
  var lastError = null;
  function rememberFailure(url, err) {
    online = false;
    lastError = { url: url, message: String((err && err.message) || err || '未知错误'), time: new Date().toISOString() };
    if (typeof window.dispatchEvent === 'function' && typeof window.CustomEvent === 'function') {
      window.dispatchEvent(new window.CustomEvent('smartbridge:api-error', { detail: lastError }));
    }
    return null;
  }

  /* 统一 fetch：超时 1.5s。失败仍回落 null（保持页面可用），但失败原因已留痕 */
  function request(path, options, timeoutMs) {
    var ctrl = new AbortController();
    var target = path.indexOf('http') === 0 ? path : base + path;
    var timer = setTimeout(function () { ctrl.abort(); }, timeoutMs || 1500);
    return fetch(target,
      Object.assign({ signal: ctrl.signal, credentials: 'include', headers: { Accept: 'application/json' } }, options || {}))
      .then(function (res) {
        clearTimeout(timer);
        if (!res.ok) {
          /* 服务端在 body 里带了可读的 message（如「项目不存在」），优先取它 */
          return res.text().then(function (text) {
            var msg = '';
            try { var b = JSON.parse(text); msg = (b && (b.message || b.code)) || ''; } catch (e) { msg = String(text || '').slice(0, 120); }
            throw new Error(msg ? msg + '（HTTP ' + res.status + '）' : 'HTTP ' + res.status);
          });
        }
        online = true;
        return res.json();
      })
      .then(function (json) { return (json && json.data !== undefined) ? json.data : json; })
      .catch(function (err) { clearTimeout(timer); return rememberFailure(target, err); });
  }

  function requireRemote(result, action) {
    if (result !== null && result !== undefined) return result;
    var err = new Error(action + '失败：' + (lastError ? lastError.message : '业务服务不可用或返回格式不正确'));
    err.code = 'SERVICE_UNAVAILABLE';
    err.detail = lastError;
    throw err;
  }

  var API_MAP = {
    company:      '/api/company/profile',
    projects:     '/api/company/projects',
    requirements: '/api/company/requirements',
    candidates:   '/api/company/candidates',
    acceptance:   '/api/company/acceptance',
    artifacts:    '/api/company/artifacts',
    templates:    '/api/company/templates',
    messages:     '/api/company/messages',
    settings:     '/api/company/settings',
    stages:       '/api/meta/stages'
  };
  /* 本地 Mock 里对应的键名（与远端键不同名时在此映射） */
  /* 冲突 B06：projects 原误指 STEPS（流程步骤），已移除，改由 /api/company/projects 返回项目资源
     冲突 B12：CONFIRM 已改名 REQUIREMENT_CONFIRMATIONS（与教师端「企业确认请求」区分） */
  var MOCK_KEY = { candidates: 'CANDS', stages: 'STEPS', acceptance: 'ACCEPT', requirements: 'REQUIREMENT_CONFIRMATIONS' };

  var Store = {
    /* 读取：缓存 → mycircle → Mock */
    get: function (key) {
      if (cache[key] !== undefined) return Promise.resolve(cache[key]);
      var remoteP = API_MAP[key] ? request(API_MAP[key]) : Promise.resolve(null);
      return remoteP.then(function (remote) {
        var value = remote || window.MOCK[MOCK_KEY[key] || key];
        cache[key] = value;
        return value;
      });
    },
    invalidate: function (key) { delete cache[key]; },
    invalidateAll: function () { Object.keys(cache).forEach(function (k) { delete cache[k]; }); },

    /* 提交企业侧决策（温度单位混用二选一） */
    submitDecision: function (payload) {
      return request('/api/company/decisions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({
          project_id: window.MOCK.project_id, status: 'running', request_time: new Date().toISOString()
        }, payload))
      }).then(function (r) { return requireRemote(r, '提交企业决策'); });
    },
    /* 提交验收结论 */
    submitAcceptance: function (payload) {
      return request('/api/company/acceptance/decide', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({
          project_id: window.MOCK.project_id, status: 'success', request_time: new Date().toISOString()
        }, payload))
      }).then(function (r) { return requireRemote(r, '提交验收结论'); });
    },
    /* 发起需求 */
    submitRequirement: function (payload) {
      return request('/api/company/requirements', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({
          project_id: window.MOCK.project_id, status: 'pending', request_time: new Date().toISOString()
        }, payload))
      }).then(function (r) { return requireRemote(r, '发起需求'); });
    },

    uploadFiles: function (files, purpose) {
      var form = new FormData();
      Array.prototype.forEach.call(files || [], function (file) { form.append('files', file, file.name); });
      form.append('purpose', purpose || 'requirement_attachment');
      form.append('project_id', window.MOCK.project_id);
      return request('/api/files', { method: 'POST', body: form }, 30000)
        .then(function (r) { return requireRemote(r, '上传需求附件'); });
    },
    requestCandidateAuthorization: function (candidateIds, scope) {
      return request('/api/company/authorization-requests', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ project_id: window.MOCK.project_id, candidate_ids: candidateIds, scope: scope, request_time: new Date().toISOString() })
      }).then(function (r) { return requireRemote(r, '发送候选人授权请求'); });
    },
    submitCandidateDecision: function (payload) {
      return request('/api/company/candidate-decisions', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ project_id: window.MOCK.project_id, request_time: new Date().toISOString() }, payload))
      }).then(function (r) { return requireRemote(r, '提交人才对接决定'); });
    },
    submitFeedback: function (payload) {
      return request('/api/company/feedback', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ project_id: window.MOCK.project_id, request_time: new Date().toISOString() }, payload))
      }).then(function (r) { return requireRemote(r, '提交企业反馈'); });
    },

    getBase: function () { return base; },
    setBase: function (next) {
      base = String(next || '').replace(/\/$/, '');
      localStorage.setItem(LS_BASE, base);
      Store.invalidateAll();
      return base;
    },
    resetBase: function () { base = DEFAULT_BASE; localStorage.removeItem(LS_BASE); Store.invalidateAll(); },
    isOnline: function () { return online; },
    /* 供页面「最后错误」提示条读取：{ url, message, time } */
    lastError: function () { return lastError; },
    clearError: function () { lastError = null; },

    settings: function () { return Object.assign({}, window.MOCK.settings, localSettings()); },
    saveSettings: saveSettings,
    ping: function () { return request('/api/health', null, 1200).then(function (r) { return !!r; }); }
  };

  /* 启动时合并本地设置到内存 Mock */
  window.MOCK.settings = Object.assign({}, window.MOCK.settings, localSettings());

  window.Store = Store;
})();
