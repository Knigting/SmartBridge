/* ==========================================================================
   智训桥 SmartBridge · 企业端 —— 共享数据模型
   与 mycircle 本地服务约定的结构保持一致
   团队规范：统一字段 project_id / status / process_log；状态枚举
     pending | running | success | partial_success | failed
   业务来源：《智训桥 SmartBridge 竞赛解决方案》设备点检项目案例
   ========================================================================== */
window.MOCK = (function () {
  /* 统一项目主键：三端一致（原 SMB-2026-0917-041，冲突 A01） */
  const project_id = "PRJ-0917-001";

  const PHASES = [
  {id:0, name:"需求定义", steps:[0,1,2,3]},
  {id:1, name:"任务构建", steps:[4,5,6,7]},
  {id:2, name:"执行跟踪", steps:[8,9]},
  {id:3, name:"人才对接", steps:[10,11,12]},
  {id:4, name:"反馈复用", steps:[13,14]},
];
/* status: ok 已完成 / cur 进行中 / wait 未开始 */
  const STEPS = [
  {t:"上传资料，描述问题", st:"ok", d:"你上传了需求说明与点检样表，并说明了希望改善的工作。",
   body:`<div class="block-label">已提交材料</div>
     <div class="files">
       <div class="file"><i style="background:#2f5bff">DOC</i><div>equipment-inspection-requirements.docx<small>128 KB · 9 月 12 日</small></div></div>
       <div class="file"><i style="background:#0f9d76">XLS</i><div>inspection-sample-last-4-weeks.xlsx<small>2.4 MB · 9 月 12 日</small></div></div>
     </div>
     <div class="field"><label>你的问题描述</label>
     <textarea rows="2" readonly>每周点检表来自多个班组，汇总容易漏项，希望自动整理异常并生成周报。</textarea></div>`,
   art:"需求说明 v1"},

  {t:"补充缺失信息", st:"ok", d:"系统列出影响交付的 4 个缺失项，你已逐项补充。",
   body:`<div class="block-label">已补充的信息</div><div class="list">
     <div class="row-item done"><span class="tick">✓</span><b>公司名称</b><span class="k">华明制造</span></div>
     <div class="row-item done"><span class="tick">✓</span><b>温度异常阈值</b><span class="k">&gt; 80℃ 判为异常，＝80℃ 为正常</span></div>
     <div class="row-item done"><span class="tick">✓</span><b>缺失值处理</b><span class="k">列入待核查清单，不补为正常</span></div>
     <div class="row-item done"><span class="tick">✓</span><b>共享字段范围</b><span class="k">设备编号 / 温度 / 班组 / 日期</span></div>
   </div>`, art:"待确认清单（已关闭）"},

  {t:"需求草稿已整理好", st:"ok", d:"你上传的资料已整理为结构化需求草稿，等待你确认。",
   body:`<div class="block-label">需求草稿</div><div class="list">
     <div class="row-item"><b style="width:74px;flex-shrink:0;color:var(--ink-4);font-weight:600">业务目标</b><span>汇总每周点检记录，形成异常清单与周报</span></div>
     <div class="row-item"><b style="width:74px;flex-shrink:0;color:var(--ink-4);font-weight:600">输入材料</b><span>点检样表、字段说明、企业确认的异常规则</span></div>
     <div class="row-item"><b style="width:74px;flex-shrink:0;color:var(--ink-4);font-weight:600">交付形式</b><span>汇总表 · 异常明细 · 周报 · 操作说明</span></div>
     <div class="row-item"><b style="width:74px;flex-shrink:0;color:var(--ink-4);font-weight:600">需你确认</b><span>阈值及单位 · 缺失值处理 · 共享字段 · 验收口径</span></div>
   </div>`, art:"需求卡 v1.1（草稿）"},

  {t:"确认需求卡与共享范围", st:"ok", d:"已逐项确认关键信息，需求卡生效并同步给教师与学生。（冲突 B16：原为 cur，与后续已完成的第 5–8 步矛盾）",
   body:`<div class="block-label">请逐项确认</div>
     <div class="list" id="confirmList"></div>
     <div class="meter"><div class="track"><i id="confirmBar" style="width:0%"></i></div><b id="confirmPct">0 / 4 已确认</b></div>
     <div style="margin-top:14px;display:flex;gap:9px">
       <button class="btn btn-green" id="confirmBtn" disabled onclick="saveConfirm()">确认并生效</button>
       <button class="btn btn-outline" onclick="toast('已打开脱敏副本预览')">预览脱敏副本</button>
     </div>`, art:"需求卡 v1.1（确认版）"},

  {t:"核对技能与阶段安排", st:"ok", d:"围绕你的需求，任务所需技能与执行阶段已列好，你已核对无误。",
   body:`<div class="block-label">任务所需技能</div>
     <div class="skills" style="margin-bottom:12px">
       <span class="skill b">数据处理</span><span class="skill g">Excel</span>
       <span class="skill a">数据导入</span><span class="skill v">异常识别</span>
     </div>
     <div class="block-label">执行阶段</div><div class="list">
       <div class="row-item"><b style="width:52px;flex-shrink:0">阶段一</b><span>数据整理 · 统一字段 / 去重 / 标记缺失值</span></div>
       <div class="row-item"><b style="width:52px;flex-shrink:0">阶段二</b><span>规则实现 · 按确认阈值识别异常</span></div>
       <div class="row-item"><b style="width:52px;flex-shrink:0">阶段三</b><span>成果呈现 · 汇总表 + 异常明细 + 周报</span></div>
       <div class="row-item"><b style="width:52px;flex-shrink:0">阶段四</b><span>交付复用 · 编写操作说明并完成复现检查</span></div>
     </div>`, art:"技能与阶段清单"},

  {t:"确认任务卡与交付标准", st:"ok", d:"4 个任务卡已确认，每个任务都写明了交付标准与验收方式。",
   body:`<div class="task-grid">
     <div class="task"><span class="no">任务一</span><b>数据整理</b><p>统一字段、唯一标识与去重规则</p><div class="meta"><span class="pill">验收：字段一致</span></div></div>
     <div class="task"><span class="no">任务二</span><b>规则实现</b><p>按确认阈值输出异常与缺失值清单</p><div class="meta"><span class="pill">验收：固定样例</span></div></div>
     <div class="task"><span class="no">任务三</span><b>成果呈现</b><p>按周生成统计与可追溯明细</p><div class="meta"><span class="pill">验收：业务可用</span></div></div>
     <div class="task"><span class="no">任务四</span><b>交付复用</b><p>编写操作说明并完成复现检查</p><div class="meta"><span class="pill">验收：可复现</span></div></div>
   </div>`, art:"任务包 v1.0"},

  {t:"材料上架，项目编号生成", st:"ok", d:"任务与考核规则已入库，项目编号在三端保持一致。",
   body:`<div class="list">
     <div class="row-item done"><span class="tick">✓</span><b>项目编号</b><span class="k mono">PRJ-0917-001</span></div>
     <div class="row-item done"><span class="tick">✓</span><b>任务材料状态</b><span class="k">已上架（4 个任务）</span></div>
     <div class="row-item done"><span class="tick">✓</span><b>版本关联</b><span class="k">v1.0 · 关联需求卡确认版</span></div>
   </div>`, art:"项目编号与材料清单"},

  {t:"等待教师承接", st:"ok", d:"已通知匹配度最高的教师，其中一位已确认承接并发布任务。",
   body:`<div class="list">
     <div class="row-item done"><b>李慧敏 · 智能制造学院</b><span class="k">已承接 · 匹配度 92%</span></div>
     <div class="row-item"><b>李老师 · 人工智能学院</b><span class="k">已阅 · 匹配度 87%</span></div>
   </div>`, art:"教师承接确认"},

  {t:"跟踪进度，处理异常", st:"cur", d:"执行期间你只需处理需要决策的事项，正常进展会按周汇总给你。",
   body:`<div class="kanban">
     <div class="kb"><h6>任务一 数据整理<span class="chip ok">完成</span></h6><div class="item">统一字段 + 去重</div></div>
     <div class="kb"><h6>任务二 规则实现<span class="chip run">进行中</span></h6><div class="item">等待你的决策</div></div>
     <div class="kb"><h6>任务三 成果呈现<span class="chip wait">未开始</span></h6><div class="item">—</div></div>
     <div class="kb"><h6>任务四 交付复用<span class="chip wait">未开始</span></h6><div class="item">—</div></div>
   </div>
   <div class="alert" id="decisionBox">
     <span class="ai"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M12 9v4M12 17v.1"/><path d="M10.3 3.9L2.6 17.4A2 2 0 004.3 20.4h15.4a2 2 0 001.7-3L13.7 3.9a2 2 0 00-3.4 0z"/></svg></span>
     <div style="flex:1">
       <b>点检表温度单位混用，需要你决定处理方式</b>
       <p>部分班组使用华氏度。该问题影响 1 个后续任务，其他任务不受影响。</p>
       <div class="acts">
         <button class="btn btn-primary btn-sm" onclick="decide('统一换算为摄氏度')">统一换算</button>
         <button class="btn btn-outline btn-sm" onclick="decide('剔除该批数据')">剔除该批数据</button>
       </div>
     </div>
   </div>`, art:"进度汇总（周）"},

  {t:"阶段成果验收", st:"wait", d:"按项目启动时约定的清单验收，可逐项检查后选择通过或要求返修。",
   body:`<div class="list" id="acceptList"></div>
     <div style="margin-top:13px;display:flex;gap:9px;flex-wrap:wrap">
       <button class="btn btn-green" id="acceptBtn" disabled onclick="accept()">通过验收</button>
       <button class="btn btn-outline" onclick="toast('已生成返修单，关联到任务三')">要求返修</button>
     </div>`, art:"验收记录 + 成果包"},

  {t:"查看候选名单", st:"wait", d:"需要后续维护人员时，可从参与过本项目的人才中查看匿名画像并回选。",
   body:`<div class="list">
     <div class="row-item"><b>候选 A</b><span class="k">异常识别 92 · 2 次边界修复</span></div>
     <div class="row-item"><b>候选 B</b><span class="k">数据整理 81 · 零迟交</span></div>
     <div class="row-item"><b>候选 C</b><span class="k">规则理解 88 · 单位换算修复</span></div>
     <div class="row-item"><b>候选 D</b><span class="k">协作记录良好 · 贡献待核验</span></div>
   </div>
   <div style="margin-top:13px"><button class="btn btn-primary btn-sm" onclick="nav('talent',document.querySelectorAll('.rail-item')[2])">前往人才对接</button></div>`, art:"匿名候选名单"},

  {t:"回选并发起授权", st:"wait", d:"选定意向后发起授权请求，学生同意后才能看到身份与联系方式。",
   body:`<div class="list">
     <div class="row-item done"><span class="tick">✓</span><b>候选 A</b><span class="k">授权请求已发送 · 等待回复</span></div>
     <div class="row-item done"><span class="tick">✓</span><b>候选 C</b><span class="k">授权请求已发送 · 等待回复</span></div>
   </div>`, art:"授权请求记录"},

  {t:"查看授权成果", st:"wait", d:"同意授权的候选人，其作品、测试记录与修订轨迹对你开放。",
   body:`<div class="flow">
     <div class="fn done"><div class="d">✓</div><span>发送请求</span></div>
     <div class="fn cur"><div class="d">⏳</div><span>学生确认</span></div>
     <div class="fn"><div class="d">🔓</div><span>开放成果</span></div>
     <div class="fn"><div class="d">🤝</div><span>进入对接</span></div>
   </div>
   <div style="margin-top:14px;display:flex;gap:9px">
     <button class="btn btn-primary btn-sm" onclick="authorize()">模拟：学生同意授权</button>
   </div>
   <div id="authResult"></div>`, art:"授权范围清单"},

  {t:"面试与录用", st:"wait", d:"基于已开放的成果安排针对性面试，重点确认待验证的能力项。",
   body:`<div class="list">
     <div class="row-item done"><span class="tick">✓</span><b>候选 A 已开放成果</b><span class="k">异常识别 92 · 修复 2 次边界错误</span></div>
   </div>
   <div style="margin-top:13px;display:flex;gap:9px;flex-wrap:wrap">
     <button class="btn btn-outline btn-sm" onclick="toast('已预约周三 14:00 针对性面试')">预约面试</button>
     <button class="btn btn-green btn-sm" onclick="hire()">达成录用意向</button>
   </div>
   <div id="hireResult"></div>`, art:"面试与录用记录"},

  {t:"反馈与复用", st:"wait", d:"对本次工作质量作出评价，经验会沉淀为模板，下一次同类需求可直接套用。",
   body:`<div class="block-label">工作质量评价</div>
     <div class="stars" id="stars">
       <span class="star" onclick="rate(1)">★</span><span class="star" onclick="rate(2)">★</span>
       <span class="star" onclick="rate(3)">★</span><span class="star" onclick="rate(4)">★</span><span class="star" onclick="rate(5)">★</span>
     </div>
     <div class="field"><label>补充说明</label>
       <textarea rows="3" id="fbText">交付及时，异常规则执行准确，周报可直接用于班组例会。建议后续补充设备维护经验。</textarea>
     </div>
     <div style="margin-top:12px"><button class="btn btn-primary" onclick="submitFb()">提交反馈</button></div>
     <div id="fbResult"></div>`, art:"评价与模板归档"},
];
  /* 冲突 B12：与教师端 qa.html 的 CONFIRM（企业确认请求）同名不同义，改名以示区分 */
  const REQUIREMENT_CONFIRMATIONS = [
  {k:"阈值及单位", d:"温度 ＞80℃ 判为异常；＝80℃ 为边界正常值"},
  {k:"缺失值处理", d:"列入待核查清单，不自动补为正常值"},
  {k:"共享字段范围", d:"设备编号 / 温度 / 班组 / 日期可共享，备注字段脱敏"},
  {k:"验收口径", d:"以汇总表 + 异常明细 + 周报三项成果验收"},
];
  const ACCEPT = [
  {k:"材料完整性", d:"汇总表、异常明细、周报、运行说明齐全"},
  {k:"客观正确性", d:"已标记样例识别正确，温度单位已统一"},
  {k:"业务适用性", d:"周报可直接用于班组例会查看"},
  {k:"交付可复用性", d:"按说明运行可得到一致结果"},
];
  const CANDS = [
  {n:"候选 A", id:"STU-••••27", score:92, auth:true, why:"同类点检任务独立完成，异常识别固定测试全对", ev:"任务二作品 + 2 次返修记录（边界条件已修复）", gap:"设备维护经验（待验证）", ready:"每周 12 小时"},
  {n:"候选 B", id:"STU-••••53", score:81, auth:false, why:"数据处理表现稳定，多次提交零迟交", ev:"任务一成果 + 团队贡献记录", gap:"异常规则实现（未接触）", ready:"每周 8 小时"},
  {n:"候选 C", id:"STU-••••08", score:88, auth:true, why:"修复过单位换算错误，规则理解扎实", ev:"任务二 / 任务三提交与重测记录", gap:"周报业务表达（待验证）", ready:"每周 10 小时"},
  {n:"候选 D", id:"STU-••••91", score:76, auth:false, why:"协作记录良好，负责成果呈现模块", ev:"团队周报成果（个人贡献待核验）", gap:"独立完成任务证据不足", ready:"每周 6 小时"},
];

  return {
    project_id: project_id,
    PHASES: PHASES, STEPS: STEPS, REQUIREMENT_CONFIRMATIONS: REQUIREMENT_CONFIRMATIONS, ACCEPT: ACCEPT, CANDS: CANDS,

    /* ---------- 企业档案（本端身份） ---------- */
    company: {
      name: "华明制造",
      contact: "张工",
      role: "设备管理部 · 主管",
      sector: "装备制造 · 济南",
      since: "2026-03-12"
    },

    /* ---------- 平台能力接入位 · 本端使用情况 ----------
       命题硬性要求第 1 条：至少调用 3 类平台核心自动化技能。
       本端五类技能均有真实业务落点，故全部预留接入位（≥3 已满足）。
       命题硬性要求第 2 条：至少 2 套校内实训系统 / 实训硬件数据互通 ——
       本端直接接 lms（接入位 B1 任务包下发 / B2 班级进度回填）；
       实训硬件数据网关经「平台侧统一接入」回流，故企业端不再单设 edge 接入位。 */
    capability: {
      used: ["parse-batch", "training", "multimodal", "rag", "report"],
      minRequired: 3,
      note: "接入位只声明「能力用在哪」，能力本体由后端实现；未接入时界面显示「未接入」，流程不受影响。",
      systems: [
        {
          id: "lms", name: "校内实训教学平台", protocol: "HTTP API", place: "接入位 B1 / B2",
          desc: "承接转化后的实训任务下发，并把班级提交进度与成绩回填到企业侧项目卡",
          rows: [
            { k: "机械设计 2203", v: "28 / 32 已提交 · 均分 88" },
            { k: "机械设计 2202", v: "26 / 30 已提交 · 均分 85" },
            { k: "机电一体化 2201", v: "31 / 31 已提交 · 均分 91" }
          ]
        },
        {
          id: "edge", name: "实训硬件数据网关", protocol: "MQTT / OPC-UA", place: "平台侧统一接入",
          desc: "读取数控实训台、机器人工作站与采集端工况，用于验收环节的确定性比对",
          rows: [
            { k: "CNC-02 数控实训台", v: "主轴运行 12.4 h · 正常" },
            { k: "RB-11 机器人工作站", v: "示教轨迹 38 点 · 正常" },
            { k: "GW-07 物联网网关", v: "点位在线率 99.2%" }
          ]
        }
      ]
    },

    /* ---------- 消息中心 ---------- */
    messages: [
      { level: "urgent", title: "点检表温度单位混用，需要你决定处理方式", from: "教师端 · 李慧敏", time: "今天 09:12", status: "pending", step: "第 9 步" },
      { level: "info",   title: "点检周报 v2 已通过固定测试，待你验收",       from: "学生端 · 提交检查", time: "今天 15:05", status: "running", step: "第 10 步" },
      { level: "info",   title: "2 名候选人已同意资料授权",                   from: "学生端 · 授权确认", time: "今天 11:48", status: "running", step: "第 13 步" },
      { level: "info",   title: "教师已发布 4 个任务",                         from: "教师端 · 任务管理", time: "昨天 09:30", status: "success", step: "第 7 步" },
      { level: "low",    title: "本项目经验已归档为可复用模板",               from: "系统",             time: "昨天 08:00", status: "success", step: "第 15 步" }
    ],

    /* ---------- 成果包（验收通过后可下载的材料清单） ---------- */
    artifacts: [
      { name: "需求确认版（需求卡 v1.1）",     kind: "DOC", size: "126 KB", ver: "v1.1", ready: true },
      { name: "脱敏样本（近 4 周点检表）",     kind: "XLS", size: "2.4 MB", ver: "v1.0", ready: true },
      { name: "任务包与验收标准",               kind: "DOC", size: "312 KB", ver: "v1.0", ready: true },
      { name: "统一台账（去重后）",             kind: "XLS", size: "1.1 MB", ver: "v2.0", ready: true },
      { name: "异常清单与待核查清单",           kind: "XLS", size: "284 KB", ver: "v2.0", ready: true },
      { name: "点检周报 v2",                     kind: "XLS", size: "196 KB", ver: "v2.0", ready: false },
      { name: "运行说明与复现检查记录",         kind: "MD",  size: "18 KB",  ver: "v1.0", ready: false }
    ],

    /* ---------- 模板库 ---------- */
    templates: [
      { name: "设备点检台账整理",       from: "PRJ-0917-001", reuse: 2, note: "含异常判定规则与固定样例，替换数据源即可复用" },
      { name: "周报统计与可追溯明细",   from: "PRJ-0917-001", reuse: 1, note: "统计口径与明细回溯方式已固化" },
      { name: "质量数据周报汇总",       from: "PRJ-0830-014", reuse: 3, note: "适用于多班组质量数据聚合场景" }
    ],

    /* ---------- 数据报告输入数据集（可视化报告生成能力的入参） ---------- */
    reportData: {
      baselineHours: 15.2, actualHours: 6.0, savedHours: 9.2,
      passRate: 100, missRate: 0, rework: 1,
      classes: [
        { name: "2024级数据科学班", submitted: 28, total: 32, avg: 88 }
      ]
    },

    /* ---------- 设置 ---------- */
    settings: {
      showMaskedOnly: true,
      weeklyDigest: true,
      reuseCase: true,
      apiBase: "http://localhost:8080",
      coreMock: true
    }
  };
})();
