# 智训桥 SmartBridge · 接入位清单（预留位置说明）

> 本文件是**前端 → 后端**的交接说明。前端只预留位置，不实现任何后端逻辑与数据逻辑。
> 后端按本表逐条实现即可，**页面与交互代码无需改动**。

统一返回契约（所有能力、所有系统一致）：

```js
{ skill, ok, code, mode, input, output, evidence[], error, meta }
```

- `mode`：`live` 已接入 / `mock` 模拟通道 / `none` 未接入
- `evidence[]` **必须带出处**（`file` / `sheet` / `page` / `range` / `doc` / `snippet` / `system` / `topic` 之一）
  —— 这是评委判断「跨系统联动是否真实」的依据
- 未接入时返回 `code: 'not_connected'`，**不抛异常**，界面显示「未接入」并说明原因，流程照走

---

## 0. 预留位置一共三类，分别放在哪

| 类型 | 放在哪（组件） | 前端写法 | 后端要做什么 |
|---|---|---|---|
| **能力接入位** | 各页面里一个 `<div class="cap">` 卡片 | `<div data-cap="A2" data-skill="parse-batch" data-args='{…}'>` | 注册该 skill 的适配器 |
| **实训系统接入** | `settings.html` 的「校内实训系统接入」卡 + 相关页面侧栏 | `CORE.registerSystem('lms' \| 'edge', {…})` | 分别接两套系统 |
| **业务数据读写** | `assets/store.js` 的 `API_MAP` | `Store.get('requests')` / `Store.submitReview({…})` | 实现对应 REST 接口 |

三类都遵循「远端优先、本地回落、绝不报错」，互不依赖。

**三个交付包（企业端 / 教师端 / 学生端）各有一份**，接入位编号 A/B/C/D/E 三端一致，
便于对照同一能力在不同角色的落点：**企业端 15 处 · 教师端 17 处 · 学生端 14 处，合计 46 处**。
五类技能**不集中堆放**：每一处都落在真正会用到它的业务环节上，单页最多 3 类技能。
每端的 `assets/core.js` 是同一套契约，三端可共用同一个后端适配器模块。

---

## 1. 企业端 · 接入位（5 个页面共 15 处）

| 接入位 | 能力 | 页面 / 位置 | 交互入口（前端已留） | 需保留字段 |
|---|---|---|---|---|
| A1 | 文件批量解析 | `demand.html` · 发起需求 | 文件选择框 `change` → 把文件名数组交给 `CORE.call()` | `files[]`、字段名与行数、异常项 |
| A2 | 文件批量解析 | `project.html` · 第 3 步（需求草稿整理） | 项目页该步渲染时自动调用 | 同上 |
| A3 | 文件批量解析 | `acceptance.html` · 验收中心（必交材料） | 页面加载时自动调用 | 同上 |
| B1 | 实训系统自动操作 | `project.html` · 第 7 步（材料上架） | 渲染时自动调用（`lms` `write` 下发任务包） | `system`、`op`、`ref`/回执、`rows[]` |
| B2 | 实训系统自动操作 | `report.html` · 班级提交进度与均分 | 加载时自动调用（`lms` `read` 拉班级进度与成绩） | 同上 |
| C1 | 语音 / 图像多模态 | `demand.html` · 发起需求（现场点检表照片） | 点击「现场照片」区域 → 传入选中图片 | `kind`、`text`、`fields{}`、`confidence` |
| C2 | 语音 / 图像多模态 | `acceptance.html` · 验收中心（仪表 / 实操照片） | 加载时自动调用 | 同上 |
| C3 | 语音 / 图像多模态 | `demand.html` · 发起需求（语音口述） | 上传语音后自动调用 | 同上 |
| D1 | RAG 知识库检索 | `project.html` · 第 5 步（技能与阶段） | 渲染时自动调用 | `hits[]`(`doc`/`page`/`scope`/`score`)、`answer` |
| D2 | RAG 知识库检索 | `acceptance.html` · 验收中心（验收规范比对） | 加载时自动调用 | 同上 |
| D3 | RAG 知识库检索 | `report.html` · 工时基线检索 | 加载时自动调用 | 同上 |
| D4 | RAG 知识库检索 | `talent.html` · 岗位能力标准匹配 | 加载时自动调用 | 同上 |
| E1 | 可视化报告生成 | `report.html` · 量化效益分析报告 | 点击「重新生成」→ 传入报告数据集 | `title`、`metrics[]`、`charts[]`、`file` |
| E2 | 可视化报告生成 | `talent.html` · 候选人画像报告 | 加载时自动调用 | 同上 |
| E3 | 可视化报告生成 | `report.html` · 执行进度周报 | 加载时自动调用 | 同上 |

> 企业端**只操作校内实训教学平台 `lms`**（B1 任务包下发 / B2 进度成绩回填），
> **不直接读实训硬件网关**——设备工况由教师端 / 学生端的 B3 读取，企业侧走平台侧统一接入，
> 避免同一份硬件数据出现两个来源。因此本端没有 `edge` 接入位。

---

## 2. 教师端 · 接入位（8 个页面共 17 处）

| 接入位 | 能力 | 页面 / 位置 | 交互入口（前端已留） | 需保留字段 |
|---|---|---|---|---|
| A1 | 文件批量解析 | `review.html` · 项目审核 | 加载时自动调用（「重新同步」也可触发） | `files[]`、字段名与行数、异常项 |
| A2 | 文件批量解析 | `project.html` · 第 2 步（任务设计） | 渲染时自动调用 | 同上 |
| A3 | 文件批量解析 | `evaluation.html` · 评价复核 | 加载时自动调用 | 同上 |
| B1 | 实训系统自动操作 | `tasks.html` · 任务管理「分发与回填」 | 点击分发 / 渲染时自动调用（`lms` `write` 下发任务阶段与验收标准） | `system`、`op`、`ref`/回执、`rows[]` |
| B2 | 实训系统自动操作 | `students.html` · 班级学生 | 加载时自动调用（`lms` `read` 拉进度成绩） | 同上 |
| B3 | 实训系统自动操作 | `students.html` · 班级学生「实训台操作记录」 | 加载时自动调用（`edge` `read` 固定样例结果与操作日志） | 同上 |
| C1 | 语音 / 图像多模态 | `qa.html` · 答疑聚合 | 加载时自动调用（提问截图） | `kind`、`text`、`fields{}`、`confidence` |
| C2 | 语音 / 图像多模态 | `evaluation.html` · 评价复核 | 加载时自动调用（实操照片） | 同上 |
| C3 | 语音 / 图像多模态 | `qa.html` · 答疑聚合 | 加载时自动调用（语音提问） | 同上 |
| D1 | RAG 知识库检索 | `project.html` · 第 7 步（任务阶段对标） | 渲染时自动调用 | `hits[]`、`answer` |
| D2 | RAG 知识库检索 | `review.html` · 项目审核 | 加载时自动调用 | 同上 |
| D3 | RAG 知识库检索 | `evaluation.html` · 评价复核 | 加载时自动调用 | 同上 |
| D4 | RAG 知识库检索 | `qa.html` · 答疑聚合 | 加载时自动调用 | 同上 |
| E1 | 可视化报告生成 | `index.html` · 工作台 | 加载时自动调用（教学执行周报） | `title`、`sections[]`、`metrics[]`、`charts[]`、`file` |
| E2 | 可视化报告生成 | `students.html` · 班级学生 | 加载时自动调用（班级能力画像） | 同上 |
| E3 | 可视化报告生成 | `library.html` · 案例库「归档前先成稿」 | 加载时自动调用（任务包说明与阶段验收清单） | 同上 |
| E4 | 可视化报告生成 | `library.html` · 案例库「归档前先成稿」 | 加载时自动调用（复核记录与教学结论） | 同上 |

> 页面上的「第 N 步」指该端流程收敛后的**全局步号**（企业侧 15 步 / 教师侧 16 步），
> 在 `project.html` 的 5 个阶段标签页里可逐页看到对应位置。

**实训系统**：`lms` 接入位 B1（任务下发）/ B2（班级进度回填）；`edge` 接入位 B3（实训台操作记录）。
两套系统分列在不同页面，便于演示「同一批学生数据、两个来源交叉印证」。

---

## 3. 学生端 · 接入位（7 个页面共 14 处）

| 接入位 | 能力 | 页面 / 位置 | 交互入口（前端已留） | 需保留字段 |
|---|---|---|---|---|
| A1 | 文件批量解析 | `tasks.html` · 我的任务（阶段列表下） | 页面加载时自动调用（本轮待提交产物批量解析） | `files[]`、字段名与行数、`anomalies[]` |
| A2 | 文件批量解析 | `task.html` · 阶段详情（提交按钮上方） | 提交前自动调用（产物完整性与字段口径检查） | 同上 |
| B1 | 实训系统自动操作 | `tasks.html` · 阶段总览卡内 | 加载时自动调用（`lms` `read` 拉在册进度与成绩） | `system`、`op`、`ref`/回执、`rows[]` |
| B2 | 实训系统自动操作 | `tasks.html` · 提交与检查记录表下方 | 点「提交本阶段产物」后由 `Store.submitLevel()` 触发（`lms` `write` 回写） | 同上 |
| B3 | 实训系统自动操作 | `report.html` · 成长轨迹卡内 | 加载时自动调用（`edge` `read` 拉设备工况与操作日志） | 同上 |
| C1 | 语音 / 图像多模态 | `task.html` · 产物清单下方 | 选择运行截图 / 仪表照片后自动调用（读数与步骤判定） | `kind`、`text`、`fields{}`、`confidence` |
| C2 | 语音 / 图像多模态 | `inagent.html` · 对话框下方 | 语音提问按钮 → 转写后回填输入框 | 同上 |
| D1 | RAG 知识库检索 | `task.html` · 验收标准卡内 | 渲染时自动调用（按企业验收规范与工艺文档比对） | `hits[]`(`doc`/`page`/`scope`/`score`)、`answer` |
| D2 | RAG 知识库检索 | `report.html` · 六维画像卡内 | 加载时自动调用（对标岗位能力标准 / 学校课程标准） | 同上 |
| D3 | RAG 知识库检索 | `inagent.html` · 提问记录卡内 | 加载时自动调用（检索课程标准与微课知识库并给出处） | 同上 |
| D4 | RAG 知识库检索 | `learning.html` · 补强计划卡内 | 加载时自动调用（按薄弱点检索微课与企业公开任务） | 同上 |
| E1 | 可视化报告生成 | `report.html` · 待验证能力下方 | 加载时自动调用（生成《能力画像与证据摘要报告》） | `title`、`sections[]`、`metrics[]`、`charts[]`、`file` |
| E2 | 可视化报告生成 | `index.html` · 最近动态卡内 | 加载时自动调用（每周成长报告） | 同上 |
| E3 | 可视化报告生成 | `company.html` · 能力材料包卡内 | 「同意授权」后自动调用（能力材料包摘要） | 同上 |

**实训系统**：`lms`（校内实训教学平台，HTTP API）接入位 B1/B2；`edge`（实训硬件数据网关，MQTT/OPC-UA）接入位 B3。

> 学生端还额外保留了**两个非 CORE 接入点**（属「业务数据读写」类，见 §4）：
> ① `assets/store.js` 的 `Store.chat()` / `Store.pingInagent()` —— 本地 inAgent 桌面端网关（默认 `127.0.0.1:3000`，
> 依次探测 `/api/chat`、`/api/invoke`、`/api/message`，未启动自动回落本地引导式回复）；
> ② `Store.submitLevel()` —— 关卡产物提交。
> 这两处不需要注册 CORE 适配器，直接把后端地址填上即可。

---

## 4. 业务数据接口（`assets/store.js` 的 `API_MAP`）

### 企业端

| key | 方法 | 路径 |
|---|---|---|
| `company` | GET | `/api/company/profile` |
| `projects` | GET | `/api/company/projects` |
| `requirements` | GET | `/api/company/requirements` |
| `candidates` | GET | `/api/company/candidates` |
| `acceptance` | GET | `/api/company/acceptance` |
| `artifacts` | GET | `/api/company/artifacts` |
| `templates` | GET | `/api/company/templates` |
| `messages` | GET | `/api/company/messages` |
| — | POST | `/api/company/requirements`（发起需求） |
| — | POST | `/api/company/decisions`（提交决策） |
| — | POST | `/api/company/acceptance/decide`（提交验收结论） |

### 教师端

| key | 方法 | 路径 |
|---|---|---|
| `teacher` | GET | `/api/teacher/profile` |
| `requests` | GET | `/api/teacher/requests` |
| `stages` | GET | `/api/teacher/tasks` |
| `students` | GET | `/api/teacher/students` |
| `questions` | GET | `/api/teacher/questions` |
| `evaluations` | GET | `/api/teacher/evaluations` |
| `library` | GET | `/api/teacher/library` |
| — | POST | `/api/teacher/requests/review`（需求审核结论） |
| — | POST | `/api/teacher/tasks/publish`（发布任务阶段） |
| — | POST | `/api/teacher/evaluations/decide`（评价复核结论） |

### 学生端

| key | 方法 | 路径 |
|---|---|---|
| `student` | GET | `/api/student/profile` |
| `project` | GET | `/api/student/project` |
| `levels` | GET | `/api/student/levels` |
| `contributions` | GET | `/api/student/contributions` |
| `feed` | GET | `/api/student/feed` |
| `notifications` | GET | `/api/student/notifications` |
| `report` | GET | `/api/student/report` |
| `learning` | GET | `/api/learning/recommendations` |
| `company` | GET | `/api/student/authorizations` |
| `stages` | GET | `/api/meta/stages` |
| — | POST | `/api/levels/{id}/submit`（提交关卡产物） |
| — | POST | `/api/inagent/chat`（助手对话，另有 `/api/invoke`、`/api/message` 兼容路径） |

- 响应可以是裸数据，也可以是 `{ "data": … }`（前端两种都认）。
- 统一超时 **1.5 秒**（对话 3 秒），失败自动回落本地 Mock；侧栏三盏灯同步变化
  （`mycircle` 数据源 / `inAgent` 助手 / `能力通道`）。
- `GET /api/health` 用于「重新检测连接」。

---

## 5. 后端注册方式（示例，照抄即可）

```js
// 1) 注册能力
CORE.register('parse-batch', {
  connected: true,
  describe: 'POST /api/parse-batch',
  run(payload, ctx) {
    return fetch('/api/parse-batch', { method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload) }).then(r => r.json());  // → { output, evidence }
  }
});

// 2) 注册两套校内实训系统
CORE.registerSystem('lms',  { connected: true, describe: '校内实训教学平台 HTTP API',
  read(query, ctx) { /* 拉班级提交进度与成绩 */ },
  write(payload, ctx) { /* 下发任务阶段与验收标准 */ } });
CORE.registerSystem('edge', { connected: true, describe: '实训硬件数据网关 MQTT / OPC-UA',
  read(query, ctx) { /* 拉固定样例测试结果与设备操作日志 */ } });

// 3) 关掉模拟通道 → 接入位自动切真实通道
CORE.setMock(false);
```

`run()` 返回 `{ output, evidence }` 即可，也可直接返回完整 envelope。

---

## 6. `output` 各能力的字段约定

| 能力 | `output` 结构 |
|---|---|
| `parse-batch` | `{ total, fields[], files:[{ name, type, rows\|pages, fields[], text }], anomalies:[{ type, count, note }] }` |
| `training` | `{ system, op, action, ref\|receipt, rows[] }` |
| `multimodal` | `{ kind, text, fields{}, confidence }` |
| `rag` | `{ query, scopes[], answer, hits:[{ doc, page, snippet, score, scope }] }` |
| `report` | `{ kind, title, sections:[{h,p}], charts:[{ type, title, series:[{name,value}] }], metrics:[{k,v,d}], file }` |

> 前端渲染层已按上表逐字段读取；字段缺失会**自动跳过不渲染空值**，但**结构层级不要改**。

---

## 7. 验收自测（可选）

项目根目录提供统一页面自测脚本（用系统 Edge 无头模式）：

```powershell
node tools/smoke-all.js
```

三个包都可以不传页面清单，直接跑各自默认的全量页面规格
（企业端 14 个 · 教师端 13 个 · 学生端 9 个，均已含 `project.html?phase=0..4` 或 `task.html?id=1|2` 这类参数页）。

它会逐页出预览图并断言：侧栏 / 顶栏已注入、接入位骨架已替换为结果、**无 `undefined` 外泄**、
**无外链资源**（保持「双击即用」的离线口径）。
后端接入后再跑一次，把断言里的「接入位 N/N」从 `mock` 切到 `live` 即算通过。
