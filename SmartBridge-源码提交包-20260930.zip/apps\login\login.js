(function () {
  'use strict';
  var identities = {
    student: { label: '学生端', roles: ['student'], path: '/student/index.html', username: '2024010156' },
    teacher: { label: '教师端', roles: ['teacher', 'school_admin'], path: '/teacher/index.html', username: 'lihuimin' },
    company: { label: '企业端', roles: ['company_admin', 'company_member'], path: '/company/index.html', username: 'zhanggong' },
    admin: { label: '平台管理', roles: ['platform_admin'], path: '/admin/index.html', username: 'admin' }
  };
  var selected = 'student';
  var form = document.getElementById('loginForm');
  var username = document.getElementById('username');
  var password = document.getElementById('password');
  var message = document.getElementById('message');
  var submit = document.getElementById('submitButton');
  var remember = document.getElementById('remember');

  function showMessage(text, success) {
    message.textContent = text || '';
    message.className = text ? 'message show' + (success ? ' success' : '') : 'message';
  }
  function selectRole(role, preserveUser) {
    selected = role;
    Array.from(document.querySelectorAll('.identity')).forEach(function (button) {
      var active = button.dataset.role === role;
      button.classList.toggle('active', active);
      button.setAttribute('aria-checked', active ? 'true' : 'false');
    });
    if (!preserveUser) username.value = localStorage.getItem('smartbridge_login_' + role) || identities[role].username;
    submit.querySelector('span').textContent = '进入' + identities[role].label;
    showMessage('');
  }
  Array.from(document.querySelectorAll('.identity')).forEach(function (button) {
    button.addEventListener('click', function () { selectRole(button.dataset.role, false); password.value = ''; password.focus(); });
  });
  document.getElementById('fillDemo').addEventListener('click', function () {
    username.value = identities[selected].username;
    password.value = 'SmartBridge123!';
    showMessage('已填入本地演示账号，请点击登录。', true);
  });
  document.getElementById('togglePassword').addEventListener('click', function () {
    var showing = password.type === 'text';
    password.type = showing ? 'password' : 'text';
    this.textContent = showing ? '显示' : '隐藏';
    this.setAttribute('aria-label', showing ? '显示密码' : '隐藏密码');
  });
  form.addEventListener('submit', function (event) {
    event.preventDefault();
    var account = username.value.trim();
    if (!account || !password.value) return showMessage('请输入账号和密码。');
    submit.disabled = true;
    submit.innerHTML = '<i class="spinner"></i><span>正在验证身份</span>';
    showMessage('');
    fetch('/api/auth/login', { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ username: account, password: password.value }) })
      .then(function (response) { return response.json().then(function (body) { if (!response.ok) throw new Error(body.message || '登录失败'); return body.data; }); })
      .then(function (data) {
        var roles = String(data.user.role_codes || '').split(',').map(function (value) { return value.trim(); });
        var allowed = identities[selected].roles.some(function (role) { return roles.indexOf(role) >= 0; });
        if (!allowed) {
          return fetch('/api/auth/logout', { method: 'POST', credentials: 'include' }).then(function () { throw new Error('该账号不属于所选身份，请重新选择。'); });
        }
        if (remember.checked) localStorage.setItem('smartbridge_login_' + selected, account); else localStorage.removeItem('smartbridge_login_' + selected);
        showMessage('验证成功，正在进入' + identities[selected].label + '…', true);
        window.setTimeout(function () { location.href = identities[selected].path; }, 350);
      })
      .catch(function (error) { showMessage(error.message === 'Failed to fetch' ? '无法连接本地业务服务，请先运行启动脚本。' : error.message); })
      .finally(function () { submit.disabled = false; submit.innerHTML = '<span>进入' + identities[selected].label + '</span><b aria-hidden="true">→</b>'; });
  });
  selectRole('student', false);
})();
