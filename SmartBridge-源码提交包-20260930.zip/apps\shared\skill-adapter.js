(function (global) {
  'use strict';
  if (!global.CORE || typeof global.CORE.register !== 'function') return;

  var base = global.SMARTBRIDGE_SKILL_BASE || '';
  var apiKey = global.SMARTBRIDGE_SKILL_KEY || '';

  function headers(json) {
    var result = { Accept: 'application/json' };
    if (json) result['Content-Type'] = 'application/json';
    if (apiKey) result['X-Skill-Api-Key'] = apiKey;
    return result;
  }

  function request(path, options) {
    return fetch(base + path, options).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (body) {
        if (!response.ok) throw new Error(body.message || ('HTTP ' + response.status));
        return body.data || body;
      });
    });
  }

  global.CORE.register('parse-batch', {
    connected: true,
    describe: 'SmartBridge Skills /parse-batch',
    run: function (input) {
      var form = new FormData();
      var hasFile = false;
      (input.files || []).forEach(function (item) {
        var file = item instanceof File ? item : item.file;
        if (file instanceof File) { form.append('files', file, file.name); hasFile = true; }
      });
      form.append('purpose', input.purpose || '');
      /* 接入位没有真实文件时改用内置样例，避免「请上传文件」的死界面 */
      if (!hasFile) return request('/api/skills/parse-batch/samples', {
        method: 'POST', headers: headers(true),
        body: JSON.stringify({ purpose: input.purpose || '内置样例批量解析' })
      });
      return request('/api/skills/parse-batch', { method: 'POST', headers: headers(false), body: form });
    }
  });

  global.CORE.register('rag', {
    connected: true,
    describe: 'SmartBridge Skills /rag/query',
    run: function (input) {
      return request('/api/skills/rag/query', { method: 'POST', headers: headers(true), body: JSON.stringify({ query: input.query || '', scopes: input.scopes || [], project_id: input.project_id || '', top_k: input.topK || 5 }) });
    }
  });

  global.CORE.register('report', {
    connected: true,
    describe: 'SmartBridge Skills /report',
    run: function (input) {
      return request('/api/skills/report', { method: 'POST', headers: headers(true), body: JSON.stringify({ title: input.title, kind: input.kind, data: input.data || {} }) });
    }
  });

  function trainingPlan(input) {
    return request('/api/skills/training/plan', { method: 'POST', headers: headers(true), body: JSON.stringify(input || {}) });
  }
  function trainingApprove(planId, approvedBy, reason) {
    return request('/api/skills/training/plans/' + encodeURIComponent(planId) + '/approve', { method: 'POST', headers: headers(true), body: JSON.stringify({ approved_by: approvedBy, reason: reason || '' }) });
  }
  function trainingExecute(planId, approvalToken, idempotencyKey) {
    var h = headers(true);
    if (idempotencyKey) h['Idempotency-Key'] = idempotencyKey;
    return request('/api/skills/training/execute', { method: 'POST', headers: h, body: JSON.stringify({ plan_id: planId, approval_token: approvalToken || '' }) });
  }
  global.SmartBridgeTraining = { plan: trainingPlan, approve: trainingApprove, execute: trainingExecute };
  global.CORE.register('training', {
    connected: true,
    describe: 'SmartBridge Skills /training',
    run: function (input) {
      return trainingPlan({ system: input.system, op: input.op || 'read', action: input.action, payload: input.payload || input.query || {} }).then(function (plan) {
        if (plan.approval_required) {
          return { skill: 'training', version: '1.0.0', ok: false, code: 'approval_required', mode: 'live', input: input, output: plan, evidence: [{ plan_id: plan.plan_id, plan_hash: plan.plan_hash, risk: plan.risk }], error: '该写操作需要人工审批', meta: { at: new Date().toISOString(), adapter: 'SmartBridge Skills' } };
        }
        return trainingExecute(plan.plan_id, '', '');
      });
    }
  });

  global.CORE.register('multimodal', {
    connected: true,
    describe: 'SmartBridge Skills /multimodal/recognize',
    run: function (input) {
      var file = input.file || input.source;
      if (file instanceof File) {
        var form = new FormData();
        form.append('file', file, file.name);
        form.append('kind', input.kind || (file.type.indexOf('audio/') === 0 ? 'audio' : 'image'));
        form.append('purpose', input.purpose || '');
        form.append('language', input.language || 'zh-CN');
        return request('/api/skills/multimodal/recognize', { method: 'POST', headers: headers(false), body: form });
      }
      /* 接入位没有用户上传的文件时改用内置样例素材，保证本地可直接跑通（结果标注为本地演示通道） */
      return request('/api/skills/multimodal/samples', {
        method: 'POST', headers: headers(true),
        body: JSON.stringify({ source: typeof input.source === 'string' ? input.source : '', kind: input.kind || '', purpose: input.purpose || '', language: input.language || 'zh-CN' })
      });
    }
  });

  // 本地运行统一走 8080 网关转发到 8090 Skill 服务。
  // 服务异常时返回明确错误，不再回落到 core.js 的内置模拟结果。
  ['lms', 'edge'].forEach(function (systemId) {
    global.CORE.registerSystem(systemId, {
      connected: true,
      describe: 'SmartBridge 本地 Training Skill / ' + systemId,
      read: function (input) {
        return global.CORE.call('training', '', Object.assign({}, input || {}, { system: systemId, op: 'read' }));
      },
      write: function (input) {
        return global.CORE.call('training', '', Object.assign({}, input || {}, { system: systemId, op: 'write' }));
      }
    });
  });
  global.CORE.setMock(false);
})(window);
