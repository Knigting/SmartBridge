# Student web application

The student workspace is served at `/student/` by `services/api`.

It covers tasks, active-stage work, learning, reports, the inAgent assistant, enterprise opportunities and privacy settings. Skill calls use the shared `/shared/skill-adapter.js` adapter and the API gateway.

See `integration-points.md` for the capability map. Run `node tools/smoke-all.js` from the repository root for page verification.
