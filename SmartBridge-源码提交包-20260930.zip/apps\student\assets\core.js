/* ==========================================================================
   智训桥 SmartBridge · 学生端 —— 平台能力接入层（window.CORE）
   --------------------------------------------------------------------------
   本文件与「企业端 / 教师端」的 assets/core.js 保持同一契约，只做一件事：
   为命题要求的「五类平台核心自动化技能」与「两套校内实训系统」预留统一接入位。
   **能力本体不在这里实现** —— 后端写好之后，通过 register() / registerSystem()
   挂适配器接进来，页面与交互代码一行都不用改。

   它负责四件事：
     1) 声明统一契约：任何能力的入参与返回都是同一个 envelope 形状
        { skill, version, ok, code, mode, input, output, evidence[], error, meta }
     2) invoke() 统一派发；未接入时返回契约形状的 not_connected 结果，
        **绝不抛异常** —— 调用方直接当「这块数据暂时没有」处理，界面不空转
     3) 记录调用留痕 CORE.trace —— 这是「确实调用了平台能力」的证据链
     4) 内置 mock 通道：演示与离线可直接跑通，返回一律标 mode:'mock'，
        界面上显示为「模拟通道」，不会与真实对接混淆

   ── 后端接入方式（写后端时照抄）──────────────────────────────────────
     CORE.register('parse-batch', {
       connected: true,
       describe: 'POST /api/parse-batch',
       run(payload, ctx) {
         return fetch('/api/parse-batch', { method:'POST',
           headers:{'Content-Type':'application/json'},
           body: JSON.stringify(payload) }).then(r => r.json());  // → { output, evidence }
       }
     });

     两套校内实训系统各自注册（命题硬性要求第 2 条：≥2 套系统互通）：
     CORE.registerSystem('lms',  { connected:true, read(…){}, write(…){}, describe:'校内实训教学平台 HTTP API' });
     CORE.registerSystem('edge', { connected:true, read(…){}, write(…){}, describe:'实训硬件数据网关 MQTT/OPC-UA' });

     后端就绪后关掉模拟：CORE.setMock(false);

   ── 页面怎么用接入位 ──────────────────────────────────────────────
     页面只声明「哪儿用」，不写调用逻辑：
       <div class="cap" data-cap="D1" data-skill="rag" data-args='{"query":"…"}'></div>
     core.js 会自动调 CORE.call(skill, hookId, args) 并把结果画成接入位卡片。
     hookId 与 CORE.hooks 一一对应，可在「设置」页看到完整清单与状态。

   加载顺序：data/mock.js → assets/store.js → assets/shell.js → assets/core.js → 页面脚本
   ========================================================================== */
window.CORE = (function () {
  'use strict';

  var VERSION = '1.0.0';
  var nowISO = function () { return new Date().toISOString(); };

  /* ============================================================ 五类能力 */
  var SKILLS = {
    'parse-batch': {
      key: 'A', label: '文件批量解析', short: '批量解析',
      demand: '命题硬性要求第 1 条（必调技能之一）',
      contract: 'files: Array<{name,ext,size}> → { files:[{ name, type, rows|pages, fields[], text }] }',
      adapts: '脚本 / 清单 / 表格 / 截图；单批 ≥ 2 份才算「批量」'
    },
    'training': {
      key: 'B', label: '实训系统自动操作', short: '跨系统操作',
      demand: '命题硬性要求第 1 条 + 第 2 条（≥2 套校内实训系统 / 硬件互通）',
      contract: '(system, {op:"write"|"read", action, payload|query}) → { system, action, ref|rows, evidence[] }',
      adapts: 'lms = 校内实训教学平台（进度 / 成绩 / 提交回写）；edge = 实训硬件数据网关（设备工况与操作日志）'
    },
    'multimodal': {
      key: 'C', label: '语音 / 图像多模态识别', short: '多模态',
      demand: '命题硬性要求第 1 条（必调技能之一）',
      contract: '{ kind:"image"|"audio", source, purpose } → { kind, text, fields, confidence, evidence[] }',
      adapts: '运行截图 / 仪表照片 → 读数与步骤判定；语音提问 → 转写'
    },
    'rag': {
      key: 'D', label: 'RAG 知识库检索', short: 'RAG 检索',
      demand: '命题硬性要求第 1 条 + 创新点「企业工艺垂直知识库」',
      contract: '(query, { scopes:[], topK }) → { hits:[{ doc, page, snippet, score }], answer, evidence[] }',
      adapts: 'scopes：企业验收规范 / 岗位能力标准 / 学校课程标准 / 微课知识库 / 历史任务库'
    },
    'report': {
      key: 'E', label: '数据可视化报告生成', short: '可视化报告',
      demand: '命题硬性要求第 1 条 + 交付物⑥「量化效益分析报告」',
      contract: '(data, { kind, format }) → { title, sections[], charts:[{ type, title, series }], file, evidence[] }',
      adapts: 'kind：能力画像 / 成长周报 / 能力材料包；format：html | pdf | docx'
    }
  };

  /* ============================================================ 两套校内实训系统
     命题硬性要求第 2 条：至少 2 套校内实训系统 / 实训硬件的数据互通与跨系统融合。
     本端按「一套真接 + 一套适配器接口」思路预留，当前均走模拟通道。 */
  var SYSTEMS = [
    {
      id: 'lms', label: '校内实训教学平台', kind: 'api', protocol: 'HTTP API',
      scope: '实训题库 · 阶段任务 · 班级提交 · 成绩回填',
      contract: 'read: 拉本人阶段进度与成绩 · write: 回写提交与检查结果',
      place: '接入位 B1 / B2',
      vendor: '某职业学院实训教学平台（演示）'
    },
    {
      id: 'edge', label: '实训硬件数据网关', kind: 'stream', protocol: 'MQTT / OPC-UA',
      scope: '数控实训台 · 机器人工作站 · 工业物联网采集端',
      contract: 'read: 拉设备工况与操作日志，作为实操留痕',
      place: '接入位 B3',
      vendor: '实训中心设备联网网关（演示）'
    }
  ];

  /* ============================================================ 接入位清单
     id    接入位编号，页面上以 data-cap="id" 声明
     skill 所属能力
     page  所在页面
     where 业务位置（用于设置页清单）
     wired true = 界面已留好调用点
     编号规则：A/B/C/D/E 与「企业端 / 教师端」一致，便于对照同一能力在不同角色的落点 */
  var HOOKS = [
    { id: 'A1', skill: 'parse-batch', page: 'tasks.html',    where: '我的任务 · 批量解析本轮要提交的多个产物（脚本 / 清单 / 表）', wired: true },
    { id: 'A2', skill: 'parse-batch', page: 'task.html',     where: '阶段详情 · 提交前批量检查产物完整性与字段口径',              wired: true },

    { id: 'B1', skill: 'training',    page: 'tasks.html',    where: '我的任务 · 从校内实训教学平台拉本人阶段进度与成绩（跨系统回填）', wired: true, sys: 'lms' },
    { id: 'B2', skill: 'training',    page: 'tasks.html',    where: '我的任务 · 把提交与检查结果回写实训教学平台（提交记录表下方）', wired: true, sys: 'lms' },
    { id: 'B3', skill: 'training',    page: 'report.html',   where: '能力画像 · 从实训硬件数据网关拉实操工况与操作日志（实操留痕）', wired: true, sys: 'edge' },

    { id: 'C1', skill: 'multimodal',  page: 'task.html',     where: '阶段详情 · 运行截图 / 仪表照片读数与步骤判定（客观正确性）',  wired: true },
    { id: 'C2', skill: 'multimodal',  page: 'inagent.html',  where: 'inAgent 助手 · 语音提问转写为文字',                          wired: true },

    { id: 'D1', skill: 'rag',         page: 'task.html',     where: '阶段详情 · 按企业验收规范与工艺文档逐条比对',                wired: true },
    { id: 'D2', skill: 'rag',         page: 'report.html',   where: '能力画像 · 对标岗位能力标准 / 学校课程标准，生成待验证能力',  wired: true },
    { id: 'D3', skill: 'rag',         page: 'inagent.html',  where: 'inAgent 助手 · 检索课程标准与微课知识库并给出出处',          wired: true },
    { id: 'D4', skill: 'rag',         page: 'learning.html', where: '微课与补强 · 按薄弱点检索微课与企业公开任务内容',            wired: true },

    { id: 'E1', skill: 'report',      page: 'report.html',   where: '能力画像 · 生成《能力画像与证据摘要报告》',                  wired: true },
    { id: 'E2', skill: 'report',      page: 'index.html',    where: '工作台 · 生成每周成长报告（过程分与薄弱点变化）',            wired: true },
    { id: 'E3', skill: 'report',      page: 'company.html',  where: '企业对接 · 生成能力材料包摘要（匿名画像 + 作品证据）',        wired: true }
  ];

  /* ============================================================ 适配器注册 */
  var adapters = {};   /* skillKey → { connected, run, describe } */
  var systems = {};    /* sysId    → { connected, write, read, describe } */
  var config = { mock: true, endpoint: '', timeout: 30000 };
  var trace = [];

  function register(skill, adapter) {
    if (!SKILLS[skill]) return false;
    adapters[skill] = adapter || {};
    return true;
  }
  function registerSystem(id, adapter) {
    if (!SYSTEMS.some(function (s) { return s.id === id; })) return false;
    systems[id] = adapter || {};
    return true;
  }
  function setMock(on) { config.mock = !!on; return config.mock; }
  function useEndpoint(url) { config.endpoint = String(url || ''); return config.endpoint; }

  /* ============================================================ 统一契约 */
  function envelope(skill, input, o) {
    o = o || {};
    return {
      skill: skill,
      version: VERSION,
      ok: !!o.ok,
      code: o.code || (o.ok ? 'ok' : 'not_connected'),
      mode: o.mode || 'none',                 /* live | mock | none */
      input: input || null,
      output: o.output || null,
      evidence: o.evidence || [],
      error: o.error || '',
      meta: {
        at: nowISO(),
        ms: o.ms == null ? 0 : o.ms,
        adapter: o.adapter || '',
        skillLabel: (SKILLS[skill] || {}).label || skill,
        hookId: o.hookId || ''
      }
    };
  }

  function record(env, hookId) {
    trace.push({
      at: env.meta.at, skill: env.skill, hook: hookId || '',
      mode: env.mode, ok: env.ok, code: env.code, evidence: env.evidence.length
    });
    if (trace.length > 200) trace.splice(0, trace.length - 200);
    return env;
  }

  /* ============================================================ mock 通道
     仅为演示与离线自测存在；每条都带 mode:'mock' 与 evidence，便于与真接区分。
     数据取自方案中的设备点检案例，与其它两端保持一致。 */
  var MOCK = {
    'parse-batch': function (input) {
      var files = (input && input.files) || [];
      var list = files.length ? files : [
        { name: 'rule_check.py', ext: 'py', size: '4 KB' },
        { name: 'exception_list.xlsx', ext: 'xlsx', size: '318 KB' },
        { name: 'pending-review-unit-mismatch.md', ext: 'md', size: '6 KB' }
      ];
      return {
        output: {
          count: list.length,
          files: list.map(function (f) {
            var ext = String(f.ext || '').toLowerCase();
            var type = ext === 'xlsx' || ext === 'csv' ? '表格'
              : ext === 'py' || ext === 'js' || ext === 'sql' ? '脚本'
                : ext === 'png' || ext === 'jpg' ? '图片' : '文档';
            return {
              name: f.name, type: type,
              rows: type === '表格' ? 128 : null,
              pages: type === '文档' ? 2 : null,
              fields: type === '表格' ? ['设备编号', '日期', '温度', '班组', '点检人', '备注'] : ['产物说明'],
              text: type === '脚本' ? '包含温度阈值判断与缺失值分流，未写入补全逻辑' : '字段命名与阶段一约定一致'
            };
          }),
          anomalies: ['待核查清单里 3 条未标注来源批次（建议补行号）']
        },
        evidence: list.map(function (f) {
          return { file: f.name, kind: '批量解析', note: '模拟通道 · 非真实解析' };
        })
      };
    },

    'training': function (input) {
      var sys = (input && input.system) || 'lms';
      var op = (input && input.op) || 'read';
      if (sys === 'edge') {
        return {
          output: {
            system: 'edge', action: op,
            rows: [
              { dev: '数控实训台 CNC-02', state: '运行', metric: '主轴温度 42℃ / 转速 3200rpm', log: '14:31 完成工位切换' },
              { dev: '机器人工作站 RB-11', state: '待机', metric: '重复定位精度 0.02mm', log: '14:05 完成一次取放' },
              { dev: '采集网关 GW-07', state: '在线', metric: '上报周期 5s / 丢包 0', log: '14:33 心跳正常' }
            ]
          },
          evidence: [{ system: 'edge', protocol: 'MQTT / OPC-UA', note: '模拟通道 · 非真实采集' }]
        };
      }
      if (op === 'write') {
        return {
          output: { system: 'lms', action: 'write', ref: 'TASK-PRJ-0917-001#L2', rows: null,
            note: '已回写：阶段二提交与检查结果（状态 running）' },
          evidence: [{ system: 'lms', api: 'POST /api/levels/{id}/submit', note: '模拟通道 · 非真实回写' }]
        };
      }
      return {
        output: {
          system: 'lms', action: 'read',
          rows: [
            { no: '阶段一', progress: '100%', score: 86, state: '已通过' },
            { no: '阶段二', progress: '60%', score: null, state: '提交检查中' },
            { no: '阶段三', progress: '0%', score: null, state: '未解锁' },
            { no: '阶段四', progress: '0%', score: null, state: '未解锁' }
          ]
        },
        evidence: [{ system: 'lms', api: 'GET /api/student/levels', note: '模拟通道 · 非真实回填' }]
      };
    },

    'multimodal': function (input) {
      var kind = (input && input.kind) || 'image';
      if (kind === 'audio') {
        return {
          output: {
            kind: 'audio',
            text: '温度单位一会儿摄氏度一会儿华氏度，我不确定该怎么处理，是不是要自己换算？',
            fields: { 涉及批次: '三号线', 关键问题: '单位混用是否自行换算', 期望: '明确处理方式' },
            confidence: 0.88
          },
          evidence: [{ kind: 'audio', duration: '12.4s', note: '模拟通道 · 非真实转写' }]
        };
      }
      return {
        output: {
          kind: 'image',
          text: '运行截图 → 识别到异常清单表头 5 列、数据行 27 行；仪表读数 84℃',
          fields: { 表头: '设备编号 / 日期 / 温度 / 判定 / 说明', 行数: '27', 读数: '84℃（> 80℃，异常）', 步骤: '第 3 步未见单位标注' },
          confidence: 0.83
        },
        evidence: [{ kind: 'image', file: (input && input.source) || 'exception-list-screenshot.png', note: '模拟通道 · 非真实识别' }]
      };
    },

    'rag': function (input) {
      var q = (input && input.query) || '温度阈值与缺失值处理要求';
      return {
        output: {
          query: q,
          answer: '企业确认版：温度 > 80℃ 记异常，= 80℃ 为边界正常值；缺失值列入待核查，不得自行补成正常值；单位混用须提交企业确认，不得自行换算。',
          hits: [
            { doc: '设备点检验收规范_v2.pdf', page: 4, scope: '企业验收规范', snippet: '温度异常判定以 80℃ 为界，边界值按正常处理', score: 0.93 },
            { doc: '岗位能力标准 · 数据处理岗.pdf', page: 12, scope: '岗位能力标准', snippet: '能按既定口径处理缺失与异常，不擅自补全数据', score: 0.88 },
            { doc: '课程标准 · 数据清洗与质量.pdf', page: 7, scope: '学校课程标准', snippet: '掌握边界条件、缺失值分流与可追溯输出', score: 0.81 }
          ]
        },
        evidence: [{ scope: '企业验收规范 / 岗位能力标准 / 学校课程标准', topK: (input && input.topK) || 5, note: '模拟通道 · 非真实检索' }]
      };
    },

    'report': function (input) {
      var kind = (input && input.kind) || '能力画像';
      var base = {
        '能力画像': {
          title: '能力画像与证据摘要（陈晓雨 · 软件技术 2201）',
          sections: [
            { h: '结论摘要', p: '六个维度中 4 项有任务证据支撑，过程分累计 268；成果呈现与问题定位缺少证据，标记为待验证。' },
            { h: '证据来源', p: '依据四阶段提交记录、固定样例测试（5 条）与返修轨迹，非自评。' },
            { h: '改进建议', p: '优先补边界条件与缺失值处理；单位混用问题已提交教师汇总，未自行处理，处置正确。' }
          ],
          charts: [
            { type: 'bar', title: '六维能力（满分 100）', series: [{ name: '数据整理', value: 88 }, { name: '规则实现', value: 74 }, { name: '成果呈现', value: 46 }, { name: '问题定位', value: 38 }] },
            { type: 'bar', title: '任务匹配度', series: [{ name: '去重规则', value: 92 }, { name: '异常判断', value: 76 }, { name: '周报呈现', value: 46 }] }
          ],
          metrics: [
            { k: '已通过阶段', v: '1 / 4', d: '阶段二检查中' },
            { k: '过程分', v: '268', d: '含补强项' },
            { k: '待验证能力', v: '3 项', d: '缺证据不下结论' },
            { k: '固定样例', v: '5 / 5', d: '边界值正确' }
          ]
        },
        '成长周报': {
          title: '每周成长报告（第 4 教学周）',
          sections: [
            { h: '本周完成', p: '阶段一通过（过程分 +86）；阶段二产物已提交，进入自动检查。' },
            { h: '本周卡点', p: '80℃ 边界值曾误判，已按企业规则修正；单位混用问题已上报。' },
            { h: '下周计划', p: '完成阶段二待核查清单并提交通知，补一节边界条件微课。' }
          ],
          charts: [
            { type: 'bar', title: '每周过程分', series: [{ name: '第1周', value: 96 }, { name: '第2周', value: 104 }, { name: '第3周', value: 68 }, { name: '第4周', value: 26 }] },
            { type: 'bar', title: '阶段完成度', series: [{ name: '阶段一', value: 100 }, { name: '阶段二', value: 60 }, { name: '阶段三', value: 0 }, { name: '阶段四', value: 0 }] }
          ],
          metrics: [
            { k: '本周过程分', v: '26', d: '仍在累计' },
            { k: '提问记录', v: '12 条', d: '均已记入清单' },
            { k: '薄弱点', v: '3 项', d: '已匹配微课' },
            { k: '待办', v: '3 项', d: '含 1 项授权请求' }
          ]
        },
        '能力材料包': {
          title: '能力材料包摘要（匿名编号 CND-0427）',
          sections: [
            { h: '可提供内容', p: '匿名能力画像、四阶段过程档案、作品证据（统一台账 / 异常清单 / 待核查清单）。' },
            { h: '未包含内容', p: '姓名、班级、联系方式等直接标识；未经本人逐项授权不对外提供。' },
            { h: '待验证项', p: '批量数据的异常维护经验、跨班组口径沟通确认、按说明独立复现他人成果。' }
          ],
          charts: [
            { type: 'bar', title: '材料完备度', series: [{ name: '画像', value: 100 }, { name: '过程档案', value: 100 }, { name: '作品证据', value: 67 }, { name: '待验证清单', value: 100 }] }
          ],
          metrics: [
            { k: '材料项', v: '4 项', d: '3 项已就绪' },
            { k: '匿名编号', v: 'CND-0427', d: '不含身份信息' },
            { k: '授权状态', v: '待本人确认', d: '逐项授权' },
            { k: '企业请求', v: '2 家', d: '均未开放' }
          ]
        }
      };
      var r = base[kind] || base['能力画像'];
      return {
        output: {
          kind: kind, title: r.title, sections: r.sections, charts: r.charts, metrics: r.metrics,
          dataset: (input && input.data) || {},
          file: 'SmartBridge-' + kind + '报告-2026-0917.html'
        },
        evidence: [{ kind: kind, source: '学期过程档案 + 阶段提交记录', note: '模拟通道 · 非真实生成' }]
      };
    }
  };

  /* ============================================================ 统一派发 */
  function invoke(skill, payload, ctx) {
    var t0 = Date.now();
    var hookId = (ctx && ctx.hook) || '';
    var adapter = adapters[skill];
    try {
      if (adapter && (adapter.connected || adapter.run)) {
        return Promise.resolve(adapter.run(payload, ctx || {}))
          .catch(function (e) {
            return record(envelope(skill, payload, {
              ok: false, mode: 'live', code: 'error',
              error: String((e && e.message) || e), hookId: hookId, ms: Date.now() - t0
            }), hookId);
          })
          .then(function (res) {
            if (res && res.skill) return record(res, hookId);
            return record(envelope(skill, payload, {
              ok: true, mode: 'live', code: 'ok',
              output: res && res.output, evidence: (res && res.evidence) || [],
              adapter: (adapter && adapter.describe) || '已接入适配器',
              hookId: hookId, ms: Date.now() - t0
            }), hookId);
          });
      }
      if (config.mock && MOCK[skill]) {
        var out = MOCK[skill](payload, ctx || {});
        return Promise.resolve(record(envelope(skill, payload, {
          ok: true, mode: 'mock', code: 'mock',
          output: out && out.output, evidence: (out && out.evidence) || [],
          adapter: '内置模拟通道', hookId: hookId, ms: Date.now() - t0
        }), hookId));
      }
      return Promise.resolve(record(envelope(skill, payload, {
        ok: false, mode: 'none', code: 'not_connected',
        error: '该能力尚未接入后端实现', hookId: hookId, ms: Date.now() - t0
      }), hookId));
    } catch (e) {
      return Promise.resolve(record(envelope(skill, payload, {
        ok: false, mode: 'none', code: 'error',
        error: String((e && e.message) || e), hookId: hookId, ms: Date.now() - t0
      }), hookId));
    }
  }

  /* ============================================================ 便利方法 */
  function parseBatch(files, ctx) { return invoke('parse-batch', { files: files || [], endpoint: config.endpoint }, ctx); }
  function systemOp(sysId, op, payload, ctx) {
    return invoke('training', {
      system: sysId, op: op,
      action: (payload && payload.action) || '',
      payload: (payload && payload.payload) != null ? payload.payload : null,
      query: (payload && payload.query) != null ? payload.query : null
    }, ctx);
  }
  function multimodal(input, ctx) { return invoke('multimodal', input || {}, ctx); }
  function ragQuery(query, scopes, ctx) { return invoke('rag', { query: query || '', scopes: scopes || [], topK: (ctx && ctx.topK) || 5 }, ctx); }
  function reportGen(data, kind, ctx) { return invoke('report', { data: data || {}, kind: kind || '能力画像', format: (ctx && ctx.format) || 'html' }, ctx); }

  /* 页面统一入口：call(skill, hookId, args) —— 永不抛异常 */
  function call(skill, hookId, args) {
    args = args || {};
    try {
      switch (skill) {
        case 'parse-batch': return parseBatch(args.files || [], { hook: hookId, purpose: args.purpose });
        case 'training': return systemOp(args.system, args.op || 'read', args, { hook: hookId });
        case 'multimodal': return multimodal(args, { hook: hookId });
        case 'rag': return ragQuery(args.query, args.scopes, { hook: hookId });
        case 'report': return reportGen(args.data, args.kind, { hook: hookId, format: args.format });
        default:
          return Promise.resolve(envelope(skill, args, {
            ok: false, code: 'unknown_skill', error: '未知能力：' + skill, hookId: hookId
          }));
      }
    } catch (e) {
      return Promise.resolve(envelope(skill, args, {
        ok: false, code: 'error', error: String((e && e.message) || e), hookId: hookId
      }));
    }
  }

  /* ============================================================ 状态查询 */
  function skillState(key) {
    var a = adapters[key];
    if (a && (a.connected || a.run)) return { state: 'live', label: '已接入', cls: 'live' };
    if (config.mock && MOCK[key]) return { state: 'mock', label: '模拟通道', cls: 'mock' };
    return { state: 'none', label: '未接入', cls: 'none' };
  }
  function systemState(id) {
    var a = systems[id];
    if (a && (a.connected || a.read || a.write)) return { state: 'live', label: '已接入', cls: 'live' };
    if (config.mock) return { state: 'mock', label: '模拟通道', cls: 'mock' };
    return { state: 'none', label: '未接入', cls: 'none' };
  }
  function status() {
    var skills = Object.keys(SKILLS).map(function (k) {
      var s = skillState(k);
      return {
        key: k, meta: SKILLS[k], state: s.state, label: s.label, cls: s.cls,
        hooks: HOOKS.filter(function (h) { return h.skill === k; })
      };
    });
    var sys = SYSTEMS.map(function (s) {
      var st = systemState(s.id);
      return { id: s.id, meta: s, state: st.state, label: st.label, cls: st.cls };
    });
    return {
      version: VERSION,
      mock: config.mock,
      liveSkills: skills.filter(function (s) { return s.state === 'live'; }).length,
      required: 3,
      skills: skills,
      systems: sys,
      hooks: { total: HOOKS.length, wired: HOOKS.filter(function (h) { return h.wired; }).length },
      trace: trace.slice(-20)
    };
  }
  function hook(id) {
    for (var i = 0; i < HOOKS.length; i++) if (HOOKS[i].id === id) return HOOKS[i];
    return null;
  }

  /* ============================================================ 接入位自动渲染
     页面只使用五项已注册能力，例如 <div class="cap" data-cap="D1" data-skill="rag" data-args='{"query":"问题"}'>
     渲染结果与「企业端 / 教师端」同构：能力名 + 接入位编号 + 状态徽标 + 输出字段 + 出处。 */
  function esc(s) {
    if (window.U && U.esc) return U.esc(s);
    return String(s == null ? '' : s).replace(/[&<>]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c];
    });
  }
  function kv(k, v) {
    if (v === null || v === undefined || v === '') return '';
    return '<div class="cap-kv"><span class="k">' + esc(k) + '</span><span class="v">' + esc(v) + '</span></div>';
  }
  function skeleton(id, skill, hk) {
    var meta = SKILLS[skill] || {};
    return '<div class="cap-head"><b>' + esc(meta.label || skill) + '</b>' +
      '<span class="hook">' + esc(id) + '</span>' +
      '<span class="cap-mode none"><i></i>调用中…</span></div>' +
      '<div class="cap-why">' + esc((hk && hk.where) || '') + '</div>';
  }
  /* 解析异常种类很多，字段不统一：缺 note 时用其它字段拼出可读说明，避免出现 undefined */
  function anomalyText(a) {
    if (!a || typeof a !== 'object') return String(a || '');
    var note = a.note || (a.original !== undefined
      ? ('原始值 ' + a.original + (a.normalized !== undefined && a.normalized !== a.original ? ' → ' + a.normalized : ''))
      : (a.normalized ? ('规范为 ' + a.normalized) : (a.field ? ('字段 ' + a.field) : '')));
    return [a.type, a.count == null ? '' : a.count + ' 处', note].filter(Boolean).join(' · ');
  }
  /* 跨系统返回的行结构按动作不同而不同，按已知字段优先级挑一个可读的主字段 */
  function trainingRowText(r) {
    if (!r || typeof r !== 'object') return String(r || '');
    var skip = { metric: 1, value: 1, submitted: 1, total: 1, avg: 1 };
    if (r.device || r.cls) {
      return (r.device ? (r.device + ' ' + (r.metric || '') + ' ' + (r.value || '') + ' · ' + (r.status || ''))
        : (r.cls + ' ' + r.submitted + '/' + r.total + ' 已提交 · 均分 ' + r.avg + ' · ' + (r.status || ''))).trim();
    }
    var main = r.name || r.stage_no || r.case_id || r.device_id || '';
    var rest = Object.keys(r).filter(function (k) { return !skip[k] && r[k] !== null && r[k] !== '' && typeof r[k] !== 'object'; })
      .map(function (k) { return k + '=' + r[k]; }).slice(0, 4).join(' ');
    return [main, rest].filter(Boolean).join(' · ');
  }

  function block(id, skill, hk, env) {
    var meta = SKILLS[skill] || {};
    var st = { live: '已接入', mock: '模拟通道', none: '未接入', simulated: '本地演示通道' }[env.mode] || env.mode;
    var head = '<div class="cap-head"><b>' + esc(meta.label || skill) + '</b>' +
      '<span class="hook">' + esc(id) + '</span>' +
      '<span class="cap-mode ' + esc(env.mode) + '"><i></i>' + esc(st) + '</span></div>' +
      '<div class="cap-why">' + esc((hk && hk.where) || '') + '</div>';
    /* 写操作按治理策略要求人工审批：不是调用失败，而是「计划已生成、待审批」的中间态 */
    if (env.code === 'approval_required') {
      var p = env.output || {};
      return '<div class="cap-head"><b>' + esc(meta.label || skill) + '</b>' +
        '<span class="hook">' + esc(id) + '</span>' +
        '<span class="cap-mode pending"><i></i>待人工审批</span></div>' +
        '<div class="cap-why">' + esc((hk && hk.where) || '') + '　·　写操作已生成执行计划，按治理策略需人工审批后才会执行。</div>' +
        '<div class="cap-out">' + kv('目标系统', (p.system === 'edge' ? '实训硬件数据网关' : '校内实训教学平台') + ' · ' + (p.action || '—')) +
        kv('风险等级', p.risk || '—') + kv('计划编号', p.plan_id || '—') +
        kv('审批方式', 'POST /api/skills/training/plans/' + (p.plan_id || '<plan_id>') + '/approve') + '</div>';
    }
    if (!env.ok) {
      /* 调用失败：徽标必须如实显示失败，绝不能亮「已接入」绿灯 */
      return '<div class="cap-head"><b>' + esc(meta.label || skill) + '</b>' +
        '<span class="hook">' + esc(id) + '</span>' +
        '<span class="cap-mode none"><i></i>调用失败</span></div>' +
        '<div class="cap-why">' + esc((hk && hk.where) || '') + '</div>' +
        '<div class="cap-out">' + kv('失败原因', env.error || env.code || '未知错误') + '</div>';
    }
    var o = env.output || {};
    var rows = [];
    if (skill === 'parse-batch') {
      rows.push(kv('解析文件', (o.count || 0) + ' 份'));
      var names = (o.files || []).map(function (f) { return f.name + '（' + f.type + '）'; }).join('、');
      rows.push(kv('文件清单', names));
      rows.push(kv('异常提示', (o.anomalies || []).map(anomalyText).join('；')));
    } else if (skill === 'training') {
      rows.push(kv('目标系统', (o.system === 'edge' ? '实训硬件数据网关' : '校内实训教学平台') + ' · ' + o.action));
      if (o.ref) rows.push(kv('回执', o.ref + (o.receipt ? '　' + o.receipt : '')));
      if (o.rows && o.rows.length) rows.push(kv('返回条目', o.rows.map(trainingRowText).join('；')));
    } else if (skill === 'multimodal') {
      rows.push(kv('模态', o.kind === 'audio' ? '语音转写' : '图像识别'));
      rows.push(kv('识别文本', o.text));
      rows.push(kv('结构化字段', Object.keys(o.fields || {}).map(function (k) { return k + '=' + o.fields[k]; }).join(' · ')));
      rows.push(kv('置信度', o.confidence));
    } else if (skill === 'rag') {
      rows.push(kv('检索问题', o.query));
      rows.push(kv('结论', o.answer));
      rows.push(kv('命中片段', (o.hits || []).map(function (h) { return h.doc + ' p' + h.page + '（' + h.scope + ' ' + h.score + '）'; }).join('；')));
    } else if (skill === 'report') {
      rows.push(kv('报告标题', o.title));
      rows.push(kv('章节', (o.sections || []).map(function (s) { return s.h; }).join(' / ')));
      rows.push(kv('指标', (o.metrics || []).map(function (m) { return m.k + ' ' + m.v; }).join('；')));
      rows.push(kv('图表', (o.charts || []).map(function (c) { return c.title; }).join('；')));
      rows.push(kv('产出文件', o.file));
    }
    var ev = (env.evidence || []).map(function (e) {
      return '<code>' + esc(JSON.stringify(e).replace(/[{}"]/g, '').replace(/,/g, ' · ')) + '</code>';
    }).join('');
    return head +
      '<div class="cap-out">' + rows.filter(Boolean).join('') + '</div>' +
      (ev ? '<div class="cap-ev"><span class="t">EVIDENCE · 出处</span>' + ev + '</div>' : '');
  }

  /* 报告类接入位只声明了 kind，本身不带指标。这里先向业务服务取真实聚合数据，
     再交给报告 Skill，避免一律返回「请传入真实 metrics」 */
  function enrichArgs(skill, args) {
    if (skill !== 'report' || typeof fetch !== 'function') return Promise.resolve(args);
    return fetch('/api/report-data', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ kind: args.kind || '', data: args.data || {} })
    }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
      var d = j && j.data;
      if (!d || (!d.metrics && !d.sections && !d.charts)) return args;
      var merged = {};
      Object.keys(args).forEach(function (k) { merged[k] = args[k]; });
      merged.data = d;
      if (d.title) merged.title = d.title;
      return merged;
    }).catch(function () { return args; });
  }

  function paintCaps() {
    /* 侧栏能力通道指示：无论本页有没有接入位都先更新（模拟通道也算「可用」） */
    var s = status();
    var cn = document.getElementById('capName');
    if (cn) {
      cn.textContent = s.liveSkills > 0 ? '已接入 ' + s.liveSkills + ' 类'
        : (s.mock ? '模拟通道 ' + s.hooks.wired + ' 处' : '未接入');
    }
    var cd = document.getElementById('capDot');
    if (cd) {
      if (s.liveSkills > 0 || s.mock) cd.classList.add('ok');
      else cd.classList.remove('ok');
    }

    var nodes = document.querySelectorAll('[data-cap]');
    if (!nodes.length) return;
    Array.prototype.forEach.call(nodes, function (el) {
      var id = el.getAttribute('data-cap');
      var skill = el.getAttribute('data-skill') || (hook(id) || {}).skill;
      var args = {};
      try { args = JSON.parse(el.getAttribute('data-args') || '{}'); } catch (e) { args = {}; }
      var hk = hook(id) || {};
      el.className = 'cap skeleton';
      el.innerHTML = skeleton(id, skill, hk);
      el.setAttribute('data-cap-state', 'pending');
      enrichArgs(skill, args).then(function (finalArgs) {
        var key = 'smartbridge-cap:' + location.pathname + ':' + id + ':' + skill + ':' + JSON.stringify(finalArgs || {});
        try {
          var cached = sessionStorage.getItem(key);
          if (cached) return JSON.parse(cached);
        } catch (e) { /* Session storage is optional. */ }
        return call(skill, id, finalArgs).then(function (env) {
          try { if (env && env.ok) sessionStorage.setItem(key, JSON.stringify(env)); } catch (e) { /* Ignore quota errors. */ }
          return env;
        });
      }).then(function (env) {
        /* 调用失败的接入位打 error 标记：自测脚本能区分「真 live」与「假 live」 */
        var doneMode = env && env.ok === false ? 'error' : ((env && env.mode) || 'none');
        el.className = 'cap' + (doneMode === 'none' ? ' skeleton' : '');
        el.innerHTML = block(id, skill, hk, env);
        /* 「已渲染」专属标记，供自测脚本断言，避免与静态说明卡片混淆 */
        el.setAttribute('data-cap-done', doneMode);
      });
    });
  }

  var CORE = {
    version: VERSION,
    skills: SKILLS,
    systems: SYSTEMS,
    hooks: HOOKS,
    hook: hook,
    register: register,
    registerSystem: registerSystem,
    setMock: setMock,
    useEndpoint: useEndpoint,
    invoke: invoke,
    call: call,
    parseBatch: parseBatch,
    systemOp: systemOp,
    multimodal: multimodal,
    ragQuery: ragQuery,
    reportGen: reportGen,
    status: status,
    skillState: skillState,
    systemState: systemState,
    render: paintCaps,
    getTrace: function () { return trace.slice(); }
  };
  Object.defineProperty(CORE, 'trace', { get: function () { return trace.slice(); } });

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', paintCaps);
  else paintCaps();

  return CORE;
})();
(function () {
  var source = '/shared/skill-adapter.js?v=20260924-1';
  if (document.readyState === 'loading') document.write('<script src="' + source + '"><\/script>');
  else {
    var script = document.createElement('script');
    script.src = source;
    document.head.appendChild(script);
  }
})();
