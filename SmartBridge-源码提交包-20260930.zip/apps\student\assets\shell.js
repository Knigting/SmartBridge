/* ==========================================================================
   shell.js —— 页面外壳（侧边导航 + 顶栏）与通用渲染工具
   所有页面共用，保证导航一致与页面间跳转；当前页自动高亮。
   ========================================================================== */
(function () {
  /* ---------------- 导航配置（新增页面只需在此加一项） ---------------- */
  const ICON = {
    home: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
    task: '<path d="M4 6h16M4 12h16M4 18h10"/>',
    flag: '<path d="M12 3l2.4 4.9 5.4.8-3.9 3.8.9 5.4-4.8-2.5-4.8 2.5.9-5.4L4.2 8.7l5.4-.8z"/>',
    chart: '<path d="M4 19V9M10 19V5M16 19v-8M22 19H2"/>',
    agent: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6.5 8-6.5s8 2.5 8 6.5"/>',
    book: '<path d="M4 19V5a2 2 0 0 1 2-2h13v18H6a2 2 0 0 1-2-2zm0 0a2 2 0 0 1 2-2h13"/>',
    building: '<path d="M3 21h18M5 21V8l7-5 7 5v13M9 21v-6h6v6"/>',
    setting: '<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.6-2-3.4-2.4 1a7 7 0 0 0-2-1.2L14 3h-4l-.5 2.6a7 7 0 0 0-2 1.2l-2.4-1-2 3.4 2 1.6A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.6 2 3.4 2.4-1a7 7 0 0 0 2 1.2L10 21h4l.5-2.6a7 7 0 0 0 2-1.2l2.4 1 2-3.4-2-1.6c.1-.4.1-.8.1-1.2z"/>'
  };

  const NAV = [
    { href: "index.html",    label: "工作台",       icon: ICON.home, match: ["index.html", ""] },
    { href: "tasks.html",    label: "我的任务",     icon: ICON.task, match: ["tasks.html", "task.html"], badge: 1 },
    { href: "report.html",   label: "能力画像",     icon: ICON.chart, match: ["report.html"] },
    { href: "inagent.html",  label: "inAgent 助手", icon: ICON.agent, match: ["inagent.html"] },
    { href: "learning.html", label: "微课与补强",   icon: ICON.book, match: ["learning.html"] },
    { href: "company.html",  label: "企业对接",     icon: ICON.building, match: ["company.html"], badge: 2, badgeWarn: true }
  ];
  const NAV2 = [
    { href: "settings.html", label: "设置", icon: ICON.setting, match: ["settings.html"] }
  ];

  const STATUS_TEXT = {
    pending: "pending", running: "running", success: "success",
    partial_success: "partial_success", failed: "failed"
  };
  const STATUS_CN = {
    pending: "待开始", running: "进行中", success: "已通过",
    partial_success: "部分成功", failed: "未通过",
    /* 试做 / 录用状态（冲突 B18：原复用执行态 running，与「已完成试做」文案矛盾） */
    trial_done: "试做已完成", hired: "已录用", not_hired: "未录用", interview_pending: "待安排"
  };

  const U = {
    /* 状态徽章：严格使用团队规范的状态枚举 */
    badge(status, extraCn) {
      return `<span class="badge badge-${status}">${STATUS_TEXT[status] || status}${extraCn ? " · " + extraCn : ""}</span>`;
    },
    statusCn(s) { return STATUS_CN[s] || s; },
    /* 16 站流程轨道 */
    track(stages, current) {
      const donePct = ((current - 1) / (stages.length - 1)) * 96 + 3.1;
      const stops = stages.map(s => {
        const cls = Number(s.no) < current ? "done" : (Number(s.no) === current ? "current" : "");
        return `<div class="stop ${cls}" role="listitem" title="${s.no} ${s.name}">
          <span class="stop-dot"></span><span class="stop-no">${s.no}</span></div>`;
      }).join("");
      return `<div class="track" role="list" aria-label="16 步流程轨道">
        <span class="track-line-done" style="width:${donePct}%"></span>${stops}</div>`;
    },
    /* 动态时间线 */
    feed(items) {
      return `<ul class="feed">${items.map(i => `
        <li class="${i.kind}">
          <h3>${i.title} ${U.badge(i.badge)}<span class="time num">${i.time}</span></h3>
          <p>${i.desc}</p>
        </li>`).join("")}</ul>`;
    },
    /* 能力雷达（SVG，六维） */
    radar(dims) {
      const R = 58, n = dims.length, cx = 0, cy = 0;
      const pt = (i, r) => {
        const a = -Math.PI / 2 + (2 * Math.PI * i) / n;
        return [ (cx + Math.cos(a) * r).toFixed(1), (cy + Math.sin(a) * r).toFixed(1) ];
      };
      const ring = r => dims.map((_, i) => pt(i, r).join(",")).join(" ");
      const value = dims.map((d, i) => pt(i, R * d.value / 100).join(",")).join(" ");
      const axes = dims.map((_, i) => { const [x, y] = pt(i, R); return `<line class="radar-axis" x1="0" y1="0" x2="${x}" y2="${y}"/>`; }).join("");
      const labels = dims.map((d, i) => {
        const [x, y] = pt(i, R + 12);
        const anchor = Math.abs(x) < 6 ? "middle" : (x > 0 ? "start" : "end");
        return `<text class="radar-label" x="${x}" y="${Number(y) + 4}" text-anchor="${anchor}">${d.key}</text>`;
      }).join("");
      return `<svg width="200" height="164" viewBox="-100 -82 200 164" role="img" aria-label="六维能力雷达图">
        <polygon class="radar-axis" points="${ring(R)}"/>
        <polygon class="radar-axis" opacity=".6" points="${ring(R * .66)}"/>
        <polygon class="radar-axis" opacity=".4" points="${ring(R * .33)}"/>
        <polygon class="radar-poly" points="${value}"/>
        ${axes}${labels}
        <style>.radar-poly{fill:rgba(255,159,41,.20);stroke:#EF8C0C;stroke-width:1.8}
        .radar-axis{stroke:#E6E1D6;fill:none;stroke-width:1}
        .radar-label{font-size:9.5px;fill:#6B6558}</style>
      </svg>`;
    },
    esc(s) { return String(s).replace(/[&<>]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c])); },
    /* ?id= 参数 */
    param(k) { return new URLSearchParams(location.search).get(k); }
  };

  /* ---------------- 渲染外壳 ---------------- */
  function current() {
    const f = (location.pathname.split("/").pop() || "index.html");
    return f;
  }
  function navHtml() {
    const cur = current();
    const item = a => {
      const on = a.match.includes(cur);
      return `<a href="${a.href}" ${on ? 'aria-current="page"' : ""}>
        <svg viewBox="0 0 24 24">${a.icon}</svg>${a.label}
        ${a.badge ? `<span class="nav-badge num${a.badgeWarn ? " warn" : ""}">${a.badge}</span>` : ""}
      </a>`;
    };
    return `<div class="brand">
        <img class="brand-logo" src="assets/logo.png" alt="智训桥 SmartBridge logo">
        <div><div class="brand-name">智训桥</div><span class="brand-sub">SmartBridge · 学生端</span></div>
      </div>
      <nav class="nav" aria-label="主导航">${NAV.map(item).join("")}
        <span class="nav-label">成长与就业</span>
        ${NAV2.map(item).join("")}
      </nav>
      <div class="sidebar-foot">
        <span class="src-dot" id="srcDot"></span>mycircle：<span class="mono" id="srcName">检测中</span><br>
        <span class="src-dot" id="agDot"></span>本地助手：<span class="mono" id="agName">检测中</span><br>
        <span class="src-dot" id="capDot"></span>能力通道：<span class="mono" id="capName">检测中</span><br>
        智训桥 SmartBridge · 规范 v2.1
      </div>`;
  }
  function topHtml(student) {
    return `<div class="search">
        <svg viewBox="0 0 24 24"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></svg>
        <input id="globalSearch" type="search" placeholder="搜索任务卡、知识点、微课…" aria-label="全局搜索">
      </div>
      <div class="topbar-spacer"></div>
      <button class="icon-btn" aria-label="通知（有未读）" onclick="location.href='index.html#todo'">
        <svg viewBox="0 0 24 24"><path d="M18 9a6 6 0 1 0-12 0c0 7-2 8-2 8h16s-2-1-2-8"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>
        <span class="dot" aria-hidden="true"></span>
      </button>
      <button class="avatar" onclick="location.href='settings.html'">
        <span class="avatar-face" aria-hidden="true">${U.esc(student.name.charAt(0))}</span>
        <span class="avatar-meta"><span class="avatar-name">${U.esc(student.name)}</span><br>
        <span class="avatar-class">${U.esc(student.klass)}</span></span>
      </button>`;
  }

  function mount() {
    const sb = document.getElementById("app-sidebar");
    const tb = document.getElementById("app-topbar");
    const student = window.MOCK.student;
    if (sb) sb.innerHTML = navHtml();
    if (tb) { tb.className = "topbar"; tb.innerHTML = topHtml(student); }

    /* 数据源指示灯：业务服务（mycircle）与内置本地助手分别探测 */
    const dot = document.getElementById("srcDot");
    const name = document.getElementById("srcName");
    Store.ping().then(ok => {
      if (!dot) return;
      if (ok) { dot.classList.add("ok"); name.textContent = "已连接"; }
      else { dot.classList.remove("ok"); name.textContent = "本地 Mock"; }
    });
    const agDot = document.getElementById("agDot");
    const agName = document.getElementById("agName");
    if (Store.pingInagent) {
      Store.pingInagent().then(ok => {
        if (!agDot) return;
        if (ok) { agDot.classList.add("ok"); agName.textContent = "已就绪"; }
        else { agDot.classList.remove("ok"); agName.textContent = "规则兜底"; }
      });
    }

    /* 全局搜索：回车跳转到最相关页面 */
    const input = document.getElementById("globalSearch");
    if (input) {
      input.addEventListener("keydown", e => {
        if (e.key !== "Enter") return;
        const q = input.value.trim();
        if (!q) return;
        const map = [["企业", "company.html"], ["画像", "report.html"], ["报告", "report.html"], ["微课", "learning.html"],
                     ["补强", "learning.html"], ["提问", "inagent.html"], ["inagent", "inagent.html"],
                     ["任务", "tasks.html"], ["阶段", "tasks.html"], ["设置", "settings.html"]];
        const hit = map.find(m => q.toLowerCase().includes(m[0].toLowerCase()));
        location.href = hit ? hit[1] : "tasks.html";
      });
    }
  }

  window.U = U;
  document.addEventListener("DOMContentLoaded", mount);
})();
