/* ==========================================================================
   store.js —— 数据层：优先读 mycircle 本地共享服务，失败自动回落本地 Mock
   --------------------------------------------------------------------------
   用法：const data = await Store.get('student')
   切换服务：Store.setBase('http://192.168.1.20:8080')  或浏览器控制台执行
   约定接口（与团队规范一致，字段/状态枚举统一）：
     GET  /api/student/profile        GET  /api/student/levels
     GET  /api/student/feed           GET  /api/student/notifications
     GET  /api/student/report         GET  /api/learning/recommendations
     GET  /api/student/authorizations POST /api/inagent/chat
     POST /api/levels/{id}/submit
   ========================================================================== */
(function () {
  const DEFAULT_BASE = "http://localhost:8080";   // ← mycircle 本地共享服务地址
  const LS_BASE = "mycircle_base";
  const LS_SETTINGS = "student_settings";
  /* 内置本地助手的同源接口：走本地知识库检索，命中带出处。
     本地交付只保留这一条通路——外部 inAgent 桌面端网关在本项目没有对应后端，已移除。 */
  const BUILTIN_INAGENT = "/api/inagent/chat";

  const cache = {};
  let base = localStorage.getItem(LS_BASE) || DEFAULT_BASE;
  let online = false;            // mycircle（业务服务）是否连通
  let inagentOnline = false;     // 内置助手是否连通
  let inagentSource = "";        // builtin = 内置本地助手；"" = 本地引导式回复

  /* 本地覆盖（设置页写入，保证纯静态环境下设置也能持久化） */
  function localSettings() {
    try { return JSON.parse(localStorage.getItem(LS_SETTINGS) || "{}"); }
    catch { return {}; }
  }
  function saveSettings(patch) {
    const next = Object.assign({}, window.MOCK.settings, localSettings(), patch);
    localStorage.setItem(LS_SETTINGS, JSON.stringify(next));
    window.MOCK.settings = next;
    return next;
  }

  var lastError = null;
  function rememberFailure(url, err) {
    if (!url.startsWith("http") || url.startsWith(base)) online = false;
    lastError = { url: url, message: String((err && err.message) || err || "未知错误"), time: new Date().toISOString() };
    if (typeof window.dispatchEvent === "function" && typeof window.CustomEvent === "function") {
      window.dispatchEvent(new window.CustomEvent("smartbridge:api-error", { detail: lastError }));
    }
    return null;
  }
  /* 写操作失败时用它拼出可读原因：不再一律说「业务服务不可用」 */
  function remoteMessage(action) { return action + "失败：" + (lastError ? lastError.message : "业务服务不可用或返回格式不正确"); }

  /* 统一的 fetch 封装：超时 1.5s。失败仍回落 null（页面不白成一团），但原因留痕 */
  async function request(path, options, timeoutMs) {
    const ctrl = new AbortController();
    const target = path.startsWith("http") ? path : base + path;
    const timer = setTimeout(() => ctrl.abort(), timeoutMs || 1500);
    try {
      const res = await fetch(target,
        Object.assign({ signal: ctrl.signal, credentials: "include", headers: { "Accept": "application/json" } }, options || {}));
      clearTimeout(timer);
      if (!res.ok) {
        /* 服务端 body 里有可读 message（如「项目不存在」），优先取它 */
        const text = await res.text().catch(() => "");
        let msg = "";
        try { const b = JSON.parse(text); msg = (b && (b.message || b.code)) || ""; } catch (e) { msg = String(text || "").slice(0, 120); }
        throw new Error(msg ? msg + "（HTTP " + res.status + "）" : "HTTP " + res.status);
      }
      if (!path.startsWith("http") || path.startsWith(base)) online = true;
      const json = await res.json();
      return (json && json.data !== undefined) ? json.data : json;   // 兼容 {code,data} 与裸对象
    } catch (e) {
      clearTimeout(timer);
      return rememberFailure(target, e);   // 交给调用方回落 Mock
    }
  }

  /* ---- inAgent 助手：同源后端知识库检索 ----
     请求体遵循团队统一字段：project_id / user_query / request_time。
     服务端命中即返回带出处的答复；未命中明确说明并转交教师。
     内置通路不可用时回落二级逻辑：本地规则回复（页面永不空转）。 */
  async function inagentChat(text) {
    /* 冲突 B01：统一为 project_id（原 task_id）；冲突 B15：删除冗余的 message 同值字段 */
    const payload = {
      project_id: window.MOCK.project_id,
      user_query: text,
      request_time: new Date().toISOString()
    };
    /* 内置本地助手：同源后端 /api/inagent/chat，走本地知识库检索，命中带出处 */
    const builtin = await request("/api/inagent/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    }, 12000);
    if (builtin) {
      const builtinReply = builtin.reply || builtin.result_content || builtin.output || builtin.content;
      if (typeof builtinReply === "string" && builtinReply.trim()) {
        inagentOnline = true;
        inagentSource = "builtin";
        return builtinReply;
      }
    }
    inagentOnline = false;
    inagentSource = "";
    return null;
  }

  const API_MAP = {
    student:       "/api/student/profile",
    levels:        "/api/student/levels",
    feed:          "/api/student/feed",
    notifications: "/api/student/notifications",
    report:        "/api/student/report",
    learning:      "/api/learning/recommendations",
    /* 冲突 B08：授权请求归属 student 域，原误挂 /api/company/requests 下 */
    company:       "/api/student/authorizations",
    stages:        "/api/meta/stages",
    project:       "/api/student/project",
    contributions: "/api/student/contributions"
  };

  const Store = {
    /* 读取：缓存 → mycircle → Mock */
    async get(key) {
      if (cache[key] !== undefined) return cache[key];
      let remote = null;
      if (API_MAP[key]) remote = await request(API_MAP[key]);
      const value = remote || window.MOCK[key];
      cache[key] = value;
      return value;
    },
    /* 强制刷新（提交产物、切换设置后调用） */
    invalidate(key) { delete cache[key]; },
    /* inAgent 对话：远程网关 → 本地引导式回复（两级兜底，页面永不空转） */
    async chat(text) {
      const remote = await inagentChat(text);
      if (remote) return remote;
      const rules = window.MOCK.inagent.replies;
      for (const r of rules) {
        if (r.keys.some(k => text.toLowerCase().includes(k.toLowerCase()))) return r.text;
      }
      return window.MOCK.inagent.fallback;
    },
    /* 提交关卡产物 */
    async submitLevel(levelId, payload) {
      const remote = await request("/api/levels/" + levelId + "/submit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(Object.assign({ project_id: window.MOCK.project_id, status: "running" }, payload))
      });
      if (remote === null || remote === undefined) throw new Error(remoteMessage("提交阶段产物"));
      return remote;
    },
    async updateVisibility(openToCompany) {
      return Store.updatePrivacy({ openToCompany: !!openToCompany });
    },
    async updatePrivacy(patch) {
      const remote = await request("/api/student/privacy-settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ settings: patch, request_time: new Date().toISOString() })
      });
      if (remote === null || remote === undefined) throw new Error(remoteMessage("更新隐私设置"));
      saveSettings(patch);
      return remote;
    },
    async decideAuthorization(requestId, decision) {
      const remote = await request("/api/student/authorizations/" + encodeURIComponent(requestId) + "/decision", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ decision: decision, request_time: new Date().toISOString() })
      });
      if (remote === null || remote === undefined) throw new Error(remoteMessage("提交授权决定"));
      return remote;
    },
    /* 服务地址管理 */
    getBase() { return base; },
    setBase(next) {
      base = (next || "").replace(/\/$/, "");
      localStorage.setItem(LS_BASE, base);
      Object.keys(cache).forEach(k => delete cache[k]);
      return base;
    },
    resetBase() { base = DEFAULT_BASE; localStorage.removeItem(LS_BASE); Object.keys(cache).forEach(k => delete cache[k]); },
    isOnline() { return online; },
    lastError() { return lastError; },
    clearError() { lastError = null; },
    isInagentOnline() { return inagentOnline; },
    /* 设置持久化 */
    settings() { return Object.assign({}, window.MOCK.settings, localSettings()); },
    saveSettings: saveSettings,
    /* 探测一次连通性（页面底部状态灯用） */
    async ping() { const r = await request("/api/health"); return !!r; },
    /* 探测内置本地助手是否可用（助手页状态灯用） */
    async pingInagent() {
      const builtin = await request(BUILTIN_INAGENT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        /* probe 标记：服务端据此不把探活请求写入学生问题清单 */
        body: JSON.stringify({ user_query: "ping", probe: true, project_id: window.MOCK.project_id, request_time: new Date().toISOString() })
      }, 6000);
      const ok = !!(builtin && typeof (builtin.reply || builtin.result_content) === "string");
      inagentOnline = ok;
      inagentSource = ok ? "builtin" : "";
      return ok;
    },
    /* 当前助手来源：builtin（内置本地知识库助手）/ ""（本地引导式回复） */
    inagentMode() { return inagentSource; }
  };

  /* 启动时合并本地设置到内存 Mock */
  window.MOCK.settings = Object.assign({}, window.MOCK.settings, localSettings());

  window.Store = Store;
})();
