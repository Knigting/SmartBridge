# Teacher web application

The teacher workspace is served at `/teacher/` by `services/api`.

It covers project review, tasks, students, evaluation, review, resources, questions and settings. Skill calls use the shared `/shared/skill-adapter.js` adapter and the API gateway.

See `integration-points.md` for the capability map. Run `node tools/smoke-all.js` from the repository root for page verification.
