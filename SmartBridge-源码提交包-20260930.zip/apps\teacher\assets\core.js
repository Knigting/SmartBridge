/* ==========================================================================
   智训桥 SmartBridge · 教师端 —— 平台能力接入层（window.CORE）
   --------------------------------------------------------------------------
   本文件只做一件事：为命题要求的「五类平台核心自动化技能」与「两套校内实训
   系统」预留统一接入位。**能力本体不在这里实现** —— 后端写好之后，通过
   register() / registerSystem() 挂适配器接进来，页面与交互代码一行都不用改。

   它负责四件事：
     1) 声明统一契约：任何能力的入参与返回都是同一个 envelope 形状
        { skill, ok, code, mode, input, output, evidence[], meta }
     2) invoke() 统一派发；未接入时返回契约形状的 not_connected 结果，
        **绝不抛异常** —— 调用方直接当「这块数据暂时没有」处理，界面不空转
     3) 记录调用留痕 CORE.trace —— 这是「确实调用了平台能力」的证据链
     4) 内置 mock 通道：演示与离线可直接跑通，返回一律标 mode:'mock'，
        界面上显示为「模拟通道」，不会与真实对接混淆

   ── 后端接入方式（写后端时照抄）──────────────────────────────────────
     CORE.register('parse-batch', {
       connected: true,
       describe: 'POST /api/parse-batch',
       run(payload, ctx) {
         return fetch('/api/parse-batch', { method:'POST',
           headers:{'Content-Type':'application/json'},
           body: JSON.stringify(payload) }).then(r => r.json());  // → { output, evidence }
       }
     });

     两套校内实训系统各自注册（命题硬性要求第 2 条：≥2 套系统互通）：
     CORE.registerSystem('lms',  { connected:true, write(…){}, read(…){}, describe:'校内实训教学平台 HTTP API' });
     CORE.registerSystem('edge', { connected:true, write(…){}, read(…){}, describe:'实训硬件数据网关 MQTT/OPC-UA' });

     后端就绪后关掉模拟：CORE.setMock(false);

   ── 页面怎么用接入位 ──────────────────────────────────────────────
     页面只声明「哪儿用」，不写调用逻辑：
       <div data-cap="D3" data-skill="rag" data-args='{"query":"…"}'></div>
     shell.js 会自动调 CORE.call(skill, hookId, args) 并把结果画成接入位卡片。
     hookId 与 CORE.hooks 一一对应，可在「设置」页看到完整清单与状态。

   教师端与另两端共用同一个项目编号 PRJ-0917-001（设备点检台账整理），
   接入位编号 A/B/C/D/E 与二端一致，便于对照同一处能力在不同角色下的落点。

   加载顺序：data/mock.js → assets/core.js → assets/store.js → assets/shell.js → 页面脚本
   ========================================================================== */
window.CORE = (function () {
  'use strict';

  var VERSION = '1.0.0';
  var nowISO = function () { return new Date().toISOString(); };

  /* ============================================================ 五类能力 */
  var SKILLS = {
    'parse-batch': {
      key: 'A', label: '文件批量解析', short: '批量解析',
      demand: '命题硬性要求第 1 条（必调技能之一）',
      contract: 'files: Array<{name,ext,size}> → { files:[{ name, type, rows|pages, fields[], text }] }',
      adapts: 'Word / Excel / PDF / 图片；单批 ≥ 2 份才算「批量」'
    },
    'training': {
      key: 'B', label: '实训系统自动操作', short: '跨系统操作',
      demand: '命题硬性要求第 1 条 + 第 2 条（≥2 套校内实训系统 / 硬件互通）',
      contract: '(system, {op:"write"|"read", action, payload|query}) → { system, action, ref|rows, evidence[] }',
      adapts: 'lms = 校内实训教学平台（任务下发 / 班级提交与成绩）；edge = 实训硬件数据网关（设备工况与操作日志）'
    },
    'multimodal': {
      key: 'C', label: '语音 / 图像多模态识别', short: '多模态',
      demand: '命题硬性要求第 1 条（必调技能之一）',
      contract: '{ kind:"image"|"audio", source, purpose } → { kind, text, fields, confidence, evidence[] }',
      adapts: '点检表拍照 → 表格结构化；仪表 / 实操照片 → 读数与步骤判定；语音 → 转写'
    },
    'rag': {
      key: 'D', label: 'RAG 知识库检索', short: 'RAG 检索',
      demand: '命题硬性要求第 1 条 + 创新点「企业工艺垂直知识库」',
      contract: '(query, { scopes:[], topK }) → { hits:[{ doc, page, snippet, score }], answer, evidence[] }',
      adapts: 'scopes：企业工艺文档库 / 岗位能力标准 / 学校课程标准 / 历史任务库 / 验收规范'
    },
    'report': {
      key: 'E', label: '数据可视化报告生成', short: '可视化报告',
      demand: '命题硬性要求第 1 条 + 交付物⑥「量化效益分析报告」',
      contract: '(data, { kind, format }) → { title, sections[], charts:[{ type, title, series }], metrics[], file, evidence[] }',
      adapts: 'kind：教学周报 / 班级画像 / 任务包说明 / 复核记录；format：html | pdf | docx'
    }
  };

  /* ============================================================ 两套校内实训系统
     命题硬性要求第 2 条：至少 2 套校内实训系统 / 实训硬件的数据互通与跨系统融合。
     本端按「一套真接 + 一套适配器接口」思路预留，当前均走模拟通道。 */
  var SYSTEMS = [
    {
      id: 'lms', label: '校内实训教学平台', kind: 'api', protocol: 'HTTP API',
      scope: '实训题库 · 任务下发 · 班级提交 · 成绩回填',
      contract: 'write: 下发转化后的实训任务包 · read: 拉班级提交进度与成绩',
      place: '接入位 B1 / B2',
      vendor: '某职业学院实训教学平台（演示）'
    },
    {
      id: 'edge', label: '实训硬件数据网关', kind: 'stream', protocol: 'MQTT / OPC-UA',
      scope: '数控实训台 · 机器人工作站 · 工业物联网采集端',
      contract: 'write: 下发固定样例与实训参数 · read: 拉设备工况与操作日志',
      place: '接入位 B3',
      vendor: '实训中心设备联网网关（演示）'
    }
  ];

  /* ============================================================ 接入位清单
     id    接入位编号，页面上以 data-cap="id" 声明
     skill 所属能力
     page  所在页面
     where 业务位置（用于设置页清单）
     wired true = 界面已留好调用点                                            */
  var HOOKS = [
    { id: 'A1', skill: 'parse-batch', page: 'review.html',     where: '项目审核 · 批量解析企业上传的样表与说明，抽出需求卡要点与教学适配提示', wired: true },
    { id: 'A2', skill: 'parse-batch', page: 'project.html',    where: '任务设计 · 批量解析教学参考资料，抽出可复用的阶段素材与技能标签',       wired: true },
    { id: 'A3', skill: 'parse-batch', page: 'evaluation.html', where: '评价复核 · 批量解析学生提交的成果材料，核对必交项与字段完整性',         wired: true },

    { id: 'B1', skill: 'training',    page: 'tasks.html',      where: '任务管理 · 向校内实训教学平台下发任务阶段与验收标准',                  wired: true, sys: 'lms' },
    { id: 'B2', skill: 'training',    page: 'students.html',   where: '班级学生 · 从教学平台拉班级提交进度与成绩（跨系统回填）',              wired: true, sys: 'lms' },
    { id: 'B3', skill: 'training',    page: 'students.html',   where: '班级学生 · 从实训硬件数据网关拉固定样例测试结果与操作日志做确定性比对', wired: true, sys: 'edge' },

    { id: 'C1', skill: 'multimodal',  page: 'qa.html',         where: '答疑聚合 · 学生提问截图 / 板演照片识别为文字与要点',                   wired: true },
    { id: 'C2', skill: 'multimodal',  page: 'evaluation.html', where: '评价复核 · 学生实操照片与仪表读数步骤判定（客观正确性）',              wired: true },
    { id: 'C3', skill: 'multimodal',  page: 'qa.html',         where: '答疑聚合 · 学生语音提问转写为问题条目',                                wired: true },

    { id: 'D1', skill: 'rag',         page: 'project.html',    where: '任务设计 · 任务阶段对标岗位能力标准与学校课程标准，标注先修条件',      wired: true },
    { id: 'D2', skill: 'rag',         page: 'review.html',     where: '项目审核 · 按教学适配性与脱敏要求检索历史同类需求与处理经验',          wired: true },
    { id: 'D3', skill: 'rag',         page: 'evaluation.html', where: '评价复核 · 检索评分标准与历史评价口径，形成复核依据',                  wired: true },
    { id: 'D4', skill: 'rag',         page: 'qa.html',         where: '答疑聚合 · 从案例库与知识条目检索同类问题的标准答法',                  wired: true },

    { id: 'E1', skill: 'report',      page: 'index.html',      where: '工作台 · 生成教学执行周报（审核 / 进度 / 答疑 / 复核）',              wired: true },
    { id: 'E2', skill: 'report',      page: 'students.html',   where: '班级学生 · 生成班级能力画像与个体证据摘要',                            wired: true },
    { id: 'E3', skill: 'report',      page: 'library.html',    where: '案例库 · 生成任务包说明与阶段验收清单，作为归档初稿',                  wired: true },
    { id: 'E4', skill: 'report',      page: 'library.html',    where: '案例库 · 生成复核记录与可沉淀为案例的教学结论',                        wired: true }
  ];

  /* ============================================================ 适配器注册 */
  var adapters = {};   /* skillKey → { connected, run, describe } */
  var systems = {};    /* sysId    → { connected, write, read, describe } */
  var config = { mock: true, endpoint: '', timeout: 30000 };
  var trace = [];

  function register(skill, adapter) {
    if (!SKILLS[skill]) return false;
    adapters[skill] = adapter || null;
    return true;
  }
  function registerSystem(id, adapter) {
    if (!SYSTEMS.some(function (s) { return s.id === id; })) return false;
    systems[id] = adapter || null;
    return true;
  }
  function setMock(on) { config.mock = !!on; return config.mock; }
  function useEndpoint(url) { config.endpoint = String(url || ''); return config.endpoint; }

  /* ============================================================ 统一契约 */
  function envelope(skill, input, o) {
    o = o || {};
    return {
      skill: skill,
      version: VERSION,
      ok: !!o.ok,
      code: o.code || (o.ok ? 'ok' : 'not_connected'),
      mode: o.mode || 'none',                 /* live | mock | none */
      input: input || null,
      output: o.output || null,
      evidence: o.evidence || [],
      error: o.error || '',
      meta: {
        at: nowISO(),
        ms: o.ms == null ? 0 : o.ms,
        adapter: o.adapter || '',
        skillLabel: (SKILLS[skill] || {}).label || skill,
        hookId: o.hookId || ''
      }
    };
  }

  function record(env, hookId) {
    trace.push({
      at: env.meta.at, skill: env.skill, hook: hookId || '',
      mode: env.mode, ok: env.ok, code: env.code, evidence: env.evidence.length
    });
    if (trace.length > 200) trace.splice(0, trace.length - 200);
    return env;
  }

  /* ============================================================ mock 通道
     仅为演示与离线自测存在；每条都带 mode:'mock' 与 evidence，便于与真接区分。
     数据取自方案中的设备点检案例，与其它两端保持一致。 */
  var MOCK = {
    'parse-batch': function (input) {
      var files = (input && input.files) || [];
      var list = files.length ? files : [
        { name: '点检样表_一号线_第4周.xlsx', ext: 'xlsx', size: '842 KB' },
        { name: '点检样表_二号线_第4周.xlsx', ext: 'xlsx', size: '796 KB' },
        { name: '点检样表_三号线_第4周.xlsx', ext: 'xlsx', size: '911 KB' },
        { name: 'equipment-register-guide.docx', ext: 'docx', size: '134 KB' }
      ];
      var FIELDS = ['设备编号', '日期', '温度', '班组', '点检人', '备注'];
      return {
        output: {
          total: list.length,
          fields: FIELDS,
          files: list.map(function (f) {
            var n = String((f && f.name) || 'file');
            var ext = (n.split('.').pop() || '').toLowerCase();
            var sheet = /^(xls|xlsx|csv)$/.test(ext);
            var img = /^(jpg|jpeg|png|webp)$/.test(ext);
            return {
              name: n,
              type: sheet ? '表格' : (img ? '图片' : '文档'),
              rows: sheet ? (n.indexOf('一号线') > -1 ? 186 : n.indexOf('二号线') > -1 ? 174 : 203) : undefined,
              pages: img ? undefined : (sheet ? 3 : 6),
              fields: sheet ? FIELDS : (img ? [] : ['设备编号', '温度', '班组']),
              text: sheet ? '已抽出 6 个字段列，表头一致，可直接并入统一台账' : '已抽出正文段落与两处表格'
            };
          }),
          anomalies: [
            { type: '缺失值', count: 7, note: '温度列为空，需进入待核查清单' },
            { type: '单位混用', count: 12, note: '三号线部分班组使用华氏度' },
            { type: '重复记录', count: 3, note: '同一设备同一时段重复提交' }
          ]
        },
        /* evidence 只放真实存在的字段，避免出现空值占位；后端按同样约定返回即可 */
        evidence: list.slice(0, 4).map(function (f) {
          var n = String((f && f.name) || 'file');
          var ext = (n.split('.').pop() || '').toLowerCase();
          var e = { file: n };
          if (/^(xls|xlsx|csv)$/.test(ext)) { e.sheet = 'Sheet1'; e.range = 'A1:F203'; }
          else { e.page = 1; }
          return e;
        })
      };
    },

    'training': function (input) {
      var sys = (input && input.system) || 'lms';
      var op = (input && input.op) || 'read';
      var action = (input && input.action) || '';
      if (sys === 'edge') {
        return {
          output: {
            system: 'edge', op: op, action: action || 'read-device-log',
            rows: [
              { device: '数控实训台 CNC-02', metric: '主轴运行时长', value: '12.4 h', status: '正常' },
              { device: '机器人工作站 RB-11', metric: '示教轨迹点数', value: '38 点', status: '正常' },
              { device: '工业物联网网关 GW-07', metric: '采集点位在线率', value: '99.2%', status: '正常' },
              { device: '温度采集模块 TM-05', metric: '固定样例回放一致性', value: '5 / 5 通过', status: '通过' }
            ],
            receipt: '已与实训硬件数据网关建立只读会话（模拟）'
          },
          evidence: [{ system: 'edge', protocol: 'MQTT / OPC-UA', topic: 'training/edge/tm-05', note: '模拟通道 · 非真实对接' }]
        };
      }
      return {
        output: {
          system: 'lms', op: op, action: action || 'read-class-progress',
          ref: 'LMS-TASK-2026-0917-008',
          receipt: op === 'write'
            ? '任务包已登记到校内实训教学平台题库；对应班级已收到实训任务（模拟）'
            : '已拉取班级提交进度与成绩（模拟）',
          rows: [
            { cls: '机械设计 2203', submitted: 28, total: 32, avg: 88, status: '进行中' },
            { cls: '机械设计 2202', submitted: 26, total: 30, avg: 85, status: '进行中' },
            { cls: '机电一体化 2201', submitted: 31, total: 31, avg: 91, status: '已提交' }
          ]
        },
        evidence: [{ system: 'lms', protocol: 'HTTP API', endpoint: '/api/teaching/task-package', note: '模拟通道 · 非真实对接' }]
      };
    },

    'multimodal': function (input) {
      var kind = (input && input.kind) || 'image';
      if (kind === 'audio') {
        return {
          output: {
            kind: 'audio',
            text: '学生提问：三号线的点检表里温度一会儿写摄氏度一会儿写华氏度，我们整理周报的时候老出错，想知道统一按哪个口径算。',
            fields: { 提问人: '2024级数据科学班 · 第2组', 涉及阶段: '字段整理与去重', 期望: '明确单位口径' },
            confidence: 0.86
          },
          evidence: [{ kind: 'audio', duration: '18.2s', note: '模拟通道 · 非真实转写' }]
        };
      }
      return {
        output: {
          kind: 'image',
          text: '学生提交的照片 → 识别出表头 6 列、数据行 28 行',
          fields: { 表头: '设备编号 / 日期 / 温度 / 班组 / 点检人 / 备注', 行数: '28', 单位混用: '是（℃ 与 ℉ 混排）' },
          confidence: 0.81
        },
        evidence: [{ kind: 'image', file: (input && input.source) || '点检表_第2组_截图.jpg', note: '模拟通道 · 非真实识别' }]
      };
    },

    'rag': function (input) {
      var q = (input && input.query) || '';
      var scopes = (input && input.scopes) || [];
      return {
        output: {
          query: q,
          scopes: scopes,
          answer: '已在企业工艺库、岗位能力标准与验收规范中命中相关条目，可用于校正技能标签与验收口径。',
          hits: [
            { doc: '设备点检作业指导书', page: 7, snippet: '温度超过 80℃ 判为异常；等于 80℃ 为边界正常值，边界值不得四舍五入。', score: 0.91, scope: '企业工艺文档库' },
            { doc: '设备数据维护岗 · 岗位能力标准', page: 3, snippet: '能按标准完成台账字段统一、异常识别与周报输出，错误率低于 3%。', score: 0.87, scope: '岗位能力标准' },
            { doc: '数据处理实务 · 课程标准', page: 12, snippet: '实训内容应覆盖数据清洗、异常判定、结果呈现三个层级。', score: 0.79, scope: '学校课程标准' },
            { doc: '历史任务库 · 点检台账类（11 条）', page: 1, snippet: '同类任务平均人工工时 15.2 小时/月，返修率 1.4 次/任务。', score: 0.74, scope: '历史任务库' }
          ]
        },
        evidence: [
          { doc: '设备点检作业指导书', page: 7 },
          { doc: '设备数据维护岗 · 岗位能力标准', page: 3 },
          { doc: '历史任务库 · 点检台账类（11 条）', page: 1 }
        ]
      };
    },

    'report': function (input) {
      var kind = (input && input.kind) || '教学周报';
      var d = (input && input.data) || {};
      var base = {
        '教学周报': {
          title: '设备点检项目 · 教学执行周报（第 4 周）',
          sections: [
            { h: '本周结论', p: '3 个班级 85 名学生已领取任务；任务一通过率 91%，任务二因企业侧阈值口径未确认暂缓 1 个班组。' },
            { h: '待你处理', p: '3 条企业需求待审核、2 条共性答疑待回复、8 份教学评价待复核。' },
            { h: '下周安排', p: '任务三（汇总与周报）启动；把「缺失值计入待核查」写入班级统一口径。' }
          ],
          charts: [
            { type: 'bar', title: '任务阶段完成度（%）', series: [{ name: '任务一', value: 100 }, { name: '任务二', value: 62 }, { name: '任务三', value: 8 }, { name: '任务四', value: 0 }] },
            { type: 'bar', title: '班级提交率（%）', series: [{ name: '2203', value: 88 }, { name: '2202', value: 87 }, { name: '2201', value: 100 }] }
          ],
          metrics: [
            { k: '参与学生', v: '85 人', d: '3 个班级' },
            { k: '整体完成率', v: '68%', d: '按阶段加权' },
            { k: '待复核提交', v: '8 份', d: '需教师确认' },
            { k: '需关注学生', v: '2 人', d: '滞后或风险' }
          ]
        },
        '班级画像': {
          title: '2024级数据科学班 · 能力画像与证据摘要',
          sections: [
            { h: '结论摘要', p: '班级在「数据清洗」维度整体最强（均分 90），「规则实现」分化最大（45–92）。' },
            { h: '证据来源', p: '以 4 个任务阶段的提交记录、固定样例测试与返修轨迹为依据，非自评。' },
            { h: '教学建议', p: '下一轮针对「边界条件」增加一次共性讲评；对 2 名滞后学生安排结对。' }
          ],
          charts: [
            { type: 'bar', title: '能力维度均分', series: [{ name: '数据清洗', value: 90 }, { name: '规则实现', value: 74 }, { name: '结果呈现', value: 83 }, { name: '协作记录', value: 86 }] },
            { type: 'bar', title: '证据充分度（人）', series: [{ name: '可独立完成', value: 3 }, { name: '需指导', value: 1 }, { name: '证据不足', value: 1 }] }
          ],
          metrics: [
            { k: '班级人数', v: '5 人', d: '在册' },
            { k: '最高维度', v: '数据清洗 90', d: '均分' },
            { k: '个体差异', v: '47 分', d: '最低 45 / 最高 92' },
            { k: '需关注', v: '2 人', d: '滞后或风险' }
          ]
        },
        '任务包说明': {
          title: '设备点检任务包 · 阶段说明与验收清单',
          sections: [
            { h: '任务目标', p: '汇总每周点检记录，形成统一台账、异常清单与周报。' },
            { h: '阶段划分', p: '共 4 个阶段：字段整理与去重 → 异常规则实现 → 汇总表与周报生成 → 操作说明与复现检查。' },
            { h: '验收清单', p: '原始记录可追溯；阈值与边界条件正确；结果完整可读；按说明可复现。' }
          ],
          charts: [
            { type: 'bar', title: '阶段建议课时（h）', series: [{ name: '阶段一', value: 3 }, { name: '阶段二', value: 3 }, { name: '阶段三', value: 4 }, { name: '阶段四', value: 2 }] }
          ],
          metrics: [
            { k: '阶段数', v: '4 个', d: '共 12 课时' },
            { k: '技能标签', v: '5 个', d: '已对标课程标准' },
            { k: '适配班级', v: '3 个', d: '2023/2024 级' },
            { k: '先修条件', v: '1 项', d: '表格数据基础' }
          ]
        },
        '复核记录': {
          title: '教学评价复核记录（第 4 周）',
          sections: [
            { h: '复核范围', p: '本周 8 份提交进入复核队列，其中 2 份触发「重复失败」与「团队贡献不清」标记。' },
            { h: '复核结论', p: '6 份维持系统建议分；1 份上调 3 分（返修轨迹完整）；1 份下调 5 分（边界条件未修正）。' },
            { h: '沉淀建议', p: '把「温度阈值边界值不可四舍五入」沉淀为案例库知识条目。' }
          ],
          charts: [
            { type: 'bar', title: '复核动作分布', series: [{ name: '维持', value: 6 }, { name: '上调', value: 1 }, { name: '下调', value: 1 }] }
          ],
          metrics: [
            { k: '复核总量', v: '8 份', d: '本周' },
            { k: '维持原分', v: '6 份', d: '75%' },
            { k: '调整', v: '2 份', d: '+3 / −5' },
            { k: '可沉淀条目', v: '1 条', d: '边界值口径' }
          ]
        }
      };
      var r = base[kind] || base['教学周报'];
      return {
        output: {
          kind: kind,
          title: r.title,
          sections: r.sections,
          charts: r.charts,
          metrics: (r.metrics || []).map(function (m) { return m; }),
          dataset: d,
          file: 'SmartBridge-' + kind + '-2026-0918.html'
        },
        evidence: [{ kind: kind, source: '教学平台提交记录 + 本项目过程档案', note: '模拟通道 · 非真实生成' }]
      };
    }
  };

  /* ============================================================ 统一派发 */
  function invoke(skill, payload, ctx) {
    var t0 = Date.now();
    var hookId = (ctx && ctx.hook) || '';
    var adapter = adapters[skill];
    try {
      if (adapter && (adapter.connected || adapter.run)) {
        return Promise.resolve(adapter.run(payload, ctx || {}))
          .catch(function (e) {
            return record(envelope(skill, payload, {
              ok: false, mode: 'live', code: 'error',
              error: String((e && e.message) || e), hookId: hookId, ms: Date.now() - t0
            }), hookId);
          })
          .then(function (res) {
            if (res && res.skill) return record(res, hookId);
            return record(envelope(skill, payload, {
              ok: true, mode: 'live', code: 'ok',
              output: res && res.output, evidence: (res && res.evidence) || [],
              adapter: (adapter && adapter.describe) || '已接入适配器',
              hookId: hookId, ms: Date.now() - t0
            }), hookId);
          });
      }
      if (config.mock && MOCK[skill]) {
        var out = MOCK[skill](payload, ctx || {});
        return Promise.resolve(record(envelope(skill, payload, {
          ok: true, mode: 'mock', code: 'mock',
          output: out && out.output, evidence: (out && out.evidence) || [],
          adapter: '内置模拟通道', hookId: hookId, ms: Date.now() - t0
        }), hookId));
      }
      return Promise.resolve(record(envelope(skill, payload, {
        ok: false, mode: 'none', code: 'not_connected',
        error: '该能力尚未接入后端实现', hookId: hookId, ms: Date.now() - t0
      }), hookId));
    } catch (e) {
      return Promise.resolve(record(envelope(skill, payload, {
        ok: false, mode: 'none', code: 'error',
        error: String((e && e.message) || e), hookId: hookId, ms: Date.now() - t0
      }), hookId));
    }
  }

  /* ============================================================ 便利方法 */
  function parseBatch(files, ctx) { return invoke('parse-batch', { files: files || [], endpoint: config.endpoint }, ctx); }
  function systemOp(sysId, op, payload, ctx) {
    return invoke('training', {
      system: sysId, op: op,
      action: (payload && payload.action) || '',
      payload: (payload && payload.payload) != null ? payload.payload : null,
      query: (payload && payload.query) != null ? payload.query : null
    }, ctx);
  }
  function multimodal(input, ctx) { return invoke('multimodal', input || {}, ctx); }
  function ragQuery(query, scopes, ctx) { return invoke('rag', { query: query || '', scopes: scopes || [], topK: (ctx && ctx.topK) || 5 }, ctx); }
  function reportGen(data, kind, ctx) { return invoke('report', { data: data || {}, kind: kind || '教学周报', format: (ctx && ctx.format) || 'html' }, ctx); }

  /* 页面统一入口：call(skill, hookId, args) —— 永不抛异常 */
  function call(skill, hookId, args) {
    args = args || {};
    try {
      switch (skill) {
        case 'parse-batch': return parseBatch(args.files || [], { hook: hookId, purpose: args.purpose });
        case 'training': return systemOp(args.system, args.op || 'read', args, { hook: hookId });
        case 'multimodal': return multimodal(args, { hook: hookId });
        case 'rag': return ragQuery(args.query, args.scopes, { hook: hookId });
        case 'report': return reportGen(args.data, args.kind, { hook: hookId, format: args.format });
        default:
          return Promise.resolve(envelope(skill, args, {
            ok: false, code: 'unknown_skill', error: '未知能力：' + skill, hookId: hookId
          }));
      }
    } catch (e) {
      return Promise.resolve(envelope(skill, args, {
        ok: false, code: 'error', error: String((e && e.message) || e), hookId: hookId
      }));
    }
  }

  /* ============================================================ 状态查询 */
  function skillState(key) {
    var a = adapters[key];
    if (a && (a.connected || a.run)) return { state: 'live', label: '已接入', cls: 'live' };
    if (config.mock && MOCK[key]) return { state: 'mock', label: '模拟通道', cls: 'mock' };
    return { state: 'none', label: '未接入', cls: 'none' };
  }
  function systemState(id) {
    var a = systems[id];
    if (a && (a.connected || a.read || a.write)) return { state: 'live', label: '已接入', cls: 'live' };
    if (config.mock) return { state: 'mock', label: '模拟通道', cls: 'mock' };
    return { state: 'none', label: '未接入', cls: 'none' };
  }
  function status() {
    var skills = Object.keys(SKILLS).map(function (k) {
      var s = skillState(k);
      return { key: k, meta: SKILLS[k], state: s.state, label: s.label, cls: s.cls,
        hooks: HOOKS.filter(function (h) { return h.skill === k; }) };
    });
    var sys = SYSTEMS.map(function (s) {
      var st = systemState(s.id);
      return { id: s.id, meta: s, state: st.state, label: st.label, cls: st.cls };
    });
    return {
      version: VERSION,
      mock: config.mock,
      liveSkills: skills.filter(function (s) { return s.state === 'live'; }).length,
      required: 3,
      skills: skills,
      systems: sys,
      hooks: { total: HOOKS.length, wired: HOOKS.filter(function (h) { return h.wired; }).length },
      calls: trace.length,
      note: config.mock
        ? '当前开启模拟通道：返回结果均为演示数据，界面上标为「模拟通道」，不代表已真实对接。后端就绪后调用 CORE.setMock(false) 即切换为真实通道。'
        : '已关闭模拟通道，全部能力走后端适配器。'
    };
  }

  var CORE = {
    version: VERSION,
    skills: SKILLS,
    systems: SYSTEMS,
    hooks: HOOKS,
    config: config,

    register: register,
    registerSystem: registerSystem,
    setMock: setMock,
    useEndpoint: useEndpoint,

    invoke: invoke,
    parseBatch: parseBatch,
    systemOp: systemOp,
    multimodal: multimodal,
    ragQuery: ragQuery,
    reportGen: reportGen,
    call: call,

    status: status,
    skillState: skillState,
    systemState: systemState,
    hook: function (id) {
      for (var i = 0; i < HOOKS.length; i++) if (HOOKS[i].id === id) return HOOKS[i];
      return null;
    },
    trace: trace,
    clearTrace: function () { trace.length = 0; }
  };

  return CORE;
})();
(function () {
  var source = '/shared/skill-adapter.js?v=20260924-1';
  if (document.readyState === 'loading') document.write('<script src="' + source + '"><\/script>');
  else {
    var script = document.createElement('script');
    script.src = source;
    document.head.appendChild(script);
  }
})();
