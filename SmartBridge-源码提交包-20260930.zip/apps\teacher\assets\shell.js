/* ==========================================================================
   shell.js —— 页面外壳（顶栏 + 侧边导航 + 设计规范抽屉 + Toast）与通用渲染工具
   --------------------------------------------------------------------------
   所有页面共用，保证导航一致与页面间跳转；当前页自动高亮。
   同时负责「平台能力接入位」的自动渲染：页面只写
       <div data-cap="D2" data-skill="rag" data-args='{"query":"…"}'></div>
   shell 会调 CORE.call() 并把结果画成接入位卡片（含状态徽标与 evidence 出处）。
   ========================================================================== */
(function () {
  /* ---------------- 导航配置（新增页面只需在此加一项） ---------------- */
  var ICON = {
    home: '<path d="M3 10.5L12 3l9 7.5"/><path d="M5 9.5V21h14V9.5"/>',
    review: '<path d="M6 3h9l5 5v13H6z"/><path d="M14 3v6h6"/><path d="M9.5 14.5l2 2 3.5-4"/>',
    task: '<path d="M9 6h11M9 12h11M9 18h11"/><path d="M4 6l1.2 1.2L7.5 4.8"/><path d="M4 12l1.2 1.2L7.5 10.8"/><path d="M4 18l1.2 1.2L7.5 16.8"/>',
    stage: '<rect x="3" y="4" width="18" height="16" rx="2.5"/><path d="M8 4v16M3 12h5"/>',
    students: '<circle cx="9" cy="8" r="3.4"/><path d="M3 20c0-3.3 2.7-5.6 6-5.6s6 2.3 6 5.6"/><path d="M17 11.5a3 3 0 100-6"/>',
    qa: '<path d="M4 5h16v12H8l-4 4z"/><path d="M8.5 10.5h7M8.5 13.5h4"/>',
    eval: '<path d="M12 3.6l2.6 5.3 5.9.8-4.3 4.1 1 5.8-5.2-2.8-5.2 2.8 1-5.8L3.5 9.7l5.9-.8z"/>',
    library: '<path d="M4 7a2 2 0 012-2h4l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H6a2 2 0 01-2-2z"/>',
    spec: '<circle cx="12" cy="12" r="9"/><path d="M12 16v-4.5M12 8.2v.1"/>',
    setting: '<circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 00-.1-1.2l2-1.6-2-3.4-2.4 1a7 7 0 00-2-1.2L14 3h-4l-.5 2.6a7 7 0 00-2 1.2l-2.4-1-2 3.4 2 1.6A7 7 0 005 12c0 .4 0 .8.1 1.2l-2 1.6 2 3.4 2.4-1a7 7 0 002 1.2L10 21h4l.5-2.6a7 7 0 002-1.2l2.4 1 2-3.4-2-1.6c.1-.4.1-.8.1-1.2z"/>'
  };

  /* 导航按教师实际工作顺序：先日常教学工作，再资源与设置。
     企业端侧栏的「三端协同状态」块在教师端不再出现。 */
  var NAV1 = [
    { href: 'index.html',      label: '工作台',   icon: ICON.home,     match: ['index.html', ''] },
    { href: 'review.html',     label: '项目审核', icon: ICON.review,   match: ['review.html'], badge: 3 },
    { href: 'tasks.html',      label: '任务管理', icon: ICON.task,     match: ['tasks.html', 'project.html'] },
    { href: 'students.html',   label: '班级学生', icon: ICON.students, match: ['students.html'], badge: 5, quiet: true },
    { href: 'qa.html',         label: '答疑聚合', icon: ICON.qa,       match: ['qa.html'], badge: 2 },
    { href: 'evaluation.html', label: '评价复核', icon: ICON.eval,     match: ['evaluation.html'], badge: 8 }
  ];
  var NAV2 = [
    { href: 'library.html',    label: '案例库',   icon: ICON.library,  match: ['library.html'] }
  ];
  var NAV3 = [
    { href: 'settings.html',   label: '设置',     icon: ICON.setting,  match: ['settings.html'] }
  ];

  var BRAND = { name: '智训桥 SmartBridge', sub: '教师工作台', mark: '智' };

  /* ---------------- 通用渲染工具 ---------------- */
  var MODE_TEXT = { live: '已接入', mock: '模拟通道', none: '未接入', simulated: '本地演示通道' };

  /* 解析异常项有两种形状：{type,count,note} 与 {type,field,original,normalized}，统一成一行可读文本 */
  function anomalyText(a) {
    if (!a || typeof a !== 'object') return String(a || '');
    var note = a.note || (a.original !== undefined
      ? ('原始值 ' + a.original + (a.normalized !== undefined && a.normalized !== a.original ? ' → ' + a.normalized : ''))
      : (a.normalized ? ('规范为 ' + a.normalized) : (a.field ? ('字段 ' + a.field) : '')));
    return [a.type, a.count == null ? '' : a.count + ' 处', note].filter(Boolean).join(' · ');
  }
  /* 跨系统返回的行结构按动作不同而不同，按已知字段优先级挑一个可读的主字段 */
  function trainingRowText(r) {
    if (!r || typeof r !== 'object') return String(r || '');
    var skip = { metric: 1, value: 1, submitted: 1, total: 1, avg: 1 };
    if (r.device || r.cls) {
      return (r.device ? (r.device + ' ' + (r.metric || '') + ' ' + (r.value || '') + ' · ' + (r.status || ''))
        : (r.cls + ' ' + r.submitted + '/' + r.total + ' 已提交 · 均分 ' + r.avg + ' · ' + (r.status || ''))).trim();
    }
    var main = r.name || r.stage_no || r.case_id || r.device_id || '';
    var rest = Object.keys(r).filter(function (k) { return !skip[k] && r[k] !== null && r[k] !== '' && typeof r[k] !== 'object'; })
      .map(function (k) { return k + '=' + r[k]; }).slice(0, 4).join(' ');
    return [main, rest].filter(Boolean).join(' · ');
  }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  var U = {
    esc: esc,
    modeText: function (m) { return MODE_TEXT[m] || m; },
    /* 团队状态枚举徽标 */
    badge: function (status, extra) {
      var CN = { pending: '待处理', running: '进行中', success: '已完成', partial_success: '部分完成', failed: '未通过' };
      var CLS = { pending: 'need', running: 'run', success: 'ok', partial_success: 'wait', failed: 'need' };
      return '<span class="chip ' + (CLS[status] || 'wait') + '"><span class="chip-dot"></span>' +
        (CN[status] || status) + (extra ? ' · ' + esc(extra) : '') + '</span>';
    },
    /* 15 步流程轨道：把流程收进一处，不必一屏铺开 */
    track: function (phases, steps) {
      var done = 0;
      steps.forEach(function (s) { if (s.st === 'ok') done++; });
      var pct = Math.round(done / steps.length * 100);
      return '<div class="rail-mini">' + phases.map(function (p, i) {
        var allOk = p.steps.every(function (si) { return steps[si].st === 'ok'; });
        var running = p.steps.some(function (si) { return steps[si].st === 'cur'; });
        return '<div class="rm ' + (allOk ? 'done' : (running ? 'cur' : '')) + '"><i></i><span>' + esc(p.name) + '</span></div>';
      }).join('') + '</div><div class="meter"><div class="track"><i style="width:' + pct + '%"></i></div><b>' + done + ' / ' + steps.length + ' 步</b></div>';
    },
    /* 横向条形图（对比类数据） */
    bars: function (series) {
      var max = Math.max.apply(null, series.map(function (s) { return Number(s.value) || 0; }).concat([1]));
      return '<div class="rp-chart">' + series.map(function (s) {
        var w = Math.round((Number(s.value) || 0) / max * 100);
        return '<div class="rp-bar"><span class="lb">' + esc(s.name) + '</span>' +
          '<span class="tr"><i style="width:' + w + '%"></i></span>' +
          '<span class="vl">' + esc(s.display != null ? s.display : s.value + (s.unit || '')) + '</span></div>';
      }).join('') + '</div>';
    },
    /* 键值行 */
    kv: function (rows) {
      return rows.map(function (r) {
        return '<div class="cap-kv"><span class="k">' + esc(r.k) + '</span><span class="v">' + esc(r.v) + '</span></div>';
      }).join('');
    },
    /* evidence 出处（命题评分看重「说得出出处」） */
    evidence: function (list) {
      if (!list || !list.length) return '';
      return '<div class="cap-ev"><span class="t">证据出处 EVIDENCE</span>' + list.map(function (e) {
        var parts = [];
        Object.keys(e).forEach(function (k) {
          if (k === 'note') return;
          if (e[k] === undefined || e[k] === null || e[k] === '') return;   /* 不渲染空字段 */
          parts.push(k + ':' + (typeof e[k] === 'object' ? JSON.stringify(e[k]) : e[k]));   /* 嵌套对象（如 verify）展开为 JSON，避免 [object Object] */
        });
        var note = e.note ? (parts.length ? ' · ' : '') + e.note : '';
        return '<code>' + esc(parts.join(' / ') + note) + '</code>';
      }).join('') + '</div>';
    },
    /* 按技能类型渲染 output */
    capOutput: function (skill, o) {
      if (!o) return '<div class="cap-why">暂无返回数据。</div>';
      if (skill === 'parse-batch') {
        return '<div class="parse">' + (o.files || []).map(function (f) {
          var c = f.type === '表格' ? '#0f9d76' : (f.type === '图片' ? '#7a4ddb' : '#2f5bff');
          var t = f.type === '表格' ? (f.rows || '—') + ' 行' : (f.type === '图片' ? '图片' : (f.pages || '—') + ' 页');
          return '<div class="f"><i style="background:' + c + '">' + esc(f.type === '表格' ? 'XLS' : (f.type === '图片' ? 'IMG' : 'DOC')) + '</i>' +
            '<div><b>' + esc(f.name) + '</b><small>' + esc(t) + (f.fields && f.fields.length ? ' · 字段 ' + f.fields.length + ' 列' : '') + '</small></div></div>';
        }).join('') + '</div>' +
          (o.anomalies && o.anomalies.length
            ? '<div class="cap-ev"><span class="t">解析发现的问题</span>' + o.anomalies.map(function (a) {
              return '<code>' + esc(anomalyText(a)) + '</code>';
            }).join('') + '</div>' : '');
      }
      if (skill === 'training') {
        return U.kv([{ k: '系统', v: o.system === 'edge' ? '实训硬件数据网关' : '校内实训教学平台' },
                     { k: '动作', v: o.action || '—' },
                     { k: o.ref ? '任务编号' : '回执', v: o.ref || o.receipt || '—' }]) +
          '<div class="cap-ev"><span class="t">跨系统数据</span>' + (o.rows || []).map(function (r) {
            return '<code>' + esc(trainingRowText(r)) + '</code>';
          }).join('') + '</div>';
      }
      if (skill === 'multimodal') {
        return U.kv([{ k: '类型', v: o.kind === 'audio' ? '语音转写' : '图像识别' }]) +
          '<div class="cap-ev"><span class="t">识别结果</span><code>' + esc(o.text) + '</code></div>' +
          '<div class="cap-ev"><span class="t">结构化字段</span><code>' +
            esc(Object.keys(o.fields || {}).map(function (k) { return k + '=' + o.fields[k]; }).join(' · ')) + '</code></div>' +
          U.kv([{ k: '置信度', v: (Math.round((o.confidence || 0) * 100)) + '%' }]);
      }
      if (skill === 'rag') {
        return '<div class="cap-ev"><span class="t">命中条目</span>' + (o.hits || []).map(function (h) {
          return '<code>' + esc(h.doc + ' p.' + h.page + ' 〔' + h.scope + '〕 score ' + h.score) + '\n' + h.snippet + '</code>';
        }).join('') + '</div>' + '<div class="cap-why">' + esc(o.answer) + '</div>';
      }
      if (skill === 'report') {
        return '<div class="cap-why">' + esc(o.title) + '</div>' +
          (o.metrics && o.metrics.length ? '<div class="cap-ev"><span class="t">关键指标</span>' + o.metrics.map(function (m) {
            return '<code>' + esc(m.k + ' ' + m.v + '（' + m.d + '）') + '</code>';
          }).join('') + '</div>' : '') +
          (o.charts || []).map(function (c) {
            return '<div class="cap-ev"><span class="t">' + esc(c.title) + '</span>' + U.bars(c.series) + '</div>';
          }).join('') +
          '<div class="cap-ev"><span class="t">报告文件</span><code>' + esc(o.file) + '</code></div>';
      }
      return '<div class="cap-why">' + esc(JSON.stringify(o).slice(0, 200)) + '</div>';
    },
    /* 接入位骨架（调用中） */
    capSkeleton: function (id, skill, hook) {
      var meta = (window.CORE && CORE.skills[skill]) || { label: skill };
      return '<div class="cap-head"><b>' + esc(meta.label) + '</b><span class="hook">' + esc(id) + '</span>' +
        '<span class="cap-mode none"><i></i>调用中…</span></div>' +
        '<div class="cap-why">' + esc((hook && hook.where) || '') + '</div>';
    },
    /* 接入位结果卡 */
    capBlock: function (id, skill, hook, env) {
      var meta = (window.CORE && CORE.skills[skill]) || { label: skill, demand: '' };
      var mode = env.mode || 'none';
      /* 写操作按治理策略要求人工审批：这不是调用失败，而是「计划已生成、待审批」的中间态 */
      if (env.code === 'approval_required') {
        var p = env.output || {};
        return '<div class="cap-head"><b>' + esc(meta.label) + '</b><span class="hook">' + esc(id) + '</span>' +
          '<span class="cap-mode pending"><i></i>待人工审批</span></div>' +
          '<div class="cap-why">' + esc((hook && hook.where) || meta.demand || '') + '　·　写操作已生成执行计划，按治理策略需人工审批后才会执行。</div>' +
          '<div class="cap-out">' + U.kv([
            { k: '目标系统', v: (p.system === 'edge' ? '实训硬件数据网关' : '校内实训教学平台') + ' · ' + (p.action || '—') },
            { k: '风险等级', v: p.risk || '—' },
            { k: '计划编号', v: p.plan_id || '—' },
            { k: '审批方式', v: 'POST /api/skills/training/plans/' + (p.plan_id || '<plan_id>') + '/approve' }
          ]) + U.evidence(env.evidence) + '</div>';
      }
      /* 调用失败：如实显示失败原因与处理建议，绝不能亮「已接入」绿灯 */
      if (env.ok === false) {
        return '<div class="cap-head"><b>' + esc(meta.label) + '</b><span class="hook">' + esc(id) + '</span>' +
          '<span class="cap-mode none"><i></i>调用失败</span></div>' +
          '<div class="cap-why">' + esc((hook && hook.where) || meta.demand || '') + '</div>' +
          '<div class="cap-out"><div class="cap-ev"><span class="t">失败原因</span><code>' + esc(env.error || '未知错误') + '</code></div></div>';
      }
      return '<div class="cap-head"><b>' + esc(meta.label) + '</b><span class="hook">' + esc(id) + '</span>' +
        '<span class="cap-mode ' + esc(mode) + '"><i></i>' + esc(MODE_TEXT[mode] || mode) + '</span></div>' +
        '<div class="cap-why">' + esc((hook && hook.where) || meta.demand || '') +
        (mode === 'none' ? '　·　' + esc(env.error || '后端尚未接入，此处直接承接返回值即可') : '') + '</div>' +
        (mode === 'none' ? '' : '<div class="cap-out">' + U.capOutput(skill, env.output) +
          U.evidence(env.evidence) + '</div>') +
        '';
    },
    param: function (k) { return new URLSearchParams(location.search).get(k); }
  };

  /* ---------------- 渲染外壳 ---------------- */
  function current() { return (location.pathname.split('/').pop() || 'index.html'); }

  function navItem(a) {
    var on = a.match.indexOf(current()) > -1;
    return '<a class="rail-item" href="' + a.href + '"' + (on ? ' aria-current="page"' : '') + '>' +
      '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' + a.icon + '</svg>' +
      esc(a.label) + (a.badge ? '<span class="count' + (a.quiet ? ' quiet' : '') + '">' + a.badge + '</span>' : '') + '</a>';
  }
  function sidebarHtml() {
    return '<div class="brand" style="padding:15px 12px 10px">' +
        '<div class="brand-mark">' + BRAND.mark + '</div>' +
        '<div class="brand-text"><b>' + BRAND.name + '</b><span>' + BRAND.sub + '</span></div></div>' +
      '<div class="rail-label">教学工作</div>' + NAV1.map(navItem).join('') +
      '<div class="rail-label">资源与配置</div>' + NAV2.map(navItem).join('') +
      '<div class="rail-label">帮助与设置</div>' +
      '<button class="rail-item" type="button" onclick="Shell.openSpec()">' +
        '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round">' + ICON.spec + '</svg>设计规范</button>' +
      NAV3.map(navItem).join('') +
      '<div class="rail-foot">' +
        '<b><span class="src-dot" id="srcDot"></span>数据源：<span class="mono" id="srcName">检测中</span></b>' +
        '<p>能力接入：<span class="mono" id="capName">检测中</span><br>' +
        '项目编号 PRJ-0917-001 · 需求→任务→评价闭环。</p>' +
      '</div>';
  }
  function topbarHtml() {
    return '<a class="brand" href="index.html">' +
        '<div class="brand-mark">' + BRAND.mark + '</div>' +
        '<div class="brand-text"><b>' + BRAND.name + '</b><span>' + BRAND.sub + '</span></div></a>' +
      '<div class="search">' +
        '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg>' +
        '<input id="globalSearch" type="search" placeholder="搜索需求、任务或学生…" aria-label="全局搜索"></div>' +
      '<div class="topbar-right">' +
        '<a class="ghost-btn" href="review.html">' +
          '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h9l5 5v13H6z"/><path d="M14 3v6h6"/><path d="M9.5 14.5l2 2 3.5-4"/></svg>审核需求</a>' +
        '<a class="ghost-btn icon" href="index.html#notice" aria-label="通知（' + MOCK.notifications.length + ' 条）">' +
          '<svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M18 8a6 6 0 10-12 0c0 7-3 8-3 8h18s-3-1-3-8"/><path d="M10.5 21a2 2 0 003 0"/></svg>' +
          '<span class="dot-badge"></span></a>' +
        '<a class="avatar" href="settings.html" title="' + esc(MOCK.teacher.name) + ' · ' + esc(MOCK.teacher.college) + '">' + esc(MOCK.teacher.name.charAt(0)) + '</a>' +
      '</div>';
  }

  /* 设计规范抽屉（全站共用，无需每页重复） */
  function specHtml() {
    return '<div class="sheet-mask" id="specMask"></div>' +
      '<aside class="sheet" id="specSheet" aria-label="设计规范">' +
      '<div class="sheet-head"><b>设计规范 · 教师端</b>' +
        '<button class="ghost-btn icon" style="margin-left:auto" type="button" onclick="Shell.closeSpec()" aria-label="关闭">' +
        '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>' +
      '<div class="sheet-body">' +
        '<div class="spec"><h4>设计原则</h4>' +
        '<p><b>① 待办前置。</b>首屏先回答「今天要处理什么」，审核、答疑、复核三件事优先于流程说明。</p>' +
        '<p><b>② 过程隐去，只留判断。</b>系统先做客观检查（样例测试、提交记录、去重与异常识别），教师只看到「已自动核过 / 需要你判断」。</p>' +
        '<p><b>③ 用教学语言。</b>统一为教学表述（需求卡、任务阶段、提交成果、能力画像），不出现技术术语。</p>' +
        '<p><b>④ 复杂收敛为阶段。</b>16 个环节收敛为 5 个阶段，每阶段最多 4 步。</p>' +
        '<p><b>⑤ 能力可替换。</b>涉及平台自动化的位置一律做成「接入位」，不写死实现。</p></div>' +
        '<div class="spec"><h4>色彩</h4><div class="swatches">' +
        '<div class="sw"><i style="background:#06b8a8"></i><span>Brand #06B8A8</span></div>' +
        '<div class="sw"><i style="background:#0f9d76"></i><span>Success #0F9D76</span></div>' +
        '<div class="sw"><i style="background:#c2760a"></i><span>Warning #C2760A</span></div>' +
        '<div class="sw"><i style="background:#dd4b52"></i><span>Danger #DD4B52</span></div>' +
        '<div class="sw"><i style="background:#101828"></i><span>Ink #101828</span></div>' +
        '<div class="sw"><i style="background:#f6f7fb"></i><span>BG #F6F7FB</span></div></div>' +
        '<p style="margin-top:10px">语义色只用于状态：绿＝完成 / 通过，蓝＝进行中，琥珀＝待你处理，灰＝未开始。同一屏幕不超过两种强调色。</p></div>' +
        '<div class="spec"><h4>字体与层级</h4>' +
        '<div class="typo-row"><span style="font-size:26px;font-weight:800">28 / 800</span>页面主标题<code>letter-spacing -0.5</code></div>' +
        '<div class="typo-row"><span style="font-size:21px;font-weight:800">21 / 800</span>区块标题</div>' +
        '<div class="typo-row"><span style="font-size:16px;font-weight:700">16 / 700</span>卡片标题</div>' +
        '<div class="typo-row"><span style="font-size:14px">14 / 400</span>正文<code>line-height 1.6</code></div>' +
        '<div class="typo-row"><span style="font-size:12.5px;color:#667085">12.5 / 400</span>辅助说明</div></div>' +
        '<div class="spec"><h4>间距与形状</h4>' +
        '<p>8px 网格：卡片内边距 16–18px，卡片间距 14–18px，页面留白 24–28px。</p>' +
        '<p>圆角：卡片 16 / 控件 12 / 小元件 9，按钮高度统一 38px（小号 32px）。</p>' +
        '<p>阴影只做两级：静置 <code>sh-1</code>，悬停 <code>sh-2</code>；焦点态用 3px 品牌色光圈。</p></div>' +
        '<div class="spec"><h4>易用性检查</h4>' +
        '<p>· 所有可点击元素有 hover 反馈与 <code>:focus-visible</code> 焦点环</p>' +
        '<p>· 状态不只靠颜色区分，同时有文字标签与图标</p>' +
        '<p>· 危险 / 不可逆操作需二次确认，示范性操作有 Toast 反馈</p>' +
        '<p>· 关键按钮固定右对齐，次要操作为描边按钮</p>' +
        '<p>· ≥1180px 双栏，≤860px 单栏折叠，触控目标 ≥32px</p></div>' +
      '</div></aside>';
  }

  /* ---------------- Toast ---------------- */
  var toastTimer;
  function toast(msg) {
    var t = document.getElementById('toast');
    if (!t) { t = document.createElement('div'); t.id = 'toast'; t.className = 'toast'; document.body.appendChild(t); }
    t.innerHTML = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="#6ee7b7" stroke-width="2.6" stroke-linecap="round"><path d="M5 13l4 4L19 7"/></svg>' + esc(msg);
    t.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('on'); }, 2600);
  }

  /* ---------------- 接入位自动渲染 ---------------- */
  /* 报告类接入位只声明了 kind，本身不带指标。这里先向业务服务取真实聚合数据，
     再交给报告 Skill，避免一律返回「请传入真实 metrics」 */
  function enrichArgs(skill, args) {
    if (skill !== 'report' || typeof fetch !== 'function') return Promise.resolve(args);
    return fetch('/api/report-data', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ kind: args.kind || '', data: args.data || {} })
    }).then(function (r) { return r.ok ? r.json() : null; }).then(function (j) {
      var d = j && j.data;
      if (!d || (!d.metrics && !d.sections && !d.charts)) return args;
      var merged = {};
      Object.keys(args).forEach(function (k) { merged[k] = args[k]; });
      merged.data = d;
      if (d.title) merged.title = d.title;
      return merged;
    }).catch(function () { return args; });
  }

  function callOncePerSession(skill, id, args) {
    var key = 'smartbridge-cap:' + location.pathname + ':' + id + ':' + skill + ':' + JSON.stringify(args || {});
    try {
      var cached = sessionStorage.getItem(key);
      if (cached) return Promise.resolve(JSON.parse(cached));
    } catch (e) { /* Session storage is optional. */ }
    return CORE.call(skill, id, args).then(function (env) {
      try { if (env && env.ok) sessionStorage.setItem(key, JSON.stringify(env)); } catch (e) { /* Ignore quota errors. */ }
      return env;
    });
  }

  function paintCaps() {
    var nodes = document.querySelectorAll('[data-cap]');
    if (!nodes.length) return;
    if (!window.CORE) {
      Array.prototype.forEach.call(nodes, function (el) {
        el.className = 'cap skeleton';
        el.innerHTML = '<div class="cap-head"><b>' + esc(el.getAttribute('data-skill') || '') + '</b>' +
          '<span class="hook">' + esc(el.getAttribute('data-cap')) + '</span>' +
          '<span class="cap-mode none"><i></i>未接入</span></div>' +
          '<div class="cap-why">接入层 assets/core.js 未加载。</div>';
      });
      var cn = document.getElementById('capName');
      if (cn) cn.textContent = '接入层缺失';
      return;
    }
    Array.prototype.forEach.call(nodes, function (el) {
      var id = el.getAttribute('data-cap');
      var skill = el.getAttribute('data-skill') || (CORE.hook(id) || {}).skill;
      var args = {};
      try { args = JSON.parse(el.getAttribute('data-args') || '{}'); } catch (e) { args = {}; }
      var hook = CORE.hook(id) || {};
      el.className = 'cap skeleton';
      el.innerHTML = U.capSkeleton(id, skill, hook);
      enrichArgs(skill, args).then(function (finalArgs) {
        return callOncePerSession(skill, id, finalArgs);
      }).then(function (env) {
        /* 调用失败的接入位打 error 标记：自测脚本能区分「真 live」与「假 live」 */
        var doneMode = env && env.ok === false ? 'error' : ((env && env.mode) || 'none');
        el.className = 'cap' + (doneMode === 'none' ? ' skeleton' : '');
        el.innerHTML = U.capBlock(id, skill, hook, env);
        /* 打上「已渲染」标记，供自测脚本断言；与静态说明卡片区分开 */
        el.setAttribute('data-cap-done', doneMode);
      });
    });
    /* 侧栏能力通道指示灯 */
    var st = CORE.status();
    var cn = document.getElementById('capName');
    if (cn) cn.textContent = st.liveSkills === 0
      ? (st.mock ? '模拟通道 ' + st.hooks.wired + ' 处' : '未接入')
      : '已接入 ' + st.liveSkills + ' 类';
  }

  /* ---------------- 挂载 ---------------- */
  function mount() {
    var sb = document.getElementById('app-sidebar');
    var tb = document.getElementById('app-topbar');
    if (sb) sb.innerHTML = sidebarHtml();
    if (tb) { tb.className = 'topbar'; tb.innerHTML = topbarHtml(); }
    if (!document.getElementById('specSheet')) {
      var d = document.createElement('div');
      d.innerHTML = specHtml();
      while (d.firstChild) document.body.appendChild(d.firstChild);
    }
    document.getElementById('specMask').addEventListener('click', closeSpec);

    /* 数据源指示灯：mycircle 与 能力接入通道分别探测 */
    Store.ping().then(function (ok) {
      var dot = document.getElementById('srcDot'), name = document.getElementById('srcName');
      if (!dot) return;
      dot.className = 'src-dot' + (ok ? ' ok' : '');
      name.textContent = ok ? 'mycircle 已连接' : '本地 Mock';
    });

    var input = document.getElementById('globalSearch');
    if (input) {
      input.addEventListener('keydown', function (e) {
        if (e.key !== 'Enter') return;
        var q = input.value.trim();
        if (!q) return;
        var map = [['审核', 'review.html'], ['需求', 'review.html'], ['任务', 'tasks.html'], ['阶段', 'tasks.html'],
                   ['学生', 'students.html'], ['班级', 'students.html'], ['答疑', 'qa.html'], ['提问', 'qa.html'],
                   ['评价', 'evaluation.html'], ['复核', 'evaluation.html'], ['案例', 'library.html'], ['模板', 'library.html'],
                   ['报告', 'index.html'], ['设置', 'settings.html'], ['项目', 'project.html']];
        var hit = map.filter(function (m) { return q.indexOf(m[0]) > -1; })[0];
        location.href = hit ? hit[1] : 'review.html';
      });
    }

    paintCaps();
  }

  function openSpec() {
    document.getElementById('specSheet').classList.add('on');
    document.getElementById('specMask').classList.add('on');
  }
  function closeSpec() {
    document.getElementById('specSheet').classList.remove('on');
    document.getElementById('specMask').classList.remove('on');
  }
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeSpec(); });

  window.U = U;
  window.Shell = { openSpec: openSpec, closeSpec: closeSpec, toast: toast, repaint: paintCaps, nav: function (href) { location.href = href; } };

  /* 接口失败统一提示：数据层以前把错误吞成 null 后静默回落本地数据，
     页面分不清「真实数据」和「本地兜底数据」。这里在首次失败时给出可见提示。 */
  var notified = false;
  window.addEventListener("smartbridge:api-error", function (e) {
    if (notified) return;
    notified = true;
    var d = e.detail || {};
    toast("业务服务未连通：" + d.message + "（当前页面可能显示本地兜底数据）", 6000);
  });
  document.addEventListener('DOMContentLoaded', mount);
})();
