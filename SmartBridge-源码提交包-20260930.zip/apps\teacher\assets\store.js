/* ==========================================================================
   store.js —— 数据层：优先读 mycircle 本地共享服务，失败自动回落本地 Mock
   --------------------------------------------------------------------------
   用法：const data = await Store.get('requests')
   切换服务：Store.setBase('http://192.168.1.20:8080')
   约定接口（与团队规范一致，字段 / 状态枚举统一）：
     GET  /api/teacher/profile           GET  /api/teacher/requests
     GET  /api/teacher/tasks             GET  /api/teacher/students
     GET  /api/teacher/questions         GET  /api/teacher/evaluations
     GET  /api/teacher/library           GET  /api/meta/stages
     POST /api/teacher/requests/review   POST /api/teacher/tasks/publish
     POST /api/teacher/evaluations/decide
   --------------------------------------------------------------------------
   与 assets/core.js 的分工：
     store.js   负责「业务数据」—— 需求、任务、班级学生、答疑、评价、案例库。
     core.js    负责「平台能力」—— 五类自动化技能与两套校内实训系统。
   两者都遵循「远端优先、本地回落、绝不报错」，互不依赖。
   ========================================================================== */
(function () {
  var DEFAULT_BASE = 'http://localhost:8080';   /* ← mycircle 本地共享服务地址 */
  var LS_BASE = 'mycircle_base';
  var LS_SETTINGS = 'teacher_settings';

  var cache = {};
  var base = localStorage.getItem(LS_BASE) || DEFAULT_BASE;
  var online = false;

  function localSettings() {
    try { return JSON.parse(localStorage.getItem(LS_SETTINGS) || '{}'); } catch (e) { return {}; }
  }
  function saveSettings(patch) {
    var next = Object.assign({}, window.MOCK.settings, localSettings(), patch);
    localStorage.setItem(LS_SETTINGS, JSON.stringify(next));
    window.MOCK.settings = next;
    if (next.apiBase && next.apiBase !== base) setBase(next.apiBase);
    return next;
  }

  /* 记录最近一次请求的真实失败原因。
     以前 request() 把所有异常一律吞成 null，页面只能显示「业务服务不可用」，
     后端到底返回了 400 参数错误还是 500 数据库错误完全被掩盖，排障只能靠猜。
     现在把服务端返回的 message 抓出来，写操作失败时原样透给用户。 */
  var lastError = null;
  function rememberFailure(url, err) {
    online = false;
    lastError = { url: url, message: String((err && err.message) || err || '未知错误'), time: new Date().toISOString() };
    if (typeof window.dispatchEvent === 'function' && typeof window.CustomEvent === 'function') {
      window.dispatchEvent(new window.CustomEvent('smartbridge:api-error', { detail: lastError }));
    }
    return null;
  }

  /* 统一 fetch：超时 1.5s。失败仍回落 null（保持页面可用），但失败原因已留痕 */
  function request(path, options, timeoutMs) {
    var ctrl = new AbortController();
    var target = path.indexOf('http') === 0 ? path : base + path;
    var timer = setTimeout(function () { ctrl.abort(); }, timeoutMs || 1500);
    return fetch(target,
      Object.assign({ signal: ctrl.signal, credentials: 'include', headers: { Accept: 'application/json' } }, options || {}))
      .then(function (res) {
        clearTimeout(timer);
        if (!res.ok) {
          /* 服务端在 body 里带了可读的 message（如「请提供归档名称」），优先取它 */
          return res.text().then(function (text) {
            var msg = '';
            try { var b = JSON.parse(text); msg = (b && (b.message || b.code)) || ''; } catch (e) { msg = String(text || '').slice(0, 120); }
            throw new Error(msg ? msg + '（HTTP ' + res.status + '）' : 'HTTP ' + res.status);
          });
        }
        online = true;
        return res.json();
      })
      .then(function (json) { return (json && json.data !== undefined) ? json.data : json; })
      .catch(function (err) { clearTimeout(timer); return rememberFailure(target, err); });
  }

  function requireRemote(result, action) {
    if (result !== null && result !== undefined) return result;
    var err = new Error(action + '失败：' + (lastError ? lastError.message : '业务服务不可用或返回格式不正确'));
    err.code = 'SERVICE_UNAVAILABLE';
    err.detail = lastError;
    throw err;
  }

  var API_MAP = {
    teacher:     '/api/teacher/profile',
    requests:    '/api/teacher/requests',
    stages:      '/api/teacher/tasks',
    students:    '/api/teacher/students',
    questions:   '/api/teacher/questions',
    evaluations: '/api/teacher/evaluations',
    library:     '/api/teacher/library',
    kpis:        '/api/teacher/kpis',
    /* 冲突 B09：补全大小写映射（原仅映射 teacher，其余回落会取到 undefined） */
    notifications: '/api/teacher/notifications',
    settings:    '/api/teacher/settings'
  };
  var MOCK_KEY = {
    teacher: 'teacher',
    requests: 'REQUESTS',
    students: 'STUDENTS',
    questions: 'QUESTIONS',
    evaluations: 'EVAL',
    library: 'LIBRARY',
    stages: 'STAGE_DRAFT',
    notifications: 'NOTIFICATIONS'
  };

  var Store = {
    /* 读取：缓存 → mycircle → Mock */
    get: function (key) {
      if (cache[key] !== undefined) return Promise.resolve(cache[key]);
      var remoteP = API_MAP[key] ? request(API_MAP[key]) : Promise.resolve(null);
      return remoteP.then(function (remote) {
        var value = remote || window.MOCK[MOCK_KEY[key] || key];
        cache[key] = value;
        return value;
      });
    },
    invalidate: function (key) { delete cache[key]; },
    invalidateAll: function () { Object.keys(cache).forEach(function (k) { delete cache[k]; }); },

    /* 提交需求审核结论（通过 / 退回补充） */
    submitReview: function (payload) {
      return request('/api/teacher/requests/review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({
          project_id: window.MOCK.project_id, status: 'published', request_time: new Date().toISOString()
        }, payload))
      }).then(function (r) { return requireRemote(r, '提交需求审核'); });
    },
    /* 发布任务阶段到教学平台 */
    submitTaskDraft: function (payload) {
      return request('/api/teacher/tasks/publish', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({
          project_id: window.MOCK.project_id, status: 'running', request_time: new Date().toISOString()
        }, payload))
      }).then(function (r) { return requireRemote(r, '发布任务阶段'); });
    },
    /* 提交教学评价复核结论 */
    submitEvaluation: function (payload) {
      return request('/api/teacher/evaluations/decide', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({
          project_id: window.MOCK.project_id, status: 'success', request_time: new Date().toISOString()
        }, payload))
      }).then(function (r) { return requireRemote(r, '提交评价复核'); });
    },

    saveTaskStages: function (projectId, stages) {
      return request('/api/teacher/projects/' + encodeURIComponent(projectId) + '/task-stages', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stages: stages, request_time: new Date().toISOString() })
      }).then(function (r) { return requireRemote(r, '保存任务阶段'); });
    },
    submitQuestionReply: function (questionId, reply) {
      return request('/api/teacher/questions/' + encodeURIComponent(questionId) + '/reply', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ reply: reply, request_time: new Date().toISOString() })
      }).then(function (r) { return requireRemote(r, '提交答疑回复'); });
    },
    submitConfirmationRequest: function (payload) {
      return request('/api/teacher/enterprise-confirmations', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ project_id: window.MOCK.project_id, request_time: new Date().toISOString() }, payload))
      }).then(function (r) { return requireRemote(r, '发送企业确认请求'); });
    },
    saveCase: function (payload) {
      return request('/api/teacher/library', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(Object.assign({ project_id: window.MOCK.project_id, request_time: new Date().toISOString() }, payload))
      }).then(function (r) { return requireRemote(r, '归档案例'); });
    },

    getBase: function () { return base; },
    setBase: function (next) {
      base = String(next || '').replace(/\/$/, '');
      localStorage.setItem(LS_BASE, base);
      Store.invalidateAll();
      return base;
    },
    resetBase: function () { base = DEFAULT_BASE; localStorage.removeItem(LS_BASE); Store.invalidateAll(); },
    isOnline: function () { return online; },
    /* 供页面「最后错误」提示条读取：{ url, message, time } */
    lastError: function () { return lastError; },
    clearError: function () { lastError = null; },

    settings: function () { return Object.assign({}, window.MOCK.settings, localSettings()); },
    saveSettings: saveSettings,
    ping: function () { return request('/api/health', null, 1200).then(function (r) { return !!r; }); }
  };

  /* 启动时合并本地设置到内存 Mock */
  window.MOCK.settings = Object.assign({}, window.MOCK.settings, localSettings());

  window.Store = Store;
})();
