/* ==========================================================================
   data/mock.js —— 智训桥 SmartBridge · 教师端 演示数据
   --------------------------------------------------------------------------
   与另两端共用同一项目：PRJ-0917-001《设备点检台账整理与异常周报生成》。
   所有内容均为演示数据，不含任何真实企业与个人信息；学生姓名 / 学号均为虚构。
   教师侧 16 步流程收敛为 5 个阶段，每阶段 2–4 步，页面上以标签页 + 时间线呈现。
   ========================================================================== */
window.MOCK = (function () {
  const project_id = "PRJ-0917-001";

  /* ---------- 16 步收敛为 5 阶段（教师侧完整流程） ---------- */
  const PHASES = [
    { id: 0, name: "需求承接", steps: [0, 1, 2] },
    { id: 1, name: "教学准备", steps: [3, 4, 5] },
    { id: 2, name: "任务发布", steps: [6, 7] },
    { id: 3, name: "过程监督", steps: [8, 9, 10, 11] },
    { id: 4, name: "评价与改进", steps: [12, 13, 14, 15] },
  ];

  /* status: ok 已完成 / cur 进行中（需要你处理） / wait 未开始 */
  const STEPS = [
    { t: "收到入库通知", st: "ok", d: "平台自动接收企业交付的任务，已识别企业、项目类型与参与人数。",
      body: `<div class="block-label">系统自动识别的信息</div><div class="list">
        <div class="row-item"><b style="width:88px;flex-shrink:0;color:var(--ink-4);font-weight:600">企业 / 项目</b><span>华明制造 · 设备点检台账整理与异常周报生成</span></div>
        <div class="row-item"><b style="width:88px;flex-shrink:0;color:var(--ink-4);font-weight:600">项目类型</b><span>数据处理类 · 可转化为实训任务</span></div>
        <div class="row-item"><b style="width:88px;flex-shrink:0;color:var(--ink-4);font-weight:600">参与人数</b><span>1 个班 · 32 人（建议）</span></div>
        <div class="row-item"><b style="width:88px;flex-shrink:0;color:var(--ink-4);font-weight:600">职能方向</b><span>数据清洗 / 异常识别 / 报表输出</span></div>
      </div>
      <div class="cap-ev" style="margin-top:12px"><span class="t">说明</span><code>本步由平台自动完成，你无需操作；如不需要本任务可直接跳过。</code></div>`,
      art: "任务入库回执" },

    { t: "预览项目", st: "ok", d: "已查看任务书、职位说明与评分标准，并从题库中选取了对口的题目。",
      body: `<div class="block-label">任务书要点</div><div class="list">
        <div class="row-item"><b style="width:88px;flex-shrink:0;color:var(--ink-4);font-weight:600">业务目标</b><span>汇总每周点检记录，形成异常清单与周报</span></div>
        <div class="row-item"><b style="width:88px;flex-shrink:0;color:var(--ink-4);font-weight:600">交付形式</b><span>汇总表 · 异常明细 · 周报 · 操作说明</span></div>
        <div class="row-item"><b style="width:88px;flex-shrink:0;color:var(--ink-4);font-weight:600">评分标准</b><span>材料完整性 / 客观正确性 / 业务适用性 / 可复用性</span></div>
      </div>
      <div class="block-label" style="margin-top:14px">已选用的题库题目</div>
      <div class="skills"><span class="skill b">表格数据清洗</span><span class="skill g">条件判断与阈值</span><span class="skill a">报表结构设计</span><span class="skill v">结果呈现</span></div>`,
      art: "项目预览记录" },

    { t: "人工筛选（是否承接）", st: "ok", d: "已确认承接本任务，进入教学准备。（冲突 B16：原为 cur，与后续已完成的第 4–10 步矛盾）",
      body: `<div class="block-label">请逐项确认</div>
        <div class="list" id="reviewList"></div>
        <div class="meter"><div class="track"><i id="reviewBar" style="width:0%"></i></div><b id="reviewPct">0 / 5 已确认</b></div>
        <div style="margin-top:14px;display:flex;gap:9px;flex-wrap:wrap">
          <button class="btn btn-green" id="reviewBtn" disabled onclick="saveReview()">确认承接并进入教学准备</button>
          <button class="btn btn-outline" onclick="Shell.toast('已退回给需求方，并标记原因：与本专业先修条件不匹配')">退回并标记原因</button>
        </div>`,
      art: "审核结论 v1" },

    { t: "指定班级", st: "ok", d: "已确定承接班级与排课安排，教学平台收到排课计划。",
      body: `<div class="block-label">承接安排</div><div class="list">
        <div class="row-item done"><span class="tick">✓</span><b>承接班级</b><span class="k">2024级数据科学班（32 人）</span></div>
        <div class="row-item done"><span class="tick">✓</span><b>任课教师</b><span class="k">李慧敏 · 智能制造学院</span></div>
        <div class="row-item done"><span class="tick">✓</span><b>课时安排</b><span class="k">4 周 · 每周 3 课时 · 共 12 课时</span></div>
        <div class="row-item done"><span class="tick">✓</span><b>先修条件</b><span class="k">表格数据处理基础（已满足）</span></div>
      </div>`,
      art: "排课与承接记录" },

    { t: "读取学生名单", st: "ok", d: "已从教务与教学平台读取选课名单、学号与课程时间，无需人工录入。",
      body: `<div class="block-label">读取结果</div><div class="list">
        <div class="row-item done"><span class="tick">✓</span><b>名单来源</b><span class="k">教务系统 / 教学平台（自动同步）</span></div>
        <div class="row-item done"><span class="tick">✓</span><b>学员数量</b><span class="k">32 人 · 已按 3 个实践小组预分组</span></div>
        <div class="row-item done"><span class="tick">✓</span><b>课程时间</b><span class="k">每周三 5–7 节 · 实训室 B302</span></div>
      </div>`,
      art: "学生名单同步记录" },

    { t: "建立学生档案", st: "ok", d: "已为每名学生建立档案，生成基础信息表，后续提交与评价都挂到档案上。",
      body: `<div class="block-label">档案字段</div>
        <div class="skills"><span class="skill b">学号</span><span class="skill g">姓名</span><span class="skill a">实践小组</span><span class="skill v">选课与成绩</span><span class="skill b">提交与返修轨迹</span></div>
        <div class="cap-ev" style="margin-top:12px"><span class="t">口径</span><code>档案只记录与教学相关的表现，不收集与教学无关的个人信息。</code></div>`,
      art: "学生基础信息表" },

    { t: "发布课题", st: "ok", d: "课题、知识点与方法已发布，辅助材料随课题一并下发。",
      body: `<div class="block-label">课题概要</div><div class="list">
        <div class="row-item"><b style="width:88px;flex-shrink:0;color:var(--ink-4);font-weight:600">课题名称</b><span>设备点检台账整理与异常周报生成</span></div>
        <div class="row-item"><b style="width:88px;flex-shrink:0;color:var(--ink-4);font-weight:600">知识点</b><span>字段规范化 · 去重策略 · 阈值与边界判断 · 报表结构</span></div>
        <div class="row-item"><b style="width:88px;flex-shrink:0;color:var(--ink-4);font-weight:600">辅助材料</b><span>点检样表（脱敏）· 字段说明 · 异常规则说明</span></div>
      </div>`,
      art: "课题发布记录" },

    { t: "分发任务并辅导", st: "ok", d: "任务已按小组分发到每位学生，并完成了一次集中辅导。",
      body: `<div class="block-label">分发情况</div><div class="list">
        <div class="row-item done"><span class="tick">✓</span><b>第 1 组</b><span class="k">3 人 · 已领取 · 负责字段整理与去重</span></div>
        <div class="row-item done"><span class="tick">✓</span><b>第 2 组</b><span class="k">3 人 · 已领取 · 负责异常规则实现</span></div>
        <div class="row-item done"><span class="tick">✓</span><b>第 3 组</b><span class="k">3 人 · 已领取 · 负责汇总与周报</span></div>
      </div>
      <div class="cap-ev" style="margin-top:12px"><span class="t">辅导记录</span><code>集中讲解一次：去重按时间戳保留最新记录；30 分钟内 2 组提问已答复。</code></div>`,
      art: "任务分发与辅导记录" },

    { t: "过程监督", st: "ok", d: "平台每晚自动汇总学生状态并预警异常，无需你一直盯系统。",
      body: `<div class="block-label">最近一次自动汇总</div><div class="list">
        <div class="row-item"><b style="width:110px;flex-shrink:0;color:var(--ink-4);font-weight:600">提交进度</b><span>85 / 96 人次已提交（88.5%）</span></div>
        <div class="row-item"><b style="width:110px;flex-shrink:0;color:var(--ink-4);font-weight:600">异常预警</b><span>2 人连续未提交、1 组重复失败 2 次</span></div>
        <div class="row-item"><b style="width:110px;flex-shrink:0;color:var(--ink-4);font-weight:600">共性提问</b><span>3 条（单位口径、边界值、缺失值是否计入异常）</span></div>
      </div>`,
      art: "过程监督日报" },

    { t: "查看真实过程", st: "ok", d: "可查看每名学生的提交轨迹、返修记录与运行回放，教学过程可追溯。",
      body: `<div class="block-label">可追溯的过程证据</div>
        <div class="skills"><span class="skill b">提交轨迹</span><span class="skill g">固定样例测试结果</span><span class="skill a">返修与重测记录</span><span class="skill v">协作记录</span></div>
        <div class="cap-ev" style="margin-top:12px"><span class="t">说明</span><code>过程证据由平台自动留痕，教师与学生均不可修改，作为评价依据。</code></div>`,
      art: "过程证据索引" },

    { t: "人工介入与辅导", st: "cur", d: "这是当前需要你完成的环节：对滞后学生与共性错误进行介入，并记录处理方式。",
      body: `<div class="block-label">建议介入项</div>
        <div class="list" id="interveneList"></div>
        <div style="margin-top:14px;display:flex;gap:9px;flex-wrap:wrap">
          <button class="btn btn-primary" onclick="Shell.toast('已推送讲评材料给相关学生，并记录为一次集中辅导')">推送讲评并记录</button>
          <button class="btn btn-outline" onclick="location.href='qa.html'">去答疑聚合处理</button>
        </div>`,
      art: "介入记录 v1" },

    { t: "重复 AI 评测", st: "wait", d: "待过程监督收尾后启动：AI 先出过程项预评，你只确认或修改有分歧的部分。",
      body: `<div class="block-label">即将进行</div><div class="list">
        <div class="row-item"><b style="width:110px;flex-shrink:0;color:var(--ink-4);font-weight:600">预评范围</b><span>提交完整性、样例测试通过率、返修轨迹</span></div>
        <div class="row-item"><b style="width:110px;flex-shrink:0;color:var(--ink-4);font-weight:600">你的动作</b><span>确认 AI 结果，或对个别学生人工调整</span></div>
      </div>
      <div class="cap-ev" style="margin-top:12px"><span class="t">原则</span><code>AI 只做客观项预评，教学判断权始终在教师；预评分数不覆盖教师已填写的部分。</code></div>`,
      art: "—" },

    { t: "获取学情报告", st: "wait", d: "结课后生成成绩报告与学情总览，供教学复盘与教研使用。",
      body: `<div class="block-label">报告包含</div>
        <div class="skills"><span class="skill b">成绩总览</span><span class="skill g">能力维度分布</span><span class="skill a">个体差异</span><span class="skill v">证据摘要</span></div>`,
      art: "—" },

    { t: "改进课程", st: "wait", d: "把本轮暴露的问题回灌到课程设计，并把企业任务沉淀为可复用的教学资源。",
      body: `<div class="block-label">改进动作</div><div class="list">
        <div class="row-item"><b style="width:110px;flex-shrink:0;color:var(--ink-4);font-weight:600">课程调整</b><span>增加一次「阈值与边界值」专项讲评</span></div>
        <div class="row-item"><b style="width:110px;flex-shrink:0;color:var(--ink-4);font-weight:600">资源沉淀</b><span>将脱敏后的点检案例与规则模板归档到案例库</span></div>
      </div>`,
      art: "—" },

    { t: "接收就业反馈", st: "wait", d: "接收企业侧的岗位使用反馈，作为教学改进的外部输入。",
      body: `<div class="block-label">反馈维度</div>
        <div class="skills"><span class="skill b">岗位适应情况</span><span class="skill g">企业评价</span><span class="skill a">能力缺口</span></div>`,
      art: "—" },

    { t: "最终闭环", st: "wait", d: "改进结果用于下一轮任务筛选与教学迭代，形成闭环。",
      body: `<div class="block-label">闭环动作</div><div class="list">
        <div class="row-item"><b style="width:110px;flex-shrink:0;color:var(--ink-4);font-weight:600">筛选逻辑</b><span>按本轮适配度调整下一轮企业任务的承接范围</span></div>
        <div class="row-item"><b style="width:110px;flex-shrink:0;color:var(--ink-4);font-weight:600">评价标准</b><span>把「边界值不可四舍五入」写入统一评分口径</span></div>
      </div>`,
      art: "—" },
  ];

  /* ---------- 需求审核要点（第 3 步逐项确认） ---------- */
  const REVIEW = [
    { k: "关键字段齐全，且保留原文来源位置", d: "已核对样表 6 列字段与来源页码" },
    { k: "待确认问题是否已全部关闭", d: "阈值 / 单位 / 缺失值口径均由企业确认" },
    { k: "脱敏副本已去除企业专属信息", d: "已替换企业名、设备台账编号" },
    { k: "已判断教学适配性与学生先修条件", d: "与《数据处理实务》课程标准 3 个层级对齐" },
    { k: "已划分教学实践与专业承接范围", d: "数据清洗与报表留校，工艺判定转交专业承接者" },
  ];

  /* ---------- 评价复核队列 ---------- */
  const EVAL = [
    { id: 101, student: "张晓明", group: "第1组", task: "字段整理与去重", score: 92, tests: "5/5", reworks: 0, status: "pending", comment: "",
      evidence: "独立完成字段统一与去重，保留原始记录可追溯，固定样例全部通过。" },
    { id: 102, student: "王浩宇", group: "第2组", task: "异常规则实现", score: 78, tests: "3/5", reworks: 2, status: "pending", comment: "",
      evidence: "边界条件判断有误，经两次返修后已修正；协作记录清晰。" },
    { id: 103, student: "陈静怡", group: "第2组", task: "汇总表与周报生成", score: 85, tests: "4/5", reworks: 1, status: "pending", comment: "",
      evidence: "周报结构完整，部分统计口径待复核；个人贡献可核验。" },
    { id: 104, student: "李思雨", group: "第1组", task: "异常规则实现", score: 88, tests: "4/5", reworks: 1, status: "done", comment: "概念理解到位，返修后边界处理准确。",
      evidence: "正确实现阈值判断，返修后测试通过。" },
  ];

  /* ---------- 班级学生 ---------- */
  const STUDENTS = [
    { id: 1, name: "张晓明", sid: "2024010112", group: "第1组", progress: 92, lastSubmit: "09-17 14:30", status: "normal", submits: 6, reworks: 0, stageDone: 3,
      tags: ["数据清洗", "Python", "规则实现"],
      records: [{ text: "提交「字段整理与去重」成果 v2", time: "今天 14:30" }, { text: "通过固定样例测试 5/5", time: "今天 14:32" }, { text: "提交清洗日志", time: "昨天 20:10" }] },
    { id: 2, name: "李思雨", sid: "2024010118", group: "第1组", progress: 88, lastSubmit: "09-17 11:20", status: "normal", submits: 5, reworks: 1, stageDone: 3,
      tags: ["Excel", "报表生成"],
      records: [{ text: "提交「异常规则实现」成果", time: "今天 11:20" }, { text: "返修后重测通过 4/5", time: "今天 12:05" }] },
    { id: 3, name: "王浩宇", sid: "2024010125", group: "第2组", progress: 45, lastSubmit: "09-15 16:45", status: "lag", submits: 3, reworks: 2, stageDone: 2,
      tags: ["条件判断"],
      records: [{ text: "提交「异常规则实现」成果 v1", time: "09-15 16:45" }, { text: "边界条件判断有误，需返修", time: "09-15 17:02" }] },
    { id: 4, name: "陈静怡", sid: "2024010130", group: "第2组", progress: 76, lastSubmit: "09-16 09:10", status: "normal", submits: 5, reworks: 1, stageDone: 3,
      tags: ["数据聚合", "可视化"],
      records: [{ text: "提交「汇总表与周报生成」草稿", time: "09-16 09:10" }, { text: "周报结构完整，统计口径待复核", time: "09-16 10:00" }] },
    { id: 5, name: "刘子豪", sid: "2024010142", group: "第3组", progress: 30, lastSubmit: "09-14 13:50", status: "risk", submits: 2, reworks: 1, stageDone: 1,
      tags: ["Excel"],
      records: [{ text: "提交「字段整理与去重」草稿", time: "09-14 13:50" }, { text: "连续 3 天未提交新进展", time: "09-17 00:00" }] },
    { id: 6, name: "陈晓雨", sid: "2024010156", group: "第2组", progress: 45, lastSubmit: "09-17 14:32", status: "lag", submits: 3, reworks: 1, stageDone: 1,
      tags: ["数据清洗", "规则实现"],
      records: [{ text: "阶段二产物进入提交检查", time: "今天 14:32" }, { text: "80℃ 边界条件已修正并重测", time: "昨天 15:40" }] },
  ];

  /* ---------- 当前需介入项（第 11 步） ---------- */
  const INTERVENE = [
    { who: "刘子豪 · 第3组", why: "连续 3 天未提交，进度 30%", act: "单独沟通 + 结对帮扶", ok: false },
    { who: "王浩宇 · 第2组", why: "边界条件判断连续出错 2 次", act: "推送「边界值判定」讲评", ok: false },
    { who: "全班 · 共性", why: "缺失值是否计入异常数量口径不一", act: "集中讲评并统一口径", ok: true },
  ];

  /* ---------- 企业需求（待审核） ---------- */
  const REQUESTS = [
    { id: 1, industry: "智能制造", date: "2026-09-17", title: "设备点检台账整理与异常周报生成", urgent: true, status: "pending",
      desc: "某园区制造企业按周接收多个班组的设备点检表，存在字段不统一、重复记录、缺失值分散等问题，希望生成统一台账与异常周报。",
      tags: ["数据清洗", "Excel", "规则实现"], goal: "汇总每周点检记录，形成异常清单与周报", input: "点检样表、字段说明、异常规则",
      deliverable: "汇总表、异常明细、周报及说明", confirm: "阈值单位、缺失值处理、共享字段", stages: 4, cls: "2024级数据科学班" },
    { id: 2, industry: "物流仓储", date: "2026-09-16", title: "出入库报表自动化汇总", urgent: false, status: "pending",
      desc: "需要整合多个仓库每日出入库记录，按品类与日期生成汇总报表，并标记异常库存波动。",
      tags: ["报表生成", "Python", "数据汇总"], goal: "自动生成每日出入库汇总报表", input: "出入库记录、品类映射表",
      deliverable: "汇总报表、异常波动清单", confirm: "汇总口径、异常阈值", stages: 3, cls: "2023级工业互联网班" },
    { id: 3, industry: "质量管理", date: "2026-09-15", title: "质量检测数据可视化看板", urgent: false, status: "pending",
      desc: "希望将历史质量检测数据整理为可视化看板，支持按班次、产线维度下钻查看。",
      tags: ["可视化", "数据分析", "看板"], goal: "构建质量数据可视化看板", input: "检测数据、产线编码、班次规则",
      deliverable: "看板页面、数据说明", confirm: "维度定义、刷新频率", stages: 3, cls: "2024级数据科学班" },
    { id: 4, industry: "智能制造", date: "2026-09-10", title: "工单处理时效统计", urgent: false, status: "published",
      desc: "统计维修工单从报修到办结的时效分布，识别超结工单并分析原因。",
      tags: ["统计分析", "工单数据"], goal: "分析工单处理时效", input: "工单记录、状态流转规则",
      deliverable: "时效统计表、超结清单", confirm: "状态节点、超结标准", stages: 3, cls: "2023级工业互联网班" },
  ];

  /* ---------- 答疑聚合 ---------- */
  const QUESTIONS = [
    { id: 1, count: 12, task: "任务一 · 字段整理", question: "如何判断重复记录应该保留哪一条？", replied: false, reply: "",
      summary: "学生对同一设备多次点检记录的去重策略存在疑问，建议统一按时间戳保留最新记录。" },
    { id: 2, count: 8, task: "任务二 · 异常规则", question: "80℃ 属于异常还是边界正常值？", replied: false, reply: "",
      summary: "温度阈值的边界条件理解不一致，需要结合企业确认的规则统一说明。" },
    { id: 3, count: 6, task: "任务三 · 周报生成", question: "周报中缺失值是否计入异常数量？", replied: true, reply: "缺失值单独列为「待核查」，不计入异常数量，统计口径以企业确认版为准。",
      summary: "学生反馈周报统计口径不清晰，建议明确缺失值单独列为「待核查」。" },
  ];
  const KNOWLEDGE = ["设备点检字段规范", "异常值判断标准", "周报模板与示例", "数据去重最佳实践", "企业规则确认流程"];

  /* ---------- 案例库 ---------- */
  const LIBRARY = [
    { id: 201, type: "案例", date: "2026-09-10", title: "设备点检台账整理（脱敏版）", desc: "去除企业专属信息后的标准化教学案例，包含完整任务阶段与评分标准。", used: 3 },
    { id: 202, type: "模板", date: "2026-09-05", title: "异常值判断规则模板", desc: "可配置阈值的通用异常规则模板，适用于温度、数量等多种字段类型。", used: 5 },
    { id: 203, type: "模板", date: "2026-08-28", title: "周报生成规范", desc: "统一的周报字段、格式与验收清单，支持多项目复用。", used: 2 },
    { id: 204, type: "案例", date: "2026-08-20", title: "出入库报表自动化汇总", desc: "物流仓储场景的数据汇总与报表生成教学案例。", used: 1 },
    { id: 205, type: "案例", date: "2026-08-12", title: "质量数据可视化看板", desc: "质量检测数据的看板搭建案例，含维度设计与交互说明。", used: 2 },
  ];

  /* ---------- 任务阶段草稿 ---------- */
  const STAGE_DRAFT = [
    { id: 1, name: "字段整理与去重", desc: "统一字段名称与单位，处理重复记录，标记缺失项并输出清洗日志", skills: ["Excel", "Python pandas"], status: "published", duration: 3, acceptance: "原始记录可追溯，处理规则符合约定" },
    { id: 2, name: "异常规则实现", desc: "依据企业确认的阈值识别异常，输出异常明细清单", skills: ["条件判断", "规则引擎"], status: "published", duration: 3, acceptance: "阈值、单位和边界条件正确" },
    { id: 3, name: "汇总表与周报生成", desc: "生成周度汇总表、异常明细与可读周报", skills: ["报表生成", "数据聚合"], status: "draft", duration: 4, acceptance: "结果完整，业务人员能理解" },
    { id: 4, name: "操作说明与复现检查", desc: "补充运行说明、依赖与异常处理说明，完成复现自检", skills: ["文档编写", "复现测试"], status: "draft", duration: 2, acceptance: "按说明可复现，责任边界清楚" },
  ];

  /* ---------- 通知 ---------- */
  const NOTIFICATIONS = [
    { text: "企业「华明制造」已确认异常规则阈值", time: "5 分钟前", read: false, level: "ok" },
    { text: "张晓明提交了「字段整理与去重」成果 v2", time: "22 分钟前", read: false, level: "info" },
    { text: "刘子豪连续 3 天未提交任务，建议关注", time: "1 小时前", read: false, level: "warn" },
    { text: "系统生成 8 份待复核教学评价", time: "2 小时前", read: true, level: "info" },
  ];

  /* ---------- 工作台 KPI ---------- */
  const KPIS = [
    { label: "待审核企业需求", value: 3, sub: "今日新增 1 条", trend: "+1", dir: "up", href: "review.html" },
    { label: "进行中任务阶段", value: 4, sub: "覆盖 1 个项目", trend: "持平", dir: "flat", href: "tasks.html" },
    { label: "待复核评价", value: 3, sub: "2 份需重点关注", trend: "+2", dir: "up", href: "evaluation.html" },
    { label: "需关注学生", value: 2, sub: "滞后或测试未通过", trend: "-1", dir: "down", href: "students.html" },
  ];

  /* ---------- 五阶段流程（工作台时间线） ---------- */
  const FLOW = [
    { title: "需求承接", who: "企业发起 · 教师判断", detail: "接收任务通知、预览任务书与评分标准，教师判断是否承接及教学适配性。" },
    { title: "教学准备", who: "教师主导", detail: "指定班级与排课、读取学生名单、建立学生档案，形成教学基线。" },
    { title: "任务发布", who: "教师 · 学生", detail: "发布课题与辅助材料，按小组分发任务并完成一次集中辅导。" },
    { title: "过程监督", who: "学生实践 · 教师介入", detail: "平台每晚自动汇总并预警；教师查看真实过程，对滞后与共性错误介入辅导。" },
    { title: "评价与改进", who: "教师复核 · 闭环", detail: "AI 出客观项预评、教师复核教学评价，学情报告回灌课程改进并沉淀案例。" },
  ];

  return {
    project_id: project_id,
    PHASES: PHASES, STEPS: STEPS, REVIEW: REVIEW, EVAL: EVAL, STUDENTS: STUDENTS,

    /* ---------- 教师档案（本端身份） ---------- */
    teacher: {
      name: "李慧敏",
      college: "智能制造学院",
      role: "讲师",
      email: "lihm@example.edu.cn",
      cls: "2024级数据科学班"
    },

    /* ---------- 平台能力接入位 · 本端使用情况 ----------
       命题硬性要求第 1 条：至少调用 3 类平台核心自动化技能；本端五类均有落点，全部预留。
       命题硬性要求第 2 条：至少 2 套校内实训系统互通 —— 本端接入 lms 与 edge。 */
    capability: {
      used: ["parse-batch", "training", "multimodal", "rag", "report"],
      minRequired: 3,
      note: "接入位只声明「能力用在哪」，能力本体由后端实现；未接入时界面显示「未接入」，教学流程不受影响。",
      systems: [
        {
          id: "lms", name: "校内实训教学平台", protocol: "HTTP API", place: "接入位 B1 / B2",
          desc: "下发任务阶段与验收标准到教学平台，并把班级提交进度与成绩回填到教师工作台",
          rows: [
            { k: "机械设计 2203", v: "28 / 32 已提交 · 均分 88" },
            { k: "机械设计 2202", v: "26 / 30 已提交 · 均分 85" },
            { k: "机电一体化 2201", v: "31 / 31 已提交 · 均分 91" }
          ]
        },
        {
          id: "edge", name: "实训硬件数据网关", protocol: "MQTT / OPC-UA", place: "接入位 B3",
          desc: "读取数控实训台、机器人工作站与采集端工况，用于固定样例测试结果的确定性比对",
          rows: [
            { k: "CNC-02 数控实训台", v: "主轴运行 12.4 h · 正常" },
            { k: "RB-11 机器人工作站", v: "示教轨迹 38 点 · 正常" },
            { k: "GW-07 物联网网关", v: "点位在线率 99.2%" }
          ]
        }
      ]
    },

    REQUESTS: REQUESTS,
    QUESTIONS: QUESTIONS,
    KNOWLEDGE: KNOWLEDGE,
    LIBRARY: LIBRARY,
    STAGE_DRAFT: STAGE_DRAFT,
    INTERVENE: INTERVENE,
    notifications: NOTIFICATIONS,
    kpis: KPIS,
    flowSteps: FLOW,

    /* ---------- 评价权重与通知偏好 ---------- */
    weights: [
      { key: "process", label: "过程表现（提交及时性、协作记录）", value: 30 },
      { key: "result", label: "成果质量（样例测试通过、交付完整度）", value: 50 },
      { key: "contribution", label: "个人贡献（可核验的独立部分）", value: 20 },
    ],
    notifPrefs: [
      { key: "req", label: "企业需求审核提醒", on: true },
      { key: "submit", label: "学生提交成果提醒", on: true },
      { key: "risk", label: "风险任务预警", on: true },
      { key: "weekly", label: "每周教学汇总", on: false },
    ],

    /* ---------- 报告页数据 ---------- */
    reportData: {
      hours: [
        { k: "第1周", v: 3 }, { k: "第2周", v: 3 }, { k: "第3周", v: 3 }, { k: "第4周", v: 3 }
      ],
      clsRows: [
        { cls: "2024级数据科学班", submitted: "28 / 32", avg: 88, pass: 91, status: "进行中" },
      ],
      dims: [
        { k: "数据清洗", v: 90 }, { k: "规则实现", v: 74 }, { k: "结果呈现", v: 83 }, { k: "协作记录", v: 86 }
      ]
    },

    settings: {
      apiBase: "http://localhost:8080",
      coreMock: true,
      maskedOnly: true,
      weeklyDigest: false,
      reuseCase: true,
      defaultClass: "2024级数据科学班"
    }
  };
})();
