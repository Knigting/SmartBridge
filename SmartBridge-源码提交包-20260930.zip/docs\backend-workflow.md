# Backend and workflow architecture

## Responsibilities

`services/api` owns authentication, business CRUD, uploads, exports, database transactions, audit records, static web delivery and the Skill gateway.

`services/skill-service` owns five independent capabilities: batch parsing, RAG retrieval, report generation, training-system operations and multimodal recognition.

## Workflow dispatch

Each platform has five active workflow bindings in MySQL, for a total of 20. A business event is dispatched through:

```text
POST /api/workflows/:platform/:trigger/dispatch
```

The API resolves the registered binding, forwards the normalized payload to the Skill service, and records the platform, trigger, Skill and run result for auditability.

## Data flow

```text
Browser app
  -> API route or workflow dispatch
  -> MySQL transaction / Skill gateway
  -> Skill service
  -> normalized result with evidence
  -> audit record and browser response
```

Files are stored on disk under `services/api/uploads/`; MySQL stores metadata and hashes. Skill-generated artifacts and indexes live under `services/skill-service/runtime/`.

## Operation safeguards

Training-system write operations are not executed directly. They require a generated plan, explicit approval token, idempotency key and post-operation read-back verification. Read operations use the same registered action whitelist without the approval step.
