# Delivery notes

## Required source directories

Keep these directories together when delivering the project:

- `apps/`
- `services/`
- `data/training/`
- `scripts/`
- `tools/`
- `docs/`

Do not rename training files without updating `services/skill-service/src/train-data.js` and the verification fixtures.

## Generated directories

The following directories contain runtime or verification output rather than authoritative source code:

- `services/api/uploads/`
- `services/skill-service/runtime/`
- `reports/verification/`

They are created automatically when needed.

## Verification commands

```powershell
npm run check --prefix services/api
npm run check --prefix services/skill-service
npm test --prefix services/skill-service
node tools/static-integrity.js
node tools/smoke-all.js
node tools/verify-files.js
node tools/verify-data-crud.js
node tools/verify-workflow-dispatch.js
node tools/verify-platform-skills.js
```

The multimodal tests use the local simulation provider unless a real OCR/ASR provider is configured. A simulated success must not be described as real OCR or ASR.
