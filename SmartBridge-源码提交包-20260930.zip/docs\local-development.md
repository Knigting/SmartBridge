# Local development

## Runtime architecture

The system uses one MySQL database named `smartbridge`. All five browser applications use the same Express API and the same source of truth.

- API and static web gateway: `http://127.0.0.1:8080`
- Skill service: `http://127.0.0.1:8090`
- MySQL: `127.0.0.1:3306`
- Runtime database account: `smartbridge_app`

The API serves web files from `apps/` and forwards Skill calls to the Skill service. Skill metadata and workflow bindings are persisted in MySQL.

## Setup and startup

Run `setup.cmd` once. It installs missing dependencies, initializes the database, builds local training indexes, registers Skills and starts both services.

For normal use, run `start.cmd`. To stop the two Node.js listeners, run `stop.cmd`.

PowerShell entry points are also available:

```powershell
.\scripts\first-run.ps1
.\scripts\start-system.ps1
.\scripts\stop-system.ps1
.\scripts\initialize-database.ps1
```

## Service checks

- API health: <http://127.0.0.1:8080/api/health>
- Skill status: <http://127.0.0.1:8090/api/skills/status>
- Login: <http://127.0.0.1:8080/login/index.html>

Do not open HTML files directly because that bypasses the API, authentication and Skill gateway.

## Storage

- Uploaded file bytes: `services/api/uploads/`
- Uploaded-file metadata and SHA-256 digests: MySQL
- Skill runtime state, generated reports and indexes: `services/skill-service/runtime/`
- Source training data: `data/training/`
- Verification artifacts: `reports/verification/`

Generated runtime directories are not source modules and may be cleaned between isolated test runs.

## Current Skill modes

| Skill | Mode | Notes |
|---|---|---|
| Batch file parsing | Live + LLM | Deterministic parsing (XLSX, CSV, TSV, JSON, TXT, Markdown, DOCX, PDF) plus a real-model summary and per-file advice (`enrichBatch`) |
| RAG retrieval | Live + LLM | Deterministic recall; the model composes the answer strictly from cited chunks (`synthesizeAnswer`); corpus includes compliance-crawled public pages (scope `公开资料库`, see `scripts/crawl-public-corpus.js`) |
| Visual report generation | Trained + LLM | Numbers are computed in code; the model only writes conclusion / findings / suggestions (`synthesizeNarrative`) and is forbidden from inventing figures |
| Training-system operation | Local sandbox + LLM intent | Natural-language instructions are parsed by the model into structured intent, then re-validated by the deterministic plan/approval/idempotency/read-back pipeline |
| Multimodal recognition | Not configured | The current endpoint is text-only; the skill returns an explicit error instead of any simulated result. Set `LLM_VISION_MODEL` / `LLM_ASR_MODEL` on a capable endpoint to enable |

Model configuration lives in `services/skill-service/.env` (gitignored): `LLM_BASE_URL`, `LLM_API_KEYS` (comma-separated key pool with cooldown failover), `LLM_MODEL`, `LLM_MAX_TOKENS=4096` (the reasoning model needs a large budget or the answer body comes back empty). Self-check: `GET /api/skills/model/ping`; full assertions: `node tools/verify-live-models.js`.

## Security

This is a local demonstration configuration. Do not expose ports `3306`, `8080` or `8090` to the public Internet. Before deployment, disable demo mode, rotate database and JWT secrets, enable HTTPS, rate limits, backups and file scanning.
