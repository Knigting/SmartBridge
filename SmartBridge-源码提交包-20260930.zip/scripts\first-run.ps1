param(
  [string]$DbAdminPassword = '',
  [switch]$SkipOpen
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$apiService = Join-Path $projectRoot 'services\api'
$skillService = Join-Path $projectRoot 'services\skill-service'
$envFile = Join-Path $apiService '.env'

if (-not (Get-Command node.exe -ErrorAction SilentlyContinue)) { throw 'Node.js 20 or later is required.' }
if (-not (Get-Command npm.cmd -ErrorAction SilentlyContinue)) { throw 'npm is required.' }
if (-not (Test-Path $envFile)) { throw 'services\api\.env is missing from the package.' }

if (-not $DbAdminPassword) {
  $DbAdminPassword = Read-Host 'Enter the local MySQL root password (press Enter to use 123456)'
  if (-not $DbAdminPassword) { $DbAdminPassword = '123456' }
}

$envText = [IO.File]::ReadAllText($envFile)
$escapedPassword = $DbAdminPassword.Replace('$', '$$')
$envText = [Text.RegularExpressions.Regex]::Replace($envText, '(?m)^DB_ADMIN_PASSWORD=.*$', "DB_ADMIN_PASSWORD=$escapedPassword")
[IO.File]::WriteAllText($envFile, $envText, [Text.UTF8Encoding]::new($false))

if (-not (Test-Path (Join-Path $apiService 'node_modules'))) { npm install --prefix $apiService }
if (-not (Test-Path (Join-Path $skillService 'node_modules'))) { npm install --prefix $skillService }

npm run db:init --prefix $apiService
if ($LASTEXITCODE -ne 0) { throw 'Database initialization failed.' }
npm run train:data --prefix $skillService
if ($LASTEXITCODE -ne 0) { throw 'Skill training data initialization failed.' }
npm run db:skills --prefix $apiService
if ($LASTEXITCODE -ne 0) { throw 'Skill metadata initialization failed.' }

& (Join-Path $PSScriptRoot 'start-system.ps1') -SkipOpen:$SkipOpen
