$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$apiService = Join-Path $projectRoot 'services\api'

if (-not (Test-Path (Join-Path $apiService 'node_modules'))) {
  npm install --prefix $apiService
}
npm run db:init --prefix $apiService
if ($LASTEXITCODE -ne 0) { throw 'Database initialization failed.' }
Write-Host 'Database initialization completed.'
