param([switch]$SkipOpen)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$apiService = Join-Path $projectRoot 'services\api'
$skillService = Join-Path $projectRoot 'services\skill-service'

if (-not (Get-Command node.exe -ErrorAction SilentlyContinue)) {
  throw 'Node.js was not found. Install Node.js 20 or later and reopen this launcher.'
}
if (-not (Get-Command npm.cmd -ErrorAction SilentlyContinue)) {
  throw 'npm was not found. Reinstall Node.js with npm enabled.'
}
if (-not (Test-Path (Join-Path $apiService '.env'))) {
  throw 'services\api\.env was not found. Run setup.cmd before daily startup.'
}

if (-not (Test-Path (Join-Path $apiService 'node_modules'))) {
  Write-Host 'Installing API service dependencies...'
  npm install --prefix $apiService
}
if (-not (Test-Path (Join-Path $skillService 'node_modules'))) {
  Write-Host 'Installing Skill service dependencies...'
  npm install --prefix $skillService
}

$nodeExe = (Get-Command node.exe).Source
if (-not (Get-NetTCPConnection -LocalPort 8090 -State Listen -ErrorAction SilentlyContinue)) {
  Write-Host 'Loading Skill training data and local indexes...'
  npm run train:data --prefix $skillService
  if ($LASTEXITCODE -ne 0) { throw 'Skill training data initialization failed.' }
  Write-Host 'Starting Skill service: http://127.0.0.1:8090'
  Start-Process -FilePath $nodeExe -ArgumentList @('src/server.js') -WorkingDirectory $skillService -WindowStyle Hidden
}

$skillReady = $false
for ($attempt = 0; $attempt -lt 40; $attempt++) {
  try {
    $status = Invoke-RestMethod -Uri 'http://127.0.0.1:8090/api/skills/status' -TimeoutSec 2
    if ($status.data.available -eq 5) { $skillReady = $true; break }
  } catch { Start-Sleep -Milliseconds 500 }
}
if (-not $skillReady) { throw 'Skill service did not become ready in 20 seconds.' }

Write-Host 'Syncing Skills and workflow bindings...'
npm run db:skills --prefix $apiService
if ($LASTEXITCODE -ne 0) { throw 'Skill metadata synchronization failed.' }

if (-not (Get-NetTCPConnection -LocalPort 8080 -State Listen -ErrorAction SilentlyContinue)) {
  Write-Host 'Starting API and web gateway: http://127.0.0.1:8080'
  Start-Process -FilePath $nodeExe -ArgumentList @('src/server.js') -WorkingDirectory $apiService -WindowStyle Hidden
}

$apiReady = $false
for ($attempt = 0; $attempt -lt 40; $attempt++) {
  try {
    $health = Invoke-RestMethod -Uri 'http://127.0.0.1:8080/api/health' -TimeoutSec 2
    if ($health) { $apiReady = $true; break }
  } catch { Start-Sleep -Milliseconds 500 }
}
if (-not $apiReady) { throw 'API service did not become ready in 20 seconds. Check MySQL and services\api\.env.' }

Write-Host 'SmartBridge is ready.'
Write-Host 'Login:   http://127.0.0.1:8080/login/index.html'
Write-Host 'Admin:   http://127.0.0.1:8080/admin/index.html'
Write-Host 'Company: http://127.0.0.1:8080/company/index.html'
Write-Host 'Teacher: http://127.0.0.1:8080/teacher/index.html'
Write-Host 'Student: http://127.0.0.1:8080/student/index.html'
Write-Host 'Skills:  http://127.0.0.1:8090/api/skills/status'

if (-not $SkipOpen) { Start-Process 'http://127.0.0.1:8080/login/index.html' }
