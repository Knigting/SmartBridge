$ErrorActionPreference = 'Stop'

foreach ($port in 8080, 8090) {
  $listeners = Get-NetTCPConnection -LocalPort $port -State Listen -ErrorAction SilentlyContinue
  foreach ($listener in $listeners) {
    $process = Get-Process -Id $listener.OwningProcess -ErrorAction SilentlyContinue
    if ($process -and $process.ProcessName -eq 'node') {
      Stop-Process -Id $process.Id -Force
      Write-Host "Stopped SmartBridge listener on port $port (PID $($process.Id))."
    } elseif ($process) {
      Write-Warning "Port $port is owned by $($process.ProcessName) (PID $($process.Id)); it was not stopped."
    }
  }
}
