SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS organizations (
  id VARCHAR(36) PRIMARY KEY, code VARCHAR(32) NOT NULL UNIQUE, name VARCHAR(128) NOT NULL,
  type ENUM('platform','school','company') NOT NULL, status ENUM('pending','active','disabled') NOT NULL DEFAULT 'pending',
  owner_name VARCHAR(64), created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(36) PRIMARY KEY, organization_id VARCHAR(36), username VARCHAR(80) NOT NULL UNIQUE, password_hash VARCHAR(100) NOT NULL,
  display_name VARCHAR(64) NOT NULL, email VARCHAR(128), student_no VARCHAR(32), status ENUM('active','disabled','pending') NOT NULL DEFAULT 'active',
  last_login_at DATETIME(3), created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  CONSTRAINT fk_users_org FOREIGN KEY (organization_id) REFERENCES organizations(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS roles (id VARCHAR(36) PRIMARY KEY, code VARCHAR(40) NOT NULL UNIQUE, name VARCHAR(64) NOT NULL) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS user_roles (user_id VARCHAR(36) NOT NULL, role_id VARCHAR(36) NOT NULL, PRIMARY KEY(user_id,role_id), FOREIGN KEY(user_id) REFERENCES users(id), FOREIGN KEY(role_id) REFERENCES roles(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS classes (
  id VARCHAR(36) PRIMARY KEY, organization_id VARCHAR(36) NOT NULL, code VARCHAR(32) NOT NULL, name VARCHAR(96) NOT NULL,
  teacher_user_id VARCHAR(36), academic_year VARCHAR(16), status ENUM('active','archived') DEFAULT 'active',
  UNIQUE KEY uk_class_org_code(organization_id,code), FOREIGN KEY(organization_id) REFERENCES organizations(id), FOREIGN KEY(teacher_user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS class_enrollments (class_id VARCHAR(36) NOT NULL, student_user_id VARCHAR(36) NOT NULL, group_name VARCHAR(32), status ENUM('active','withdrawn') DEFAULT 'active', PRIMARY KEY(class_id,student_user_id), FOREIGN KEY(class_id) REFERENCES classes(id), FOREIGN KEY(student_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS requirements (
  id VARCHAR(36) PRIMARY KEY, code VARCHAR(32) NOT NULL UNIQUE, company_org_id VARCHAR(36) NOT NULL, creator_user_id VARCHAR(36) NOT NULL,
  title VARCHAR(180) NOT NULL, description TEXT, business_goal TEXT, deliverables TEXT, status ENUM('draft','submitted','under_review','accepted','rejected','converted') NOT NULL DEFAULT 'submitted',
  urgent TINYINT(1) NOT NULL DEFAULT 0, submitted_at DATETIME(3), created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), version INT NOT NULL DEFAULT 0,
  FOREIGN KEY(company_org_id) REFERENCES organizations(id), FOREIGN KEY(creator_user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS files (
  id VARCHAR(36) PRIMARY KEY, organization_id VARCHAR(36), uploader_user_id VARCHAR(36), original_name VARCHAR(255) NOT NULL,
  stored_name VARCHAR(255) NOT NULL, mime_type VARCHAR(128), size_bytes BIGINT NOT NULL, sha256 CHAR(64), purpose VARCHAR(64), storage_path VARCHAR(512) NOT NULL,
  status ENUM('active','deleted','quarantined') DEFAULT 'active', created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  FOREIGN KEY(organization_id) REFERENCES organizations(id), FOREIGN KEY(uploader_user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS requirement_files (requirement_id VARCHAR(36) NOT NULL, file_id VARCHAR(36) NOT NULL, PRIMARY KEY(requirement_id,file_id), FOREIGN KEY(requirement_id) REFERENCES requirements(id), FOREIGN KEY(file_id) REFERENCES files(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS requirement_reviews (id VARCHAR(36) PRIMARY KEY, requirement_id VARCHAR(36) NOT NULL, reviewer_user_id VARCHAR(36) NOT NULL, decision ENUM('accept','reject') NOT NULL, reason TEXT, created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3), FOREIGN KEY(requirement_id) REFERENCES requirements(id), FOREIGN KEY(reviewer_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS projects (
  id VARCHAR(36) PRIMARY KEY, code VARCHAR(32) NOT NULL UNIQUE, requirement_id VARCHAR(36), name VARCHAR(180) NOT NULL,
  company_org_id VARCHAR(36) NOT NULL, school_org_id VARCHAR(36) NOT NULL, teacher_user_id VARCHAR(36) NOT NULL,
  status ENUM('preparing','published','running','evaluating','accepting','reworking','completed','cancelled') NOT NULL DEFAULT 'preparing',
  current_stage VARCHAR(64), progress DECIMAL(5,2) NOT NULL DEFAULT 0, started_at DATE, due_at DATE, version INT NOT NULL DEFAULT 0,
  created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3), updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  FOREIGN KEY(requirement_id) REFERENCES requirements(id), FOREIGN KEY(company_org_id) REFERENCES organizations(id), FOREIGN KEY(school_org_id) REFERENCES organizations(id), FOREIGN KEY(teacher_user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS project_members (project_id VARCHAR(36) NOT NULL, user_id VARCHAR(36) NOT NULL, member_role VARCHAR(32) NOT NULL, PRIMARY KEY(project_id,user_id,member_role), FOREIGN KEY(project_id) REFERENCES projects(id), FOREIGN KEY(user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS project_classes (project_id VARCHAR(36) NOT NULL, class_id VARCHAR(36) NOT NULL, PRIMARY KEY(project_id,class_id), FOREIGN KEY(project_id) REFERENCES projects(id), FOREIGN KEY(class_id) REFERENCES classes(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS project_rules (id VARCHAR(36) PRIMARY KEY, project_id VARCHAR(36) NOT NULL, rule_key VARCHAR(64) NOT NULL, rule_text TEXT NOT NULL, sort_order INT DEFAULT 0, version INT DEFAULT 1, UNIQUE KEY uk_project_rule(project_id,rule_key,version), FOREIGN KEY(project_id) REFERENCES projects(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS task_stages (
  id VARCHAR(36) PRIMARY KEY, project_id VARCHAR(36) NOT NULL, stage_no INT NOT NULL, name VARCHAR(160) NOT NULL, description TEXT,
  acceptance TEXT, duration_hours INT DEFAULT 0, status ENUM('draft','published','running','submitted','reviewing','passed','revision_required') DEFAULT 'draft', due_at DATETIME(3), version INT DEFAULT 0,
  UNIQUE KEY uk_project_stage_no(project_id,stage_no), FOREIGN KEY(project_id) REFERENCES projects(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS task_assignments (id VARCHAR(36) PRIMARY KEY, task_stage_id VARCHAR(36) NOT NULL, student_user_id VARCHAR(36) NOT NULL, status ENUM('locked','available','running','submitted','passed','revision_required') DEFAULT 'locked', score DECIMAL(5,2), unlocked_at DATETIME(3), UNIQUE KEY uk_stage_student(task_stage_id,student_user_id), FOREIGN KEY(task_stage_id) REFERENCES task_stages(id), FOREIGN KEY(student_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS submissions (id VARCHAR(36) PRIMARY KEY, assignment_id VARCHAR(36) NOT NULL, attempt_no INT NOT NULL, status ENUM('submitted','reviewing','passed','revision_required') DEFAULT 'submitted', note TEXT, score DECIMAL(5,2), submitted_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3), UNIQUE KEY uk_assignment_attempt(assignment_id,attempt_no), FOREIGN KEY(assignment_id) REFERENCES task_assignments(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS submission_files (submission_id VARCHAR(36) NOT NULL, file_id VARCHAR(36) NOT NULL, artifact_type VARCHAR(64), PRIMARY KEY(submission_id,file_id), FOREIGN KEY(submission_id) REFERENCES submissions(id), FOREIGN KEY(file_id) REFERENCES files(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS process_logs (id VARCHAR(36) PRIMARY KEY, project_id VARCHAR(36) NOT NULL, user_id VARCHAR(36), event_type VARCHAR(64) NOT NULL, title VARCHAR(180) NOT NULL, detail TEXT, created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3), FOREIGN KEY(project_id) REFERENCES projects(id), FOREIGN KEY(user_id) REFERENCES users(id), INDEX idx_process_project_time(project_id,created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS questions (id VARCHAR(36) PRIMARY KEY, project_id VARCHAR(36) NOT NULL, task_stage_id VARCHAR(36), asker_user_id VARCHAR(36), question TEXT NOT NULL, summary TEXT, status ENUM('pending','answered','enterprise_confirm') DEFAULT 'pending', created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3), FOREIGN KEY(project_id) REFERENCES projects(id), FOREIGN KEY(task_stage_id) REFERENCES task_stages(id), FOREIGN KEY(asker_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS question_replies (id VARCHAR(36) PRIMARY KEY, question_id VARCHAR(36) NOT NULL, replier_user_id VARCHAR(36) NOT NULL, reply TEXT NOT NULL, created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3), FOREIGN KEY(question_id) REFERENCES questions(id), FOREIGN KEY(replier_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS evaluations (id VARCHAR(36) PRIMARY KEY, project_id VARCHAR(36) NOT NULL, student_user_id VARCHAR(36) NOT NULL, evaluator_user_id VARCHAR(36), score DECIMAL(5,2), status ENUM('pending','confirmed','adjusted') DEFAULT 'pending', comment TEXT, evidence_summary TEXT, updated_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), UNIQUE KEY uk_eval_project_student(project_id,student_user_id), FOREIGN KEY(project_id) REFERENCES projects(id), FOREIGN KEY(student_user_id) REFERENCES users(id), FOREIGN KEY(evaluator_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS acceptances (id VARCHAR(36) PRIMARY KEY, project_id VARCHAR(36) NOT NULL, company_user_id VARCHAR(36), round_no INT NOT NULL DEFAULT 1, result ENUM('pending','passed','revision_required') DEFAULT 'pending', comment TEXT, decided_at DATETIME(3), UNIQUE KEY uk_accept_project_round(project_id,round_no), FOREIGN KEY(project_id) REFERENCES projects(id), FOREIGN KEY(company_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS acceptance_items (id VARCHAR(36) PRIMARY KEY, acceptance_id VARCHAR(36) NOT NULL, item_text VARCHAR(255) NOT NULL, checked TINYINT(1) DEFAULT 0, FOREIGN KEY(acceptance_id) REFERENCES acceptances(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS resources (id VARCHAR(36) PRIMARY KEY, project_id VARCHAR(36), owner_user_id VARCHAR(36), name VARCHAR(180) NOT NULL, type ENUM('case','template','rubric','knowledge') NOT NULL, scope ENUM('project','school','platform') DEFAULT 'project', version VARCHAR(20) DEFAULT 'v1.0', status ENUM('draft','pending','published','rejected') DEFAULT 'draft', description TEXT, updated_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), FOREIGN KEY(project_id) REFERENCES projects(id), FOREIGN KEY(owner_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS student_visibility (student_user_id VARCHAR(36) PRIMARY KEY, open_to_company TINYINT(1) DEFAULT 0, show_real_name TINYINT(1) DEFAULT 0, allow_process_log TINYINT(1) DEFAULT 1, weekly_report TINYINT(1) DEFAULT 1, reuse_case TINYINT(1) DEFAULT 0, updated_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), FOREIGN KEY(student_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS authorization_requests (id VARCHAR(36) PRIMARY KEY, student_user_id VARCHAR(36) NOT NULL, company_org_id VARCHAR(36) NOT NULL, requester_user_id VARCHAR(36), role_name VARCHAR(96), scope_json JSON NOT NULL, status ENUM('pending','approved','rejected','revoked','expired') DEFAULT 'pending', expires_at DATETIME(3), decided_at DATETIME(3), access_count INT DEFAULT 0, created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3), FOREIGN KEY(student_user_id) REFERENCES users(id), FOREIGN KEY(company_org_id) REFERENCES organizations(id), FOREIGN KEY(requester_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS candidate_shortlists (id VARCHAR(36) PRIMARY KEY, project_id VARCHAR(36), company_org_id VARCHAR(36) NOT NULL, student_user_id VARCHAR(36) NOT NULL, status ENUM('shortlisted','authorization_requested','trial','intent','closed') DEFAULT 'shortlisted', created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3), FOREIGN KEY(project_id) REFERENCES projects(id), FOREIGN KEY(company_org_id) REFERENCES organizations(id), FOREIGN KEY(student_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS enterprise_feedback (id VARCHAR(36) PRIMARY KEY, project_id VARCHAR(36), student_user_id VARCHAR(36), company_user_id VARCHAR(36) NOT NULL, rating INT, feedback TEXT, kind VARCHAR(64), created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3), FOREIGN KEY(project_id) REFERENCES projects(id), FOREIGN KEY(student_user_id) REFERENCES users(id), FOREIGN KEY(company_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS notifications (id VARCHAR(36) PRIMARY KEY, user_id VARCHAR(36) NOT NULL, title VARCHAR(180) NOT NULL, body TEXT, level ENUM('info','urgent','success','warning') DEFAULT 'info', href VARCHAR(255), read_at DATETIME(3), created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3), FOREIGN KEY(user_id) REFERENCES users(id), INDEX idx_notifications_user_read(user_id,read_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS audit_logs (id VARCHAR(36) PRIMARY KEY, actor_user_id VARCHAR(36), actor_name VARCHAR(64), action VARCHAR(96) NOT NULL, target_type VARCHAR(64), target_id VARCHAR(64), before_json JSON, after_json JSON, ip_address VARCHAR(45), created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3), FOREIGN KEY(actor_user_id) REFERENCES users(id), INDEX idx_audit_time(created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS background_jobs (id VARCHAR(36) PRIMARY KEY, name VARCHAR(180) NOT NULL, type VARCHAR(64) NOT NULL, owner_user_id VARCHAR(36), status ENUM('pending','running','success','failed') DEFAULT 'pending', progress INT DEFAULT 0, error_message TEXT, started_at DATETIME(3), finished_at DATETIME(3), created_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3), FOREIGN KEY(owner_user_id) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
CREATE TABLE IF NOT EXISTS system_settings (setting_key VARCHAR(96) PRIMARY KEY, setting_value JSON NOT NULL, updated_by VARCHAR(36), updated_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3), FOREIGN KEY(updated_by) REFERENCES users(id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS=1;
