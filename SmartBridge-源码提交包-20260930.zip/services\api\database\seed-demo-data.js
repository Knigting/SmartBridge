/**
 * 本地演示数据补充脚本（可重复执行，幂等）
 *
 * 目的：原生 schema.sql 只给了最小数据集，企业端「候选人」等列表接口会返回空，
 *      四端页面因此回落到前端模拟数据，看起来像「前后端没打通」。
 *      本脚本补齐授权申请、可见性设置、过程日志与通知，让四端接口都有真实返回。
 *
 * 用法：cd backend && node database/seed-demo-data.js
 */
require('dotenv').config({ path: require('path').resolve(__dirname, '..', '.env') });
const mysql = require('mysql2/promise');

const STUDENTS = ['user-student-chen', 'user-student-liu', 'user-student-wang'];
const COMPANIES = ['org-company-huaming', 'org-company-hengcheng', 'org-company-yunqi'];
const SCOPES = ['匿名能力画像', '阶段作品', '过程证据'];

async function main() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
  });
  const run = async (sql, params) => { const [r] = await conn.execute(sql, params); return r; };
  let inserted = 0;

  /* 1) 学生可见性：刘子豪、王浩宇对企业开放，陈晓雨由学生端自己控制 */
  for (const [index, id] of STUDENTS.entries()) {
    await run(`INSERT INTO student_visibility (student_user_id, open_to_company, show_real_name, allow_process_log, weekly_report, reuse_case, updated_at)
      VALUES (?, ?, ?, 1, 1, ?, NOW())
      ON DUPLICATE KEY UPDATE allow_process_log=1, weekly_report=1, updated_at=NOW()`,
      [id, index === 0 ? 0 : 1, index === 0 ? 0 : 1, index === 0 ? 0 : 1]);
  }
  inserted += STUDENTS.length;

  /* 2) 授权申请：三名学生 → 华明制造（含一条已通过），保证企业端候选人列表有真实数据 */
  const statuses = ['approved', 'pending', 'pending'];
  for (const [index, id] of STUDENTS.entries()) {
    const rid = `ar-demo-${id.split('-').pop()}`;
    await run(`INSERT INTO authorization_requests (id, student_user_id, company_org_id, requester_user_id, role_name, scope_json, status, expires_at, decided_at, access_count, created_at)
      VALUES (?, ?, 'org-company-huaming', ?, '智能制造数据处理实训', ?, ?, DATE_ADD(NOW(), INTERVAL 30 DAY), ?, ?, NOW() - INTERVAL ? DAY)
      ON DUPLICATE KEY UPDATE status=VALUES(status), scope_json=VALUES(scope_json)`,
      [rid, id, 'user-company-zhang', JSON.stringify(SCOPES.slice(0, index + 1)), statuses[index],
        statuses[index] === 'approved' ? new Date() : null, statuses[index] === 'approved' ? 2 : 0, index + 1]);
  }
  inserted += STUDENTS.length;

  /* 3) 过程日志：学生端首页动态与贡献日历需要多条记录 */
  const logs = [
    ['user-student-chen', 'submit', '提交阶段二交付物', '点检样表清洗结果 v2，含缺失值待核查清单'],
    ['user-student-chen', 'review', '阶段二教师批阅', '单位统一正确，缺失值处理需补充依据'],
    ['user-student-liu', 'submit', '提交阶段一交付物', '完成字段口径对照表'],
    ['user-student-wang', 'parse', '运行点检样表解析', '发现 3 处异常：温度单位混用、读数缺失、油位枚举越界'],
    ['user-student-wang', 'submit', '提交阶段三交付物', '周报模板输出，异常清单单独列出']
  ];
  const [[project]] = await conn.execute('SELECT id FROM projects ORDER BY id LIMIT 1');
  const projectId = project ? project.id : null;
  for (const [index, item] of logs.entries()) {
    const lid = `pl-demo-${index + 1}`;
    await run(`INSERT INTO process_logs (id, project_id, user_id, event_type, title, detail, created_at)
      VALUES (?, ?, ?, ?, ?, ?, NOW() - INTERVAL ? HOUR)
      ON DUPLICATE KEY UPDATE title=VALUES(title), detail=VALUES(detail)`,
      [lid, projectId, item[0], item[1], item[2], item[3], (index + 1) * 7]);
  }
  inserted += logs.length;

  /* 4) 通知：四端消息中心有内容 */
  const notes = [
    ['user-student-chen', '阶段二批阅结果已发布', '教师已批阅并提交改进建议，请查看阶段详情。', 'info', '/student/task.html'],
    ['user-student-liu', '阶段三开放', '阶段三「异常识别与周报输出」已开放，请在截止前提交。', 'warning', '/student/tasks.html'],
    ['user-company-zhang', '新增 1 条候选人授权申请', '王浩宇向华明制造提交了能力画像查看申请。', 'info', '/company/talent.html'],
    ['user-teacher-li', '3 名学生待批阅', '阶段二共 3 份交付物等待批阅。', 'urgent', '/teacher/review.html']
  ];
  for (const [index, item] of notes.entries()) {
    const nid = `nt-demo-${index + 1}`;
    await run(`INSERT INTO notifications (id, user_id, title, body, level, href, created_at)
      VALUES (?, ?, ?, ?, ?, ?, NOW() - INTERVAL ? HOUR)
      ON DUPLICATE KEY UPDATE title=VALUES(title), body=VALUES(body)`,
      [nid, item[0], item[1], item[2], item[3], item[4], (index + 1) * 3]);
  }
  inserted += notes.length;

  const [cand] = await conn.execute(`SELECT COUNT(*) n FROM authorization_requests ar JOIN evaluations e ON e.student_user_id=ar.student_user_id WHERE ar.company_org_id='org-company-huaming'`);
  const [vis] = await conn.execute('SELECT COUNT(*) n FROM student_visibility WHERE open_to_company=1');
  const [log] = await conn.execute('SELECT COUNT(*) n FROM process_logs');
  const [not] = await conn.execute('SELECT COUNT(*) n FROM notifications');
  await conn.end();

  console.log(`演示数据已就绪（本次处理 ${inserted} 条）：`);
  console.log(`  企业端可见候选人：${cand[0].n} 条`);
  console.log(`  对企业开放的学生：${vis[0].n} 名`);
  console.log(`  过程日志：${log[0].n} 条`);
  console.log(`  通知：${not[0].n} 条`);
}

main().catch(error => { console.error('执行失败：', error.message); process.exit(1); });
