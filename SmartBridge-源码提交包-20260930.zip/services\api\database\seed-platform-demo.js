/**
 * 平台级演示数据生成器（幂等，可重复执行）
 *
 * 业务设定：山东智能制造职业学院 · 2024 级两个班，对接三家制造/软件企业的产教融合实训。
 *   项目一  华明制造 × 2024级数据科学班  设备点检台账整理与异常周报生成   （进行中 · 阶段二）
 *   项目二  恒成软件 × 2024级数控技术班  数控刀具寿命预警台账与工艺参数卡片（评估中 · 阶段三）
 *   项目三  云启数据科技 × 2024级数据科学班 设备运行日志异常识别与维护看板  （进行中 · 阶段一）
 *
 * 覆盖范围：组织/用户/班级/企业需求/项目/阶段/阶段分配/提交/提交文件/教学评价/
 *          企业验收/内容资源/学生提问与回复/候选人短名单/企业反馈/隐私授权/通知/过程留痕/后台任务
 * 目标：让五类 Skill（批量解析、知识库检索、实训系统操作、报告生成、多模态识别）
 *      在四端页面上都能拿到真实、互相印证的业务数据。
 *
 * 用法：cd backend && node database/seed-platform-demo.js
 * 清理：cd backend && node database/seed-platform-demo.js --reset
 */
require('dotenv').config({ path: require('path').resolve(__dirname, '..', '.env') });
const mysql = require('mysql2/promise');

const RESET_ONLY = process.argv.includes('--reset');
const PLACEHOLDER_HASH = process.env.DEMO_PASSWORD_HASH || '';

const SCHOOL = 'org-school-001';
const T_LI = 'user-teacher-li';
const P1 = 'project-0917-001';
const DAY = 24 * 60 * 60 * 1000;
const at = days => new Date(Date.now() + days * DAY);

/* ---------------- 生成数据定义 ---------------- */

const NEW_USERS = [
  /* 教师与学校 */
  { id: 'g-user-teacher-zhao', org: SCHOOL, username: 'zhaoqihang', name: '赵启航', role: 'role-teacher', email: 'zhaoqihang@school.edu.cn' },
  { id: 'g-user-teacher-wu', org: SCHOOL, username: 'wuxiaolei', name: '吴晓蕾', role: 'role-teacher', email: 'wuxiaolei@school.edu.cn' },
  /* 企业成员 */
  { id: 'g-user-company-wang', org: 'org-company-hengcheng', username: 'wangqian', name: '王倩', role: 'role-company-member', email: 'wangqian@hengcheng.com' },
  { id: 'g-user-company-luo', org: 'org-company-yunqi', username: 'luomin', name: '罗敏', role: 'role-company-member', email: 'luomin@yunqi.com' },
  /* 2024级数据科学班 新增 3 名 */
  { id: 'g-user-sun', org: SCHOOL, username: '2024010207', name: '孙梦洁', role: 'role-student', studentNo: '2024010207', email: '2024010207@school.edu.cn' },
  { id: 'g-user-zhao', org: SCHOOL, username: '2024010213', name: '赵一鸣', role: 'role-student', studentNo: '2024010213', email: '2024010213@school.edu.cn' },
  { id: 'g-user-zhou', org: SCHOOL, username: '2024010221', name: '周佳怡', role: 'role-student', studentNo: '2024010221', email: '2024010221@school.edu.cn' },
  /* 2024级数控技术班 3 名 */
  { id: 'g-user-lizh', org: SCHOOL, username: '2024010308', name: '李振国', role: 'role-student', studentNo: '2024010308', email: '2024010308@school.edu.cn' },
  { id: 'g-user-guo', org: SCHOOL, username: '2024010315', name: '郭晓峰', role: 'role-student', studentNo: '2024010315', email: '2024010315@school.edu.cn' },
  { id: 'g-user-tian', org: SCHOOL, username: '2024010322', name: '田雨', role: 'role-student', studentNo: '2024010322', email: '2024010322@school.edu.cn' }
];

const CLASS_DATA = 'class-data-2024';
const CLASS_NC = 'g-class-nc-2024';
const NEW_CLASSES = [
  { id: CLASS_NC, org: SCHOOL, code: 'NC-2024-01', name: '2024级数控技术班', teacher: T_LI, year: '2024' }
];

const NEW_ENROLLMENTS = [
  { classId: CLASS_DATA, student: 'g-user-sun', group: '第1组' },
  { classId: CLASS_DATA, student: 'g-user-zhao', group: '第1组' },
  { classId: CLASS_DATA, student: 'g-user-zhou', group: '第2组' },
  { classId: CLASS_NC, student: 'g-user-lizh', group: '第1组' },
  { classId: CLASS_NC, student: 'g-user-guo', group: '第2组' },
  { classId: CLASS_NC, student: 'g-user-tian', group: '第1组' }
];

const NEW_REQUIREMENTS = [
  { id: 'g-req-0922-004', code: 'REQ-0922-004', org: 'org-company-hengcheng', creator: 'user-company-chengang', title: '数控刀具寿命预警台账与工艺参数卡片', status: 'converted', urgent: 1, days: -12,
    desc: '恒成软件为三家 CNC 加工客户维护刀具寿命数据，目前靠 Excel 人工登记，刀具到期预警经常漏登。需要把刀具寿命台账与工艺参数卡片标准化。',
    goal: '刀具到期前 3 天自动预警，工艺参数与刀具编号一一对应可追溯', deliv: '刀具寿命台账、工艺参数卡片、预警规则说明、复现检查记录' },
  { id: 'g-req-0923-005', code: 'REQ-0923-005', org: 'org-company-yunqi', creator: 'user-company-zhao', title: '设备运行日志异常识别与维护看板', status: 'converted', urgent: 0, days: -9,
    desc: '云启数据科技服务的客户产线每天产生大量设备运行日志，缺少自动异常识别，停机原因靠人工复盘。',
    goal: '识别异常模式并输出维护看板，缩短停机复盘时间', deliv: '日志解析结果、告警规则清单、维护看板、停机分析说明' },
  { id: 'g-req-0924-006', code: 'REQ-0924-006', org: 'org-company-huaming', creator: 'user-company-zhang', title: '实训过程数据可视化与交付看板', status: 'submitted', urgent: 0, days: -2,
    desc: '华明制造希望在内部晨会上直接引用学生交付的周报数据，需要一套可持续更新的可视化看板。',
    goal: '让企业侧一屏看到进度、异常与人才表现', deliv: '看板说明、数据口径表、样例看板' },
  { id: 'g-req-0924-007', code: 'REQ-0924-007', org: 'org-company-yunqi', creator: 'user-company-zhao', title: '质检数据自动汇总与异常推送', status: 'draft', urgent: 1, days: -1,
    desc: '质检日报依赖人工汇总，异常结果推送滞后。',
    goal: '质检数据当日汇总并对超限结果即时推送', deliv: '汇总脚本、推送规则、日检样例' }
];

const NEW_PROJECTS = [
  { id: 'g-project-0924-002', code: 'PRJ-0924-002', req: 'g-req-0922-004', name: '数控刀具寿命预警台账与工艺参数卡片',
    company: 'org-company-hengcheng', teacher: T_LI, status: 'evaluating', stage: '成果呈现', progress: 82, start: -23, due: 53,
    rules: [
      '刀具剩余寿命 < 20% 触发预警，= 20% 记为临界并在备注标注',
      '工艺参数统一使用 SI 单位（转速 r/min、进给 mm/min、切深 mm）',
      '参数缺失一律列入待核查，不得按同类刀具均值补齐',
      '同一刀具同一班次重复登记，按时间戳去重保留最新一条'
    ] },
  { id: 'g-project-0924-003', code: 'PRJ-0924-003', req: 'g-req-0923-005', name: '设备运行日志异常识别与维护看板',
    company: 'org-company-yunqi', teacher: T_LI, status: 'running', stage: '任务启动', progress: 35, start: -10, due: 72,
    rules: [
      '日志时间戳统一换算到 UTC+8 后再对齐',
      '告警分三级：P0 停机 / P1 需当日处理 / P2 观察项',
      '停机定义为连续 5 分钟无心跳，短暂抖动不计入停机',
      '同一设备 10 分钟内同类告警合并为一条，注明合并次数'
    ] }
];

const NEW_STAGES = [
  { id: 'g-stage-p2-1', project: 'g-project-0924-002', no: 1, name: '工艺参数采集与字段标准化', status: 'passed', hours: 12, due: -14,
    desc: '从脱敏工艺卡与刀具台账中采集参数，统一字段名、单位与精度。',
    accept: '字段口径表完整；单位统一为 SI；同一参数在不同来源取值一致' },
  { id: 'g-stage-p2-2', project: 'g-project-0924-002', no: 2, name: '刀具寿命台账建模与阈值规则', status: 'passed', hours: 16, due: -4,
    desc: '建立刀具寿命台账，实现预警阈值判定与临界标注。',
    accept: '阈值规则可复现；临界值处理符合企业口径；台账可追溯到原始记录' },
  { id: 'g-stage-p2-3', project: 'g-project-0924-002', no: 3, name: '工艺卡片与偏差分析周报', status: 'submitted', hours: 14, due: 5,
    desc: '输出工艺参数卡片，并按周汇总偏差与预警清单。',
    accept: '卡片与台账编号一致；周报含预警条数与偏差原因' },
  { id: 'g-stage-p2-4', project: 'g-project-0924-002', no: 4, name: '交付复用：参数模板与复现说明', status: 'published', hours: 10, due: 16,
    desc: '沉淀参数模板与复现步骤，供下一批学生直接复用。',
    accept: '模板可直接套用；复现说明能让他人独立跑通' },
  { id: 'g-stage-p3-1', project: 'g-project-0924-003', no: 1, name: '日志解析与时间对齐', status: 'running', hours: 12, due: 4,
    desc: '解析设备运行日志，统一时间戳并补齐设备主数据。',
    accept: '时间对齐到 UTC+8；字段缺失有明确处理记录' },
  { id: 'g-stage-p3-2', project: 'g-project-0924-003', no: 2, name: '异常模式识别与告警规则', status: 'published', hours: 18, due: 15,
    desc: '识别异常模式并形成 P0/P1/P2 告警规则。',
    accept: '规则覆盖已知异常；告警分级有依据；合并逻辑正确' },
  { id: 'g-stage-p3-3', project: 'g-project-0924-003', no: 3, name: '维护看板与停机分析', status: 'published', hours: 16, due: 26,
    desc: '输出维护看板与停机原因分析。',
    accept: '看板可读；停机时长口径与定义一致' },
  { id: 'g-stage-p3-4', project: 'g-project-0924-003', no: 4, name: '交付复用：告警规则包与运维手册', status: 'published', hours: 10, due: 38,
    desc: '把规则沉淀为可复用规则包与手册。',
    accept: '规则包可直接导入；手册含排障步骤' }
];

/* 阶段进度：学生 → 该项目的阶段状态与分数 */
const PROGRESS = {
  'g-project-0924-002': {
    'g-user-lizh': ['passed', 'passed', 'submitted', 'available'],
    'g-user-guo': ['passed', 'revision_required', 'available', 'locked'],
    'g-user-tian': ['passed', 'passed', 'running', 'locked']
  },
  'g-project-0924-003': {
    'user-student-chen': ['running', 'locked', 'locked', 'locked'],
    'user-student-liu': ['available', 'locked', 'locked', 'locked'],
    'user-student-wang': ['running', 'locked', 'locked', 'locked'],
    'g-user-sun': ['passed', 'available', 'locked', 'locked'],
    'g-user-zhao': ['available', 'locked', 'locked', 'locked'],
    'g-user-zhou': ['submitted', 'locked', 'locked', 'locked']
  }
};
/* 项目一（已有）阶段进度：补上新增 3 名学生 */
const PROGRESS_P1 = {
  'g-user-sun': ['passed', 'passed', 'running', 'locked'],
  'g-user-zhao': ['passed', 'submitted', 'available', 'locked'],
  'g-user-zhou': ['passed', 'submitted', 'available', 'locked']
};

const SCORES = {
  passed: [95, 92, 91, 90, 88, 87, 86, 84, 83, 82, 81, 80, 78, 76],
  submitted: [85, 83, 82, 78, 76, 74, 72, 70],
  revision_required: [62, 58, 55]
};

const NEW_RESOURCES = [
  { id: 'g-res-01', project: 'g-project-0924-002', owner: T_LI, name: '刀具寿命阈值判定规则库', type: 'rubric', scope: 'project', ver: 'v1.2', status: 'published', desc: '20% 预警、临界标注与去重口径的企业确认版规则' },
  { id: 'g-res-02', project: 'g-project-0924-002', owner: 'g-user-company-wang', name: '数控刀具寿命台账模板', type: 'template', scope: 'project', ver: 'v1.0', status: 'published', desc: '含刀具编号、剩余寿命、班次、预警状态的标准化台账' },
  { id: 'g-res-03', project: 'g-project-0924-002', owner: T_LI, name: '工艺参数卡片模板（SI 单位）', type: 'template', scope: 'project', ver: 'v1.1', status: 'published', desc: '转速/进给/切深统一 SI 单位的工艺卡片' },
  { id: 'g-res-04', project: 'g-project-0924-002', owner: T_LI, name: '数控工艺参数标准化实践案例', type: 'case', scope: 'school', ver: 'v2.0', status: 'published', desc: '从脱敏工艺卡到标准化台账的完整处理过程' },
  { id: 'g-res-05', project: 'g-project-0924-003', owner: T_LI, name: '设备运行日志字段口径说明', type: 'knowledge', scope: 'project', ver: 'v1.0', status: 'published', desc: '心跳、停机、告警级别的字段定义与时间对齐口径' },
  { id: 'g-res-06', project: 'g-project-0924-003', owner: 'g-user-company-luo', name: '告警分级与合并规则', type: 'rubric', scope: 'project', ver: 'v0.3', status: 'pending', desc: 'P0/P1/P2 判定依据与 10 分钟合并窗口' },
  { id: 'g-res-07', project: 'g-project-0924-003', owner: T_LI, name: '日志异常模式识别实践案例', type: 'case', scope: 'school', ver: 'v1.0', status: 'published', desc: '常见异常模式与识别思路，含误报样例' },
  { id: 'g-res-08', project: P1, owner: T_LI, name: '设备点检异常规则库', type: 'rubric', scope: 'project', ver: 'v2.1', status: 'published', desc: '温度/振动/油位三类异常的阈值与边界口径' },
  { id: 'g-res-09', project: P1, owner: T_LI, name: '点检台账清洗脚本（含缺失值分支）', type: 'case', scope: 'project', ver: 'v1.3', status: 'published', desc: '字段统一、单位换算、缺失值分流与去重的参考实现' },
  { id: 'g-res-10', project: null, owner: T_LI, name: '台账去重与唯一标识实践', type: 'case', scope: 'school', ver: 'v1.0', status: 'published', desc: '设备编号 + 点检日期 + 班组三键去重的完整演练' },
  { id: 'g-res-11', project: null, owner: T_LI, name: '可追溯周报写作指南', type: 'knowledge', scope: 'school', ver: 'v1.1', status: 'published', desc: '统计口径、异常计数与证据留痕的写作要求' },
  { id: 'g-res-12', project: null, owner: 'user-admin', name: '交付材料完整性评分表', type: 'rubric', scope: 'platform', ver: 'v1.0', status: 'published', desc: '四项必交材料与四维评分口径' },
  { id: 'g-res-13', project: null, owner: 'user-admin', name: '智能制造企业公开实训任务清单', type: 'case', scope: 'platform', ver: 'v2.0', status: 'published', desc: '三家企业的可公开任务与难度参考' },
  { id: 'g-res-14', project: null, owner: 'user-admin', name: '产教融合项目验收通用规范', type: 'knowledge', scope: 'platform', ver: 'v1.0', status: 'published', desc: '验收前置条件、材料清单与合格判定' },
  { id: 'g-res-15', project: 'g-project-0924-002', owner: T_LI, name: '边界值与缺失值处理微课', type: 'knowledge', scope: 'school', ver: 'v1.0', status: 'published', desc: '三类分支写法与缺失值分流的常见错误' },
  { id: 'g-res-16', project: 'g-project-0924-003', owner: T_LI, name: '维护看板设计要点', type: 'knowledge', scope: 'school', ver: 'v1.0', status: 'published', desc: '看板指标选择与停机时长口径' }
];

const QUESTION_BANK = [
  { id: 'q-1', project: P1, stage: 'stage-2', asker: 'user-student-chen', q: '温度单位混用如何处理？', s: '℃ 与 ℉ 混用，需要企业确认', st: 'enterprise_confirm', days: -3,
    reply: { by: 'user-company-zhang', text: '统一换算为摄氏度，并在备注列标注换算来源与原始数值；无法确认原始单位的记录列入待核查。', days: -2 } },
  { id: 'q-2', project: P1, stage: 'stage-2', asker: 'user-student-wang', q: '80℃ 算异常吗？', s: '边界值判断口径', st: 'answered', days: -4,
    reply: { by: T_LI, text: '按企业确认口径：大于 80℃ 判异常，等于 80℃ 属边界正常值，边界值不得四舍五入后再判定。', days: -3 } },
  { id: 'q-3', project: P1, stage: 'stage-2', asker: 'user-student-liu', q: '缺失值可以补正常吗？', s: '缺失值处理口径', st: 'pending', days: -2 },
  { id: 'g-q-04', project: P1, stage: 'stage-2', asker: 'g-user-sun', q: '点检编号重复但内容不同，去重保留哪一条？', s: '去重保留策略', st: 'answered', days: -5,
    reply: { by: T_LI, text: '设备编号、点检日期、班组三者相同即视为重复：有时间戳按时间戳保留最新一条，无时间戳保留点检编号较大者，并在备注写去重依据。', days: -4 } },
  { id: 'g-q-05', project: P1, stage: 'stage-2', asker: 'g-user-zhou', q: '周报里缺失值要不要计入异常数量？', s: '统计口径', st: 'answered', days: -3,
    reply: { by: T_LI, text: '不计入异常数量，但必须单独列为待核查清单，并在周报中给出条数与处理状态。', days: -2 } },
  { id: 'g-q-06', project: P1, stage: 'stage-3', asker: 'user-student-chen', q: '周报是自然周还是教学周？', s: '周期口径', st: 'pending', days: -1 },
  { id: 'g-q-07', project: 'g-project-0924-002', stage: 'g-stage-p2-2', asker: 'g-user-lizh', q: '刀具剩余寿命正好 20% 算预警还是正常？', s: '刀具阈值边界', st: 'answered', days: -6,
    reply: { by: 'g-user-company-wang', text: '20% 记为临界，不算预警；低于 20% 才触发预警。临界刀具需在备注标注并按周统计。', days: -5 } },
  { id: 'g-q-08', project: 'g-project-0924-002', stage: 'g-stage-p2-2', asker: 'g-user-guo', q: '刀具转速原来写的是 rpm，需要改成 r/min 吗？', s: '单位统一要求', st: 'enterprise_confirm', days: -4,
    reply: { by: 'g-user-company-wang', text: '需要，全部按 SI 单位：转速 r/min、进给 mm/min、切深 mm；换算过程写在口径表里。', days: -3 } },
  { id: 'g-q-09', project: 'g-project-0924-002', stage: 'g-stage-p2-2', asker: 'g-user-tian', q: '同一刀具一个班次登记两次，以哪条为准？', s: '重复登记口径', st: 'answered', days: -5,
    reply: { by: T_LI, text: '按时间戳去重保留最新一条，同时在备注写明"已去重，原始 2 条"。', days: -4 } },
  { id: 'g-q-10', project: 'g-project-0924-002', stage: 'g-stage-p2-3', asker: 'g-user-lizh', q: '工艺卡片要跟着台账编号走吗？', s: '编号一致性', st: 'pending', days: -1 },
  { id: 'g-q-11', project: 'g-project-0924-003', stage: 'g-stage-p3-1', asker: 'user-student-chen', q: '日志时间戳有本地时间和 UTC，怎么对齐？', s: '时间对齐口径', st: 'answered', days: -3,
    reply: { by: T_LI, text: '统一换算到 UTC+8 再对齐，换算前先记录原始时区字段，避免二次换算。', days: -2 } },
  { id: 'g-q-12', project: 'g-project-0924-003', stage: 'g-stage-p3-1', asker: 'user-student-wang', q: '停了 3 分钟算停机吗？', s: '停机定义', st: 'enterprise_confirm', days: -2,
    reply: { by: 'g-user-company-luo', text: '不算，连续 5 分钟无心跳才定义为停机；3 分钟属短暂抖动，按 P2 观察项处理。', days: -1 } },
  { id: 'g-q-13', project: 'g-project-0924-003', stage: 'g-stage-p3-1', asker: 'g-user-zhou', q: '同一设备 10 分钟内多条同类告警要全部保留吗？', s: '告警合并口径', st: 'answered', days: -2,
    reply: { by: T_LI, text: '合并为一条，并在合并次数字段写明条数，原始告警保留在明细里可追溯。', days: -1 } },
  { id: 'g-q-14', project: 'g-project-0924-003', stage: 'g-stage-p3-1', asker: 'g-user-sun', q: 'P0 和 P1 的判定依据具体是什么？', s: '告警分级依据', st: 'pending', days: -1 }
];

const FEEDBACK = [
  { id: 'g-fb-01', project: P1, student: 'user-student-chen', by: 'user-company-zhang', rating: 5, kind: '阶段评价', text: '台账字段统一干净，温度单位换算标注清楚，可直接进我司周报。' },
  { id: 'g-fb-02', project: P1, student: 'g-user-sun', by: 'user-company-zhang', rating: 5, kind: '阶段评价', text: '去重逻辑写得清晰，保留依据可追溯，这一版可以直接复用。' },
  { id: 'g-fb-03', project: P1, student: 'user-student-liu', by: 'user-company-zhang', rating: 3, kind: '改进建议', text: '缺失值仍被补成了正常值，需按待核查流程重做。' },
  { id: 'g-fb-04', project: P1, student: 'user-student-wang', by: 'user-company-zhang', rating: 4, kind: '阶段评价', text: '异常清单结构不错，边界值说明再补一句判定顺序即可。' },
  { id: 'g-fb-05', project: 'g-project-0924-002', student: 'g-user-lizh', by: 'g-user-company-wang', rating: 5, kind: '阶段评价', text: '参数单位全部转成 SI 且保留了换算过程，符合我们交付要求。' },
  { id: 'g-fb-06', project: 'g-project-0924-002', student: 'g-user-tian', by: 'g-user-company-wang', rating: 4, kind: '阶段评价', text: '台账结构规范，预警清单建议再加一列处置状态。' },
  { id: 'g-fb-07', project: 'g-project-0924-002', student: 'g-user-guo', by: 'g-user-company-wang', rating: 2, kind: '返修要求', text: '临界值 20% 被算成预警，导致预警数量虚高，请按口径返修。' },
  { id: 'g-fb-08', project: 'g-project-0924-003', student: 'g-user-sun', by: 'g-user-company-luo', rating: 5, kind: '阶段评价', text: '时间对齐处理干净，原始时区字段保留得好。' },
  { id: 'g-fb-09', project: 'g-project-0924-003', student: 'g-user-zhou', by: 'g-user-company-luo', rating: 4, kind: '阶段评价', text: '告警合并思路可行，需补充合并后明细可追溯的说明。' },
  { id: 'g-fb-10', project: 'g-project-0924-003', student: 'user-student-chen', by: 'g-user-company-luo', rating: 4, kind: '改进建议', text: '日志解析脚本要能处理设备编号缺失行，否则会整批中断。' }
];

const SHORTLIST = [
  { id: 'g-sl-01', project: P1, org: 'org-company-huaming', student: 'user-student-chen', status: 'intent' },
  { id: 'g-sl-02', project: P1, org: 'org-company-huaming', student: 'g-user-sun', status: 'trial' },
  { id: 'g-sl-03', project: P1, org: 'org-company-huaming', student: 'user-student-wang', status: 'shortlisted' },
  { id: 'g-sl-04', project: 'g-project-0924-002', org: 'org-company-hengcheng', student: 'g-user-lizh', status: 'intent' },
  { id: 'g-sl-05', project: 'g-project-0924-002', org: 'org-company-hengcheng', student: 'g-user-tian', status: 'trial' },
  { id: 'g-sl-06', project: 'g-project-0924-003', org: 'org-company-yunqi', student: 'g-user-sun', status: 'shortlisted' },
  { id: 'g-sl-07', project: 'g-project-0924-003', org: 'org-company-yunqi', student: 'user-student-chen', status: 'authorization_requested' },
  { id: 'g-sl-08', project: 'g-project-0924-003', org: 'org-company-yunqi', student: 'g-user-zhou', status: 'shortlisted' }
];

const FILES = [
  { id: 'g-file-01', org: SCHOOL, by: 'user-student-chen', name: '点检台账_三号线_2026-09.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', purpose: 'submission' },
  { id: 'g-file-02', org: SCHOOL, by: 'user-student-chen', name: '异常与缺失值清单_三号线.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', purpose: 'submission' },
  { id: 'g-file-03', org: SCHOOL, by: 'user-student-liu', name: '字段口径说明_第3组.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', purpose: 'submission' },
  { id: 'g-file-04', org: SCHOOL, by: 'g-user-sun', name: '去重规则说明_孙梦洁.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', purpose: 'submission' },
  { id: 'g-file-05', org: SCHOOL, by: 'g-user-tian', name: '刀具寿命台账_2026Q3.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', purpose: 'submission' },
  { id: 'g-file-06', org: SCHOOL, by: 'g-user-lizh', name: '工艺参数采集表_CNC02.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', purpose: 'submission' },
  { id: 'g-file-07', org: SCHOOL, by: 'g-user-lizh', name: '工艺卡片_CNC02_修订版.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', purpose: 'submission' },
  { id: 'g-file-08', org: SCHOOL, by: 'g-user-guo', name: '刀具预警清单_郭晓峰.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', purpose: 'submission' },
  { id: 'g-file-09', org: SCHOOL, by: 'user-student-chen', name: '设备运行日志_CNC02_202609.csv', mime: 'text/csv', purpose: 'submission' },
  { id: 'g-file-10', org: SCHOOL, by: 'g-user-zhou', name: '告警规则清单_v0.3.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', purpose: 'submission' },
  { id: 'g-file-11', org: SCHOOL, by: 'g-user-sun', name: '日志时间对齐记录_孙梦洁.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', purpose: 'submission' },
  { id: 'g-file-12', org: 'org-company-hengcheng', by: 'g-user-company-wang', name: '恒成刀具主数据_脱敏.xlsx', mime: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', purpose: 'requirement' },
  { id: 'g-file-13', org: 'org-company-yunqi', by: 'g-user-company-luo', name: '云启设备日志样例_脱敏.csv', mime: 'text/csv', purpose: 'requirement' },
  { id: 'g-file-14', org: 'org-company-huaming', by: 'user-company-zhang', name: '华明周报口径要求.docx', mime: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', purpose: 'requirement' }
];

const JOBS = [
  { id: 'g-job-01', name: '数控班实训数据导入', type: 'data_import', owner: 'user-admin', status: 'success', progress: 100, days: -6 },
  { id: 'g-job-02', name: '企业需求附件病毒扫描', type: 'security', owner: 'user-admin', status: 'success', progress: 100, days: -4 },
  { id: 'g-job-03', name: '项目二交付材料完整性校验', type: 'maintenance', owner: 'user-admin', status: 'running', progress: 68, days: 0 },
  { id: 'g-job-04', name: '学生能力画像月度重算', type: 'analytics', owner: 'user-admin', status: 'queued', progress: 0, days: 0 }
];

const FEED = [
  ['submit', '提交阶段二交付物', '点检台账与异常清单 v2，缺失值改为待核查清单'],
  ['review', '阶段二教师批阅完成', '单位统一正确，缺失值处理需补充依据'],
  ['parse', '运行点检台账批量解析', '发现单位混用、超阈值、编码格式等 9 类异常'],
  ['ask', '向教师提问', '缺失值是否计入异常数量已获答复'],
  ['multimodal', '识别现场点检表照片', '识别出 9 列表头与 29 行数据'],
  ['rag', '检索异常判定依据', '命中企业异常判定标准库与边界值微课'],
  ['report', '生成周度成长报告', '含 4 项指标与 2 张图表'],
  ['submit', '提交工艺参数采集表', '单位全部换算为 SI 并保留换算过程'],
  ['review', '企业侧评价已回写', '参数标准化符合交付要求'],
  ['parse', '解析刀具寿命台账', '预警 6 条、临界 2 条'],
  ['submit', '提交维护看板初版', '含 P0/P1/P2 分级与停机时长统计'],
  ['ask', '向企业确认停机定义', '连续 5 分钟无心跳方计为停机']
];

/* ---------------- 执行 ---------------- */

async function main() {
  const conn = await mysql.createConnection({
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    multipleStatements: true
  });
  const q = async (sql, params) => { const [r] = await conn.execute(sql, params || []); return r; };
  const ins = async (table, row) => {
    const keys = Object.keys(row);
    await q(`INSERT INTO \`${table}\`(${keys.map(k => `\`${k}\``).join(',')}) VALUES(${keys.map(() => '?').join(',')})
      ON DUPLICATE KEY UPDATE ${keys.filter(k => k !== 'id').map(k => `\`${k}\`=VALUES(\`${k}\`)`).join(',')}`, keys.map(k => row[k]));
  };

  /* --- 清理：只删本脚本与上一版 demo 脚本产生的行 --- */
  const cleanups = [
    ['question_replies', "id LIKE 'g-%' OR question_id IN (SELECT id FROM questions WHERE id LIKE 'g-%')"],
    ['submission_files', "submission_id LIKE 'g-%' OR file_id LIKE 'g-%'"],
    ['submissions', "id LIKE 'g-%'"],
    ['task_assignments', "id LIKE 'g-%'"],
    ['acceptance_items', "id LIKE 'g-%' OR acceptance_id LIKE 'g-%'"],
    ['acceptances', "id LIKE 'g-%'"],
    ['evaluations', "id LIKE 'g-%'"],
    ['candidate_shortlists', "id LIKE 'g-%'"],
    ['enterprise_feedback', "id LIKE 'g-%'"],
    ['authorization_requests', "id LIKE 'g-%' OR id LIKE 'ar-demo-%'"],
    ['notifications', "id LIKE 'g-%' OR id LIKE 'nt-demo-%'"],
    ['process_logs', "id LIKE 'g-%' OR id LIKE 'pl-demo-%'"],
    ['requirement_files', "file_id LIKE 'g-%'"],
    ['files', "id LIKE 'g-%'"],
    ['resources', "id LIKE 'g-%'"],
    ['project_rules', "id LIKE 'g-%'"],
    ['project_members', "user_id LIKE 'g-user-%' OR project_id LIKE 'g-project-%'"],
    ['project_classes', "class_id LIKE 'g-class-%' OR project_id LIKE 'g-project-%'"],
    ['class_enrollments', "student_user_id LIKE 'g-user-%'"],
    ['task_stages', "id LIKE 'g-stage-%'"],
    ['projects', "id LIKE 'g-project-%'"],
    ['requirements', "id LIKE 'g-req-%'"],
    ['classes', "id LIKE 'g-class-%'"],
    ['student_visibility', "student_user_id LIKE 'g-user-%'"],
    ['background_jobs', "id LIKE 'g-%'"],
    ['user_roles', "user_id LIKE 'g-user-%'"],
    ['users', "id LIKE 'g-user-%'"],
    /* 清理助手自测产生的临时提问（uuid 形式，非业务问题） */
    ['questions', "id NOT LIKE 'q-%'"]
  ];
  for (const [table, where] of cleanups) {
    try { await q(`DELETE FROM \`${table}\` WHERE ${where}`); }
    catch (e) { if (!/foreign key/i.test(e.message)) throw e; }
  }

  if (RESET_ONLY) {
    console.log('已清理演示数据（--reset）。');
    await conn.end();
    return;
  }

  const [[anyUser]] = await conn.execute('SELECT password_hash FROM users LIMIT 1');
  const hash = anyUser ? anyUser.password_hash : PLACEHOLDER_HASH;
  if (!hash) throw new Error('无法取得演示口令哈希，请先执行 npm run db:init');

  /* 1) 用户与角色 */
  for (const u of NEW_USERS) {
    await ins('users', { id: u.id, organization_id: u.org, username: u.username, password_hash: hash, display_name: u.name, email: u.email || `${u.username}@smartbridge.local`, student_no: u.studentNo || null, status: 'active', created_at: at(-30), updated_at: at(-1) });
    await ins('user_roles', { user_id: u.id, role_id: u.role });
  }

  /* 2) 班级与在册 */
  for (const c of NEW_CLASSES) await ins('classes', { id: c.id, organization_id: c.org, code: c.code, name: c.name, teacher_user_id: c.teacher, academic_year: c.year, status: 'active' });
  for (const e of NEW_ENROLLMENTS) await ins('class_enrollments', { class_id: e.classId, student_user_id: e.student, group_name: e.group, status: 'active' });

  /* 3) 企业需求 */
  for (const r of NEW_REQUIREMENTS) {
    await ins('requirements', { id: r.id, code: r.code, company_org_id: r.org, creator_user_id: r.creator, title: r.title, description: r.desc, business_goal: r.goal, deliverables: r.deliv, status: r.status, urgent: r.urgent, submitted_at: r.status === 'draft' ? null : at(r.days), created_at: at(r.days - 1), updated_at: at(r.days + 1), version: 1 });
  }

  /* 4) 项目 / 班级关联 / 成员 / 规则 */
  for (const p of NEW_PROJECTS) {
    await ins('projects', { id: p.id, code: p.code, requirement_id: p.req, name: p.name, company_org_id: p.company, school_org_id: SCHOOL, teacher_user_id: p.teacher, status: p.status, current_stage: p.stage, progress: p.progress, started_at: new Date(at(p.start).toISOString().slice(0, 10)), due_at: new Date(at(p.due).toISOString().slice(0, 10)), version: 1, created_at: at(p.start), updated_at: at(-1) });
    await ins('project_members', { project_id: p.id, user_id: p.teacher, member_role: 'teacher' });
    const owner = p.company === 'org-company-hengcheng' ? 'user-company-chengang' : 'user-company-zhao';
    await ins('project_members', { project_id: p.id, user_id: owner, member_role: 'company_owner' });
    p.rules.forEach((text, i) => { /* id 由 project+序号确定，保证幂等 */ });
  }
  for (let i = 0; i < NEW_PROJECTS.length; i++) {
    const p = NEW_PROJECTS[i];
    for (let j = 0; j < p.rules.length; j++) {
      await ins('project_rules', { id: `g-rule-${p.code}-${j + 1}`, project_id: p.id, rule_key: `R${j + 1}`, rule_text: p.rules[j], sort_order: j + 1, version: 1 });
    }
  }
  await ins('project_classes', { project_id: 'g-project-0924-002', class_id: CLASS_NC });
  await ins('project_classes', { project_id: 'g-project-0924-003', class_id: CLASS_DATA });
  /* 项目一补上新增 3 名数据科学班学生 */
  for (const s of ['g-user-sun', 'g-user-zhao', 'g-user-zhou']) await ins('project_members', { project_id: P1, user_id: s, member_role: 'student' });

  /* 5) 任务阶段 */
  for (const s of NEW_STAGES) {
    await ins('task_stages', { id: s.id, project_id: s.project, stage_no: s.no, name: s.name, description: s.desc, acceptance: s.accept, duration_hours: s.hours, status: s.status, due_at: at(s.due), version: 1 });
  }

  /* 6) 阶段分配 + 提交 + 提交文件 */
  const p2Students = Object.keys(PROGRESS['g-project-0924-002']);
  const p3Students = Object.keys(PROGRESS['g-project-0924-003']);
  const p1New = Object.keys(PROGRESS_P1);
  const stageOf = project => NEW_STAGES.filter(s => s.project === project).sort((a, b) => a.no - b.no);

  async function buildAssignments(project, students, plan) {
    const stages = stageOf(project);
    let n = 0;
    for (const student of students) {
      const statuses = plan[student];
      for (let i = 0; i < stages.length; i++) {
        const status = statuses[i];
        const score = status === 'passed' ? SCORES.passed[(n * 3) % SCORES.passed.length]
          : status === 'submitted' ? SCORES.submitted[(n * 2) % SCORES.submitted.length]
            : status === 'revision_required' ? SCORES.revision_required[n % SCORES.revision_required.length] : null;
        const id = `g-asg-${project.slice(-3)}-${student.replace(/^g-user-|^user-/, '')}-${i + 1}`;
        await ins('task_assignments', { id, task_stage_id: stages[i].id, student_user_id: student, status, score, unlocked_at: status === 'locked' ? null : at(-20 + i * 4) });
        if (['passed', 'submitted', 'revision_required'].includes(status)) {
          const subId = `g-sub-${project.slice(-3)}-${student.replace(/^g-user-|^user-/, '')}-${i + 1}`;
          await ins('submissions', { id: subId, assignment_id: id, attempt_no: status === 'revision_required' ? 2 : 1, status: status === 'passed' ? 'passed' : status, note: status === 'revision_required' ? '按企业反馈返修中：临界值与缺失值口径需重做' : '已按验收要求提交，含结果文件与过程说明', score, submitted_at: at(-16 + i * 4) });
          const fileIdx = (n + i) % FILES.length;
          await ins('submission_files', { submission_id: subId, file_id: FILES[fileIdx].id, artifact_type: i === 0 ? '结果文件' : (i === 1 ? '异常清单' : '过程说明') });
          if (status === 'passed') {
            const fileIdx2 = (n + i + 5) % FILES.length;
            if (fileIdx2 !== fileIdx) {
              /* 一份提交挂两个产物时用第二个文件，主键组合避免重复 */
              await q('INSERT IGNORE INTO submission_files(submission_id,file_id,artifact_type) VALUES(?,?,?)', [subId, FILES[fileIdx2].id, '补充材料']);
            }
          }
        }
        n++;
      }
    }
  }

  for (const f of FILES) {
    await ins('files', { id: f.id, organization_id: f.org, uploader_user_id: f.by, original_name: f.name, stored_name: `${f.id}${f.name.slice(f.name.lastIndexOf('.'))}`, mime_type: f.mime, size_bytes: 40960 + (f.id.charCodeAt(f.id.length - 1) * 1024), sha256: require('crypto').createHash('sha256').update(f.id + f.name).digest('hex'), purpose: f.purpose, storage_path: `runtime/uploads/${f.id}`, status: 'active', created_at: at(-8) });
  }
  await buildAssignments('g-project-0924-002', p2Students, PROGRESS['g-project-0924-002']);
  await buildAssignments('g-project-0924-003', p3Students, PROGRESS['g-project-0924-003']);
  /* 项目一的新增学生走已有阶段，状态用 PROGRESS_P1 */
  for (const student of p1New) {
    const statuses = PROGRESS_P1[student];
    for (let i = 0; i < 4; i++) {
      const status = statuses[i];
      const id = `g-asg-p01-${student.replace(/^g-user-/, '')}-${i + 1}`;
      const score = status === 'passed' ? SCORES.passed[(i + student.length) % SCORES.passed.length] : status === 'submitted' ? SCORES.submitted[(i + 2) % SCORES.submitted.length] : null;
      await ins('task_assignments', { id, task_stage_id: `stage-${i + 1}`, student_user_id: student, status, score, unlocked_at: status === 'locked' ? null : at(-18 + i * 4) });
      if (['passed', 'submitted'].includes(status)) {
        const subId = `g-sub-p01-${student.replace(/^g-user-/, '')}-${i + 1}`;
        await ins('submissions', { id: subId, assignment_id: id, attempt_no: 1, status, note: '按期提交，附结果文件与过程说明', score, submitted_at: at(-15 + i * 4) });
        await ins('submission_files', { submission_id: subId, file_id: FILES[(i + 2) % 12].id, artifact_type: i === 0 ? '结果文件' : '过程说明' });
      }
    }
  }

  /* 7) 教学评价 */
  let ei = 0;
  const evalPlan = [
    [P1, ['user-student-chen', 'user-student-liu', 'user-student-wang', 'g-user-sun', 'g-user-zhao', 'g-user-zhou'], [92, 74, 83, 95, 78, 88]],
    ['g-project-0924-002', p2Students, [91, 71, 85]],
    ['g-project-0924-003', p3Students, [87, 72, 80, 90, 76, 84]]
  ];
  for (const [project, students, scores] of evalPlan) {
    for (let i = 0; i < students.length; i++) {
      const s = scores[i];
      await ins('evaluations', {
        id: `g-eval-${ei++}`, project_id: project, student_user_id: students[i], evaluator_user_id: T_LI, score: s,
        status: s >= 85 ? 'confirmed' : (s >= 75 ? 'pending' : 'adjusted'),
        comment: s >= 90 ? '交付质量稳定，过程留痕完整，可作为范例' : s >= 80 ? '整体达标，异常口径说明需再具体' : '关键口径有偏差，需按企业反馈返修后复评',
        evidence_summary: s >= 90 ? '四阶段材料齐全，异常与缺失值处理有据可查' : s >= 80 ? '阶段一、二已通过，阶段三成果呈现待完善' : '阶段二返修中：缺失值与临界值处理不符合口径',
        updated_at: at(-1)
      });
    }
  }

  /* 8) 企业验收 */
  await q(`UPDATE acceptances SET result='revision_required', comment='异常清单结构合格，缺失值处理需按待核查流程返修', decided_at=? WHERE id='acceptance-1'`, [at(-3)]);
  await q(`UPDATE acceptance_items SET checked=1 WHERE id IN ('accept-item-1','accept-item-3')`);
  const acceptances = [
    { id: 'g-acc-p1-r2', project: P1, by: 'user-company-zhang', round: 2, result: 'pending', comment: null, days: 0,
      items: ['材料完整（四项必交）', '异常规则与确认口径一致', '结果可追溯到原始记录', '说明可独立复现'] },
    { id: 'g-acc-p2-r1', project: 'g-project-0924-002', by: 'g-user-company-wang', round: 1, result: 'revision_required', comment: '临界值 20% 被判为预警，预警数量虚高，需返修后复验', days: -3,
      items: ['参数单位统一为 SI', '刀具台账可追溯', '临界值口径正确', '工艺卡片与台账编号一致'] },
    { id: 'g-acc-p2-r2', project: 'g-project-0924-002', by: 'g-user-company-wang', round: 2, result: 'pending', comment: null, days: 0,
      items: ['返修后预警数量正确', '临界刀具单独标注', '周报偏差原因完整', '模板可直接复用'] },
    { id: 'g-acc-p3-r1', project: 'g-project-0924-003', by: 'g-user-company-luo', round: 1, result: 'pending', comment: null, days: 0,
      items: ['日志时间对齐到 UTC+8', '告警分级有依据', '停机定义符合口径', '看板指标可读'] }
  ];
  let ai = 0;
  for (const a of acceptances) {
    await ins('acceptances', { id: a.id, project_id: a.project, company_user_id: a.by, round_no: a.round, result: a.result, comment: a.comment, decided_at: a.result === 'pending' ? null : at(a.days) });
    let idx = 0;
    for (const text of a.items) await ins('acceptance_items', { id: `g-accitem-${ai++}`, acceptance_id: a.id, item_text: text, checked: a.result === 'pending' ? (idx++ % 2) : 1 });
  }

  /* 9) 内容资源 */
  for (const r of NEW_RESOURCES) {
    await ins('resources', { id: r.id, project_id: r.project, owner_user_id: r.owner, name: r.name, type: r.type, scope: r.scope, version: r.ver, status: r.status, description: r.desc, updated_at: at(-2) });
  }

  /* 10) 学生提问与回复 */
  for (const item of QUESTION_BANK) {
    await ins('questions', { id: item.id, project_id: item.project, task_stage_id: item.stage, asker_user_id: item.asker, question: item.q, summary: item.s, status: item.st, created_at: at(item.days) });
    if (item.reply) await ins('question_replies', { id: `g-reply-${item.id}`, question_id: item.id, replier_user_id: item.reply.by, reply: item.reply.text, created_at: at(item.reply.days) });
  }

  /* 11) 企业反馈与候选人短名单 */
  for (const f of FEEDBACK) {
    await ins('enterprise_feedback', { id: f.id, project_id: f.project, student_user_id: f.student, company_user_id: f.by, rating: f.rating, feedback: f.text, kind: f.kind, created_at: at(-3) });
  }
  for (const s of SHORTLIST) {
    await ins('candidate_shortlists', { id: s.id, project_id: s.project, company_org_id: s.org, student_user_id: s.student, status: s.status, created_at: at(-5) });
  }

  /* 12) 隐私可见性与授权 */
  const allStudents = ['user-student-chen', 'user-student-liu', 'user-student-wang', 'g-user-sun', 'g-user-zhao', 'g-user-zhou', 'g-user-lizh', 'g-user-guo', 'g-user-tian'];
  allStudents.forEach((sid, i) => { /* 逐个插入，保持幂等 */ });
  for (let i = 0; i < allStudents.length; i++) {
    await ins('student_visibility', { student_user_id: allStudents[i], open_to_company: i % 3 === 0 ? 0 : 1, show_real_name: i % 3 === 0 ? 0 : 1, allow_process_log: 1, weekly_report: 1, reuse_case: i % 2, updated_at: at(-4) });
  }
  const authPlan = [
    ['user-student-chen', 'org-company-huaming', 'user-company-zhang', 'approved', -6],
    ['g-user-sun', 'org-company-huaming', 'user-company-zhang', 'approved', -5],
    ['user-student-wang', 'org-company-huaming', 'user-company-zhang', 'pending', -2],
    ['g-user-lizh', 'org-company-hengcheng', 'user-company-chengang', 'approved', -5],
    ['g-user-tian', 'org-company-hengcheng', 'g-user-company-wang', 'pending', -2],
    ['g-user-sun', 'org-company-yunqi', 'g-user-company-luo', 'pending', -1],
    ['g-user-zhou', 'org-company-yunqi', 'g-user-company-luo', 'rejected', -3],
    ['user-student-liu', 'org-company-yunqi', 'g-user-company-luo', 'pending', -1]
  ];
  for (let i = 0; i < authPlan.length; i++) {
    const [student, org, requester, status, days] = authPlan[i];
    await ins('authorization_requests', {
      id: `g-ar-${i + 1}`, student_user_id: student, company_org_id: org, requester_user_id: requester,
      role_name: ['设备数据维护岗', '数控工艺数据岗', '产线日志运维岗'][i % 3],
      scope_json: JSON.stringify(['匿名能力画像', '阶段作品', '过程证据'].slice(0, (i % 3) + 1)),
      status, expires_at: at(24), decided_at: status === 'pending' ? null : at(days + 1), access_count: status === 'approved' ? (i + 2) : 0, created_at: at(days)
    });
  }

  /* 13) 通知 */
  const notices = [
    ['user-student-chen', '阶段二批阅结果已发布', '教师已批阅并给出改进建议：缺失值需列入待核查清单。', 'info', '/student/task.html', -1],
    ['user-student-chen', '企业已回写评价', '华明制造对你提交的台账给出 5 星评价。', 'success', '/student/report.html', -2],
    ['user-student-liu', '阶段二需要返修', '缺失值被补成正常值，请按待核查流程重做后重新提交。', 'urgent', '/student/tasks.html', -2],
    ['user-student-wang', '阶段三已开放', '阶段三「成果呈现」已开放，请在截止前提交。', 'warning', '/student/tasks.html', -1],
    ['g-user-sun', '去重规则已获企业确认', '企业确认三键去重口径，可继续推进阶段三。', 'success', '/student/tasks.html', -3],
    ['g-user-sun', '新增 1 条企业授权申请', '云启数据科技申请查看你的匿名能力画像。', 'info', '/student/company.html', -1],
    ['g-user-zhao', '阶段二提交成功', '提交已收到，等待教师批阅。', 'info', '/student/tasks.html', -2],
    ['g-user-zhou', '周报缺失值口径待确认', '你的提问已转交企业确认，请先整理其他部分。', 'warning', '/student/inagent.html', -1],
    ['g-user-lizh', '项目二进入评估阶段', '企业已完成第一轮验收，返修项将在验收页展示。', 'info', '/student/tasks.html', -1],
    ['g-user-guo', '临界值判定需要返修', '20% 被判为预警，导致预警数量虚高，请按口径返修。', 'urgent', '/student/tasks.html', -2],
    ['g-user-tian', '工艺卡片已通过初审', '编号与台账一致，等待阶段三整体验收。', 'success', '/student/tasks.html', -2],
    ['user-company-zhang', '新增 1 条候选人授权申请', '王浩宇向华明制造提交了能力画像查看申请。', 'info', '/company/talent.html', -2],
    ['user-company-zhang', '第二轮验收待处理', '项目一第二轮验收已开启，4 个检查项待勾选。', 'warning', '/company/acceptance.html', -1],
    ['user-company-zhang', '新需求待评审', '「实训过程数据可视化与交付看板」已提交平台评审。', 'info', '/company/demand.html', -1],
    ['g-user-company-wang', '项目二第二轮验收待处理', '返修项已提交，请复验并给出结论。', 'warning', '/company/acceptance.html', -1],
    ['g-user-company-luo', '项目三首次验收待处理', '项目三进入验收环节，请按口径核对时间对齐与告警分级。', 'info', '/company/acceptance.html', -1],
    ['user-teacher-li', '3 份交付物待批阅', '项目一阶段二与项目二阶段三共 3 份提交等待批阅。', 'urgent', '/teacher/review.html', -1],
    ['user-teacher-li', '数控班预警规则需复核', '郭晓峰提交的预警清单与判定口径不一致，请复核后反馈。', 'warning', '/teacher/students.html', -2],
    ['g-user-teacher-zhao', '新增班级授课任务', '2024级数控技术班已指派给你协助指导。', 'info', '/teacher/tasks.html', -2],
    ['user-admin', '月度数据校验完成', '组织/项目/资源三类数据集校验通过，无孤立记录。', 'success', '/admin/data.html', -1]
  ];
  for (let i = 0; i < notices.length; i++) {
    const [user, title, body, level, href, days] = notices[i];
    await ins('notifications', { id: `g-nt-${i + 1}`, user_id: user, title, body, level, href, read_at: i % 4 === 0 ? at(days) : null, created_at: at(days) });
  }

  /* 14) 过程留痕 */
  const feedUsers = ['user-student-chen', 'user-student-liu', 'user-student-wang', 'g-user-sun', 'g-user-zhao', 'g-user-zhou', 'g-user-lizh', 'g-user-guo', 'g-user-tian'];
  const feedProjects = [P1, P1, P1, P1, P1, P1, 'g-project-0924-002', 'g-project-0924-002', 'g-project-0924-002'];
  let fi = 0;
  for (let i = 0; i < feedUsers.length; i++) {
    for (let j = 0; j < 5; j++) {
      const item = FEED[(i + j) % FEED.length];
      await ins('process_logs', {
        id: `g-pl-${i + 1}-${j + 1}`, project_id: feedProjects[i], user_id: feedUsers[i],
        event_type: item[0], title: item[1], detail: item[2], created_at: at(-1 * (i % 3) - (j + 1) * 0.35)
      });
      fi++;
    }
  }

  /* 15) 需求附件关联 */
  await ins('requirement_files', { requirement_id: 'g-req-0922-004', file_id: 'g-file-12' });
  await ins('requirement_files', { requirement_id: 'g-req-0923-005', file_id: 'g-file-13' });
  await ins('requirement_files', { requirement_id: 'g-req-0924-006', file_id: 'g-file-14' });

  /* 16) 后台任务 */
  for (const j of JOBS) {
    await ins('background_jobs', { id: j.id, name: j.name, type: j.type, owner_user_id: j.owner, status: j.status, progress: j.progress, error_message: null, started_at: at(j.days), finished_at: j.status === 'success' ? at(j.days + 0.1) : null });
  }

  /* --- 汇总 --- */
  const tables = ['organizations', 'users', 'classes', 'class_enrollments', 'requirements', 'projects', 'project_members', 'project_rules', 'task_stages', 'task_assignments', 'submissions', 'submission_files', 'files', 'evaluations', 'acceptances', 'acceptance_items', 'resources', 'questions', 'question_replies', 'candidate_shortlists', 'enterprise_feedback', 'authorization_requests', 'notifications', 'process_logs', 'background_jobs'];
  console.log('平台演示数据已就绪：');
  for (const t of tables) {
    const [[row]] = await conn.execute(`SELECT COUNT(*) n FROM \`${t}\``);
    console.log(`  ${t.padEnd(22)} ${row.n}`);
  }
  await conn.end();
}

main().catch(error => { console.error('执行失败：', error.message); process.exit(1); });
