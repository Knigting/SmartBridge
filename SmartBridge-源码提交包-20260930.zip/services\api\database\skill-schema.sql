CREATE TABLE IF NOT EXISTS skill_definitions (
  skill_id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  description TEXT NOT NULL,
  input_schema JSON NOT NULL,
  output_schema JSON NOT NULL,
  trigger_conditions JSON NOT NULL,
  version VARCHAR(24) NOT NULL,
  status ENUM('active','disabled') NOT NULL DEFAULT 'active',
  updated_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS skill_workflow_bindings (
  id VARCHAR(160) PRIMARY KEY,
  platform ENUM('company','teacher','student','admin') NOT NULL,
  trigger_event VARCHAR(120) NOT NULL,
  skill_id VARCHAR(64) NOT NULL,
  hook_id VARCHAR(120) NOT NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  config_json JSON NULL,
  updated_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
  UNIQUE KEY uq_skill_binding(platform,trigger_event),
  CONSTRAINT fk_skill_binding_definition FOREIGN KEY(skill_id) REFERENCES skill_definitions(skill_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS skill_runs (
  id VARCHAR(36) PRIMARY KEY,
  external_run_id VARCHAR(64) NULL,
  skill_id VARCHAR(64) NOT NULL,
  platform VARCHAR(24) NULL,
  trigger_event VARCHAR(120) NULL,
  requester_user_id VARCHAR(36) NULL,
  status ENUM('running','success','failed') NOT NULL,
  mode VARCHAR(24) NULL,
  input_json JSON NULL,
  output_json JSON NULL,
  error_message TEXT NULL,
  started_at DATETIME(3) DEFAULT CURRENT_TIMESTAMP(3),
  finished_at DATETIME(3) NULL,
  INDEX idx_skill_runs_skill_time(skill_id,started_at),
  CONSTRAINT fk_skill_run_definition FOREIGN KEY(skill_id) REFERENCES skill_definitions(skill_id),
  CONSTRAINT fk_skill_run_user FOREIGN KEY(requester_user_id) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
