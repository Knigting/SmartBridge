const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

module.exports = {
  port: Number(process.env.PORT || 8080),
  db: {
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    database: process.env.DB_NAME || 'smartbridge',
    user: process.env.DB_USER || 'smartbridge_app',
    password: process.env.DB_PASSWORD || ''
  },
  adminDb: {
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_ADMIN_USER || 'root',
    password: process.env.DB_ADMIN_PASSWORD || ''
  },
  jwtSecret: process.env.JWT_SECRET || 'local-development-only-change-me-2026',
  demoMode: String(process.env.DEMO_MODE || 'true').toLowerCase() === 'true',
  skillBase: process.env.SKILL_BASE || 'http://127.0.0.1:8090',
  uploadDir: path.resolve(path.join(__dirname, '..'), process.env.UPLOAD_DIR || './uploads'),
  projectRoot: path.resolve(__dirname, '..', '..', '..')
};
