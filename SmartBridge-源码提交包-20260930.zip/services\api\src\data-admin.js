/* ==========================================================================
   data-admin.js —— 数据导出、新增、修改、导入与总览
   --------------------------------------------------------------------------
   目的：让本地系统真正可以「把数据导出来」和「把数据加进去」，而不是只能看写死的页面。
   安全约束：
     · 数据集与字段全部走白名单，不接受任意表名或列名，避免 SQL 注入
     · 写操作统一记录审计日志
     · 用户新增时密码经 bcrypt 哈希，不存明文
   ========================================================================== */
const bcrypt = require('bcryptjs');

/* 数据集白名单：select 决定导出什么，create 决定新增时接受哪些字段 */
const DATASETS = {
  organizations: {
    label: '组织',
    select: 'id,code,name,type,status,owner_name,created_at',
    create: ['code', 'name', 'type', 'status', 'owner_name'],
    defaults: { type: 'company', status: 'pending' },
    required: ['name']
  },
  users: {
    label: '用户',
    select: 'id,username,display_name,email,student_no,organization_id,status,last_login_at,created_at',
    create: ['username', 'display_name', 'email', 'student_no', 'organization_id', 'status', 'password'],
    defaults: { status: 'active' },
    required: ['username', 'display_name']
  },
  classes: {
    label: '班级',
    select: 'id,code,name,organization_id,teacher_user_id,academic_year,status',
    create: ['code', 'name', 'organization_id', 'teacher_user_id', 'academic_year'],
    defaults: { status: 'active' },
    required: ['code', 'name', 'organization_id']
  },
  projects: {
    label: '项目',
    select: 'id,code,name,requirement_id,company_org_id,school_org_id,teacher_user_id,status,current_stage,progress,started_at,due_at',
    create: ['code', 'name', 'company_org_id', 'school_org_id', 'teacher_user_id', 'status', 'progress', 'started_at', 'due_at'],
    defaults: { status: 'preparing', progress: 0 },
    required: ['code', 'name', 'company_org_id', 'school_org_id', 'teacher_user_id']
  },
  requirements: {
    label: '企业需求',
    select: 'id,code,title,description,business_goal,deliverables,company_org_id,creator_user_id,status,urgent,submitted_at',
    create: ['title', 'description', 'business_goal', 'deliverables', 'company_org_id', 'creator_user_id', 'status', 'urgent'],
    defaults: { status: 'submitted', urgent: 0 },
    required: ['title', 'company_org_id', 'creator_user_id']
  },
  task_stages: {
    label: '任务阶段',
    select: 'id,project_id,stage_no,name,description,acceptance,duration_hours,status,due_at',
    create: ['project_id', 'stage_no', 'name', 'description', 'acceptance', 'duration_hours', 'status', 'due_at'],
    defaults: { status: 'draft', duration_hours: 0 },
    required: ['project_id', 'stage_no', 'name']
  },
  task_assignments: {
    label: '阶段任务分配',
    select: 'id,task_stage_id,student_user_id,status,score,unlocked_at',
    create: ['task_stage_id', 'student_user_id', 'status', 'score'],
    defaults: { status: 'locked' },
    required: ['task_stage_id', 'student_user_id']
  },
  submissions: {
    label: '提交记录',
    select: 'id,assignment_id,attempt_no,status,note,score,submitted_at',
    create: ['assignment_id', 'attempt_no', 'status', 'note', 'score'],
    defaults: { status: 'submitted', attempt_no: 1 },
    required: ['assignment_id']
  },
  evaluations: {
    label: '教学评价',
    select: 'id,project_id,student_user_id,evaluator_user_id,score,status,comment,evidence_summary,updated_at',
    create: ['project_id', 'student_user_id', 'evaluator_user_id', 'score', 'status', 'comment', 'evidence_summary'],
    defaults: { status: 'pending' },
    required: ['project_id', 'student_user_id']
  },
  questions: {
    label: '学生提问',
    select: 'id,project_id,task_stage_id,asker_user_id,question,summary,status,created_at',
    create: ['project_id', 'task_stage_id', 'asker_user_id', 'question', 'summary', 'status'],
    defaults: { status: 'pending' },
    required: ['project_id', 'question']
  },
  resources: {
    label: '内容资源',
    select: 'id,project_id,owner_user_id,name,type,scope,version,status,description,updated_at',
    create: ['project_id', 'owner_user_id', 'name', 'type', 'scope', 'version', 'status', 'description'],
    defaults: { type: 'case', scope: 'school', version: 'v1.0', status: 'draft' },
    required: ['name']
  },
  authorization_requests: {
    label: '隐私授权请求',
    select: 'id,student_user_id,company_org_id,requester_user_id,role_name,status,expires_at,created_at',
    create: ['student_user_id', 'company_org_id', 'requester_user_id', 'role_name', 'status'],
    defaults: { status: 'pending' },
    required: ['student_user_id', 'company_org_id']
  },
  acceptances: {
    label: '验收记录',
    select: 'id,project_id,company_user_id,round_no,result,comment,decided_at',
    create: ['project_id', 'company_user_id', 'round_no', 'result', 'comment'],
    defaults: { round_no: 1, result: 'pending' },
    required: ['project_id']
  },
  files: {
    label: '业务附件',
    select: 'id,organization_id,uploader_user_id,original_name,size_bytes,mime_type,purpose,status,created_at',
    create: [],
    defaults: {},
    required: []
  },
  notifications: {
    label: '通知',
    select: 'id,user_id,title,body,level,href,read_at,created_at',
    create: ['user_id', 'title', 'body', 'level', 'href'],
    defaults: { level: 'info' },
    required: ['user_id', 'title']
  },
  process_logs: {
    label: '过程留痕',
    select: 'id,project_id,user_id,event_type,title,detail,created_at',
    create: ['project_id', 'user_id', 'event_type', 'title', 'detail'],
    defaults: {},
    required: ['project_id', 'title']
  },
  audit_logs: {
    label: '审计日志（只读）',
    select: 'id,actor_name,action,target_type,target_id,ip_address,created_at',
    create: [], defaults: {}, required: []
  },
  background_jobs: {
    label: '后台任务',
    select: 'id,name,type,owner_user_id,status,progress,started_at,finished_at,created_at',
    create: ['name', 'type', 'owner_user_id', 'status', 'progress'],
    defaults: { status: 'pending', progress: 0 },
    required: ['name', 'type']
  },
  skill_runs: {
    label: 'Skill 运行记录（只读）',
    select: 'id,skill_id,platform,trigger_event,status,mode,created_at,finished_at',
    create: [], defaults: {}, required: []
  }
};

function toCsv(rows) {
  if (!rows.length) return '';
  const headers = Object.keys(rows[0]);
  const escape = value => {
    const text = value == null ? '' : (value instanceof Date ? value.toISOString() : String(value));
    return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
  };
  const lines = [headers.join(',')].concat(rows.map(row => headers.map(h => escape(row[h])).join(',')));
  /* 加 BOM，Excel 直接打开不乱码 */
  return '\uFEFF' + lines.join('\r\n');
}

function pickFields(body, fields) {
  const picked = {};
  for (const field of fields) if (body[field] !== undefined) picked[field] = body[field];
  return picked;
}

function registerDataAdmin(app, deps) {
  const { pool, uuid, wrap, ok, fail, audit } = deps;

  /* ---------- 数据集总览：有哪些表、各多少行 ---------- */
  app.get('/api/data/datasets', wrap(async (_req, res) => {
    const list = [];
    for (const [name, meta] of Object.entries(DATASETS)) {
      const [{ n }] = (await pool.execute(`SELECT COUNT(*) n FROM \`${name}\``))[0];
      list.push({ name, label: meta.label, rows: Number(n), editable: (meta.create || []).length > 0, fields: meta.create });
    }
    ok(res, list);
  }));

  /* ---------- 导出：csv / json ---------- */
  app.get('/api/export/:dataset', wrap(async (req, res) => {
    const meta = DATASETS[req.params.dataset];
    if (!meta) return fail(res, 404, 'DATASET_NOT_FOUND', `数据集不存在：${req.params.dataset}`);
    const limit = Math.min(Number(req.query.limit) || 5000, 20000);
    const [rows] = await pool.execute(`SELECT ${meta.select} FROM \`${req.params.dataset}\` LIMIT ${limit}`);
    const format = String(req.query.format || 'json').toLowerCase();
    if (format === 'csv') {
      const filename = encodeURIComponent(`${meta.label}-${new Date().toISOString().slice(0, 10)}.csv`);
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${filename}`);
      return res.send(toCsv(rows));
    }
    ok(res, { dataset: req.params.dataset, label: meta.label, count: rows.length, rows });
  }));

  /* ---------- 新增 ---------- */
  app.post('/api/data/:dataset', wrap(async (req, res) => {
    const name = req.params.dataset;
    const meta = DATASETS[name];
    if (!meta) return fail(res, 404, 'DATASET_NOT_FOUND', `数据集不存在：${name}`);
    if (!meta.create.length) return fail(res, 405, 'DATASET_READONLY', `${meta.label}为只读数据集，不支持新增`);
    const missing = (meta.required || []).filter(field => req.body[field] === undefined || req.body[field] === '');
    if (missing.length) return fail(res, 400, 'FIELD_REQUIRED', `缺少必填字段：${missing.join('、')}`);
    const data = Object.assign({}, meta.defaults, pickFields(req.body, meta.create));
    const id = req.body.id || uuid();
    if (name === 'users' && data.password) data.password_hash = await bcrypt.hash(String(data.password), 10);
    delete data.password;
    const columns = Object.keys(data);
    if (!columns.length) return fail(res, 400, 'NO_FIELDS', '没有可写入的字段');
    const sql = `INSERT INTO \`${name}\`(id,${columns.join(',')}) VALUES(?,${columns.map(() => '?').join(',')})`;
    await pool.execute(sql, [id, ...columns.map(column => data[column])]);
    await audit(req, `新增${meta.label}`, name, id, null, data);
    ok(res, { id, dataset: name, ...data }, 201);
  }));

  /* ---------- 修改 ---------- */
  app.put('/api/data/:dataset/:id', wrap(async (req, res) => {
    const name = req.params.dataset;
    const meta = DATASETS[name];
    if (!meta) return fail(res, 404, 'DATASET_NOT_FOUND', `数据集不存在：${name}`);
    if (!meta.create.length) return fail(res, 405, 'DATASET_READONLY', `${meta.label}为只读数据集，不支持修改`);
    const data = pickFields(req.body, meta.create);
    if (name === 'users' && data.password) { data.password_hash = await bcrypt.hash(String(data.password), 10); delete data.password; }
    const columns = Object.keys(data);
    if (!columns.length) return fail(res, 400, 'NO_FIELDS', '没有可更新的字段');
    const before = (await pool.execute(`SELECT ${meta.select} FROM \`${name}\` WHERE id=?`, [req.params.id]))[0][0] || null;
    const [result] = await pool.execute(`UPDATE \`${name}\` SET ${columns.map(column => `\`${column}\`=?`).join(',')} WHERE id=?`, [...columns.map(column => data[column]), req.params.id]);
    if (!result.affectedRows) return fail(res, 404, 'NOT_FOUND', '记录不存在');
    await audit(req, `修改${meta.label}`, name, req.params.id, before, data);
    ok(res, { id: req.params.id, dataset: name, ...data });
  }));

  /* ---------- 删除 ---------- */
  app.delete('/api/data/:dataset/:id', wrap(async (req, res) => {
    const name = req.params.dataset;
    const meta = DATASETS[name];
    if (!meta) return fail(res, 404, 'DATASET_NOT_FOUND', `数据集不存在：${name}`);
    if (!meta.create.length) return fail(res, 405, 'DATASET_READONLY', `${meta.label}为只读数据集，不支持删除`);
    const before = (await pool.execute(`SELECT ${meta.select} FROM \`${name}\` WHERE id=?`, [req.params.id]))[0][0] || null;
    const [result] = await pool.execute(`DELETE FROM \`${name}\` WHERE id=?`, [req.params.id]);
    if (!result.affectedRows) return fail(res, 404, 'NOT_FOUND', '记录不存在');
    await audit(req, `删除${meta.label}`, name, req.params.id, before, null);
    ok(res, { id: req.params.id, deleted: true });
  }));

  /* ---------- 导入：JSON 数组或 CSV 文本 ---------- */
  app.post('/api/import/:dataset', wrap(async (req, res) => {
    const name = req.params.dataset;
    const meta = DATASETS[name];
    if (!meta) return fail(res, 404, 'DATASET_NOT_FOUND', `数据集不存在：${name}`);
    if (!meta.create.length) return fail(res, 405, 'DATASET_READONLY', `${meta.label}为只读数据集，不支持导入`);
    let list = Array.isArray(req.body.rows) ? req.body.rows : [];
    if (!list.length && typeof req.body.csv === 'string') {
      const lines = req.body.csv.replace(/^\uFEFF/, '').split(/\r?\n/).filter(Boolean);
      if (lines.length > 1) {
        const headers = lines[0].split(',').map(h => h.trim());
        list = lines.slice(1).map(line => Object.fromEntries(headers.map((h, i) => [h, line.split(',')[i]])));
      }
    }
    if (!list.length) return fail(res, 400, 'NO_ROWS', '没有可导入的数据行');
    let created = 0; const errors = [];
    for (const [index, item] of list.entries()) {
      try {
        const data = Object.assign({}, meta.defaults, pickFields(item, meta.create));
        const missing = (meta.required || []).filter(field => data[field] === undefined || data[field] === '');
        if (missing.length) { errors.push({ row: index + 1, message: `缺少必填字段：${missing.join('、')}` }); continue; }
        if (name === 'users' && data.password) { data.password_hash = await bcrypt.hash(String(data.password), 10); delete data.password; }
        const columns = Object.keys(data);
        const id = item.id || uuid();
        await pool.execute(`INSERT INTO \`${name}\`(id,${columns.join(',')}) VALUES(?,${columns.map(() => '?').join(',')})`, [id, ...columns.map(c => data[c])]);
        created += 1;
      } catch (error) {
        errors.push({ row: index + 1, message: error.message });
      }
    }
    await audit(req, `导入${meta.label}`, name, String(created), null, { created, failed: errors.length });
    ok(res, { dataset: name, created, failed: errors.length, errors: errors.slice(0, 20) }, 201);
  }));
}

module.exports = { registerDataAdmin, DATASETS, toCsv };
