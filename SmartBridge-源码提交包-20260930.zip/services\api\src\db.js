const mysql = require('mysql2/promise');
const config = require('./config');

const rawPool = mysql.createPool({
  ...config.db,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  charset: 'utf8mb4',
  timezone: 'Z',
  namedPlaceholders: true
});

/* --------------------------------------------------------------------------
   undefined 绑参归一化
   --------------------------------------------------------------------------
   mysql2 收到 undefined 绑参会直接抛错（Bind parameters must not contain
   undefined），在路由里表现成 500「服务器内部错误」。前端只要漏传一个可选
   字段（例如企业端确认时没带 project_id）就会踩到，而且错误信息毫无指向性。
   在数据访问层统一把 undefined 归一化为 NULL：语义上「未提供」就等于「空值」，
   与 SQL 的 NULL 一致，不改变任何正常调用，也不需要逐个路由加防御。
   -------------------------------------------------------------------------- */
function normalizeParams(params) {
  if (Array.isArray(params)) return params.map(value => (value === undefined ? null : value));
  if (params && typeof params === 'object') {
    const result = {};
    for (const [key, value] of Object.entries(params)) result[key] = value === undefined ? null : value;
    return result;
  }
  return params;
}

function withParamGuard(target) {
  return new Proxy(target, {
    get(obj, property) {
      const original = obj[property];
      if (typeof original !== 'function') return original;
      if (property === 'execute' || property === 'query') {
        return function (sql, params, ...rest) {
          return original.call(obj, sql, normalizeParams(params), ...rest);
        };
      }
      return original.bind(obj);
    }
  });
}

const pool = withParamGuard(rawPool);

async function tx(work) {
  const connection = await rawPool.getConnection();
  try {
    await connection.beginTransaction();
    const result = await work(withParamGuard(connection));
    await connection.commit();
    return result;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

module.exports = { pool, tx, normalizeParams };
