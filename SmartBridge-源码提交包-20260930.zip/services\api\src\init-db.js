const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const config = require('./config');

const ids = {
  orgPlatform:'org-platform', orgSchool:'org-school-001', orgHuaming:'org-company-huaming', orgYunqi:'org-company-yunqi', orgHengcheng:'org-company-hengcheng',
  admin:'user-admin', teacher:'user-teacher-li', student:'user-student-chen', wang:'user-student-wang', liu:'user-student-liu', zhang:'user-company-zhang', zhao:'user-company-zhao', chengang:'user-company-chengang',
  cls:'class-data-2024', requirement:'requirement-0917-001', req2:'requirement-0916-002', req3:'requirement-0915-003', project:'project-0917-001'
};

async function insert(conn, table, row) {
  const cols = Object.keys(row);
  const sql = `INSERT INTO \`${table}\` (${cols.map(c=>`\`${c}\``).join(',')}) VALUES (${cols.map(()=>'?').join(',')}) ON DUPLICATE KEY UPDATE ${cols.filter(c=>c!=='id').map(c=>`\`${c}\`=VALUES(\`${c}\`)`).join(',') || 'id=id'}`;
  await conn.execute(sql, cols.map(c => row[c]));
}

async function main(){
  const admin = await mysql.createConnection({...config.adminDb, multipleStatements:true, charset:'utf8mb4'});
  const dbName = config.db.database.replace(/[^a-zA-Z0-9_]/g,'');
  await admin.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci`);
  await admin.query(`CREATE USER IF NOT EXISTS 'smartbridge_app'@'localhost' IDENTIFIED BY ?`, [config.db.password]);
  await admin.query(`CREATE USER IF NOT EXISTS 'smartbridge_app'@'127.0.0.1' IDENTIFIED BY ?`, [config.db.password]);
  await admin.query(`ALTER USER 'smartbridge_app'@'localhost' IDENTIFIED BY ?`, [config.db.password]);
  await admin.query(`ALTER USER 'smartbridge_app'@'127.0.0.1' IDENTIFIED BY ?`, [config.db.password]);
  await admin.query(`GRANT SELECT,INSERT,UPDATE,DELETE,CREATE,ALTER,INDEX,REFERENCES ON \`${dbName}\`.* TO 'smartbridge_app'@'localhost'`);
  await admin.query(`GRANT SELECT,INSERT,UPDATE,DELETE,CREATE,ALTER,INDEX,REFERENCES ON \`${dbName}\`.* TO 'smartbridge_app'@'127.0.0.1'`);
  await admin.end();

  const conn = await mysql.createConnection({...config.db, multipleStatements:true, charset:'utf8mb4'});
  const schema = fs.readFileSync(path.join(__dirname,'..','database','schema.sql'),'utf8');
  await conn.query(schema);
  const passwordHash = await bcrypt.hash('SmartBridge123!', 10);
  await conn.beginTransaction();
  try {
    for (const row of [
      {id:ids.orgPlatform,code:'PLATFORM',name:'智训桥运营中心',type:'platform',status:'active',owner_name:'周启明'},
      {id:ids.orgSchool,code:'SCHOOL-001',name:'山东智能制造职业学院',type:'school',status:'active',owner_name:'李慧敏'},
      {id:ids.orgHuaming,code:'COMPANY-001',name:'华明制造',type:'company',status:'active',owner_name:'张工'},
      {id:ids.orgYunqi,code:'COMPANY-008',name:'云启数据科技',type:'company',status:'active',owner_name:'赵宁'},
      {id:ids.orgHengcheng,code:'COMPANY-011',name:'恒成软件',type:'company',status:'pending',owner_name:'陈刚'}
    ]) await insert(conn,'organizations',row);
    for (const row of [
      {id:'role-platform-admin',code:'platform_admin',name:'平台管理员'},{id:'role-school-admin',code:'school_admin',name:'学校管理员'},
      {id:'role-teacher',code:'teacher',name:'教师'},{id:'role-student',code:'student',name:'学生'},
      {id:'role-company-admin',code:'company_admin',name:'企业管理员'},{id:'role-company-member',code:'company_member',name:'企业成员'}
    ]) await insert(conn,'roles',row);
    for (const row of [
      {id:ids.admin,organization_id:ids.orgPlatform,username:'admin',password_hash:passwordHash,display_name:'周启明',email:'admin@smartbridge.local',status:'active'},
      {id:ids.teacher,organization_id:ids.orgSchool,username:'lihuimin',password_hash:passwordHash,display_name:'李慧敏',email:'lihm@example.edu.cn',status:'active'},
      {id:ids.student,organization_id:ids.orgSchool,username:'2024010156',password_hash:passwordHash,display_name:'陈晓雨',student_no:'2024010156',status:'active'},
      {id:ids.wang,organization_id:ids.orgSchool,username:'2024010125',password_hash:passwordHash,display_name:'王浩宇',student_no:'2024010125',status:'active'},
      {id:ids.liu,organization_id:ids.orgSchool,username:'2024010142',password_hash:passwordHash,display_name:'刘子豪',student_no:'2024010142',status:'active'},
      {id:ids.zhang,organization_id:ids.orgHuaming,username:'zhanggong',password_hash:passwordHash,display_name:'张工',email:'zhang@huaming.example',status:'active'},
      {id:ids.zhao,organization_id:ids.orgYunqi,username:'zhaoning',password_hash:passwordHash,display_name:'赵宁',email:'zhaon@yunqi.example',status:'active'},
      {id:ids.chengang,organization_id:ids.orgHengcheng,username:'chengang',password_hash:passwordHash,display_name:'陈刚',email:'cheng@hengcheng.example',status:'pending'}
    ]) await insert(conn,'users',row);
    for (const [user_id,role_id] of [[ids.admin,'role-platform-admin'],[ids.teacher,'role-teacher'],[ids.student,'role-student'],[ids.wang,'role-student'],[ids.liu,'role-student'],[ids.zhang,'role-company-admin'],[ids.zhao,'role-company-member'],[ids.chengang,'role-company-admin']]) await insert(conn,'user_roles',{user_id,role_id});
    await insert(conn,'classes',{id:ids.cls,organization_id:ids.orgSchool,code:'DATA-2024-01',name:'2024级数据科学班',teacher_user_id:ids.teacher,academic_year:'2024',status:'active'});
    for (const [student_user_id,group_name] of [[ids.student,'第2组'],[ids.wang,'第2组'],[ids.liu,'第3组']]) await insert(conn,'class_enrollments',{class_id:ids.cls,student_user_id,group_name,status:'active'});
    for (const row of [
      {id:ids.requirement,code:'REQ-0917-001',company_org_id:ids.orgHuaming,creator_user_id:ids.zhang,title:'设备点检台账整理与异常周报生成',description:'按周汇总多个班组点检表，处理字段不统一、重复记录和缺失值。',business_goal:'形成统一台账、异常清单与周报',deliverables:'汇总表、异常明细、周报、操作说明',status:'converted',urgent:1,submitted_at:'2026-09-17 09:00:00'},
      {id:ids.req2,code:'REQ-0916-002',company_org_id:ids.orgHengcheng,creator_user_id:ids.chengang,title:'出入库报表自动化汇总',description:'整合多个仓库每日出入库记录。',business_goal:'生成每日汇总报表',deliverables:'汇总报表、异常波动清单',status:'under_review',urgent:0,submitted_at:'2026-09-16 10:00:00'},
      {id:ids.req3,code:'REQ-0915-003',company_org_id:ids.orgYunqi,creator_user_id:ids.zhao,title:'质量检测数据可视化看板',description:'将历史质量检测数据整理为可视化看板。',business_goal:'支持班次和产线维度查看',deliverables:'看板页面、数据说明',status:'under_review',urgent:0,submitted_at:'2026-09-15 11:00:00'}
    ]) await insert(conn,'requirements',row);
    await insert(conn,'projects',{id:ids.project,code:'PRJ-0917-001',requirement_id:ids.requirement,name:'设备点检台账整理与异常周报生成',company_org_id:ids.orgHuaming,school_org_id:ids.orgSchool,teacher_user_id:ids.teacher,status:'running',current_stage:'过程监督',progress:63,started_at:'2026-09-14',due_at:'2026-09-30',version:1});
    await insert(conn,'project_classes',{project_id:ids.project,class_id:ids.cls});
    for (const [user_id,member_role] of [[ids.teacher,'teacher'],[ids.zhang,'company_owner'],[ids.student,'student'],[ids.wang,'student'],[ids.liu,'student']]) await insert(conn,'project_members',{project_id:ids.project,user_id,member_role});
    const rules=['温度 > 80℃ 记为异常','温度 = 80℃ 为边界正常值','缺失值列入待核查清单，不得自行补成正常值','同一记录重复提交，去重后保留 1 条'];
    for(let i=0;i<rules.length;i++) await insert(conn,'project_rules',{id:`rule-${i+1}`,project_id:ids.project,rule_key:`R${i+1}`,rule_text:rules[i],sort_order:i+1,version:1});
    const stages=[['stage-1',1,'数据整理：统一字段、唯一标识与去重','把多个班组样表整理为统一台账。','字段统一、重复记录去重、缺失项单独标记',3,'passed'],['stage-2',2,'规则实现：输出异常及缺失值清单','按企业确认阈值输出清单。','>80℃异常；=80℃正常；缺失值待核查',3,'running'],['stage-3',3,'成果呈现：按周统计与可追溯明细','生成周报与可追溯明细。','统计可回溯到明细行',3,'published'],['stage-4',4,'交付复用：操作说明与复现检查','编写运行说明并完成复现检查。','他人可按说明复现',3,'published']];
    for(const s of stages) await insert(conn,'task_stages',{id:s[0],project_id:ids.project,stage_no:s[1],name:s[2],description:s[3],acceptance:s[4],duration_hours:s[5],status:s[6],version:1});
    for(const studentId of [ids.student,ids.wang,ids.liu]) for(let i=1;i<=4;i++) await insert(conn,'task_assignments',{id:`assign-${studentId}-${i}`,task_stage_id:`stage-${i}`,student_user_id:studentId,status:i===1?'passed':i===2?'running':'locked',score:i===1?86:null,unlocked_at:i<=2?'2026-09-14 09:00:00':null});
    await insert(conn,'submissions',{id:'submission-chen-1',assignment_id:`assign-${ids.student}-1`,attempt_no:1,status:'passed',note:'字段统一与去重通过',score:86,submitted_at:'2026-09-16 16:05:00'});
    for(const row of [{id:'log-1',project_id:ids.project,user_id:ids.student,event_type:'submission',title:'阶段二产物进入提交检查',detail:'固定样例检查中',created_at:'2026-09-17 14:32:00'},{id:'log-2',project_id:ids.project,user_id:ids.student,event_type:'passed',title:'阶段一数据整理通过',detail:'过程分 +86',created_at:'2026-09-16 16:05:00'},{id:'log-3',project_id:ids.project,user_id:ids.teacher,event_type:'intervention',title:'边界条件专项讲评',detail:'针对 80℃ 边界误判',created_at:'2026-09-17 10:00:00'}]) await insert(conn,'process_logs',row);
    for(const row of [{id:'q-1',project_id:ids.project,task_stage_id:'stage-2',asker_user_id:ids.student,question:'温度单位混用如何处理？',summary:'℃ 与 ℉ 混用，需要企业确认',status:'enterprise_confirm'},{id:'q-2',project_id:ids.project,task_stage_id:'stage-2',asker_user_id:ids.wang,question:'80℃ 算异常吗？',summary:'边界值判断口径',status:'answered'},{id:'q-3',project_id:ids.project,task_stage_id:'stage-2',asker_user_id:ids.liu,question:'缺失值可以补正常吗？',summary:'缺失值处理口径',status:'pending'}]) await insert(conn,'questions',row);
    await insert(conn,'question_replies',{id:'reply-1',question_id:'q-2',replier_user_id:ids.teacher,reply:'大于 80℃ 才异常，等于 80℃ 为边界正常值。'});
    for(const [id,student_user_id,score,status,evidence_summary] of [['eval-chen',ids.student,85,'pending','阶段一通过，阶段二检查中'],['eval-wang',ids.wang,78,'pending','边界条件返修 2 次'],['eval-liu',ids.liu,72,'pending','连续 3 天进度滞后']]) await insert(conn,'evaluations',{id,project_id:ids.project,student_user_id,evaluator_user_id:ids.teacher,score,status,comment:'',evidence_summary});
    await insert(conn,'acceptances',{id:'acceptance-1',project_id:ids.project,company_user_id:ids.zhang,round_no:1,result:'pending'});
    for(let i=0;i<4;i++) await insert(conn,'acceptance_items',{id:`accept-item-${i+1}`,acceptance_id:'acceptance-1',item_text:['材料完整','规则正确','结果可追溯','说明可复现'][i],checked:0});
    for(const row of [{id:'res-1',project_id:ids.project,owner_user_id:ids.teacher,name:'设备点检台账整理（脱敏版）',type:'case',scope:'school',version:'v2.0',status:'published',description:'设备点检教学案例'},{id:'res-2',project_id:ids.project,owner_user_id:ids.teacher,name:'周报统计与可追溯明细',type:'template',scope:'project',version:'v1.1',status:'published',description:'周报模板'},{id:'res-3',project_id:ids.project,owner_user_id:ids.zhang,name:'设备点检验收评分表',type:'rubric',scope:'project',version:'v1.0',status:'pending',description:'企业验收评分规则'},{id:'res-4',project_id:ids.project,owner_user_id:ids.teacher,name:'温度阈值与边界判定',type:'knowledge',scope:'school',version:'v1.0',status:'published',description:'边界判断知识条目'}]) await insert(conn,'resources',row);
    await insert(conn,'student_visibility',{student_user_id:ids.student,open_to_company:0,show_real_name:0,allow_process_log:1,weekly_report:1,reuse_case:0});
    for(const row of [{id:'REQ-2041',student_user_id:ids.student,company_org_id:ids.orgYunqi,requester_user_id:ids.zhao,role_name:'台账维护（项目型）',scope_json:JSON.stringify(['匿名能力画像','阶段一去重规则作品']),status:'pending',access_count:0},{id:'REQ-2038',student_user_id:ids.student,company_org_id:ids.orgHengcheng,requester_user_id:ids.chengang,role_name:'数据处理实习生',scope_json:JSON.stringify(['匿名能力画像']),status:'pending',access_count:0}]) await insert(conn,'authorization_requests',row);
    for(const row of [{id:'notice-1',user_id:ids.student,title:'2 家企业请求查看你的匿名能力画像',body:'拒绝授权不会影响能力评价',level:'urgent',href:'/student/company.html'},{id:'notice-2',user_id:ids.teacher,title:'2 名学生需要关注',body:'王浩宇、刘子豪进度滞后',level:'warning',href:'/teacher/students.html'},{id:'notice-3',user_id:ids.zhang,title:'点检周报待验收',body:'项目已进入企业验收准备',level:'info',href:'/company/acceptance.html'}]) await insert(conn,'notifications',row);
    for(const row of [{id:'audit-1',actor_user_id:ids.admin,actor_name:'周启明',action:'审核企业认证资料',target_type:'organization',target_id:ids.orgHengcheng,ip_address:'127.0.0.1'},{id:'audit-2',actor_user_id:ids.teacher,actor_name:'李慧敏',action:'调整学生评价 78 → 82',target_type:'evaluation',target_id:'eval-wang',ip_address:'127.0.0.1'},{id:'audit-3',actor_user_id:ids.zhang,actor_name:'张工',action:'查看已授权候选人材料',target_type:'authorization',target_id:'REQ-2041',ip_address:'127.0.0.1'}]) await insert(conn,'audit_logs',row);
    for(const row of [{id:'JOB-5103',name:'2024级数据科学班成员导入',type:'data_import',owner_user_id:ids.admin,status:'success',progress:100,started_at:'2026-09-23 10:06:00',finished_at:'2026-09-23 10:06:30'},{id:'JOB-5101',name:'项目文件完整性校验',type:'maintenance',owner_user_id:ids.admin,status:'running',progress:34,started_at:'2026-09-23 08:15:00'}]) await insert(conn,'background_jobs',row);
    await insert(conn,'system_settings',{setting_key:'platform_policy',setting_value:JSON.stringify({sessionMinutes:120,retentionDays:365,auditYears:3}),updated_by:ids.admin});
    await conn.commit();
  } catch(error){await conn.rollback();throw error}
  await conn.end();
  console.log('数据库 smartbridge 初始化完成：33 张表，四端共享同一业务数据。');
  console.log('本地演示账号：admin / lihuimin / 2024010156 / zhanggong；统一密码 SmartBridge123!');
}

main().catch(error=>{console.error(error.message);process.exit(1)});
