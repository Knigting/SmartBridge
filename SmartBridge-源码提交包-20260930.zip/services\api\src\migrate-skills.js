const fs = require('fs');
const path = require('path');
const { pool } = require('./db');
const { skills, bindings } = require('./skill-registry');

async function main() {
  const ddl = fs.readFileSync(path.join(__dirname, '..', 'database', 'skill-schema.sql'), 'utf8');
  for (const statement of ddl.split(/;\s*(?:\r?\n|$)/).map(x => x.trim()).filter(Boolean)) await pool.query(statement);
  for (const skill of skills) await pool.execute(`INSERT INTO skill_definitions
    (skill_id,name,description,input_schema,output_schema,trigger_conditions,version,status)
    VALUES(?,?,?,?,?,?,?,'active') ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description),input_schema=VALUES(input_schema),output_schema=VALUES(output_schema),trigger_conditions=VALUES(trigger_conditions),version=VALUES(version),status='active'`,
    [skill.id, skill.name, skill.description, JSON.stringify(skill.inputSchema), JSON.stringify(skill.outputSchema), JSON.stringify(skill.triggers), skill.version]);
  await pool.execute(`DELETE FROM skill_runs WHERE skill_id NOT IN (${skills.map(() => '?').join(',')})`, skills.map(x => x.id));
  await pool.execute(`DELETE FROM skill_workflow_bindings WHERE skill_id NOT IN (${skills.map(() => '?').join(',')})`, skills.map(x => x.id));
  await pool.execute(`DELETE FROM skill_definitions WHERE skill_id NOT IN (${skills.map(() => '?').join(',')})`, skills.map(x => x.id));
  for (const binding of bindings) await pool.execute(`INSERT INTO skill_workflow_bindings
    (id,platform,trigger_event,skill_id,hook_id,enabled,config_json) VALUES(?,?,?,?,?,?,?)
    ON DUPLICATE KEY UPDATE skill_id=VALUES(skill_id),hook_id=VALUES(hook_id),enabled=VALUES(enabled),config_json=VALUES(config_json)`,
    [binding.id, binding.platform, binding.triggerEvent, binding.skillId, binding.hookId, 1, JSON.stringify({ source: 'smartbridge-local-workflow' })]);
  const [[counts]] = await pool.query('SELECT (SELECT COUNT(*) FROM skill_definitions) skills,(SELECT COUNT(*) FROM skill_workflow_bindings WHERE enabled=1) bindings');
  console.log(`Skill 数据迁移完成：${counts.skills} 项能力，${counts.bindings} 个四端工作流绑定。`);
  await pool.end();
}

main().catch(async error => { console.error(error); try { await pool.end(); } catch (_) {} process.exit(1); });
