/* ==========================================================================
   report-data.js —— 报告 Skill 的真实数据来源
   --------------------------------------------------------------------------
   四端页面的报告接入位（E 类）只声明了 kind，本身不带指标数据，直接调报告 Skill
   会被拒绝（REPORT_DATA_REQUIRED）。这里按 kind 从业务库实算 metrics / sections /
   charts / evidence，前端取到后作为 data 传给报告 Skill，生成的报告可下载、可追溯。

   所有数字都来自当前业务库，没有硬编码的业务结论；页面传入的 data 只作为展示补充。
   ========================================================================== */
const rows = async (pool, sql, params = []) => (await pool.execute(sql, params))[0];
const one = async (pool, sql, params = []) => (await rows(pool, sql, params))[0] || null;
const num = value => (value == null ? 0 : Number(value));
const pct = value => `${Number(value || 0).toFixed(0)}%`;

function ev(title, location) { return { title, location }; }

/* 报告聚合接口不属于任何一端路径前缀，按报告类型判定演示身份。
   工作流触发面（/api/workflows/:platform/:trigger/dispatch）同样用它兜底，
   保证报告类接入位不依赖调用方主动登录。 */
const DEMO_USER_BY_REPORT_KIND = {
  量化效益: 'user-company-zhang', 执行进度: 'user-company-zhang', 人才获取: 'user-company-zhang',
  教学周报: 'user-teacher-li', 班级画像: 'user-teacher-li', 任务包说明: 'user-teacher-li', 复核记录: 'user-teacher-li',
  成长周报: 'user-student-chen', 能力画像: 'user-student-chen', 能力材料包: 'user-student-chen'
};

async function resolveReportUser(pool, kind, user) {
  if (user && user.id) return user;
  const id = DEMO_USER_BY_REPORT_KIND[String(kind || '')];
  if (!id) return user || {};
  return (await one(pool, 'SELECT u.id id,u.display_name,u.organization_id,o.name organization_name FROM users u LEFT JOIN organizations o ON o.id=u.organization_id WHERE u.id=?', [id])) || {};
}

async function projectStats(pool, projectId) {
  const project = await one(pool, `SELECT p.*, COUNT(DISTINCT s.id) stage_total,
      SUM(s.status='published') stage_published, SUM(a.status='passed') assign_passed,
      COUNT(DISTINCT a.id) assign_total, SUM(a.status='revision_required') assign_rework
    FROM projects p LEFT JOIN task_stages s ON s.project_id=p.id LEFT JOIN task_assignments a ON a.task_stage_id=s.id
    WHERE p.id=? OR p.code=? GROUP BY p.id LIMIT 1`, [projectId, projectId]);
  if (!project) return null;
  return {
    code: project.code, name: project.name, progress: num(project.progress),
    stage_total: num(project.stage_total), stage_published: num(project.stage_published),
    assign_passed: num(project.assign_passed), assign_total: num(project.assign_total),
    assign_rework: num(project.assign_rework), current_stage: project.current_stage, status: project.status
  };
}

const BUILDERS = {
  /* ---------------- 企业端 ---------------- */
  量化效益: async (pool, user, data) => {
    const stats = await projectStats(pool, data.project || 'PRJ-0917-001');
    const baseline = num(data.baselineHours) || 15.2;
    const actual = num(data.actualHours) || 6.0;
    const saved = num(data.savedHours) || Number((baseline - actual).toFixed(1));
    const drop = baseline ? Math.round((saved / baseline) * 100) : 0;
    return {
      title: `${stats ? stats.name : '当前项目'} · 量化效益分析报告`,
      metrics: [
        { k: '节省工时', v: `${saved} h/月`, d: `人工 ${baseline} → ${actual}` },
        { k: '工时降幅', v: `${drop}%`, d: '按历史同类任务中位值对照' },
        { k: '阶段通过', v: `${stats ? stats.assign_passed : 0} / ${stats ? stats.assign_total : 0}`, d: '业务库实时统计' },
        { k: '返修任务', v: `${stats ? stats.assign_rework : 0} 项`, d: '待返修阶段数' }
      ],
      sections: [
        { h: '结论摘要', p: `人工基线 ${baseline} 小时/月，交付后 ${actual} 小时/月，节省 ${saved} 小时（降幅 ${drop}%）。数据来源为业务库项目进度与阶段提交记录。` },
        { h: '口径说明', p: '工时基线取自历史同类任务库中位值；阶段通过与返修数量取自当前业务库 task_assignments 实时统计，非估算值。' },
        { h: '改进建议', p: stats && stats.assign_rework ? `当前有 ${stats.assign_rework} 项阶段待返修，建议先收敛边界值判定口径再进入下一阶段。` : '当前无待返修阶段，可按计划推进下一阶段。' }
      ],
      charts: [
        { type: 'bar', title: '月度工时对照（小时/月）', series: [{ name: '人工基线', value: baseline, unit: ' h' }, { name: '交付后', value: actual, unit: ' h' }, { name: '节省', value: saved, unit: ' h' }] },
        { type: 'bar', title: '阶段完成情况', series: [{ name: '已通过', value: stats ? stats.assign_passed : 0, unit: ' 阶段' }, { name: '待返修', value: stats ? stats.assign_rework : 0, unit: ' 阶段' }, { name: '阶段总数', value: stats ? stats.stage_total : 0, unit: ' 阶段' }] }
      ],
      evidence: [ev('业务库 projects / task_assignments', `项目 ${stats ? stats.code : data.project}`)]
    };
  },

  执行进度: async (pool, user, data) => {
    const stats = await projectStats(pool, data.project || 'PRJ-0917-001');
    return {
      title: `${stats ? stats.name : '当前项目'} · 执行进度周报`,
      metrics: [
        { k: '整体进度', v: pct(stats ? stats.progress : 0), d: `当前阶段 ${stats ? stats.current_stage || '—' : '—'}` },
        { k: '已发布阶段', v: `${stats ? stats.stage_published : 0} / ${stats ? stats.stage_total : 0}`, d: '教师端发布状态' },
        { k: '阶段通过', v: `${stats ? stats.assign_passed : 0} / ${stats ? stats.assign_total : 0}`, d: '学生提交检查' },
        { k: '待返修', v: `${stats ? stats.assign_rework : 0} 项`, d: '需补充后重交' }
      ],
      sections: [
        { h: '本周完成', p: `项目整体进度 ${pct(stats ? stats.progress : 0)}，已发布 ${stats ? stats.stage_published : 0} 个阶段，学生侧通过 ${stats ? stats.assign_passed : 0} 个阶段任务。` },
        { h: '待办与卡点', p: stats && stats.assign_rework ? `有 ${stats.assign_rework} 项阶段任务处于待返修，建议企业确认口径后由教师重新发布。` : '暂无待返修任务，进度符合预期。' },
        { h: '下周计划', p: '按阶段顺序解锁下一阶段，企业侧仅需参与口径确认与最终验收。' }
      ],
      charts: [
        { type: 'bar', title: '阶段进度分布', series: [{ name: '已通过', value: stats ? stats.assign_passed : 0 }, { name: '待返修', value: stats ? stats.assign_rework : 0 }, { name: '未开始', value: Math.max(0, (stats ? stats.assign_total : 0) - (stats ? stats.assign_passed : 0) - (stats ? stats.assign_rework : 0)) }] },
        { type: 'bar', title: '整体完成度', series: [{ name: '已完成', value: stats ? stats.progress : 0, unit: '%' }, { name: '剩余', value: Math.max(0, 100 - (stats ? stats.progress : 0)), unit: '%' }] }
      ],
      evidence: [ev('业务库 projects / task_stages', `项目 ${stats ? stats.code : data.project}`)]
    };
  },

  人才获取: async (pool, user, data) => {
    const list = await rows(pool, `SELECT u.display_name name, u.student_no, e.score, e.status,
        COALESCE(sv.open_to_company,0) open_to_company, COALESCE(ar.status,'not_requested') authorization
      FROM evaluations e JOIN users u ON u.id=e.student_user_id
      LEFT JOIN student_visibility sv ON sv.student_user_id=u.id
      LEFT JOIN authorization_requests ar ON ar.student_user_id=u.id AND ar.company_org_id=?
      ORDER BY e.score DESC LIMIT 20`, [user.organization_id]);
    const authorized = list.filter(item => item.authorization === 'approved').length;
    const top = list.length ? num(list[0].score) : 0;
    return {
      title: '候选人才能力画像与证据摘要',
      metrics: [
        { k: '候选人数', v: `${list.length} 人`, d: '含未授权匿名画像' },
        { k: '已授权', v: `${authorized} 人`, d: '可查看身份与联系方式' },
        { k: '最高评价分', v: String(top), d: '业务库评价记录' },
        { k: '待验证项', v: `${list.length} 项`, d: '建议面试确认' }
      ],
      sections: [
        { h: '结论摘要', p: `${list.length} 名候选人中 ${authorized} 名已完成授权；评价分最高 ${top} 分。排序依据为业务库评价记录，不是课堂表现。` },
        { h: '证据来源', p: '以本项目各阶段提交记录、固定样例测试与返修轨迹为依据，匿名画像在企业授权前不展示身份。' },
        { h: '面试建议', p: '重点确认设备维护现场经验等待验证项，避免以课堂表现替代岗位证据。' }
      ],
      charts: [
        { type: 'bar', title: '候选人评价分', series: list.slice(0, 6).map((item, index) => ({ name: `候选 ${String.fromCharCode(65 + index)}`, value: num(item.score) })) },
        { type: 'bar', title: '授权情况', series: [{ name: '已授权', value: authorized, unit: ' 人' }, { name: '未授权', value: Math.max(0, list.length - authorized), unit: ' 人' }] }
      ],
      evidence: [ev('业务库 evaluations / authorization_requests', `${list.length} 条评价记录`)]
    };
  },

  /* ---------------- 教师端 ---------------- */
  教学周报: async (pool, user) => {
    const kpi = await one(pool, `SELECT
        (SELECT COUNT(*) FROM requirements WHERE status IN ('submitted','under_review')) pending_requirements,
        (SELECT COUNT(*) FROM task_stages s JOIN projects p ON p.id=s.project_id WHERE p.teacher_user_id=? AND s.status='published') published_stages,
        (SELECT COUNT(*) FROM evaluations e JOIN projects p ON p.id=e.project_id WHERE p.teacher_user_id=? AND e.status IN ('pending','draft')) pending_evaluations,
        (SELECT COUNT(*) FROM questions q JOIN projects p ON p.id=q.project_id WHERE p.teacher_user_id=? AND q.status='pending') pending_questions`,
      [user.id, user.id, user.id]);
    const students = await rows(pool, `SELECT u.display_name name, ROUND(100*SUM(a.status='passed')/COUNT(a.id)) progress
      FROM class_enrollments ce JOIN classes c ON c.id=ce.class_id JOIN users u ON u.id=ce.student_user_id
      LEFT JOIN task_assignments a ON a.student_user_id=u.id WHERE c.teacher_user_id=? GROUP BY u.id`, [user.id]);
    return {
      title: '教学执行周报',
      metrics: [
        { k: '待审核需求', v: `${num(kpi?.pending_requirements)} 条`, d: '企业端已提交' },
        { k: '已发布阶段', v: `${num(kpi?.published_stages)} 个`, d: '覆盖本人项目' },
        { k: '待复核评价', v: `${num(kpi?.pending_evaluations)} 份`, d: '系统已预评' },
        { k: '待回复提问', v: `${num(kpi?.pending_questions)} 条`, d: '学生共性提问' }
      ],
      sections: [
        { h: '本周教学执行', p: `待审核企业需求 ${num(kpi?.pending_requirements)} 条，已发布任务阶段 ${num(kpi?.published_stages)} 个，待复核评价 ${num(kpi?.pending_evaluations)} 份，待回复提问 ${num(kpi?.pending_questions)} 条。` },
        { h: '需要你判断的事', p: '系统已完成客观项预评与提交检查，教师只需处理需要专业判断的部分：需求适配度、评价调整与共性答疑。' },
        { h: '数据来源', p: '以上数字来自业务库 requirements、task_stages、evaluations、questions 实时统计。' }
      ],
      charts: [
        { type: 'bar', title: '待办分布', series: [{ name: '需求审核', value: num(kpi?.pending_requirements) }, { name: '评价复核', value: num(kpi?.pending_evaluations) }, { name: '答疑回复', value: num(kpi?.pending_questions) }] },
        { type: 'bar', title: '学生阶段完成度', series: students.slice(0, 6).map(item => ({ name: item.name, value: num(item.progress), unit: '%' })) }
      ],
      evidence: [ev('业务库 requirements / task_stages / evaluations / questions', '教师本人项目范围')]
    };
  },

  班级画像: async (pool, user, data) => {
    const students = await rows(pool, `SELECT u.display_name name, u.student_no, ce.group_name team,
        ROUND(100*SUM(a.status='passed')/COUNT(a.id)) progress, COALESCE(SUM(a.score),0) score,
        MAX(a.status='revision_required') risk
      FROM class_enrollments ce JOIN classes c ON c.id=ce.class_id JOIN users u ON u.id=ce.student_user_id
      LEFT JOIN task_assignments a ON a.student_user_id=u.id WHERE c.teacher_user_id=? GROUP BY u.id, ce.group_name`, [user.id]);
    const avg = students.length ? Math.round(students.reduce((sum, item) => sum + num(item.progress), 0) / students.length) : 0;
    const risk = students.filter(item => num(item.risk) === 1).length;
    return {
      title: `${data.cls || '当前班级'} · 班级学情画像`,
      metrics: [
        { k: '班级人数', v: `${students.length} 人`, d: data.cls || '绑定班级' },
        { k: '平均进度', v: pct(avg), d: '阶段通过率均值' },
        { k: '需关注', v: `${risk} 人`, d: '存在待返修任务' },
        { k: '过程分合计', v: String(students.reduce((sum, item) => sum + num(item.score), 0)), d: '各阶段累计' }
      ],
      sections: [
        { h: '班级整体', p: `${data.cls || '当前班级'} 共 ${students.length} 人，平均阶段进度 ${pct(avg)}，其中 ${risk} 人存在待返修任务。` },
        { h: '教学重点', p: risk ? `建议对 ${risk} 名待返修学生重点检查边界值判定与单位换算两类问题。` : '班级整体进度正常，可按计划进入下一阶段。' }
      ],
      charts: [
        { type: 'bar', title: '学生阶段完成度', series: students.slice(0, 8).map(item => ({ name: item.name, value: num(item.progress), unit: '%' })) },
        { type: 'bar', title: '过程分累计', series: students.slice(0, 8).map(item => ({ name: item.name, value: num(item.score) })) }
      ],
      evidence: [ev('业务库 class_enrollments / task_assignments', `${students.length} 名学生记录`)]
    };
  },

  任务包说明: async (pool, user, data) => {
    const stages = await rows(pool, `SELECT s.stage_no, s.name, s.duration_hours, s.status, s.acceptance
      FROM task_stages s JOIN projects p ON p.id=s.project_id WHERE p.teacher_user_id=? ORDER BY s.stage_no`, [user.id]);
    const hours = stages.reduce((sum, item) => sum + num(item.duration_hours), 0);
    return {
      title: '实训任务包说明',
      metrics: [
        { k: '任务阶段', v: `${stages.length} 个`, d: `已发布 ${stages.filter(s => s.status === 'published').length} 个` },
        { k: '建议课时', v: `${hours} 课时`, d: '各阶段合计' },
        { k: '验收标准', v: `${stages.filter(s => s.acceptance).length} 项`, d: '已填写验收条款' },
        { k: '草稿阶段', v: `${stages.filter(s => s.status !== 'published').length} 个`, d: '待发布' }
      ],
      sections: [
        { h: '任务包构成', p: `共 ${stages.length} 个阶段，合计 ${hours} 课时；已发布 ${stages.filter(s => s.status === 'published').length} 个，草稿 ${stages.filter(s => s.status !== 'published').length} 个。` },
        { h: '下发与回填', p: '下发由实训系统操作 Skill 承接（接入位 B1），班级进度与成绩回填由同一能力的只读动作承接。' }
      ],
      charts: [{ type: 'bar', title: '各阶段课时', series: stages.map(item => ({ name: `阶段${item.stage_no}`, value: num(item.duration_hours), unit: ' 课时' })) }],
      evidence: [ev('业务库 task_stages', `教师本人项目 ${stages.length} 个阶段`)]
    };
  },

  复核记录: async (pool, user) => {
    const list = await rows(pool, `SELECT e.id, u.display_name student, e.score, e.status, e.comment, e.evidence_summary
      FROM evaluations e JOIN projects p ON p.id=e.project_id JOIN users u ON u.id=e.student_user_id
      WHERE p.teacher_user_id=? ORDER BY e.updated_at DESC`, [user.id]);
    const confirmed = list.filter(item => ['confirmed', 'adjusted'].includes(item.status)).length;
    return {
      title: '评价复核记录',
      metrics: [
        { k: '评价总数', v: `${list.length} 份`, d: '本人项目' },
        { k: '已复核', v: `${confirmed} 份`, d: '已确认或已调整' },
        { k: '待复核', v: `${list.length - confirmed} 份`, d: '系统已预评' },
        { k: '平均分', v: list.length ? String(Math.round(list.reduce((s, i) => s + num(i.score), 0) / list.length)) : '0', d: '业务库实时' }
      ],
      sections: [
        { h: '复核概况', p: `共 ${list.length} 份评价，已复核 ${confirmed} 份，待复核 ${list.length - confirmed} 份。系统已完成客观项预评，教师复核主观项与争议项。` },
        { h: '复核原则', p: '调整评价必须写明理由；返修后重新提交的评价以最新一次为准，历史记录保留可追溯。' }
      ],
      charts: [{ type: 'bar', title: '学生评价分', series: list.slice(0, 8).map(item => ({ name: item.student, value: num(item.score) })) }],
      evidence: [ev('业务库 evaluations', `${list.length} 条评价记录`)]
    };
  },

  /* ---------------- 学生端 ---------------- */
  成长周报: async (pool, user, data) => {
    const levels = await rows(pool, `SELECT s.stage_no no, s.name, a.status, a.score
      FROM task_assignments a JOIN task_stages s ON s.id=a.task_stage_id WHERE a.student_user_id=? ORDER BY s.stage_no`, [user.id]);
    const passed = levels.filter(item => item.status === 'passed').length;
    const score = levels.reduce((sum, item) => sum + num(item.score), 0);
    const logs = await rows(pool, `SELECT DATE(created_at) date, COUNT(*) value FROM process_logs WHERE user_id=? GROUP BY DATE(created_at) ORDER BY date`, [user.id]);
    return {
      title: `第 ${data.week || 4} 教学周 · 成长周报`,
      metrics: [
        { k: '已通过关卡', v: `${passed} / ${levels.length}`, d: '按顺序解锁' },
        { k: '过程分累计', v: String(score), d: '各阶段合计' },
        { k: '活跃天数', v: `${logs.length} 天`, d: '有过程记录' },
        { k: '待返修', v: `${levels.filter(i => i.status === 'revision_required').length} 项`, d: '需补充后重交' }
      ],
      sections: [
        { h: '本周进展', p: `已通过 ${passed} / ${levels.length} 个阶段，过程分累计 ${score} 分，有过程记录 ${logs.length} 天。` },
        { h: '下一步', p: passed < levels.length ? `继续当前关卡：${(levels.find(i => i.status !== 'passed') || {}).name || '下一阶段'}。` : '全部阶段已通过，可生成能力画像与材料包。' }
      ],
      charts: [
        { type: 'bar', title: '各阶段得分', series: levels.map(item => ({ name: `阶段${item.no}`, value: num(item.score) })) },
        { type: 'bar', title: '每日活跃度', series: logs.slice(-7).map(item => ({ name: String(item.date).slice(5), value: num(item.value), unit: ' 次' })) }
      ],
      evidence: [ev('业务库 task_assignments / process_logs', `学生 ${user.display_name || user.id}`)]
    };
  },

  能力画像: async (pool, user) => {
    const levels = await rows(pool, `SELECT s.stage_no no, s.name, a.status, a.score
      FROM task_assignments a JOIN task_stages s ON s.id=a.task_stage_id WHERE a.student_user_id=? ORDER BY s.stage_no`, [user.id]);
    const e = await one(pool, `SELECT score, status, evidence_summary FROM evaluations WHERE student_user_id=? ORDER BY updated_at DESC LIMIT 1`, [user.id]);
    const passed = levels.filter(item => item.status === 'passed').length;
    const score = levels.reduce((sum, item) => sum + num(item.score), 0);
    return {
      title: '能力画像与证据摘要报告',
      metrics: [
        { k: '通过阶段', v: `${passed} / ${levels.length}`, d: '阶段顺序解锁' },
        { k: '过程分', v: String(score), d: '各阶段累计' },
        { k: '综合评价', v: String(num(e?.score)), d: e?.status === 'confirmed' ? '教师已确认' : '系统预评' },
        { k: '证据条目', v: `${levels.length} 条`, d: '阶段提交记录' }
      ],
      sections: [
        { h: '能力结论', p: `已通过 ${passed} / ${levels.length} 个阶段，过程分 ${score} 分。画像依据为阶段提交记录与固定样例测试，不是自评。` },
        { h: '待验证能力', p: '设备维护现场经验、跨班组沟通经验属于待验证项，需在面试或实习中确认。' }
      ],
      charts: [{ type: 'bar', title: '各阶段得分', series: levels.map(item => ({ name: `阶段${item.no}`, value: num(item.score) })) }],
      evidence: [ev('业务库 task_assignments / evaluations', `学生 ${user.display_name || user.id}`), ev(e?.evidence_summary ? String(e.evidence_summary).slice(0, 60) : '阶段提交记录', '评价证据')]
    };
  },

  能力材料包: async (pool, user, data) => {
    const levels = await rows(pool, `SELECT s.stage_no no, s.name, a.status FROM task_assignments a JOIN task_stages s ON s.id=a.task_stage_id WHERE a.student_user_id=? ORDER BY s.stage_no`, [user.id]);
    const visibility = await one(pool, `SELECT * FROM student_visibility WHERE student_user_id=?`, [user.id]);
    const requests = await rows(pool, `SELECT ar.id, o.name company, ar.status FROM authorization_requests ar JOIN organizations o ON o.id=ar.company_org_id WHERE ar.student_user_id=?`, [user.id]);
    const passed = levels.filter(item => item.status === 'passed').length;
    return {
      title: '能力材料包摘要（匿名画像 + 作品证据）',
      metrics: [
        { k: '作品证据', v: `${passed} 项`, d: '已通过阶段产物' },
        { k: '开放状态', v: visibility && visibility.open_to_company ? '已开放' : '未开放', d: '由你本人控制' },
        { k: '授权请求', v: `${requests.length} 条`, d: `已同意 ${requests.filter(r => r.status === 'approved').length} 条` },
        { k: '身份展示', v: visibility && visibility.show_real_name ? '真实姓名' : '匿名编号', d: '默认匿名' }
      ],
      sections: [
        { h: '材料包构成', p: `含 ${passed} 项已通过阶段的作品证据与过程留痕。企业侧在授权前只能看到匿名能力画像。` },
        { h: '授权说明', p: '拒绝授权属独立状态，不会记为能力不合格。你随时可以关闭开放开关。' }
      ],
      charts: [{ type: 'bar', title: '阶段产物完成情况', series: levels.map(item => ({ name: `阶段${item.no}`, value: item.status === 'passed' ? 1 : 0 })) }],
      evidence: [ev('业务库 student_visibility / authorization_requests', `${requests.length} 条授权请求`)]
    };
  }
};

function registerReportData(app, deps) {
  const { pool, wrap, ok, fail } = deps;
  app.post('/api/report-data', wrap(async (req, res) => {
    const kind = String(req.body.kind || '').trim();
    const builder = BUILDERS[kind];
    if (!builder) {
      return ok(res, {
        title: kind || '业务报告',
        metrics: [{ k: '报告类型', v: kind || '未指定', d: '未匹配到聚合规则' }],
        sections: [{ h: '数据说明', p: `报告类型「${kind}」暂无业务库聚合规则，已按最小数据集生成报告。` }],
        charts: [], evidence: [ev('业务库', '未匹配聚合规则')]
      });
    }
    const data = await builder(pool, await resolveReportUser(pool, kind, req.user), req.body.data || {});
    ok(res, data);
  }));
  app.get('/api/report-data/kinds', wrap(async (_req, res) => ok(res, Object.keys(BUILDERS))));
}

/* 报告类接入位在工作流触发面（dispatch）上没有前端做数据补齐，
   这里给后端一个可直接调用的聚合入口，避免接入位因为「只声明了 kind」而 400。 */
async function enrichReportData(pool, { kind, data = {}, user = null }) {
  const builder = BUILDERS[String(kind || '').trim()];
  if (!builder) return null;
  return builder(pool, await resolveReportUser(pool, kind, user), data || {});
}

module.exports = { registerReportData, BUILDERS, DEMO_USER_BY_REPORT_KIND, resolveReportUser, enrichReportData };
