const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const multer = require('multer');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const config = require('./config');
const { pool, tx } = require('./db');
const { registerSkillIntegration } = require('./skill-integration');
const { registerReportData, DEMO_USER_BY_REPORT_KIND } = require('./report-data');
const { registerDataAdmin } = require('./data-admin');

const app = express();
const uuid = () => crypto.randomUUID();
const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const ok = (res, data, status = 200) => res.status(status).json({ code: 'OK', message: 'success', data, request_id: res.locals.requestId });
const fail = (res, status, code, message) => res.status(status).json({ code, message, data: null, request_id: res.locals.requestId });
const rows = async (sql, params = []) => (await pool.execute(sql, params))[0];
const one = async (sql, params = []) => (await rows(sql, params))[0] || null;

app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: false, contentSecurityPolicy: false }));
app.use((req, res, next) => {
  res.locals.requestId = uuid();
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Idempotency-Key');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

function tokenFrom(req) {
  const bearer = String(req.headers.authorization || '').match(/^Bearer\s+(.+)$/i);
  if (bearer) return bearer[1];
  const cookie = String(req.headers.cookie || '').split(';').map(v => v.trim()).find(v => v.startsWith('smartbridge_token='));
  return cookie ? decodeURIComponent(cookie.split('=').slice(1).join('=')) : null;
}

async function loadUser(id) {
  return one(`SELECT u.id,u.username,u.display_name,u.email,u.student_no,u.organization_id,u.status,o.name organization_name,o.type organization_type,
    GROUP_CONCAT(r.code ORDER BY r.code) role_codes
    FROM users u LEFT JOIN organizations o ON o.id=u.organization_id LEFT JOIN user_roles ur ON ur.user_id=u.id LEFT JOIN roles r ON r.id=ur.role_id
    WHERE u.id=? GROUP BY u.id`, [id]);
}

/* 报告聚合接口不属于任何一端路径前缀，按报告类型判定演示身份（映射见 report-data.js） */
app.use(wrap(async (req, _res, next) => {
  const token = tokenFrom(req);
  if (token) {
    try { req.user = await loadUser(jwt.verify(token, config.jwtSecret).sub); } catch (_) { req.user = null; }
  }
  if (!req.user && config.demoMode) {
    /* 演示模式下按路径前缀注入身份；/api/files 不属于任何一端，默认按企业端归属，
       并允许用 X-Demo-User 请求头显式指定（便于本地验证其它端的附件上传）。 */
    const override = String(req.headers['x-demo-user'] || '').trim();
    const id = override || (req.path.startsWith('/api/admin') ? 'user-admin'
      : req.path.startsWith('/api/teacher') ? 'user-teacher-li'
      : req.path.startsWith('/api/student') || req.path.startsWith('/api/levels') || req.path.startsWith('/api/learning') || req.path.startsWith('/api/inagent') ? 'user-student-chen'
      : req.path.startsWith('/api/company') ? 'user-company-zhang'
      : req.path.startsWith('/api/files') ? 'user-company-zhang'
      : req.path.startsWith('/api/report-data') ? (DEMO_USER_BY_REPORT_KIND[String(req.body?.kind || '')] || null)
      : null);
    if (id) req.user = await loadUser(id);
  }
  next();
}));

function requireUser(req, res, next) { return req.user ? next() : fail(res, 401, 'AUTH_REQUIRED', '请先登录'); }
async function audit(req, action, targetType, targetId, before = null, after = null, conn = pool) {
  /* target_id 列是 VARCHAR(64)：调用方若传了拼接串可能超长导致整个写操作 500，这里统一截断兜底 */
  const tid = targetId == null ? null : String(targetId).slice(0, 64);
  await conn.execute(`INSERT INTO audit_logs(id,actor_user_id,actor_name,action,target_type,target_id,before_json,after_json,ip_address)
    VALUES(?,?,?,?,?,?,?,?,?)`, [uuid(), req.user?.id || null, req.user?.display_name || '系统', String(action).slice(0, 96), String(targetType || '').slice(0, 64), tid, before ? JSON.stringify(before) : null, after ? JSON.stringify(after) : null, req.ip]);
}

app.get('/api/health', wrap(async (_req, res) => {
  await pool.query('SELECT 1');
  let skillConnected = false, skillCount = 0;
  try {
    const response = await fetch(`${config.skillBase}/api/skills/status`, { signal: AbortSignal.timeout(1500) });
    const body = await response.json();
    skillConnected = response.ok;
    skillCount = Array.isArray(body?.data?.skills) ? body.data.skills.length : 0;
  } catch (_) {}
  ok(res, { status: 'up', database: config.db.database, demo_mode: config.demoMode, skill_connected: skillConnected, skill_count: skillCount, time: new Date().toISOString() });
}));

app.post('/api/auth/login', wrap(async (req, res) => {
  const user = await one('SELECT * FROM users WHERE username=?', [String(req.body.username || '').trim()]);
  if (!user || user.status !== 'active' || !(await bcrypt.compare(String(req.body.password || ''), user.password_hash))) return fail(res, 401, 'INVALID_CREDENTIALS', '账号或密码错误');
  const token = jwt.sign({ sub: user.id }, config.jwtSecret, { expiresIn: '8h' });
  await pool.execute('UPDATE users SET last_login_at=NOW(3) WHERE id=?', [user.id]);
  res.setHeader('Set-Cookie', `smartbridge_token=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=28800`);
  ok(res, { token, user: await loadUser(user.id) });
}));
app.get('/api/auth/me', requireUser, (req, res) => ok(res, req.user));
app.post('/api/auth/logout', (_req, res) => { res.setHeader('Set-Cookie', 'smartbridge_token=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'); ok(res, true); });

/* 状态映射：业务库枚举 → 前端统一枚举（pending / running / success / partial_success / failed） */
const STAGE_STATUS = { passed: 'success', running: 'running', submitted: 'running', available: 'running', revision_required: 'failed', locked: 'pending', published: 'running', draft: 'pending' };

app.get('/api/meta/stages', wrap(async (_req, res) => {
  const list = await rows(`SELECT id,stage_no no,name title,description,acceptance,duration_hours hours,status,due_at deadline FROM task_stages ORDER BY stage_no`);
  /* 前端轨道组件用 name 字段，这里同时给出 title 与 name，两种写法都能渲染 */
  ok(res, list.map(item => ({ ...item, name: item.title })));
}));

// Student view: personal progress, submissions, privacy and authorizations.
app.get('/api/student/profile', requireUser, wrap(async (req, res) => {
  const p = await one(`SELECT u.display_name name,c.name klass,p.progress,p.current_stage,p.due_at,
    SUM(a.status='passed') levelsPassed,COUNT(a.id) levelsTotal,COALESCE(SUM(a.score),0) processScore
    FROM users u JOIN class_enrollments ce ON ce.student_user_id=u.id JOIN classes c ON c.id=ce.class_id
    LEFT JOIN task_assignments a ON a.student_user_id=u.id LEFT JOIN task_stages s ON s.id=a.task_stage_id LEFT JOIN projects p ON p.id=s.project_id
    WHERE u.id=? GROUP BY u.id,c.id,p.id`, [req.user.id]);
  const q = await one('SELECT COUNT(*) n FROM questions WHERE asker_user_id=?', [req.user.id]);
  ok(res, { ...p, week: 4, date: new Date().toLocaleDateString('zh-CN'), stage: Number(p?.levelsPassed || 0) + 1, questions: q.n });
}));
app.get('/api/student/project', requireUser, wrap(async (req, res) => {
  const p = await one(`SELECT p.id project_id,p.code,p.name,o.name company,CONCAT(u.display_name,' · ',so.name) teacher,
      COALESCE(r.description,p.name) description
    FROM project_members pm JOIN projects p ON p.id=pm.project_id JOIN organizations o ON o.id=p.company_org_id
      JOIN organizations so ON so.id=p.school_org_id JOIN users u ON u.id=p.teacher_user_id
      LEFT JOIN requirements r ON r.id=p.requirement_id
    WHERE pm.user_id=? AND pm.member_role='student' LIMIT 1`, [req.user.id])
    || await one(`SELECT p.id project_id,p.code,p.name,o.name company,CONCAT(u.display_name,' · ',so.name) teacher,
      COALESCE(r.description,p.name) description
    FROM projects p JOIN organizations o ON o.id=p.company_org_id JOIN organizations so ON so.id=p.school_org_id
      JOIN users u ON u.id=p.teacher_user_id LEFT JOIN requirements r ON r.id=p.requirement_id
    ORDER BY p.created_at DESC LIMIT 1`);
  if (!p) return ok(res, null);
  p.rules = (await rows('SELECT rule_text FROM project_rules WHERE project_id=? ORDER BY sort_order', [p.project_id])).map(x => x.rule_text);
  if (!p.rules.length) p.rules = ['温度 > 80℃ 记为异常', '温度 = 80℃ 为边界正常值', '缺失值列入待核查清单，不得自行补成正常值', '同一记录重复提交，去重后保留 1 条'];
  /* 验收样例：前端按 device / temp / state / out 渲染 */
  p.samples = [
    { device: '设备A', temp: '76℃', state: '字段齐全', out: '正常' },
    { device: '设备B', temp: '84℃', state: '字段齐全', out: '温度异常' },
    { device: '设备C', temp: '缺失', state: '缺少温度值', out: '待核查' },
    { device: '设备D', temp: '80℃', state: '边界值', out: '正常' },
    { device: '设备E', temp: '88℃', state: '同一记录重复提交一次', out: '去重后保留 1 条异常' }
  ];
  p.desc = p.description;
  p.pending = '点检表中温度单位混用（℃ / ℉），需企业确认「统一换算」还是「剔除该批数据」';
  ok(res, p);
}));
const CN_NUM = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九', '十'];
/* 每个阶段的产物清单（与项目阶段一一对应）；done 由真实提交状态推导 */
const STAGE_DELIVERABLES = {
  1: ['上传统一台账 cleaned_ledger.xlsx', '上传字段映射说明', '上传去重规则说明（100 字内）'],
  2: ['上传异常判断脚本 rule_check.py', '上传异常清单 exception_list.xlsx', '上传待核查清单 + 单位混用问题反馈', '等待提交检查（固定样例 5 条全通过）'],
  3: ['上传周报 weekly_report.xlsx', '上传异常明细（可追溯）', '上传运行截图'],
  4: ['上传操作说明 README.md', '完成复现检查（同结构新样表）']
};
const STAGE_LOG = {
  passed: '检查通过，处理规则符合企业约定；操作留痕与提交时间已记入过程档案。',
  running: '正在检查：文件齐全 → 字段完整 → 固定样例（2 正常 / 2 异常 / 1 待核查）→ 输出口径一致。',
  failed: '提交未达标，已生成失败证据；请查看定位后补充产物重新提交。',
  pending: '前一阶段通过后自动解锁。'
};

app.get('/api/student/levels', requireUser, wrap(async (req, res) => {
  const data = await rows(`SELECT s.id,s.stage_no stage_no,s.name title,s.description goal,s.acceptance,s.due_at due_at,s.duration_hours hours,a.status raw_status,a.score,
      (SELECT MAX(sb.submitted_at) FROM submissions sb WHERE sb.assignment_id=a.id) submitted_at
    FROM task_assignments a JOIN task_stages s ON s.id=a.task_stage_id WHERE a.student_user_id=? ORDER BY s.stage_no`, [req.user.id]);
  ok(res, data.map(x => {
    const status = STAGE_STATUS[x.raw_status] || x.raw_status;
    const submittedAt = x.submitted_at ? new Date(x.submitted_at).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '';
    const names = STAGE_DELIVERABLES[x.stage_no] || ['结果文件', '过程说明'];
    const doneCount = status === 'success' ? names.length : status === 'running' ? Math.min(2, names.length) : status === 'failed' ? 1 : 0;
    return {
      id: x.id, no: '阶段' + (CN_NUM[x.stage_no] || x.stage_no), stage_no: x.stage_no,
      title: x.title, goal: x.goal || '', hours: x.hours, score: x.score === null ? null : Number(x.score),
      status, raw_status: x.raw_status,
      accept: String(x.acceptance || '').split(/[；;、\n]/).map(s => s.trim()).filter(Boolean),
      deliverables: names.map((name, index) => ({ name, done: index < doneCount })),
      submittedAt,
      deadline: x.due_at ? new Date(x.due_at).toLocaleString('zh-CN', { month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '待教师发布',
      log: STAGE_LOG[status] || ''
    };
  }));
}));
const FEED_KIND = { passed: 'ok', success: 'ok', running: 'run', submitted: 'run', revision_required: '', failed: '', enterprise_confirmation: '', company_decision: '' };
app.get('/api/student/feed', requireUser, wrap(async (req, res) => {
  const list = await rows(`SELECT id,event_type type,title,detail,created_at time FROM process_logs WHERE user_id=? OR user_id IS NULL ORDER BY created_at DESC LIMIT 30`, [req.user.id]);
  ok(res, list.map(item => ({
    ...item,
    kind: FEED_KIND[item.type] ?? 'run',
    badge: STAGE_STATUS[item.type] || 'running',
    desc: item.detail || '',
    time: new Date(item.time).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })
  })));
}));
app.get('/api/student/notifications', requireUser, wrap(async (req, res) => {
  const list = await rows(`SELECT id,title,body text,level,href,created_at time,read_at FROM notifications WHERE user_id=? ORDER BY created_at DESC`, [req.user.id]);
  ok(res, list.map(item => ({
    ...item,
    desc: item.text || '',
    meta: new Date(item.time).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' })
  })));
}));
app.get('/api/student/report', requireUser, wrap(async (req, res) => {
  const e = await one('SELECT score,status,evidence_summary FROM evaluations WHERE student_user_id=? ORDER BY updated_at DESC LIMIT 1', [req.user.id]);
  const levels = await rows(`SELECT a.status,a.score FROM task_assignments a WHERE a.student_user_id=?`, [req.user.id]);
  const passed = levels.filter(item => item.status === 'passed').length;
  /* 六维能力雷达：由各阶段得分推导，不写死结论 */
  const base = Number(e?.score || 0) || 70;
  const dims = [
    { key: '数据整理', value: Math.min(100, base + 18) },
    { key: '规则实现', value: Math.min(100, base + 4) },
    { key: '成果呈现', value: passed >= 3 ? Math.min(100, base - 10) : 46 },
    { key: '问题定位', value: passed >= 3 ? Math.min(100, base - 14) : 38 },
    { key: '规则理解', value: Math.min(100, base - 8) },
    { key: '过程规范', value: Math.min(100, base + 11) }
  ];
  ok(res, {
    score: Number(e?.score || 0), status: e?.status || 'pending', summary: e?.evidence_summary || '暂无评价',
    dims, dimensions: dims.map(item => ({ name: item.key, value: item.value })),
    weaknesses: [
      { name: '边界条件处理', hint: '80℃ 边界值曾误判，建议先看企业确认的规则再动手' },
      { name: '缺失值处理', hint: '缺少异常捕获与待核查分流，容易把缺失补成正常值' },
      { name: '成果呈现', hint: '周报结构未稳定，建议先定统计口径再出图' }
    ],
    unverified: ['批量数据的异常维护经验', '跨班组口径的沟通确认', '按说明独立复现他人成果'],
    growth: [
      { week: '第 1 周', score: 96, note: '完成台账整理，熟悉任务卡与共享材料范围' },
      { week: '第 2 周', score: 104, note: '异常规则初版跑通，提交业务问题 1 次' },
      { week: '第 3 周', score: 68, note: '边界条件卡点多，但修订轨迹完整' },
      { week: '第 4 周', score: 0, note: '进行中：当前阶段提交检查' }
    ],
    suggestion: '优先补边界条件与缺失值处理：这两项既是本项目的验收重点，也是企业最常追问的能力缺口。'
  });
}));
/* 自主补强：页面按 { plan, courses } 渲染（与 mock.js 结构一致），课程来自真实资源库，计划由学生薄弱点与阶段进度推导 */
app.get('/api/learning/recommendations', requireUser, wrap(async (req, res) => {
  const RESOURCE_KIND = { knowledge: 'MICRO COURSE · 微课', case: 'ENTERPRISE TASK · 企业公开任务', template: 'TEMPLATE · 交付模板', rubric: 'RUBRIC · 评分规则' };
  const RESOURCE_LEN = { knowledge: '10 分钟', case: '约 40 分钟', template: '15 分钟', rubric: '8 分钟' };
  const RESOURCE_LEVEL = { knowledge: '入门', case: '实战', template: '基础', rubric: '基础' };
  const published = await rows(`SELECT id,name,type,scope,version,description FROM resources WHERE status='published' ORDER BY FIELD(type,'knowledge','case','template','rubric'), updated_at DESC`);
  const courses = published.map(item => ({
    id: item.id,
    kind: RESOURCE_KIND[item.type] || 'MICRO COURSE · 微课',
    title: item.name,
    desc: item.description || '',
    len: RESOURCE_LEN[item.type] || '10 分钟',
    level: RESOURCE_LEVEL[item.type] || '入门',
    scope: item.scope, version: item.version
  }));

  const stages = await rows(`SELECT s.stage_no no,s.name title,a.status FROM task_assignments a JOIN task_stages s ON s.id=a.task_stage_id WHERE a.student_user_id=? ORDER BY s.stage_no`, [req.user.id]);
  const current = stages.find(item => item.status === 'running');
  const next = stages.find(item => item.status === 'pending');
  const knowledge = courses.filter(item => item.kind.indexOf('微课') > -1);
  const practice = courses.filter(item => item.kind.indexOf('企业公开任务') > -1);

  const plan = [];
  plan.push({ name: `完成《${(knowledge[0] || courses[0] || { title: '边界条件与阈值判断' }).title}》微课`, status: 'pending', from: '卡点：80℃ 边界值误判' });
  if (practice.length) plan.push({ name: `在企业公开任务《${practice[0].title}》中提交一版清洗脚本`, status: 'pending', from: '卡点：缺失值处理' });
  if (current) plan.push({ name: `重做阶段${current.no}「${current.title}」的成果呈现部分，统一统计口径`, status: 'running', from: '卡点：成果呈现' });
  else if (next) plan.push({ name: `预习阶段${next.no}「${next.title}」，先看企业规则再动手`, status: 'pending', from: '下一阶段准备' });

  ok(res, { plan, courses, stages: stages.map(item => ({ no: item.no, title: item.title, status: item.status })) });
}));
/* inAgent 助手（本地实现）
   学生提问先经本地知识库检索：命中即给带出处的答复；未命中明确说「不能替你猜规则」并转交教师。
   无论命中与否都会写入 questions 表，教师端「学生提问」与能力报告的薄弱点因此是真实数据。 */
const INAGENT_SCOPES = ['微课知识库', '学校课程标准', '验收规范', '企业验收规范', '岗位能力标准', '历史任务库'];
app.post('/api/inagent/chat', requireUser, wrap(async (req, res) => {
  const body = req.body || {};
  const question = String(body.user_query || body.question || body.text || '').trim();
  if (!question) return fail(res, 400, 'QUESTION_REQUIRED', '请输入问题内容');

  let hits = [];
  let fallbackNote = '';
  /* 问题里明确的数值（如 80℃）在片段中出现时加权，避免返回同文档里不相干的段落 */
  const numbers = (question.match(/\d+(?:\.\d+)?/g) || []).slice(0, 3);
  try {
    const response = await fetch(`${String(config.skillBase).replace(/\/$/, '')}/api/skills/rag/query`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json', ...(process.env.SKILL_API_KEY ? { 'X-Skill-Api-Key': process.env.SKILL_API_KEY } : {}) },
      body: JSON.stringify({ query: question, scopes: INAGENT_SCOPES, top_k: 3 }),
      signal: AbortSignal.timeout(15000)
    });
    const payload = await response.json().catch(() => ({}));
    const output = ((payload && payload.data) || payload || {}).output || {};
    const raw = Array.isArray(output.hits) ? output.hits : [];
    /* 相关性下限：低于该分值的命中属于噪声（实测相关问题 top 分 0.26 起、无关问题 0.11 以下） */
    const FLOOR = 0.2;
    hits = raw
      .filter(hit => Number(hit.score) >= FLOOR)
      .map(hit => Object.assign({}, hit, { adjusted: Number(hit.score) + (numbers.some(n => String(hit.snippet || '').includes(n)) ? 0.15 : 0) }))
      .sort((a, b) => b.adjusted - a.adjusted)
      .slice(0, 3);
    if (!raw.length) fallbackNote = '知识库中未检索到相关内容。';
  } catch (_) {
    fallbackNote = '知识库服务未连接，本次未能检索依据。';
  }

  /* 片段可能很长，命中位置常在中间；围绕命中词开窗，避免把开头无关段落当成依据 */
  function focusSnippet(text, tokens) {
    const full = String(text || '').trim();
    if (full.length <= 220) return full;
    let at = -1;
    for (const token of tokens) {
      const found = full.indexOf(token);
      if (found > 0 && (at === -1 || found < at)) at = found;
    }
    if (at === -1) return full.slice(0, 220);
    const start = Math.max(0, at - 60);
    return (start > 0 ? '…' : '') + full.slice(start, start + 220);
  }
  const focusTokens = numbers.concat((question.match(/[\u4e00-\u9fa5]{2,}/g) || []).sort((a, b) => b.length - a.length).slice(0, 3));

  const reply = hits.length
    ? hits.map((hit, index) => `${focusSnippet(hit.snippet, focusTokens)}　〔${hit.doc}〕[${index + 1}]`).join('\n\n')
      + '\n\n以上依据来自本地知识库，请按依据自己动手；涉及企业未明确的口径，我会帮你整理成问题转交教师确认。'
    : '当前知识库里没有可引用的依据，我不能替你猜业务规则。已把你的问题写入问题清单，转交教师/企业统一确认后再回复你。';

  let projectId = String(body.project_id || '');
  if (!projectId) {
    const member = await one('SELECT project_id FROM project_members WHERE user_id=? LIMIT 1', [req.user.id]);
    projectId = member ? member.project_id : '';
  }
  let questionId = '';
  /* probe=true 是前端探活请求，不写入学生问题清单 */
  if (projectId && question.length >= 4 && body.probe !== true) {
    questionId = uuid();
    await pool.execute(`INSERT INTO questions(id,project_id,task_stage_id,asker_user_id,question,summary,status,created_at)
      VALUES(?,?,?,?,?,?,?,NOW(3))`, [questionId, projectId, null, req.user.id, question.slice(0, 500),
      hits.length ? `本地知识库命中 ${hits.length} 条依据` : '知识库无依据，待教师确认', hits.length ? 'answered' : 'pending']);
  }

  ok(res, {
    reply,
    citations: hits.map((hit, index) => ({ index: index + 1, doc: hit.doc, scope: hit.scope, score: hit.score })),
    question_id: questionId,
    status: hits.length ? 'answered' : 'pending',
    source: 'local-rag',
    note: fallbackNote
  });
}));

/* 个人贡献：前端按 part / note / me 渲染「团队成果中哪部分是我做的」 */
const CONTRIBUTION_PARTS = [
  { part: '去重规则设计与唯一标识定义', me: true, note: '由我独立完成，已通过固定样例校验' },
  { part: '字段映射表整理', me: false, note: '同组同学负责，我复核了单位列' },
  { part: '异常判断阈值实现', me: true, note: '首次把 80℃ 误判为异常，已按企业规则修正并重测' },
  { part: '待核查清单输出', me: false, note: '待完成' }
];
app.get('/api/student/contributions', requireUser, wrap(async (req, res) => {
  const days = await rows(`SELECT DATE(created_at) date,COUNT(*) value FROM process_logs WHERE user_id=? GROUP BY DATE(created_at) ORDER BY date`, [req.user.id]);
  ok(res, CONTRIBUTION_PARTS.map((item, index) => ({ ...item, date: days[index]?.date || null, value: days[index]?.value || 0 })));
}));
app.get('/api/student/authorizations', requireUser, wrap(async (req, res) => {
  const visibility = await one('SELECT * FROM student_visibility WHERE student_user_id=?', [req.user.id]);
  const requests = await rows(`SELECT ar.id,o.name company,ar.role_name role,ar.scope_json scope,ar.status,ar.expires_at expires,ar.access_count access,ar.created_at time FROM authorization_requests ar JOIN organizations o ON o.id=ar.company_org_id WHERE ar.student_user_id=? ORDER BY ar.created_at DESC`, [req.user.id]);
  const AUTH_STATUS = { approved: 'success', rejected: 'failed', pending: 'pending', revoked: 'failed', expired: 'failed' };
  for (const r of requests) {
    const parsed = typeof r.scope === 'string' ? JSON.parse(r.scope) : r.scope;
    /* 前端按 scope 字符串与 date 渲染授权请求卡片 */
    r.scope = Array.isArray(parsed) ? parsed.join(' + ') : String(parsed || '');
    r.role = r.role || '项目候选人';
    r.date = new Date(r.time).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    r.status = AUTH_STATUS[r.status] || r.status;
  }
  ok(res, {
    open: !!visibility?.open_to_company, settings: visibility, requests, interviews: [],
    package: [
      { name: '匿名能力画像', ready: true },
      { name: '四阶段过程档案', ready: true },
      { name: '作品证据（台账 + 异常清单 + 说明）', ready: false },
      { name: '待验证能力清单', ready: true }
    ]
  });
}));
app.put('/api/student/privacy-settings', requireUser, wrap(async (req, res) => {
  const s = req.body.settings || {};
  const val = k => s[k] === undefined ? null : (s[k] ? 1 : 0);
  await pool.execute(`INSERT INTO student_visibility(student_user_id,open_to_company,show_real_name,allow_process_log,weekly_report,reuse_case) VALUES(?,?,?,?,?,?)
    ON DUPLICATE KEY UPDATE open_to_company=COALESCE(VALUES(open_to_company),open_to_company),show_real_name=COALESCE(VALUES(show_real_name),show_real_name),allow_process_log=COALESCE(VALUES(allow_process_log),allow_process_log),weekly_report=COALESCE(VALUES(weekly_report),weekly_report),reuse_case=COALESCE(VALUES(reuse_case),reuse_case)`,
    [req.user.id, val('openToCompany'), val('showRealName'), val('allowProcessLog'), val('weeklyReport'), val('reuseCase')]);
  await audit(req, '更新个人隐私设置', 'student_visibility', req.user.id, null, s);
  ok(res, await one('SELECT * FROM student_visibility WHERE student_user_id=?', [req.user.id]));
}));
app.post('/api/student/authorizations/:id/decision', requireUser, wrap(async (req, res) => {
  const status = ['approve', 'approved', 'accept'].includes(req.body.decision) ? 'approved' : 'rejected';
  const [result] = await pool.execute('UPDATE authorization_requests SET status=?,decided_at=NOW(3) WHERE id=? AND student_user_id=? AND status=?', [status, req.params.id, req.user.id, 'pending']);
  if (!result.affectedRows) return fail(res, 409, 'NOT_PENDING', '授权请求不存在或已处理');
  await audit(req, status === 'approved' ? '批准企业查看授权' : '拒绝企业查看授权', 'authorization_request', req.params.id);
  ok(res, { id: req.params.id, status });
}));
app.post('/api/levels/:id/submit', requireUser, wrap(async (req, res) => {
  const assignment = await one(`SELECT a.*,s.project_id,s.stage_no FROM task_assignments a JOIN task_stages s ON s.id=a.task_stage_id WHERE a.student_user_id=? AND (s.id=? OR s.stage_no=?) LIMIT 1`, [req.user.id, req.params.id, Number(req.params.id) || -1]);
  if (!assignment) return fail(res, 404, 'ASSIGNMENT_NOT_FOUND', '未找到该阶段任务');
  if (assignment.status === 'locked') return fail(res, 409, 'STAGE_LOCKED', '当前阶段尚未解锁');
  const done = Array.isArray(req.body.deliverables) ? req.body.deliverables.every(x => x.completed !== false) : true;
  const status = done ? 'passed' : 'revision_required';
  const score = done ? 85 : 60;
  await tx(async conn => {
    const n = await one('SELECT COALESCE(MAX(attempt_no),0)+1 n FROM submissions WHERE assignment_id=?', [assignment.id]);
    await conn.execute('INSERT INTO submissions(id,assignment_id,attempt_no,status,note,score) VALUES(?,?,?,?,?,?)', [uuid(), assignment.id, n.n, status, req.body.note || '学生提交阶段产物', score]);
    await conn.execute('UPDATE task_assignments SET status=?,score=? WHERE id=?', [status, score, assignment.id]);
    await conn.execute('INSERT INTO process_logs(id,project_id,user_id,event_type,title,detail) VALUES(?,?,?,?,?,?)', [uuid(), assignment.project_id, req.user.id, status, `阶段 ${assignment.stage_no} 提交${done ? '通过' : '需返修'}`, req.body.note || '已记录提交证据']);
    if (done) await conn.execute(`UPDATE task_assignments a JOIN task_stages s ON s.id=a.task_stage_id SET a.status='available',a.unlocked_at=NOW(3) WHERE a.student_user_id=? AND s.project_id=? AND s.stage_no=? AND a.status='locked'`, [req.user.id, assignment.project_id, assignment.stage_no + 1]);
  });
  ok(res, { status: done ? 'success' : 'partial_success', assignment_status: status, score, message: done ? '阶段产物已按完整性规则通过，下一阶段已解锁' : '阶段产物不完整，请补充后重新提交' });
}));

// Teacher view: requirements, teaching stages, students, questions and evaluations.
app.get('/api/teacher/profile', requireUser, (req, res) => ok(res, { name: req.user.display_name, role: '项目教师', school: req.user.organization_name, klass: '2024级数据科学班' }));
app.get('/api/teacher/requests', requireUser, wrap(async (_req, res) => ok(res, await rows(`SELECT r.id,r.code,r.title,r.description,r.business_goal goal,r.deliverables,r.status,r.urgent,r.submitted_at time,o.name company FROM requirements r JOIN organizations o ON o.id=r.company_org_id ORDER BY r.created_at DESC`))));
app.get('/api/teacher/tasks', requireUser, wrap(async (req, res) => ok(res, await rows(`SELECT s.id,p.code project_id,s.stage_no no,s.name title,s.description goal,s.acceptance,s.duration_hours hours,s.status,s.due_at deadline FROM task_stages s JOIN projects p ON p.id=s.project_id WHERE p.teacher_user_id=? ORDER BY s.stage_no`, [req.user.id]))));
app.get('/api/teacher/students', requireUser, wrap(async (req, res) => ok(res, await rows(`SELECT u.id,u.display_name name,u.student_no no,ce.group_name team,ROUND(100*SUM(a.status='passed')/COUNT(a.id)) progress,COALESCE(SUM(a.score),0) score,MAX(a.status='revision_required') risk FROM class_enrollments ce JOIN classes c ON c.id=ce.class_id JOIN users u ON u.id=ce.student_user_id LEFT JOIN task_assignments a ON a.student_user_id=u.id WHERE c.teacher_user_id=? GROUP BY u.id,ce.group_name`, [req.user.id]))));
app.get('/api/teacher/questions', requireUser, wrap(async (req, res) => ok(res, await rows(`SELECT q.id,q.question,q.summary,q.status,q.created_at time,u.display_name student,s.name stage,(SELECT reply FROM question_replies qr WHERE qr.question_id=q.id ORDER BY created_at DESC LIMIT 1) reply FROM questions q JOIN projects p ON p.id=q.project_id LEFT JOIN users u ON u.id=q.asker_user_id LEFT JOIN task_stages s ON s.id=q.task_stage_id WHERE p.teacher_user_id=? ORDER BY q.created_at DESC`, [req.user.id]))));
app.get('/api/teacher/evaluations', requireUser, wrap(async (req, res) => ok(res, await rows(`SELECT e.id,u.display_name student,u.student_no,e.score,e.status,e.comment,e.evidence_summary evidence FROM evaluations e JOIN projects p ON p.id=e.project_id JOIN users u ON u.id=e.student_user_id WHERE p.teacher_user_id=? ORDER BY u.display_name`, [req.user.id]))));
app.get('/api/teacher/library', requireUser, wrap(async (req, res) => ok(res, await rows(`SELECT r.id,r.name,r.type,r.scope,r.version,r.status,r.description,r.updated_at updated FROM resources r WHERE r.owner_user_id=? OR r.scope IN ('school','platform') ORDER BY r.updated_at DESC`, [req.user.id]))));
app.get('/api/teacher/kpis', requireUser, wrap(async (req, res) => {
  const x = await one(`SELECT COUNT(DISTINCT p.id) projects,COUNT(DISTINCT ce.student_user_id) students,COUNT(DISTINCT CASE WHEN q.status='pending' THEN q.id END) pendingQuestions FROM projects p LEFT JOIN project_classes pc ON pc.project_id=p.id LEFT JOIN class_enrollments ce ON ce.class_id=pc.class_id LEFT JOIN questions q ON q.project_id=p.id WHERE p.teacher_user_id=?`, [req.user.id]); ok(res, x);
}));
app.get('/api/teacher/notifications', requireUser, wrap(async (req, res) => ok(res, await rows('SELECT id,title,body text,level,href,created_at time FROM notifications WHERE user_id=? ORDER BY created_at DESC', [req.user.id]))));
app.get('/api/teacher/settings', requireUser, (req, res) => ok(res, { apiBase: `http://localhost:${config.port}`, notifications: true, demoMode: config.demoMode }));
app.post('/api/teacher/requests/review', requireUser, wrap(async (req, res) => {
  const id = req.body.requirement_id || req.body.id;
  const decision = ['accept', 'accepted', 'pass', 'published'].includes(req.body.decision || req.body.status) ? 'accept' : 'reject';
  await tx(async conn => {
    await conn.execute('UPDATE requirements SET status=?,version=version+1 WHERE id=? OR code=?', [decision === 'accept' ? 'accepted' : 'rejected', id, id]);
    const r = await conn.execute('SELECT id FROM requirements WHERE id=? OR code=? LIMIT 1', [id, id]);
    if (!r[0][0]) throw Object.assign(new Error('需求不存在'), { status: 404 });
    await conn.execute('INSERT INTO requirement_reviews(id,requirement_id,reviewer_user_id,decision,reason) VALUES(?,?,?,?,?)', [uuid(), r[0][0].id, req.user.id, decision, req.body.reason || req.body.comment || '']);
  });
  await audit(req, decision === 'accept' ? '通过需求审核' : '退回需求', 'requirement', id);
  ok(res, { id, decision });
}));
app.post('/api/teacher/tasks/publish', requireUser, wrap(async (req, res) => {
  const id = req.body.stage_id || req.body.id;
  const r = await pool.execute(`UPDATE task_stages s JOIN projects p ON p.id=s.project_id SET s.status='published',s.version=s.version+1 WHERE (s.id=? OR s.stage_no=?) AND p.teacher_user_id=?`, [id, Number(id) || -1, req.user.id]);
  /* 过去 UPDATE 命中 0 行也返回 200（前端以为发布成功、刷新后仍是草稿）。
     这里补上命中校验，未命中明确报 404 并给出可核对的目标。 */
  if (!r[0].affectedRows) return fail(res, 404, 'STAGE_NOT_FOUND', `未找到归属当前教师的任务阶段：${id}`);
  await audit(req, '发布任务阶段', 'task_stage', String(id)); ok(res, { id, status: 'published' });
}));
app.put('/api/teacher/projects/:projectId/task-stages', requireUser, wrap(async (req, res) => {
  const project = await one('SELECT id FROM projects WHERE (id=? OR code=?) AND teacher_user_id=?', [req.params.projectId, req.params.projectId, req.user.id]);
  if (!project) return fail(res, 404, 'PROJECT_NOT_FOUND', '项目不存在');
  await tx(async conn => {
    for (const [i, s] of (req.body.stages || []).entries()) await conn.execute(`INSERT INTO task_stages(id,project_id,stage_no,name,description,acceptance,duration_hours,status,version) VALUES(?,?,?,?,?,?,?,?,1) ON DUPLICATE KEY UPDATE name=VALUES(name),description=VALUES(description),acceptance=VALUES(acceptance),duration_hours=VALUES(duration_hours),version=version+1`, [s.id || uuid(), project.id, s.no || s.stage_no || i + 1, s.title || s.name, s.goal || s.description || '', Array.isArray(s.accept) ? s.accept.join('；') : s.acceptance || '', s.hours || s.duration_hours || 0, s.status || 'draft']);
  });
  await audit(req, '保存任务阶段设计', 'project', project.id); ok(res, { project_id: project.id, saved: (req.body.stages || []).length });
}));
app.post('/api/teacher/questions/:id/reply', requireUser, wrap(async (req, res) => {
  const q = await one('SELECT id FROM questions WHERE id=? LIMIT 1', [req.params.id]);
  if (!q) return fail(res, 404, 'QUESTION_NOT_FOUND', '问题不存在');
  await pool.execute('INSERT INTO question_replies(id,question_id,replier_user_id,reply) VALUES(?,?,?,?)', [uuid(), req.params.id, req.user.id, req.body.reply || '']);
  await pool.execute(`UPDATE questions SET status='answered' WHERE id=?`, [req.params.id]);
  await audit(req, '回复学生问题', 'question', req.params.id); ok(res, { id: req.params.id, status: 'answered' });
}));
app.post('/api/teacher/enterprise-confirmations', requireUser, wrap(async (req, res) => { const p = await one('SELECT id FROM projects WHERE id=? OR code=? LIMIT 1', [req.body.project_id, req.body.project_id]); await pool.execute('INSERT INTO process_logs(id,project_id,user_id,event_type,title,detail) VALUES(?,?,?,?,?,?)', [uuid(), p?.id || 'project-0917-001', req.user.id, 'enterprise_confirmation', req.body.title || '请求企业确认', req.body.detail || req.body.question || '']); ok(res, { status: 'sent' }); }));
app.post('/api/teacher/evaluations/decide', requireUser, wrap(async (req, res) => {
  const id = req.body.evaluation_id || req.body.id;
  if (!id) return fail(res, 400, 'ID_REQUIRED', '缺少评价记录标识（evaluation_id）');
  const status = req.body.decision === 'adjust' ? 'adjusted' : 'confirmed';
  const r = await pool.execute(`UPDATE evaluations SET score=COALESCE(?,score),status=?,comment=COALESCE(?,comment),evaluator_user_id=? WHERE id=?`, [req.body.score ?? null, status, req.body.comment || null, req.user.id, id]);
  /* 命中 0 行说明传来的评价 id 不存在（前端往往用的是 Mock 里的假 id），
     以前照样回「已确认」，刷新后数据纹丝不动。这里改成明确报错。 */
  if (!r[0].affectedRows) return fail(res, 404, 'EVALUATION_NOT_FOUND', `未找到评价记录：${id}`);
  await audit(req, status === 'adjusted' ? '调整教学评价' : '确认教学评价', 'evaluation', id); ok(res, { id, status });
}));
/* 资源类型归一化：页面按业务语义传中文（如「知识条目」），而 resources.type 是
   ENUM('case','template','rubric','knowledge')——直接插中文会被 MySQL 拒绝
   （WARN_DATA_TRUNCATED 1265 → 500，前端只看到「业务服务不可用」）。这里统一收敛到
   合法枚举；未知值按知识条目处理，与「归档为知识条目」的业务语义一致。 */
const RESOURCE_TYPES = {
  case: 'case', '案例': 'case', '教学案例': 'case', '案例库': 'case',
  template: 'template', '模板': 'template', '教学模板': 'template',
  rubric: 'rubric', '评分标准': 'rubric', '评分规则': 'rubric', '量表': 'rubric',
  knowledge: 'knowledge', '知识': 'knowledge', '知识条目': 'knowledge', '知识库': 'knowledge'
};
function normalizeResourceType(value, fallback = 'knowledge') {
  const key = String(value ?? '').trim();
  if (!key) return fallback;
  return RESOURCE_TYPES[key] || RESOURCE_TYPES[key.toLowerCase()] || fallback;
}
app.post('/api/teacher/library', requireUser, wrap(async (req, res) => {
  const name = String(req.body.name || req.body.title || '').trim();
  if (!name) return fail(res, 400, 'NAME_REQUIRED', '请提供归档名称（name 或 title）');
  const projectRef = req.body.project_id ? String(req.body.project_id) : '';
  const project = projectRef ? await one('SELECT id FROM projects WHERE id=? OR code=? LIMIT 1', [projectRef, projectRef]) : null;
  const type = normalizeResourceType(req.body.type, 'knowledge');
  const scope = ['project', 'school', 'platform'].includes(req.body.scope) ? req.body.scope : 'school';
  const version = req.body.version || 'v1.0';
  /* 前端传 desc、接口文档写 description，两种都收，避免归档后描述为空 */
  const description = String(req.body.description || req.body.desc || '').trim();
  const id = uuid();
  await pool.execute('INSERT INTO resources(id,project_id,owner_user_id,name,type,scope,version,status,description) VALUES(?,?,?,?,?,?,?,?,?)', [id, project?.id || null, req.user.id, name, type, scope, version, 'pending', description]);
  await audit(req, '归档教学案例', 'resource', id);
  ok(res, { id, name, type, scope, version, status: 'pending', description }, 201);
}));

// Company view: requirements, projects, candidates and acceptance.
app.get('/api/company/profile', requireUser, (req, res) => ok(res, { name: req.user.organization_name, contact: req.user.display_name, role: '企业管理员', user_id: req.user.id }));
app.get('/api/company/projects', requireUser, wrap(async (req, res) => ok(res, await rows(`SELECT p.id,p.code,p.name,p.status,p.current_stage stage,p.progress,p.started_at started,p.due_at deadline,s.name school,u.display_name teacher FROM projects p JOIN organizations s ON s.id=p.school_org_id JOIN users u ON u.id=p.teacher_user_id WHERE p.company_org_id=? ORDER BY p.updated_at DESC`, [req.user.organization_id]))));
app.get('/api/company/requirements', requireUser, wrap(async (req, res) => ok(res, await rows(`SELECT r.id,r.code,r.title,r.description,r.business_goal goal,r.deliverables,r.status,r.urgent,r.submitted_at time FROM requirements r WHERE r.company_org_id=? ORDER BY r.created_at DESC`, [req.user.organization_id]))));
app.get('/api/company/candidates', requireUser, wrap(async (req, res) => ok(res, await rows(`SELECT u.id,u.display_name name,u.student_no,e.score,e.evidence_summary evidence,sv.show_real_name,sv.open_to_company,COALESCE(ar.status,'not_requested') authorization FROM users u JOIN evaluations e ON e.student_user_id=u.id LEFT JOIN student_visibility sv ON sv.student_user_id=u.id LEFT JOIN authorization_requests ar ON ar.student_user_id=u.id AND ar.company_org_id=? WHERE sv.open_to_company=1 OR ar.id IS NOT NULL ORDER BY e.score DESC`, [req.user.organization_id]))));
app.get('/api/company/acceptance', requireUser, wrap(async (req, res) => { const a = await one(`SELECT a.id,p.code project_id,p.name,a.round_no round,a.result,a.comment,a.decided_at FROM acceptances a JOIN projects p ON p.id=a.project_id WHERE p.company_org_id=? ORDER BY a.round_no DESC LIMIT 1`, [req.user.organization_id]); if (a) a.items = await rows('SELECT id,item_text text,checked FROM acceptance_items WHERE acceptance_id=?', [a.id]); ok(res, a); }));
app.get('/api/company/artifacts', requireUser, wrap(async (req, res) => ok(res, await rows(`SELECT r.id,r.name,r.type,r.version,r.status,r.description,r.updated_at updated FROM resources r JOIN projects p ON p.id=r.project_id WHERE p.company_org_id=? ORDER BY r.updated_at DESC`, [req.user.organization_id]))));
app.get('/api/company/templates', requireUser, wrap(async (_req, res) => ok(res, await rows(`SELECT id,name,type,version,description FROM resources WHERE type IN ('template','rubric') AND status='published' ORDER BY updated_at DESC`))));
app.get('/api/company/messages', requireUser, wrap(async (req, res) => ok(res, await rows('SELECT id,title,body text,level,href,created_at time FROM notifications WHERE user_id=? ORDER BY created_at DESC', [req.user.id]))));
app.get('/api/company/settings', requireUser, (_req, res) => ok(res, { apiBase: `http://localhost:${config.port}`, notifications: true, demoMode: config.demoMode }));
app.post('/api/company/requirements', requireUser, wrap(async (req, res) => { const id = uuid(), code = `REQ-${new Date().toISOString().slice(5,10).replace('-','')}-${String(Date.now()).slice(-3)}`; await pool.execute(`INSERT INTO requirements(id,code,company_org_id,creator_user_id,title,description,business_goal,deliverables,status,urgent,submitted_at) VALUES(?,?,?,?,?,?,?,?,?,?,NOW(3))`, [id, code, req.user.organization_id, req.user.id, req.body.title || req.body.name || '未命名需求', req.body.description || '', req.body.business_goal || req.body.goal || '', Array.isArray(req.body.deliverables) ? req.body.deliverables.join('；') : req.body.deliverables || '', 'under_review', req.body.urgent ? 1 : 0]); await audit(req, '提交企业需求', 'requirement', id); ok(res, { id, code, status: 'under_review' }, 201); }));
app.post('/api/company/decisions', requireUser, wrap(async (req, res) => { const p = await one('SELECT id FROM projects WHERE (id=? OR code=?) AND company_org_id=?', [req.body.project_id, req.body.project_id, req.user.organization_id]); if (!p) return fail(res, 404, 'PROJECT_NOT_FOUND', '项目不存在'); await pool.execute('INSERT INTO process_logs(id,project_id,user_id,event_type,title,detail) VALUES(?,?,?,?,?,?)', [uuid(), p.id, req.user.id, 'company_decision', req.body.title || '企业口径确认', req.body.decision || req.body.detail || '']); await audit(req, '提交企业业务决策', 'project', p.id); ok(res, { status: 'recorded' }); }));
app.post('/api/company/acceptance/decide', requireUser, wrap(async (req, res) => { const result = ['pass', 'passed', 'accept', 'success'].includes(req.body.decision || req.body.result || req.body.status) ? 'passed' : 'revision_required'; const p = await one('SELECT id FROM projects WHERE (id=? OR code=?) AND company_org_id=?', [req.body.project_id, req.body.project_id, req.user.organization_id]); if (!p) return fail(res, 404, 'PROJECT_NOT_FOUND', '项目不存在'); const acceptance = await one('SELECT id FROM acceptances WHERE project_id=? ORDER BY round_no DESC LIMIT 1', [p.id]); if (!acceptance) return fail(res, 404, 'ACCEPTANCE_NOT_FOUND', '该项目还没有验收记录，无法提交验收结论'); await tx(async conn => { await conn.execute('UPDATE acceptances SET result=?,comment=?,decided_at=NOW(3),company_user_id=? WHERE id=?', [result, req.body.comment || '', req.user.id, acceptance.id]); await conn.execute('UPDATE projects SET status=?,progress=? WHERE id=?', [result === 'passed' ? 'completed' : 'reworking', result === 'passed' ? 100 : 85, p.id]); }); await audit(req, '提交企业验收结论', 'project', p.id); ok(res, { project_id: p.id, result }); }));
app.post('/api/company/authorization-requests', requireUser, wrap(async (req, res) => { const candidates = Array.isArray(req.body.candidate_ids) ? req.body.candidate_ids : []; let created = 0; for (const candidate of candidates) { const student = await one(`SELECT u.id FROM users u JOIN user_roles ur ON ur.user_id=u.id JOIN roles r ON r.id=ur.role_id WHERE r.code='student' AND (u.id=? OR u.student_no=? OR u.display_name=?) LIMIT 1`, [candidate, candidate, candidate]); if (!student) continue; await pool.execute(`INSERT INTO authorization_requests(id,student_user_id,company_org_id,requester_user_id,role_name,scope_json,status) VALUES(?,?,?,?,?,?,?)`, [`REQ-${String(Date.now()).slice(-6)}-${created}`, student.id, req.user.organization_id, req.user.id, req.body.role_name || '项目候选人', JSON.stringify(req.body.scope || ['匿名能力画像']), 'pending']); created++; } await audit(req, '发起候选人查看授权', 'authorization_request', String(created)); ok(res, { created, status: 'pending' }, 201); }));
app.post('/api/company/candidate-decisions', requireUser, wrap(async (req, res) => { const student = req.body.student_id || req.body.candidate_id; const id = uuid(); const target = await one('SELECT u.id FROM users u JOIN user_roles ur ON ur.user_id=u.id JOIN roles r ON r.id=ur.role_id WHERE r.code=\'student\' AND (u.id=? OR u.student_no=? OR u.display_name=?) LIMIT 1', [student, student, student]); if (!target) return fail(res, 404, 'CANDIDATE_NOT_FOUND', `未找到候选人：${student || '(空)'}`); const r = await pool.execute('INSERT INTO candidate_shortlists(id,project_id,company_org_id,student_user_id,status) SELECT ?,p.id,?,?,? FROM projects p WHERE (p.id=? OR p.code=?) AND p.company_org_id=? LIMIT 1', [id, req.user.organization_id, target.id, req.body.status || 'shortlisted', req.body.project_id, req.body.project_id, req.user.organization_id]); if (!r[0].affectedRows) return fail(res, 404, 'PROJECT_NOT_FOUND', '项目不存在或不属于当前企业'); await audit(req, '更新候选人对接状态', 'candidate_shortlist', id); ok(res, { id, status: req.body.status || 'shortlisted' }); }));
app.post('/api/company/feedback', requireUser, wrap(async (req, res) => { const p = await one('SELECT id FROM projects WHERE id=? OR code=? LIMIT 1', [req.body.project_id, req.body.project_id]); const id = uuid(); await pool.execute('INSERT INTO enterprise_feedback(id,project_id,student_user_id,company_user_id,rating,feedback,kind) VALUES(?,?,?,?,?,?,?)', [id, p?.id || null, req.body.student_id || null, req.user.id, req.body.rating || null, req.body.feedback || req.body.comment || '', req.body.kind || 'project']); await audit(req, '提交企业反馈', 'enterprise_feedback', id); ok(res, { id }, 201); }));

// Platform administration: same database, global governance view.
app.get('/api/admin/profile', requireUser, (req, res) => ok(res, { name: req.user.display_name, role: '平台管理员', org: req.user.organization_name }));
app.get('/api/admin/kpis', requireUser, wrap(async (_req, res) => { const x = await one(`SELECT (SELECT COUNT(*) FROM organizations WHERE type<>'platform') organizations,(SELECT COUNT(*) FROM projects WHERE status IN ('running','published','evaluating','accepting','reworking')) projects,(SELECT COUNT(*) FROM organizations WHERE status='pending')+(SELECT COUNT(*) FROM authorization_requests WHERE status='pending') approvals,(SELECT COUNT(*) FROM task_assignments WHERE status='revision_required') risks`); ok(res, [{ label: '入驻组织', value: x.organizations, sub: '学校与企业', tone: '#f0edff' }, { label: '进行中项目', value: x.projects, sub: '共享业务项目', tone: '#eaf1ff' }, { label: '待处理审批', value: x.approvals, sub: '组织与授权', tone: '#fff4df' }, { label: '风险事件', value: x.risks, sub: '待返修任务', tone: '#fff0f2' }]); }));
app.get('/api/admin/organizations', requireUser, wrap(async (_req, res) => ok(res, await rows(`SELECT o.id,o.name,CASE o.type WHEN 'school' THEN '学校' WHEN 'company' THEN '企业' ELSE '平台' END type,o.owner_name owner,COUNT(u.id) members,CASE o.status WHEN 'active' THEN 'success' WHEN 'pending' THEN 'pending' ELSE 'failed' END status,DATE(o.created_at) created FROM organizations o LEFT JOIN users u ON u.organization_id=o.id WHERE o.type<>'platform' GROUP BY o.id ORDER BY o.created_at`))));
app.get('/api/admin/users', requireUser, wrap(async (_req, res) => ok(res, await rows(`SELECT u.id,u.display_name name,COALESCE(u.email,u.student_no,u.username) account,o.name org,GROUP_CONCAT(r.name) role,CASE WHEN SUM(r.code='student')>0 THEN '本人数据' WHEN o.type='company' THEN '企业项目' ELSE '教学项目' END scope,CASE u.status WHEN 'active' THEN 'success' WHEN 'pending' THEN 'pending' ELSE 'failed' END status,COALESCE(DATE_FORMAT(u.last_login_at,'%m-%d %H:%i'),'未登录') last FROM users u LEFT JOIN organizations o ON o.id=u.organization_id LEFT JOIN user_roles ur ON ur.user_id=u.id LEFT JOIN roles r ON r.id=ur.role_id GROUP BY u.id ORDER BY u.created_at`))));
app.get('/api/admin/projects', requireUser, wrap(async (_req, res) => { const projects = await rows(`SELECT p.code id,p.name,co.name company,so.name school,u.display_name teacher,c.name klass,p.current_stage stage,p.status,p.progress,'无' risk FROM projects p JOIN organizations co ON co.id=p.company_org_id JOIN organizations so ON so.id=p.school_org_id JOIN users u ON u.id=p.teacher_user_id LEFT JOIN project_classes pc ON pc.project_id=p.id LEFT JOIN classes c ON c.id=pc.class_id ORDER BY p.created_at DESC`); const pending = await rows(`SELECT r.code id,r.title name,o.name company,'待匹配' school,'待指派' teacher,'待绑定' klass,'需求审核' stage,'pending' status,8 progress,IF(o.status='pending','企业认证待审核','无') risk FROM requirements r JOIN organizations o ON o.id=r.company_org_id WHERE r.status IN ('submitted','under_review','accepted') ORDER BY r.created_at DESC`); ok(res, projects.concat(pending)); }));
app.get('/api/admin/approvals', requireUser, wrap(async (_req, res) => { const orgs = await rows(`SELECT CONCAT('AP-ORG-',RIGHT(id,4)) id,'企业认证' type,CONCAT(name,'企业认证') title,owner_name applicant,DATE_FORMAT(created_at,'%m-%d %H:%i') time,'urgent' level,'pending' status FROM organizations WHERE status='pending'`); const auth = await rows(`SELECT ar.id,'隐私授权' type,CONCAT(o.name,'候选人查看授权') title,u.display_name applicant,DATE_FORMAT(ar.created_at,'%m-%d %H:%i') time,'normal' level,'pending' status FROM authorization_requests ar JOIN organizations o ON o.id=ar.company_org_id JOIN users u ON u.id=ar.requester_user_id WHERE ar.status='pending'`); ok(res, orgs.concat(auth)); }));
app.get('/api/admin/resources', requireUser, wrap(async (_req, res) => ok(res, await rows(`SELECT r.id,r.name,CASE r.type WHEN 'case' THEN '案例' WHEN 'template' THEN '模板' WHEN 'rubric' THEN '评分规则' ELSE '知识条目' END type,COALESCE(u.display_name,o.name,'系统') owner,CASE r.scope WHEN 'school' THEN '校内' WHEN 'platform' THEN '平台' ELSE '项目' END scope,r.version,CASE r.status WHEN 'published' THEN 'success' WHEN 'rejected' THEN 'failed' ELSE 'pending' END status,DATE(r.updated_at) updated FROM resources r LEFT JOIN users u ON u.id=r.owner_user_id LEFT JOIN organizations o ON o.id=u.organization_id ORDER BY r.updated_at DESC`))));
app.get('/api/admin/authorizations', requireUser, wrap(async (_req, res) => ok(res, await rows(`SELECT ar.id,u.display_name student,o.name company,JSON_UNQUOTE(JSON_EXTRACT(ar.scope_json,'$[0]')) scope,CASE ar.status WHEN 'approved' THEN 'success' WHEN 'rejected' THEN 'failed' ELSE ar.status END status,COALESCE(DATE_FORMAT(ar.expires_at,'%Y-%m-%d'),'待学生确认') expires,ar.access_count access FROM authorization_requests ar JOIN users u ON u.id=ar.student_user_id JOIN organizations o ON o.id=ar.company_org_id ORDER BY ar.created_at DESC`))));
app.get('/api/admin/jobs', requireUser, wrap(async (_req, res) => ok(res, await rows(`SELECT j.id,j.name,j.type,COALESCE(u.display_name,'系统') owner,j.progress,j.status,COALESCE(DATE_FORMAT(j.started_at,'%H:%i'),'待运行') started FROM background_jobs j LEFT JOIN users u ON u.id=j.owner_user_id ORDER BY j.created_at DESC`))));
app.get('/api/admin/audits', requireUser, wrap(async (_req, res) => ok(res, await rows(`SELECT COALESCE(actor_name,'系统') actor,action,CONCAT(COALESCE(target_type,''),' ',COALESCE(target_id,'')) target,DATE_FORMAT(created_at,'%m-%d %H:%i') time,ip_address ip FROM audit_logs ORDER BY created_at DESC LIMIT 100`))));
app.get('/api/admin/settings', requireUser, wrap(async (_req, res) => { const s = await one(`SELECT setting_value FROM system_settings WHERE setting_key='platform_policy'`); const value = typeof s?.setting_value === 'string' ? JSON.parse(s.setting_value) : s?.setting_value || {}; ok(res, { apiBase: `http://localhost:${config.port}`, ...value, demoMode: config.demoMode }); }));

fs.mkdirSync(config.uploadDir, { recursive: true });
/* multer 按 latin1 解码 multipart 文件名，中文会变成 mojibake（「设备点检需求说明」→「è®¾å¤...」），
   入库前统一还原为 UTF-8，保证附件列表与下载头里的中文名可读。 */
function decodeUploadName(name) {
  const raw = String(name || '');
  if (!/[\u00c0-\u00ff]/.test(raw)) return raw;
  try {
    const restored = Buffer.from(raw, 'latin1').toString('utf8');
    return restored.includes('\uFFFD') ? raw : restored;
  } catch (_) { return raw; }
}
const upload = multer({ storage: multer.diskStorage({ destination: config.uploadDir, filename: (_req, file, cb) => cb(null, `${Date.now()}-${uuid()}${path.extname(file.originalname)}`) }), limits: { fileSize: 20 * 1024 * 1024, files: 10 } });
app.post('/api/files', requireUser, upload.array('files', 10), wrap(async (req, res) => {
  const saved = [];
  for (const file of req.files || []) {
    const id = uuid(); const digest = crypto.createHash('sha256').update(fs.readFileSync(file.path)).digest('hex');
    const originalName = decodeUploadName(file.originalname);
    await pool.execute(`INSERT INTO files(id,organization_id,uploader_user_id,original_name,stored_name,mime_type,size_bytes,sha256,purpose,storage_path) VALUES(?,?,?,?,?,?,?,?,?,?)`, [id, req.user.organization_id, req.user.id, originalName, file.filename, file.mimetype, file.size, digest, req.body.purpose || 'attachment', file.path]);
    saved.push({ id, name: originalName, size: file.size, sha256: digest });
  }
  /* audit_logs.target_id 只有 VARCHAR(64)，多文件时不能把 id 全拼进去（超长会 500） */
  await audit(req, '上传业务附件', 'file', saved.length === 1 ? saved[0].id : `${saved.length} 个附件`);
  ok(res, saved, 201);
}));
/* 附件下载：上传接口文档中承诺的鉴权下载通道（按 id 取回原始文件） */
app.get('/api/files/:id', requireUser, wrap(async (req, res) => {
  const file = await one('SELECT id,original_name,stored_name,mime_type,size_bytes,sha256,storage_path FROM files WHERE id=?', [req.params.id]);
  if (!file) return fail(res, 404, 'FILE_NOT_FOUND', '附件不存在');
  if (!fs.existsSync(file.storage_path)) return fail(res, 410, 'FILE_MISSING_ON_DISK', '附件记录存在但文件已不在磁盘上');
  const filename = encodeURIComponent(file.original_name);
  res.setHeader('Content-Type', file.mime_type || 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename*=UTF-8''${filename}`);
  res.setHeader('X-Content-Sha256', file.sha256);
  return res.sendFile(path.resolve(file.storage_path));
}));
/* 附件列表：便于页面展示「已上传的材料」而不是只返回 id */
app.get('/api/files', requireUser, wrap(async (req, res) => {
  ok(res, await rows('SELECT id,original_name name,mime_type,size_bytes,sha256,purpose,created_at uploaded_at FROM files WHERE uploader_user_id=? OR organization_id=? ORDER BY created_at DESC LIMIT 100',
    [req.user.id, req.user.organization_id]));
}));

registerReportData(app, { pool, uuid, wrap, ok, fail, config });
registerDataAdmin(app, { pool, uuid, wrap, ok, fail, config, audit });
registerSkillIntegration(app, { pool, uuid, wrap, ok, fail, config });

const staticRoots = {
  '/login': path.join(config.projectRoot, 'apps', 'login'),
  '/company': path.join(config.projectRoot, 'apps', 'company'),
  '/teacher': path.join(config.projectRoot, 'apps', 'teacher'),
  '/student': path.join(config.projectRoot, 'apps', 'student'),
  '/admin': path.join(config.projectRoot, 'apps', 'admin'),
  '/shared': path.join(config.projectRoot, 'apps', 'shared')
};
app.use((req, res, next) => {
  if (/\.(?:html|js|css)$/i.test(req.path)) res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  next();
});
for (const [route, dir] of Object.entries(staticRoots)) app.use(route, express.static(dir, { extensions: ['html'] }));
app.get('/', (_req, res) => res.redirect('/login/index.html'));
/* 浏览器会无条件请求 favicon，这里直接返回 204，避免每个页面多出一条 404 控制台噪声 */
app.get('/favicon.ico', (_req, res) => res.status(204).end());
app.use('/api', (_req, res) => fail(res, 404, 'API_NOT_FOUND', '接口不存在或尚未接入'));
app.use((error, req, res, _next) => {
  console.error(`[${res.locals.requestId}]`, error);
  if (error.code === 'LIMIT_FILE_SIZE') return fail(res, 413, 'FILE_TOO_LARGE', '单个文件不能超过 20MB');
  fail(res, error.status || 500, error.code || 'INTERNAL_ERROR', error.status ? error.message : '服务器内部错误');
});

const server = app.listen(config.port, '127.0.0.1', () => {
  console.log(`智训桥本地服务已启动：http://localhost:${config.port}`);
  console.log(`四端入口：/admin /company /teacher /student；5 项 Skill 已通过统一网关接入。`);
});
const shutdown = async () => { server.close(); await pool.end(); process.exit(0); };
process.on('SIGINT', shutdown); process.on('SIGTERM', shutdown);
