const multer = require('multer');
const { skills, byId } = require('./skill-registry');
const { enrichReportData } = require('./report-data');

const memoryUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024, files: 20 } });
const endpointSkill = path => path.includes('/training/') ? 'training' : path.includes('/multimodal/') ? 'multimodal' : path.includes('/parse-batch') ? 'parse-batch' : path.includes('/rag/') ? 'rag' : path.includes('/report') ? 'report' : null;

function jsonValue(value) { return typeof value === 'string' ? JSON.parse(value) : value; }

/* multer 默认按 latin1 解码 multipart 文件名，中文名会变成乱码（例如「待核查清单」→「å¾ æ ¸æ¥æ¸ å」）。
   转发给 Skill 之前必须还原成 UTF-8，否则 Skill 侧样例比对与证据里的文件名都会错。 */
function decodeFileName(name) {
  const raw = String(name || '');
  if (!/[\u00c0-\u00ff]/.test(raw)) return raw;
  try {
    const restored = Buffer.from(raw, 'latin1').toString('utf8');
    return restored.includes('\uFFFD') ? raw : restored;
  } catch (_) { return raw; }
}

/* 部分客户端（或非浏览器调用方）上传时不会带准确的 Content-Type，multipart 会落到
   application/octet-stream。多模态能力按 MIME 判定图片/音频，遇到 octet-stream 会直接 415。
   这里按扩展名兜底推断，避免「文件明明是 jpg 却被判不支持」。 */
const MIME_BY_EXT = {
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.gif': 'image/gif',
  '.wav': 'audio/wav', '.mp3': 'audio/mpeg', '.mp4': 'audio/mp4', '.webm': 'audio/webm', '.ogg': 'audio/ogg',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.pdf': 'application/pdf', '.csv': 'text/csv', '.json': 'application/json',
  '.txt': 'text/plain', '.md': 'text/markdown', '.py': 'text/x-python', '.sql': 'text/plain',
};
function resolveMime(file) {
  const declared = String(file.mimetype || '').toLowerCase();
  if (declared && declared !== 'application/octet-stream') return declared;
  const ext = (String(file.originalname || '').match(/\.[A-Za-z0-9]+$/) || [''])[0].toLowerCase();
  return MIME_BY_EXT[ext] || declared || 'application/octet-stream';
}

function registerSkillIntegration(app, deps) {
  const { pool, uuid, wrap, ok, fail, config } = deps;
  const base = String(config.skillBase || 'http://127.0.0.1:8090').replace(/\/$/, '');

  async function persist(req, skillId, status, input, payload, errorMessage, workflow) {
    if (!byId[skillId]) return;
    const data = payload && (payload.data || payload);
    await pool.execute(`INSERT INTO skill_runs(id,external_run_id,skill_id,platform,trigger_event,requester_user_id,status,mode,input_json,output_json,error_message,finished_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,NOW(3))`, [uuid(), data?.run_id || null, skillId, workflow?.platform || null, workflow?.triggerEvent || null, req.user?.id || null,
      status, data?.mode || null, JSON.stringify(input || {}), payload ? JSON.stringify(payload) : null, errorMessage || null]);
  }

  async function forward(req, res, targetPath, workflow) {
    const skillId = endpointSkill(targetPath);
    if (skillId && !byId[skillId]) return fail(res, 404, 'SKILL_NOT_REGISTERED', '该 Skill 未注册');
    const headers = { Accept: req.headers.accept || 'application/json' };
    if (process.env.SKILL_API_KEY) headers['X-Skill-Api-Key'] = process.env.SKILL_API_KEY;
    if (req.headers['idempotency-key']) headers['Idempotency-Key'] = req.headers['idempotency-key'];
    let body;
    const files = req.files || (req.file ? [req.file] : []);
    if (files.length) {
      body = new FormData();
      for (const [key, value] of Object.entries(req.body || {})) body.append(key, typeof value === 'string' ? value : JSON.stringify(value));
      for (const file of files) {
        body.append(skillId === 'multimodal' ? 'file' : 'files', new Blob([file.buffer], { type: resolveMime(file) }), decodeFileName(file.originalname));
      }
    } else if (!['GET', 'HEAD'].includes(req.method)) {
      headers['Content-Type'] = 'application/json';
      body = JSON.stringify(req.body || {});
    }
    let response;
    try { response = await fetch(base + targetPath, { method: req.method, headers, body, signal: AbortSignal.timeout(120000) }); }
    catch (error) { if (skillId) await persist(req, skillId, 'failed', req.body, null, error.message, workflow); return fail(res, 502, 'SKILL_SERVICE_UNAVAILABLE', 'Skill 服务不可用'); }
    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      const bytes = Buffer.from(await response.arrayBuffer());
      res.status(response.status).set('Content-Type', contentType || 'application/octet-stream');
      const disposition = response.headers.get('content-disposition'); if (disposition) res.set('Content-Disposition', disposition);
      return res.send(bytes);
    }
    const payload = await response.json().catch(() => ({}));
    if (skillId && req.method !== 'GET') await persist(req, skillId, response.ok ? 'success' : 'failed', req.body, payload, response.ok ? null : (payload.message || 'Skill 调用失败'), workflow);
    return res.status(response.status).json(payload);
  }

  app.get('/api/skills/catalog', wrap(async (_req, res) => {
    const [rows] = await pool.query(`SELECT skill_id id,name,description,input_schema,output_schema,trigger_conditions triggers,version,status FROM skill_definitions ORDER BY FIELD(skill_id,'parse-batch','training','multimodal','rag','report')`);
    ok(res, rows.map(row => ({ ...row, input_schema: jsonValue(row.input_schema), output_schema: jsonValue(row.output_schema), triggers: jsonValue(row.triggers) })));
  }));
  app.get('/api/workflows/bindings', wrap(async (_req, res) => ok(res, (await pool.query('SELECT id,platform,trigger_event,skill_id,hook_id,enabled FROM skill_workflow_bindings ORDER BY platform,skill_id'))[0])));

  app.get('/api/skills/status', wrap((req, res) => forward(req, res, '/api/skills/status')));
  app.get('/api/skills/report/profile', wrap((req, res) => forward(req, res, '/api/skills/report/profile')));
  app.get('/api/skills/training/systems', wrap((req, res) => forward(req, res, '/api/skills/training/systems')));
  app.get('/api/skills/multimodal/status', wrap((req, res) => forward(req, res, '/api/skills/multimodal/status')));
  app.get('/api/skills/runs/:id', wrap((req, res) => forward(req, res, `/api/skills/runs/${encodeURIComponent(req.params.id)}`)));
  app.get('/api/skills/reports/:id/download', wrap((req, res) => forward(req, res, `/api/skills/reports/${encodeURIComponent(req.params.id)}/download`)));
  app.post('/api/skills/parse-batch', memoryUpload.array('files', 20), wrap((req, res) => forward(req, res, '/api/skills/parse-batch')));
  app.get('/api/skills/parse-batch/samples', wrap((req, res) => forward(req, res, '/api/skills/parse-batch/samples')));
  app.post('/api/skills/parse-batch/samples', wrap((req, res) => forward(req, res, '/api/skills/parse-batch/samples')));
  app.post('/api/skills/rag/index', memoryUpload.array('files', 20), wrap((req, res) => forward(req, res, '/api/skills/rag/index')));
  app.post('/api/skills/multimodal/recognize', memoryUpload.single('file'), wrap((req, res) => forward(req, res, '/api/skills/multimodal/recognize')));
  app.get('/api/skills/multimodal/samples', wrap((req, res) => forward(req, res, '/api/skills/multimodal/samples')));
  app.post('/api/skills/multimodal/samples', wrap((req, res) => forward(req, res, '/api/skills/multimodal/samples')));
  for (const route of ['/api/skills/rag/query','/api/skills/report','/api/skills/training/plan','/api/skills/training/execute']) app.post(route, wrap((req, res) => forward(req, res, route)));
  app.post('/api/skills/training/plans/:id/approve', wrap((req, res) => forward(req, res, `/api/skills/training/plans/${encodeURIComponent(req.params.id)}/approve`)));

  app.post('/api/workflows/:platform/:trigger/dispatch', memoryUpload.any(), wrap(async (req, res) => {
    const [rows] = await pool.execute('SELECT * FROM skill_workflow_bindings WHERE platform=? AND trigger_event=? AND enabled=1 LIMIT 1', [req.params.platform, req.params.trigger]);
    const binding = rows[0];
    if (!binding) return fail(res, 404, 'WORKFLOW_BINDING_NOT_FOUND', '未找到启用的工作流 Skill 绑定');
    /* 报告类接入位通常只声明 kind（例如「教学周报」），指标本身不在页面上。
       页面直连时由前端先取 /api/report-data 再调 Skill；走工作流分发时没有这一层，
       因此在这里服务端补齐聚合数据，避免接入位以 REPORT_DATA_REQUIRED 失败。 */
    if (binding.skill_id === 'report') {
      const incoming = (req.body && typeof req.body === 'object') ? req.body : {};
      const data = (incoming.data && typeof incoming.data === 'object') ? incoming.data : {};
      const supplied = (Array.isArray(data.metrics) && data.metrics.length) || (Array.isArray(data.sections) && data.sections.length) || (Array.isArray(data.charts) && data.charts.length);
      const period = data.report_period || data.period || incoming.report_period;
      if (!supplied && !period) {
        const built = await enrichReportData(pool, { kind: incoming.kind || binding.trigger_event, data, user: req.user });
        if (built) req.body = { ...incoming, title: incoming.title || built.title, data: { ...built, ...data } };
      }
    }
    const paths = { 'parse-batch':'/api/skills/parse-batch', training:'/api/skills/training/plan', multimodal:'/api/skills/multimodal/recognize', rag:'/api/skills/rag/query', report:'/api/skills/report' };
    return forward(req, res, paths[binding.skill_id], { platform: binding.platform, triggerEvent: binding.trigger_event });
  }));
}

module.exports = { registerSkillIntegration };
