const skills = [
  {
    id: 'parse-batch', name: '批量文件解析', version: '1.0.0',
    description: '解析 xlsx、csv、tsv、json、txt、md、docx、pdf，返回字段、正文、缺失值、重复项与证据。',
    inputSchema: { type: 'object', required: ['files'], properties: { files: { type: 'array', minItems: 1, items: { type: 'string', format: 'binary' } }, purpose: { type: 'string' } } },
    outputSchema: { type: 'object', properties: { total: { type: 'integer' }, fields: { type: 'array', items: { type: 'string' } }, files: { type: 'array', items: { type: 'object' } }, anomalies: { type: 'array', items: { type: 'object' } } } },
    triggers: { event: 'file_uploaded', condition: '至少一个受支持格式的真实文件' }
  },
  {
    id: 'training', name: '实训系统操作', version: '1.0.0',
    description: '以计划、审批、执行、校验闭环调用 LMS 或边缘实训系统，写操作强制幂等与人工审批。',
    inputSchema: { type: 'object', required: ['system', 'action'], properties: { system: { type: 'string' }, op: { enum: ['read', 'write'] }, action: { type: 'string' }, payload: { type: 'object' } } },
    outputSchema: { type: 'object', properties: { plan_id: { type: 'string' }, plan_hash: { type: 'string' }, approval_required: { type: 'boolean' }, verification: { type: 'object' }, evidence: { type: 'array' } } },
    triggers: { event: 'training_operation_requested', condition: '动作位于系统白名单；写操作完成计划审批后执行' }
  },
  {
    id: 'multimodal', name: '多模态识别', version: '1.0.0',
    description: '校验图片或音频并通过可配置 OCR/ASR 提供方识别，未配置提供方时明确拒绝而不伪造结果。',
    inputSchema: { type: 'object', required: ['file'], properties: { file: { type: 'string', format: 'binary' }, kind: { enum: ['image', 'audio'] }, purpose: { type: 'string' }, language: { type: 'string' } } },
    outputSchema: { type: 'object', properties: { kind: { type: 'string' }, text: { type: 'string' }, fields: { type: 'object' }, confidence: { type: 'number' }, media: { type: 'object' }, evidence: { type: 'array' } } },
    triggers: { event: 'media_uploaded', condition: '上传受支持图片或音频且识别提供方已配置' }
  },
  {
    id: 'rag', name: '可追溯知识检索', version: '1.0.0',
    description: '对已授权索引进行本地检索，返回答案、命中片段与引用；证据不足时拒绝确定性回答。',
    inputSchema: { type: 'object', required: ['query'], properties: { query: { type: 'string', minLength: 1 }, scopes: { type: 'array', items: { type: 'string' } }, project_id: { type: 'string' }, top_k: { type: 'integer', minimum: 1, maximum: 20 } } },
    outputSchema: { type: 'object', properties: { answer: { type: 'string' }, requires_confirmation: { type: 'boolean' }, citations: { type: 'array' }, hits: { type: 'array' } } },
    triggers: { event: 'knowledge_query_submitted', condition: '问题非空且用户具备对应范围的数据权限' }
  },
  {
    id: 'report', name: '可视化报告生成', version: '1.0.0',
    description: '基于真实指标、章节、图表和证据生成可下载 HTML 报告。',
    inputSchema: { type: 'object', required: ['title', 'data'], properties: { title: { type: 'string' }, kind: { type: 'string' }, data: { type: 'object', properties: { metrics: { type: 'array' }, sections: { type: 'array' }, charts: { type: 'array' }, evidence: { type: 'array' } } } } },
    outputSchema: { type: 'object', properties: { report_id: { type: 'string' }, format: { const: 'html' }, download_url: { type: 'string' }, metrics: { type: 'array' }, sections: { type: 'array' }, charts: { type: 'array' } } },
    triggers: { event: 'report_requested', condition: '至少包含 metrics、sections 或 charts 中的一项真实数据' }
  }
];

const platformEvents = {
  company: [['requirement.uploaded','parse-batch'],['training.operation_requested','training'],['evidence.media_uploaded','multimodal'],['acceptance.knowledge_query','rag'],['project.report_requested','report']],
  teacher: [['teaching.materials_uploaded','parse-batch'],['task.operation_requested','training'],['guidance.media_uploaded','multimodal'],['guidance.knowledge_query','rag'],['teaching.report_requested','report']],
  student: [['submission.uploaded','parse-batch'],['training.operation_requested','training'],['evidence.media_uploaded','multimodal'],['assistant.knowledge_query','rag'],['capability.report_requested','report']],
  admin: [['resource.imported','parse-batch'],['platform.operation_requested','training'],['media.review_requested','multimodal'],['policy.knowledge_query','rag'],['operations.report_requested','report']]
};

const bindings = Object.entries(platformEvents).flatMap(([platform, rows]) => rows.map(([triggerEvent, skillId]) => ({
  id: `${platform}:${triggerEvent}`, platform, triggerEvent, skillId, hookId: `${platform}.${skillId}`, enabled: true
})));

const byId = Object.fromEntries(skills.map(skill => [skill.id, skill]));
module.exports = { skills, bindings, byId };
