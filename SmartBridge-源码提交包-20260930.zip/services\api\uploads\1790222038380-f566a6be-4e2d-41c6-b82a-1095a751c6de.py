# -*- coding: utf-8 -*-
"""rule_check.py —— 点检台账异常判定规则实现（学生阶段二产物）

项目：PRJ-0917-001 设备点检台账整理与异常周报生成
规则（与企业确认版一致）：
    R1 温度 > 80℃         -> 记为异常
    R2 温度 = 80℃         -> 边界正常值，不得四舍五入
    R3 温度为空           -> 待核查清单，不得补成正常值、不按 0 处理
    R4 设备+日期+班组相同  -> 重复记录，去重后保留 1 条
    ℉→℃ 换算：(f - 32) / 1.8，保留一位小数，并标注换算来源
"""
from decimal import Decimal

TEMP_LIMIT = Decimal('80')
VIB_LIMIT = Decimal('12')


def to_celsius(value):
    """华氏度换算为摄氏度，保留一位小数。"""
    return round((Decimal(str(value)) - 32) / Decimal('1.8'), 1)


def classify_temperature(raw):
    """温度三分支判定：异常 / 边界正常 / 正常 / 待核查。"""
    if raw is None or str(raw).strip() == '':
        return '待核查'                      # R3：空值先分流，禁止参与数值比较
    value = Decimal(str(raw).strip())
    if value > TEMP_LIMIT:
        return '异常'                        # R1
    if value == TEMP_LIMIT:
        return '边界正常'                    # R2
    return '正常'


def classify_vibration(raw):
    if raw is None or str(raw).strip() == '':
        return '待核查'
    value = Decimal(str(raw).strip())
    if value > VIB_LIMIT:
        return '异常'
    if value == VIB_LIMIT:
        return '边界正常'
    return '正常'


def dedup_key(row):
    """R4：设备编号 + 点检日期 + 班组 三者相同视为重复。"""
    return (row['设备编号'], row['点检日期'], row['班组'])


def dedup(rows):
    kept, seen = [], set()
    for row in rows:
        key = dedup_key(row)
        if key in seen:
            continue
        seen.add(key)
        kept.append(row)
    return kept


def summarize(rows):
    """统计口径：异常数量与待核查数量分开统计，待核查不计入异常。"""
    abnormal, pending, boundary = 0, 0, 0
    for row in rows:
        verdict = classify_temperature(row.get('运行温度(℃)'))
        if verdict == '异常':
            abnormal += 1
        elif verdict == '待核查':
            pending += 1
        elif verdict == '边界正常':
            boundary += 1
    return {'异常数量': abnormal, '待核查数量': pending, '边界正常数量': boundary}


if __name__ == '__main__':
    sample = [
        {'设备编号': 'SB030108', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': '79.9'},
        {'设备编号': 'SB030102', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': '80.0'},
        {'设备编号': 'SB030109', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': '80.1'},
        {'设备编号': 'SB030104', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': ''},
        {'设备编号': 'SB030112', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': '71.9'},
        {'设备编号': 'SB030112', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': '71.9'},
    ]
    print(summarize(dedup(sample)))
