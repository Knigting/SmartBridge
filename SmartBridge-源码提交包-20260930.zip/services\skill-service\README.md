# SmartBridge Skills（五类独立能力）

这是与原系统分离的独立 Skill 服务，不修改原压缩包中的业务后端、数据库、学生端、教师端和企业端。

## 五类能力

- `parse-batch`：真实解析 XLSX、CSV、TSV、JSON、TXT、Markdown、DOCX 和 PDF，返回字段、正文、缺失值、重复记录和出处证据。
- `rag`：真实文档切片、本地检索、引用和无依据拒答，不预置伪造企业规则。
- `report`：使用调用方提供的真实指标生成含 SVG 图表、证据来源和下载链接的 HTML 报告。
- `training`：实训系统操作计划、动作白名单、人工审批、幂等执行、执行后回读验证和审计证据。未配置真实系统时只使用明确标记为 `sandbox` 的 LMS/Edge 沙箱。
- `multimodal`：图片/音频上传校验、摘要、元数据检测和真实 OCR/ASR 供应商适配。未配置识别服务时返回 `MULTIMODAL_PROVIDER_NOT_CONFIGURED`，不生成伪识别内容。

## 启动

```powershell
npm install
npm test
npm start
```

默认地址为 `http://127.0.0.1:8090`。可使用环境变量 `SKILL_PORT` 修改端口，用 `SKILL_API_KEY` 启用调用方鉴权。

## HTTP 契约

- `GET /api/skills/status`
- `POST /api/skills/parse-batch`：`multipart/form-data`，文件字段名 `files`
- `POST /api/skills/rag/index`：`multipart/form-data`，文件字段名 `files`，可带 `scope/project_id/version`
- `POST /api/skills/rag/query`：JSON，`query/scopes/project_id/top_k`
- `POST /api/skills/report`：JSON，`title/kind/data`
- `GET /api/skills/training/systems`
- `POST /api/skills/training/plan`：生成不可篡改的操作计划
- `POST /api/skills/training/plans/{planId}/approve`：审批写操作并返回短期令牌
- `POST /api/skills/training/execute`：执行计划；写操作必须带 `Idempotency-Key`
- `GET /api/skills/multimodal/status`
- `POST /api/skills/multimodal/recognize`：`multipart/form-data`，文件字段 `file`，参数 `kind/purpose/language`
- `GET /api/skills/runs/{runId}`
- `GET /api/skills/reports/{reportId}/download`

返回与原系统 `CORE` 预留契约一致：

```json
{
  "skill": "rag",
  "ok": true,
  "code": "ok",
  "mode": "live",
  "input": {},
  "output": {},
  "evidence": [],
  "meta": { "run_id": "..." }
}
```

## 适配原系统

`adapters/core-http-adapter.js` 是独立的浏览器适配器示例，使用原系统已经预留的 `CORE.register()` 注册三类能力。正式联调时由原系统负责人选择以下任一方式：

1. 由业务后端调用本服务，再把 Skill envelope 返回页面（推荐）。
2. 在已加载 `assets/core.js` 的页面中另行引入该适配器。

适配器不包含业务页修改，也不强制原系统使用某一种接入方式。

## 接入真实实训系统

1. 复制 `config/training-systems.example.json`，填写由学校提供的测试环境地址和允许动作。
2. 把 Token 放在配置中 `auth_env` 指定的环境变量，不要写进 JSON。
3. 启动前设置 `TRAINING_SYSTEM_CONFIG` 为配置文件路径。
4. 所有写操作必须经过 `plan → approve → execute → verify`。

## 接入真实多模态服务

1. 复制 `config/multimodal-provider.example.json`，填写企业 OCR/ASR/多模态接口。
2. 识别密钥放入 `api_key_env` 指定的环境变量。
3. 启动前设置 `MULTIMODAL_PROVIDER_CONFIG` 为配置文件路径。
4. 供应商可返回 `text/transcript/ocr_text`、`fields`、`confidence`、`language`、`request_id`，Skill 会统一转换为平台 envelope。

## 真实与沙箱标识

- 真实文件解析、RAG、报告生成使用 `mode: "live"`。
- 本地实训系统沙箱使用 `mode: "sandbox"`，不冒充校内系统。
- 多模态供应商未配置时接口返回 503，不使用固定演示文字伪造识别成功。
