(function (global) {
  'use strict';
  if (!global.CORE || typeof global.CORE.register !== 'function') return;

  var base = global.SMARTBRIDGE_SKILL_BASE || 'http://127.0.0.1:8090';
  var apiKey = global.SMARTBRIDGE_SKILL_KEY || '';

  function headers(json) {
    var result = { Accept: 'application/json' };
    if (json) result['Content-Type'] = 'application/json';
    if (apiKey) result['X-Skill-Api-Key'] = apiKey;
    return result;
  }

  function request(path, options) {
    return fetch(base + path, options).then(function (response) {
      return response.json().catch(function () { return {}; }).then(function (body) {
        if (!response.ok) throw new Error(body.message || ('HTTP ' + response.status));
        return body.data || body;
      });
    });
  }

  global.CORE.register('parse-batch', {
    connected: true,
    describe: 'SmartBridge Skills /parse-batch',
    run: function (input) {
      var form = new FormData();
      (input.files || []).forEach(function (item) {
        var file = item instanceof File ? item : item.file;
        if (file instanceof File) form.append('files', file, file.name);
      });
      form.append('purpose', input.purpose || '');
      return request('/api/skills/parse-batch', { method: 'POST', headers: headers(false), body: form });
    }
  });

  global.CORE.register('rag', {
    connected: true,
    describe: 'SmartBridge Skills /rag/query',
    run: function (input) {
      return request('/api/skills/rag/query', { method: 'POST', headers: headers(true), body: JSON.stringify({ query: input.query || '', scopes: input.scopes || [], project_id: input.project_id || '', top_k: input.topK || 5 }) });
    }
  });

  global.CORE.register('report', {
    connected: true,
    describe: 'SmartBridge Skills /report',
    run: function (input) {
      return request('/api/skills/report', { method: 'POST', headers: headers(true), body: JSON.stringify({ title: input.title, kind: input.kind, data: input.data || {} }) });
    }
  });

  function trainingPlan(input) {
    return request('/api/skills/training/plan', { method: 'POST', headers: headers(true), body: JSON.stringify(input || {}) });
  }
  function trainingApprove(planId, approvedBy, reason) {
    return request('/api/skills/training/plans/' + encodeURIComponent(planId) + '/approve', { method: 'POST', headers: headers(true), body: JSON.stringify({ approved_by: approvedBy, reason: reason || '' }) });
  }
  function trainingExecute(planId, approvalToken, idempotencyKey) {
    var h = headers(true);
    if (idempotencyKey) h['Idempotency-Key'] = idempotencyKey;
    return request('/api/skills/training/execute', { method: 'POST', headers: h, body: JSON.stringify({ plan_id: planId, approval_token: approvalToken || '' }) });
  }
  global.SmartBridgeTraining = { plan: trainingPlan, approve: trainingApprove, execute: trainingExecute };
  global.CORE.register('training', {
    connected: true,
    describe: 'SmartBridge Skills /training',
    run: function (input) {
      return trainingPlan({ system: input.system, op: input.op || 'read', action: input.action, payload: input.payload || input.query || {} }).then(function (plan) {
        if (plan.approval_required) {
          return { skill: 'training', version: '1.0.0', ok: false, code: 'approval_required', mode: 'live', input: input, output: plan, evidence: [{ plan_id: plan.plan_id, plan_hash: plan.plan_hash, risk: plan.risk }], error: '该写操作需要人工审批', meta: { at: new Date().toISOString(), adapter: 'SmartBridge Skills' } };
        }
        return trainingExecute(plan.plan_id, '', '');
      });
    }
  });

  global.CORE.register('multimodal', {
    connected: true,
    describe: 'SmartBridge Skills /multimodal/recognize',
    run: function (input) {
      var file = input.file || input.source;
      if (file instanceof File) {
        var form = new FormData();
        form.append('file', file, file.name);
        form.append('kind', input.kind || (file.type.indexOf('audio/') === 0 ? 'audio' : 'image'));
        form.append('purpose', input.purpose || '');
        form.append('language', input.language || 'zh-CN');
        return request('/api/skills/multimodal/recognize', { method: 'POST', headers: headers(false), body: form });
      }
      /* 接入位没有用户上传的文件时改用内置样例素材，保证本地可直接跑通（结果标注为本地演示通道） */
      return request('/api/skills/multimodal/samples', {
        method: 'POST', headers: headers(true),
        body: JSON.stringify({ source: typeof input.source === 'string' ? input.source : '', kind: input.kind || '', purpose: input.purpose || '', language: input.language || 'zh-CN' })
      });
    }
  });
})(window);
