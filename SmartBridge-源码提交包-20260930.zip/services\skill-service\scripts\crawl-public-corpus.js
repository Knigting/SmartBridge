'use strict';

/* ==========================================================================
   crawl-public-corpus.js —— 从公开网页抓取 RAG 训练语料
   --------------------------------------------------------------------------
   合规纪律（写死在代码里，不是口头承诺）：
     1. 只抓 /wiki/<条目> 文章正文页。zh.wikipedia.org/robots.txt 对
        User-agent:* 明确 Disallow: /w/ 与 Disallow: /api/，
        但注释说明 "Friendly, low-speed bots are welcome viewing article pages"，
        所以正文页允许、API 路径不碰；
     2. 抓取前实时下载 robots.txt 并校验目标路径未被 Disallow，不允许就直接跳过；
     3. 频率限制：同一主机两次请求间隔 >= 2500ms，总请求数 <= MAX_REQUESTS；
     4. 明确的 User-Agent，注明用途；
     5. 只抓公开页面，不需要、也不使用任何登录态或凭据；
     6. 每条语料记录来源 URL、抓取时间、许可协议（维基百科正文为 CC BY-SA），
        归属信息随语料入库，展示时可溯源。

   输出：data/training/crawled/*.json + manifest.json
   消费：src/train-data.js 的 indexCrawled() 把这些文档切块索引进 RAG。

   用法：node scripts/crawl-public-corpus.js
   ========================================================================== */
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

/* HTTP 头只能是 Latin-1，UA 保持纯 ASCII；中文说明放代码注释里 */
const UA = 'SmartBridgeEduBot/1.0 (education training RAG corpus crawler; low-rate; public article pages only)';
const MIN_INTERVAL_MS = 2500;
const MAX_REQUESTS = 12;
const MIN_PARAGRAPH = 24;          /* 短于 24 字的段落视为导航/编辑提示，丢弃 */

/* 条目清单：与「设备点检 / 数据治理 / 实训验收」业务域直接相关的公开百科条目 */
const TARGETS = [
  { title: '异常检测', scope: '公开资料库', heading: '异常检测方法' },
  { title: '预测性维护', scope: '公开资料库', heading: '预测性维护概念' },
  { title: '状态监测', scope: '公开资料库', heading: '设备状态监测' },
  { title: '数据清洗', scope: '公开资料库', heading: '数据清洗方法' },
  { title: '失效模式与影响分析', scope: '公开资料库', heading: '故障分析方法' },
  { title: '品管七大手法', scope: '公开资料库', heading: '质量分析工具' }
];

const outDir = path.resolve(__dirname, '..', '..', '..', 'data', 'training', 'crawled');
fs.mkdirSync(outDir, { recursive: true });

let requestCount = 0;
let lastRequestAt = 0;

function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

/* 简单的 robots.txt 校验：只解析 User-agent: * 段的 Allow/Disallow 前缀规则 */
function parseRobots(text) {
  const lines = String(text || '').split(/\r?\n/);
  let inWildcard = false;
  const rules = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (/^user-agent:/i.test(trimmed)) { inWildcard = trimmed.replace(/^user-agent:/i, '').trim() === '*'; continue; }
    if (!inWildcard || trimmed.startsWith('#')) continue;
    const allow = trimmed.match(/^allow:\s*(\S+)/i);
    const disallow = trimmed.match(/^disallow:\s*(\S+)/i);
    if (allow) rules.push({ type: 'allow', prefix: allow[1] });
    if (disallow) rules.push({ type: 'disallow', prefix: disallow[1] });
  }
  return rules;
}

function pathAllowed(rules, urlPath) {
  /* robots 语义：最长前缀匹配优先，Allow 与 Disallow 同长时 Allow 优先（维基惯例） */
  let best = null;
  for (const rule of rules) {
    if (!urlPath.startsWith(rule.prefix)) continue;
    if (!best || rule.prefix.length > best.prefix.length
      || (rule.prefix.length === best.prefix.length && rule.type === 'allow')) best = rule;
  }
  return !best || best.type === 'allow';
}

async function fetchText(url) {
  if (requestCount >= MAX_REQUESTS) throw new Error(`请求数达到上限 ${MAX_REQUESTS}，主动停止`);
  const wait = MIN_INTERVAL_MS - (Date.now() - lastRequestAt);
  if (wait > 0) await sleep(wait);
  lastRequestAt = Date.now();
  requestCount += 1;
  const response = await fetch(url, { headers: { 'User-Agent': UA, Accept: 'text/html' }, redirect: 'follow' });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return { text: await response.text(), finalUrl: response.url };
}

/* 把文章 HTML 清洗成纯文本段落。刻意保持朴素：只用正则去标签，
   训练语料宁可少一点，也不引入 HTML 解析器依赖。 */
function htmlToParagraphs(html) {
  let body = html;
  const contentMatch = body.match(/<div[^>]+id="mw-content-text"[^>]*>([\s\S]*?)<div[^>]+class="printfooter"/i);
  if (contentMatch) body = contentMatch[1];
  body = body
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<sup[^>]*class="[^"]*reference[^"]*"[^>]*>[\s\S]*?<\/sup>/gi, '')   /* 参考文献上标 */
    .replace(/<table[\s\S]*?<\/table>/gi, '')                                      /* infobox / navbox 表格 */
    .replace(/<div[^>]+class="[^"]*(?:hatnote|navbox|editnotice|ambox)[^"]*"[^>]*>[\s\S]*?<\/div>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '');
  const paragraphs = [];
  const blockRe = /<(p|h2|h3)[^>]*>([\s\S]*?)<\/\1>/gi;
  let match;
  while ((match = blockRe.exec(body))) {
    const text = match[2]
      .replace(/<[^>]+>/g, '')
      .replace(/&nbsp;/g, ' ')
      .replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"')
      .replace(/\s+/g, ' ')
      .trim();
    if (!text) continue;
    if (match[1] === 'p') {
      if (text.length >= MIN_PARAGRAPH && !/^(帮助|编辑|本词条|您可以|请协助)/.test(text)) paragraphs.push(text);
    } else if (!/(參見|参见|參考|参考|外部連結|外部链接|延伸閱讀|延伸阅读|註釋|注释)/.test(text)) {
      paragraphs.push(`【${text}】`);
    }
  }
  return paragraphs;
}

(async () => {
  const log = { started_at: new Date().toISOString(), user_agent: UA, min_interval_ms: MIN_INTERVAL_MS, sources: [], skipped: [], errors: [] };
  console.log('下载 robots.txt 做合规校验…');
  let robots;
  try {
    const robotsRes = await fetchText('https://zh.wikipedia.org/robots.txt');
    robots = parseRobots(robotsRes.text);
    log.robots_fetched = true;
  } catch (error) {
    console.error('robots.txt 下载失败，按合规纪律中止：', error.message);
    process.exit(1);
  }

  for (const target of TARGETS) {
    const pagePath = `/wiki/${encodeURIComponent(target.title)}`;
    const url = `https://zh.wikipedia.org${pagePath}`;
    if (!pathAllowed(robots, pagePath)) {
      log.skipped.push({ title: target.title, reason: 'robots.txt 不允许该路径' });
      console.log(`跳过（robots 禁止）：${target.title}`);
      continue;
    }
    try {
      const { text: html, finalUrl } = await fetchText(url);
      const paragraphs = htmlToParagraphs(html);
      if (paragraphs.length < 3) {
        log.skipped.push({ title: target.title, reason: `有效段落过少（${paragraphs.length} 段），按清洗规则丢弃` });
        console.log(`跳过（段落过少）：${target.title}`);
        continue;
      }
      const doc = {
        id: `crawled-${crypto.createHash('sha256').update(target.title).digest('hex').slice(0, 10)}`,
        title: `${target.heading}（维基百科：${target.title}）`,
        source_entry: target.title,
        source_url: finalUrl,
        license: 'CC BY-SA 3.0（维基百科条目，作者为维基百科贡献者）',
        license_url: 'https://creativecommons.org/licenses/by-sa/3.0/deed.zh-hans',
        attribution: `维基百科「${target.title}」条目贡献者，${finalUrl}`,
        fetched_at: new Date().toISOString(),
        scope: target.scope,
        sections: [{ heading: target.heading, text: paragraphs.join('\n') }],
        stats: { paragraphs: paragraphs.length, chars: paragraphs.join('').length }
      };
      const file = path.join(outDir, `${doc.id}.json`);
      fs.writeFileSync(file, JSON.stringify(doc, null, 2), 'utf8');
      log.sources.push({ title: target.title, file: path.basename(file), url: finalUrl, paragraphs: doc.stats.paragraphs, chars: doc.stats.chars });
      console.log(`已抓取：${target.title} — ${doc.stats.paragraphs} 段 / ${doc.stats.chars} 字`);
    } catch (error) {
      log.errors.push({ title: target.title, error: error.message });
      console.log(`失败：${target.title} — ${error.message}`);
    }
  }

  log.finished_at = new Date().toISOString();
  log.request_count = requestCount;
  fs.writeFileSync(path.join(outDir, 'manifest.json'), JSON.stringify(log, null, 2), 'utf8');
  console.log(`\n完成：成功 ${log.sources.length} 篇，跳过 ${log.skipped.length} 篇，失败 ${log.errors.length} 篇，共 ${requestCount} 次请求`);
  console.log(`清单：${path.join(outDir, 'manifest.json')}`);
})();
