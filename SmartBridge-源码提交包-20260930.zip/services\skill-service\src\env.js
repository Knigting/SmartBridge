'use strict';

/* ==========================================================================
   env.js —— 极简 .env 加载（不引入 dotenv 依赖）
   --------------------------------------------------------------------------
   为什么自己写：Skill 服务要在鲲鹏/麒麟上用任意 Python/Node 运行时部署，
   少一个依赖少一处版本冲突。规则与 dotenv 保持一致：
     · KEY=VALUE，支持 export 前缀
     · # 或 ; 开头为注释，行尾注释需前留空格
     · 支持单引号 / 双引号包裹
     · 已存在的环境变量优先级更高（真实部署环境常由容器注入）
   ========================================================================== */
const fs = require('fs');
const path = require('path');

function parseEnvFile(content) {
  const result = {};
  const lines = String(content || '').split(/\r?\n/);
  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#') || line.startsWith(';')) continue;
    const withoutExport = line.replace(/^export\s+/, '');
    const separator = withoutExport.indexOf('=');
    if (separator <= 0) continue;
    const key = withoutExport.slice(0, separator).trim();
    if (!key) continue;
    let value = withoutExport.slice(separator + 1).trim();
    const quoted = (value.startsWith('"') && value.endsWith('"') && value.length > 1)
      || (value.startsWith("'") && value.endsWith("'") && value.length > 1);
    if (quoted) value = value.slice(1, -1);
    else {
      const commentAt = value.search(/\s+#/);
      if (commentAt > -1) value = value.slice(0, commentAt).trim();
    }
    result[key] = value.replace(/\\n/g, '\n');
  }
  return result;
}

function loadEnvFile(filePath) {
  if (!fs.existsSync(filePath)) return {};
  try {
    return parseEnvFile(fs.readFileSync(filePath, 'utf8'));
  } catch (error) {
    console.warn(`.env 读取失败（已忽略）：${path.basename(filePath)} ${error.message}`);
    return {};
  }
}

/* 已存在的进程环境变量不被覆盖——容器/systemd 注入的值优先级最高。
   __dirname 是 <服务根>/src，因此服务根 = 上一级，而不是上两级。 */
function loadEnv(target = process.env) {
  const dir = path.resolve(__dirname, '..');
  const files = [path.join(dir, '.env'), path.join(dir, '.env.local')];
  let loaded = 0;
  for (const file of files) {
    const values = loadEnvFile(file);
    for (const [key, value] of Object.entries(values)) {
      if (target[key] === undefined) { target[key] = value; loaded += 1; }
    }
  }
  return { files, loaded };
}

module.exports = { loadEnv, loadEnvFile, parseEnvFile };
