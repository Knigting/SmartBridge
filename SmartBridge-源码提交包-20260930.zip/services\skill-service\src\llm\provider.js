'use strict';

/* ==========================================================================
   provider.js —— 标准 OpenAI 兼容大模型客户端（多密钥池 + 自动故障转移）
   --------------------------------------------------------------------------
   本服务唯一的模型出口。两条硬性设计约束：

     1. 零兜底。任何情况下都不返回"写死的演示结果"——那是被明确要求移除的东西。
        没有可用密钥就抛 LLM_NOT_CONFIGURED / LLM_ALL_KEYS_FAILED，由上层返回
        明确错误与处理建议。
     2. 只说 OpenAI 兼容协议。智谱 GLM、DeepSeek、通义、vLLM、Ollama、鲲鹏上
        自建的 Qwen 推理服务全部通用，换模型不改业务代码。

   多密钥：LLM_API_KEYS 用逗号分隔填多个，按轮询分摊额度；某个密钥失败
   （401/403/429/5xx/超时/网络）后自动换下一个，并把它标记为冷却，
   冷却期内不再分发流量。这样"某个 key 额度用完或失效"不会拖垮整个服务。

   环境变量：
     LLM_BASE_URL       必填  兼容端点，如 https://model-router.edu-aliyun.com/v1
     LLM_API_KEYS       必填  逗号分隔的多个密钥（也可只填 LLM_API_KEY）
     LLM_API_KEY        可选  单密钥写法，会自动并入密钥池
     LLM_MODEL          必填  文本 / JSON 任务模型
     LLM_VISION_MODEL   可选  图片理解模型，不填则图片识别明确报错
     LLM_ASR_MODEL      可选  语音转写模型，不填且无本地 ASR 则音频明确报错
     LLM_MAX_TOKENS     默认 4096（推理模型需要更大预算）
     LLM_TEMPERATURE    默认 0.2
     LLM_TIMEOUT_MS     默认 120000
     LLM_MAX_RETRIES    默认 1（单密钥内的重试次数）
     LLM_KEY_COOLDOWN_MS 默认 600000（失败密钥冷却时长）
   ========================================================================== */
const crypto = require('crypto');

class LLMError extends Error {
  constructor(code, message, status, hint, details) {
    super(message);
    this.name = 'LLMError';
    this.code = code;
    this.status = status;
    this.hint = hint || '';
    this.details = details || null;
  }
}

function splitKeys(raw) {
  return String(raw || '')
    .split(/[,\n;]/)
    .map(item => item.trim())
    .filter(Boolean);
}

function readConfig(env = process.env) {
  const baseUrl = String(env.LLM_BASE_URL || '').trim().replace(/\/+$/, '');
  const keys = [...new Set([...splitKeys(env.LLM_API_KEYS), ...splitKeys(env.LLM_API_KEY)])];
  const textModel = String(env.LLM_MODEL || '').trim();
  return {
    baseUrl,
    apiKeys: keys,
    apiKey: keys[0] || '',
    model: textModel,
    visionModel: String(env.LLM_VISION_MODEL || '').trim(),
    asrModel: String(env.LLM_ASR_MODEL || '').trim(),
    asrPath: String(env.LLM_ASR_PATH || '').trim() || '/audio/transcriptions',
    timeoutMs: Number(env.LLM_TIMEOUT_MS || 120000),
    temperature: Number(env.LLM_TEMPERATURE || 0.2),
    maxTokens: Number(env.LLM_MAX_TOKENS || 4096),
    maxRetries: Number(env.LLM_MAX_RETRIES || 1),
    keyCooldownMs: Number(env.LLM_KEY_COOLDOWN_MS || 600000)
  };
}

function isConfigured(config = readConfig()) {
  return Boolean(config.baseUrl && config.apiKeys.length && config.model);
}

function missingFields(config = readConfig()) {
  const missing = [];
  if (!config.baseUrl) missing.push('LLM_BASE_URL');
  if (!config.apiKeys.length) missing.push('LLM_API_KEYS');
  if (!config.model) missing.push('LLM_MODEL');
  return missing;
}

function maskKey(key) {
  const text = String(key || '');
  if (text.length <= 12) return text ? '****' : '';
  return `${text.slice(0, 7)}****${text.slice(-4)}`;
}

function describeConfig(config = readConfig(), pool = null) {
  return {
    configured: isConfigured(config),
    base_url: config.baseUrl,
    model: config.model,
    vision_model: config.visionModel || null,
    asr_model: config.asrModel || null,
    key_count: config.apiKeys.length,
    keys_masked: config.apiKeys.map(maskKey),
    pool: pool ? pool.status() : null,
    timeout_ms: config.timeoutMs,
    missing: missingFields(config)
  };
}

/* ------------------------------------------------------------------ 密钥池 */
class KeyPool {
  constructor(keys, cooldownMs) {
    this.keys = keys.slice();
    this.cooldownMs = cooldownMs;
    this.cursor = 0;
    this.deadUntil = new Map();
  }

  isHealthy(index) {
    const until = this.deadUntil.get(index) || 0;
    return Date.now() >= until;
  }

  markFailed(index, reason) {
    this.deadUntil.set(index, Date.now() + this.cooldownMs);
    this.lastReason = { index, reason, at: new Date().toISOString() };
  }

  /* 轮询挑一个健康密钥；从 cursor 开始找一圈 */
  pick() {
    for (let step = 0; step < this.keys.length; step += 1) {
      const index = (this.cursor + step) % this.keys.length;
      if (this.isHealthy(index)) {
        this.cursor = (index + 1) % this.keys.length;
        return index;
      }
    }
    return -1;
  }

  status() {
    const now = Date.now();
    return this.keys.map((key, index) => {
      const until = this.deadUntil.get(index) || 0;
      return {
        index,
        key: maskKey(key),
        healthy: now >= until,
        cooldown_remaining_ms: Math.max(0, until - now)
      };
    });
  }
}

const POOL_CACHE = new WeakMap();
function poolFor(config) {
  let pool = POOL_CACHE.get(config);
  if (!pool) {
    pool = new KeyPool(config.apiKeys, config.keyCooldownMs);
    POOL_CACHE.set(config, pool);
  }
  return pool;
}

/* 密钥失效后需要换 key 重试的错误码 */
const KEY_SWITCH_CODES = new Set([
  'LLM_AUTH_FAILED', 'LLM_RATE_LIMITED', 'LLM_UPSTREAM_ERROR', 'LLM_TIMEOUT', 'LLM_NETWORK_ERROR'
]);

function assertConfigured(config = readConfig()) {
  if (isConfigured(config)) return config;
  throw new LLMError(
    'LLM_NOT_CONFIGURED',
    `未配置大模型接口地址或密钥：缺少 ${missingFields(config).join('、')}`,
    503,
    '请在 services/skill-service/.env 中补齐 LLM_BASE_URL / LLM_API_KEYS / LLM_MODEL 后重启 Skill 服务。' +
    '本服务已移除所有模拟通道，未配置时不会返回任何演示数据。'
  );
}

/* 在密钥池上执行：按健康状态依次尝试，全失败则抛出带诊断信息的 LLM_ALL_KEYS_FAILED */
async function withKeyPool(config, task) {
  const pool = poolFor(config);
  const attempts = [];
  const keysMasked = config.apiKeys.map(maskKey);

  for (let tried = 0; tried < config.apiKeys.length; tried += 1) {
    const index = pool.pick();
    if (index < 0) break;
    try {
      const result = await task(config.apiKeys[index], index);
      return { ...result, key_index: index, key_masked: keysMasked[index] };
    } catch (error) {
      if (error instanceof LLMError && KEY_SWITCH_CODES.has(error.code)) {
        pool.markFailed(index, `${error.code}: ${error.message}`);
        attempts.push({ key: keysMasked[index], code: error.code, status: error.status, message: error.message });
        continue;
      }
      throw error;
    }
  }

  throw new LLMError(
    'LLM_ALL_KEYS_FAILED',
    `全部 ${config.apiKeys.length} 个密钥调用均失败`,
    502,
    '检查 .env 中 LLM_API_KEYS 是否有效、额度是否耗尽，或稍后重试（失败密钥会自动冷却一段时间后重新可用）。',
    { attempts, pool: pool.status() }
  );
}

function normalizeBase(rawPath) {
  return String(rawPath || '').startsWith('/') ? rawPath : `/${rawPath || ''}`;
}

async function httpJson(url, init, timeoutMs) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let response;
  try {
    response = await fetch(url, { ...init, signal: controller.signal });
  } catch (error) {
    clearTimeout(timer);
    if (error.name === 'AbortError') {
      throw new LLMError('LLM_TIMEOUT', `模型调用超时（${timeoutMs}ms）`, 504, '增大 LLM_TIMEOUT_MS，或检查到模型服务的网络链路。', { url });
    }
    throw new LLMError('LLM_NETWORK_ERROR', `无法连接模型服务：${error.message}`, 502, '检查 LLM_BASE_URL 是否可达、端口是否放行、代理是否正确。', { url });
  } finally {
    clearTimeout(timer);
  }

  const rawText = await response.text().catch(() => '');
  if (!response.ok) {
    const code = response.status === 401 || response.status === 403
      ? 'LLM_AUTH_FAILED'
      : response.status === 429 ? 'LLM_RATE_LIMITED' : 'LLM_UPSTREAM_ERROR';
    const hint = {
      LLM_AUTH_FAILED: 'API Key 无效、已过期或无该模型权限。',
      LLM_RATE_LIMITED: '触发额度/限流，会自动切换到下一个密钥。',
      LLM_UPSTREAM_ERROR: '模型服务端返回异常。'
    }[code];
    throw new LLMError(code, `模型服务返回 HTTP ${response.status}`, 502, hint, { status: response.status, body: safeBody(rawText) });
  }
  return { rawText, response };
}

function safeBody(text) {
  try { return JSON.parse(text); } catch (_) { return String(text || '').slice(0, 500); }
}

function extractContent(payload) {
  const choice = Array.isArray(payload?.choices) ? payload.choices[0] : null;
  const message = choice?.message || {};
  const content = typeof message.content === 'string'
    ? message.content
    : Array.isArray(message.content)
      ? message.content.map(part => part?.text || '').join('')
      : '';
  return {
    content: String(content || ''),
    /* 推理模型把思考过程放在 reasoning_content、正文放在 content；
       max_tokens 不足时推理会吃光预算导致正文为空，必须显式报错。 */
    reasoning: String(message.reasoning_content || ''),
    finishReason: choice?.finish_reason || '',
    usage: payload?.usage || null,
    model: payload?.model || '',
    requestId: payload?.id || payload?.request_id || ''
  };
}

function assertNonEmpty(result, context) {
  if (result.content.trim()) return result;
  const hint = result.reasoning
    ? '该模型是推理模型，思考过程耗尽了 token 预算导致正文为空。请增大 LLM_MAX_TOKENS（建议 4096 以上）。'
    : '模型返回了空正文，请检查模型状态或调整提示词。';
  throw new LLMError('LLM_EMPTY_CONTENT', `模型返回正文为空（${context}）`, 502, hint, {
    finish_reason: result.finishReason,
    usage: result.usage,
    reasoning_preview: result.reasoning.slice(0, 200)
  });
}

function parseJsonLoose(text) {
  const cleaned = String(text || '').trim()
    .replace(/^```(?:json)?\s*/i, '')
    .replace(/```\s*$/, '')
    .trim();
  try { return JSON.parse(cleaned); } catch (_) { /* 继续尝试截取 */ }
  const start = cleaned.indexOf('{');
  const end = cleaned.lastIndexOf('}');
  if (start > -1 && end > start) {
    try { return JSON.parse(cleaned.slice(start, end + 1)); } catch (_) { /* 落到下面报错 */ }
  }
  throw new LLMError('LLM_BAD_JSON', '模型返回的不是合法 JSON', 502, '可在 .env 调低 LLM_TEMPERATURE，或更换结构化能力更强的模型。', { preview: cleaned.slice(0, 300) });
}

async function callWithRetry(fn, maxRetries) {
  let lastError;
  for (let attempt = 0; attempt <= Math.max(0, maxRetries); attempt += 1) {
    try { return await fn(); } catch (error) {
      lastError = error;
      const retriable = ['LLM_TIMEOUT', 'LLM_RATE_LIMITED', 'LLM_NETWORK_ERROR', 'LLM_UPSTREAM_ERROR'].includes(error.code);
      if (!retriable || attempt === maxRetries) break;
      await new Promise(resolve => setTimeout(resolve, 500 * (attempt + 1)));
    }
  }
  throw lastError;
}

function baseResult(call, purpose, startedAt, extraText) {
  return {
    purpose,
    provider: call.model,
    model: call.model,
    request_id: call.requestId,
    usage: call.usage,
    finish_reason: call.finishReason,
    latency_ms: Date.now() - startedAt,
    response_hash: call.rawText ? crypto.createHash('sha256').update(call.rawText).digest('hex').slice(0, 16) : '',
    /* 用到了哪个密钥：多密钥池里定位问题靠它，脱敏后写进 evidence */
    key_index: call.key_index,
    key_masked: call.key_masked,
    ...(extraText ? { text: call.content } : {})
  };
}

/* ---------------------------------------------------------------- 文本对话 */
async function chatText({ system, prompt, temperature, maxTokens, purpose = 'text', json = false, responseFormat }, overrides = {}) {
  const config = assertConfigured(overrides.config || readConfig());
  const startedAt = Date.now();
  const result = await withKeyPool(config, async (apiKey) => {
    const call = await callWithRetry(async () => {
      const { rawText } = await httpJson(`${config.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: config.model,
          messages: [
            { role: 'system', content: system || '你是严谨的企业数据处理助手。' },
            { role: 'user', content: prompt }
          ],
          temperature: Number.isFinite(temperature) ? temperature : config.temperature,
          max_tokens: maxTokens || config.maxTokens,
          ...(json || responseFormat ? { response_format: responseFormat || { type: 'json_object' } } : {})
        })
      }, config.timeoutMs);
      return { ...extractContent(JSON.parse(rawText)), rawText };
    }, config.maxRetries);
    assertNonEmpty(call, `chat/${purpose}`);
    return call;
  });

  const meta = baseResult(result, purpose, startedAt, true);
  return { ...meta, json: json ? parseJsonLoose(result.content) : null };
}

async function chatJson(options, overrides) {
  return chatText({ ...options, json: true, purpose: options.purpose || 'json' }, overrides);
}

/* ------------------------------------------------------------------- 图像理解 */
async function visionJson({ buffer, mime = 'image/png', prompt, system, maxTokens, purpose = 'vision' }, overrides = {}) {
  const config = assertConfigured(overrides.config || readConfig());
  if (!config.visionModel) {
    throw new LLMError(
      'LLM_VISION_NOT_CONFIGURED',
      '未配置视觉模型 LLM_VISION_MODEL',
      503,
      '当前接口只提供纯文本模型，无法识别图片。请提供一个支持视觉输入的模型端点，' +
      '或改用 OCR 服务（如 PaddleOCR / Tesseract）后再接入。本服务不会伪造识别结果。'
    );
  }
  const startedAt = Date.now();
  const dataUrl = `data:${mime};base64,${Buffer.from(buffer).toString('base64')}`;
  const result = await withKeyPool(config, async (apiKey) => {
    const call = await callWithRetry(async () => {
      const { rawText } = await httpJson(`${config.baseUrl}/chat/completions`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
          Authorization: `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: config.visionModel,
          messages: [
            { role: 'system', content: system || '你是工业现场表单与仪表图像识别助手。' },
            {
              role: 'user',
              content: [
                { type: 'image_url', image_url: { url: dataUrl } },
                { type: 'text', text: prompt }
              ]
            }
          ],
          temperature: config.temperature,
          max_tokens: maxTokens || config.maxTokens,
          response_format: { type: 'json_object' }
        })
      }, config.timeoutMs);
      return { ...extractContent(JSON.parse(rawText)), rawText };
    }, config.maxRetries);
    assertNonEmpty(call, 'vision');
    return call;
  });

  const meta = baseResult(result, purpose, startedAt);
  return { ...meta, model: config.visionModel, json: parseJsonLoose(result.content), text: result.content };
}

/* ------------------------------------------------------------- 语音转写 ASR */
async function transcribe({ buffer, filename = 'audio.wav', mime = 'audio/wav', language = 'zh', prompt, purpose = 'asr' }, overrides = {}) {
  const config = assertConfigured(overrides.config || readConfig());
  if (!config.asrModel) {
    throw new LLMError(
      'LLM_ASR_NOT_CONFIGURED',
      '未配置语音转写模型 LLM_ASR_MODEL',
      503,
      '当前接口未提供 /audio/transcriptions。可选方案：' +
      '① 配置支持 Whisper 协议的服务；② 部署本机 faster-whisper 并填 LOCAL_ASR_BASE。' +
      '本服务不会返回伪造的转写文本。'
    );
  }
  const startedAt = Date.now();
  const url = `${config.baseUrl}${normalizeBase(config.asrPath)}`;

  const result = await withKeyPool(config, async (apiKey) => {
    return callWithRetry(async () => {
      const form = new FormData();
      form.append('file', new Blob([buffer], { type: mime }), filename);
      form.append('model', config.asrModel);
      if (language) form.append('language', language);
      if (prompt) form.append('prompt', prompt);
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), config.timeoutMs);
      let response;
      try {
        response = await fetch(url, { method: 'POST', headers: { Accept: 'application/json', Authorization: `Bearer ${apiKey}` }, body: form, signal: controller.signal });
      } catch (error) {
        clearTimeout(timer);
        if (error.name === 'AbortError') throw new LLMError('LLM_TIMEOUT', `语音转写超时（${config.timeoutMs}ms）`, 504, '增大 LLM_TIMEOUT_MS 或缩短音频。', { url });
        throw new LLMError('LLM_NETWORK_ERROR', `无法连接语音转写服务：${error.message}`, 502, '该端点需支持 OpenAI /audio/transcriptions 协议，可用 LLM_ASR_PATH 覆写路径。', { url });
      } finally {
        clearTimeout(timer);
      }
      const rawText = await response.text().catch(() => '');
      if (!response.ok) {
        const code = response.status === 401 || response.status === 403 ? 'LLM_AUTH_FAILED' : response.status === 429 ? 'LLM_RATE_LIMITED' : 'LLM_UPSTREAM_ERROR';
        throw new LLMError(code, `语音转写返回 HTTP ${response.status}`, 502,
          '确认该模型服务提供 Whisper 兼容转写能力，或改用支持 /audio/transcriptions 的服务。', { status: response.status, body: safeBody(rawText) });
      }
      return { rawText };
    }, config.maxRetries);
  });

  let text = '';
  let body;
  try {
    body = JSON.parse(result.rawText);
    text = String(body.text || body.transcript || '').trim();
  } catch (_) {
    text = String(result.rawText || '').trim();
    body = {};
  }
  if (!text) throw new LLMError('LLM_EMPTY_TRANSCRIPT', '语音转写结果为空', 502, '检查音频编码是否受支持（推荐 16kHz 单声道 WAV/MP3）。', { body: safeBody(result.rawText) });
  return {
    purpose,
    provider: body.model || config.asrModel,
    model: config.asrModel,
    request_id: body.id || body.request_id || '',
    usage: body.usage || null,
    latency_ms: Date.now() - startedAt,
    response_hash: crypto.createHash('sha256').update(result.rawText).digest('hex').slice(0, 16),
    key_index: result.key_index,
    key_masked: result.key_masked,
    text
  };
}

/* -------------------------------------------------------------- 连通性自检 */
async function ping(overrides = {}) {
  const config = overrides.config || readConfig();
  if (!isConfigured(config)) return { ok: false, ...describeConfig(config) };
  const startedAt = Date.now();
  try {
    /* 推理模型会先把思考写进 reasoning_content，预算太小会吃光正文，
       所以探针也按正常任务给足 token，而不是象征性给几十个。 */
    const result = await chatText({
      system: '你是一个连通性探针。',
      prompt: '只回复两个字：正常',
      maxTokens: 512,
      purpose: 'ping'
    }, { config });
    return {
      ok: true,
      model: result.model,
      latency_ms: result.latency_ms,
      request_id: result.request_id,
      usage: result.usage,
      key_index: result.key_index,
      key_masked: result.key_masked,
      text: result.text || '',
      roundtrip_ms: Date.now() - startedAt
    };
  } catch (error) {
    return {
      ok: false,
      error: { code: error.code, message: error.message, hint: error.hint },
      ...describeConfig(config, poolFor(config))
    };
  }
}

module.exports = {
  LLMError,
  KeyPool,
  readConfig,
  isConfigured,
  describeConfig,
  missingFields,
  maskKey,
  assertConfigured,
  chatText,
  chatJson,
  visionJson,
  transcribe,
  ping,
  parseJsonLoose
};
