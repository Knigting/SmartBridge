'use strict';

/* ==========================================================================
   tasks.js —— 五类 Skill 各自的真实大模型任务
   --------------------------------------------------------------------------
   每一个函数都真实发起一次模型调用，并把凭据证据（模型名 / request_id / 哈希）
   返回给上层写进 Skill 的 evidence。任何一处模型不可用，都抛出带处理建议的错误，
   由路由转成明确的 HTTP 错误——不回落到任何写死的演示结果。

   共同的提示词纪律（重要）：
     · 数字一律由代码算好再喂给模型，禁止模型自己编统计值；
     · 只能依据传入的片段/数据作答，禁止凭自身知识补充事实；
     · 输出要求 JSON，由 parseJsonLoose 容忍围栏与前后废话。
   ========================================================================== */
const fs = require('fs');
const llm = require('./provider');

function evidence(call, extra) {
  return Object.assign({
    model: call.model,
    request_id: call.request_id,
    latency_ms: call.latency_ms,
    response_hash: call.response_hash
  }, extra || {});
}

/* ---------------------------------------------------- 1. 批量文件解析：摘要 */
async function summarizeParse(parsed, purpose) {
  const fileLines = (parsed.files || []).map(file => {
    const preview = String(file.text || '').slice(0, 600).replace(/\s+/g, ' ').trim();
    return `- ${file.name}（${file.type || '未知'}，${file.rows || 0} 行）字段：${(file.fields || []).join('、') || '无'}\n  片段：${preview}`;
  }).join('\n');

  const call = await llm.chatJson({
    system: '你是产教融合实训平台的数据分析助手。只依据给定内容作答，不得编造。',
    prompt: `解析目的：${purpose || '未指定'}
本次解析结果（由规则引擎产出，字段与行数已确认无误）：
文件数 ${parsed.count || 0}，成功 ${parsed.succeeded || 0}，失败 ${parsed.failed || 0}
${fileLines}

请输出 JSON：
{"summary": "不超过 120 字，说明这批文件整体是什么业务材料",
 "highlights": ["不超过 3 条，每条不超过 40 字，指出值得教师注意的点"],
 "anomaly_advice": "针对下面的异常，给出一句处理建议；无异常则填空字符串"}

已检出的异常：${JSON.stringify((parsed.anomalies || []).slice(0, 10))}`,
    purpose: 'parse-batch-summary'
  });
  return { json: call.json || {}, evidence: evidence(call) };
}

/* --------------------------------------------------------- 2. RAG：生成作答 */
async function answerFromContext(query, hits) {
  const context = (hits || []).map((hit, index) =>
    `[${index + 1}] 来源：${hit.title || '未命名'}（${hit.scope || '未分类'}，第 ${hit.chunk_no || '?'} 段）\n${String(hit.snippet || hit.text_content || '').slice(0, 500)}`
  ).join('\n\n');

  if (!context) {
    return {
      answer: '当前知识库中没有找到足够可靠的依据，我不能替你猜业务规则。已把问题转交教师确认。',
      requires_confirmation: true,
      evidence: null
    };
  }

  const call = await llm.chatJson({
    system: '你是可追溯知识检索助手。只能依据给定的片段作答，每个结论必须标注引用编号。',
    prompt: `问题：${query}

可用片段：
${context}

请输出 JSON：
{"answer": "用中文作答，每个结论后标注 [编号]",
 "requires_confirmation": true 或 false,
 "reason": "一句话说明为什么需要或不需要人工确认"}
片段不足以支撑结论时，answer 明说依据不足，requires_confirmation 填 true。`,
    purpose: 'rag-answer'
  });
  const json = call.json || {};
  return {
    answer: String(json.answer || '').trim() || '模型未返回有效回答。',
    requires_confirmation: Boolean(json.requires_confirmation),
    reason: String(json.reason || '').trim(),
    evidence: evidence(call)
  };
}

/* ------------------------------------------------------- 3. 报告：生成叙述 */
async function narrateReport(prepared, kind) {
  const metrics = (prepared.metrics || []).map(m => `${m.label}：${m.value}${m.note ? `（${m.note}）` : ''}`).join('；');
  const call = await llm.chatJson({
    system: '你是产教融合实训平台的报告撰写助手。只能使用给定的指标数字，绝不能自行编造任何数值。',
    prompt: `报告类型：${kind || '执行报告'}
标题：${prepared.title || '未命名'}

已由代码算好的指标（这是唯一可引用的数值来源）：
${metrics || '（无）'}

请输出 JSON：
{"conclusion": "不超过 150 字的总体结论",
 "analysis": "不超过 200 字的要点分析，可指出正向/负向指标含义",
 "suggestion": "不超过 120 字的可执行改进建议"}
禁止出现上面指标之外的任何数字。`,
    purpose: 'report-narrative'
  });
  const json = call.json || {};
  const sections = [
    { h: '结论与数据分析', p: [json.conclusion, json.analysis].filter(Boolean).join('\n\n') },
    { h: '改进建议', p: String(json.suggestion || '').trim() }
  ].filter(section => section.p);
  return { sections, evidence: evidence(call) };
}

/* --------------------------------------------- 4. 实训系统操作：意图转计划 */
async function interpretTraining(instruction, systems) {
  const catalog = Object.keys(systems || {}).map(id => {
    const system = systems[id];
    return `${id}：${system.label || id}，可用动作 ${Object.keys(system.actions || {}).join('、')}`;
  }).join('\n');

  const call = await llm.chatJson({
    system: '你是实训系统操作意图解析器。只能从给定的系统与动作中选择，不得发明新动作。',
    prompt: `可用系统与动作：
${catalog}

用户指令：${instruction}

请输出 JSON：
{"system": "系统 id", "action": "动作名", "op": "read 或 write", "payload": {}, "reason": "一句话说明判断依据"}
无法确定时 system 与 action 填空字符串。`,
    purpose: 'training-interpret'
  });
  return { json: call.json || {}, evidence: evidence(call) };
}

/* -------------------------------------------------- 5. 多模态：图片 / 音频 */
async function recognizeImage(filePath, mimeType, purpose) {
  const buffer = fs.readFileSync(filePath);
  const call = await llm.visionJson({
    buffer,
    mime: mimeType || 'image/png',
    prompt: `这是产教融合实训现场的图片。用途：${purpose || '未指定'}。
请输出 JSON：{"text": "识别出的文字", "fields": {"字段名": "值"}, "summary": "一句话说明这张图反映了什么"}`,
    purpose: 'multimodal-image'
  });
  return { json: call.json || {}, evidence: evidence(call) };
}

async function transcribeAudio(filePath, fileName, language) {
  const buffer = fs.readFileSync(filePath);
  const call = await llm.transcribe({ buffer, filename: fileName, language: language || 'zh', purpose: 'multimodal-audio' });
  return { text: call.text, evidence: evidence(call) };
}

/* 用文本模型把转写稿整理成结构化要点（音频链路的第二步，同样真实调用） */
async function structureTranscript(transcript, purpose) {
  const call = await llm.chatJson({
    system: '你是语音内容结构化助手。只能依据给定转写文本作答，不得添加内容。',
    prompt: `转写文本：${transcript}

用途：${purpose || '未指定'}
请输出 JSON：{"fields": {"字段名": "值"}, "summary": "一句话概括核心诉求"}`,
    purpose: 'multimodal-audio-structure'
  });
  return { json: call.json || {}, evidence: evidence(call) };
}

module.exports = {
  summarizeParse,
  answerFromContext,
  narrateReport,
  interpretTraining,
  recognizeImage,
  transcribeAudio,
  structureTranscript
};
