const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const multer = require('multer');
/* .env 必须在读取任何配置之前加载：LLM_* / SKILL_* 都从这里来 */
require('./env').loadEnv();
const { parseBatch, enrichBatch, TEXT_LIKE_EXTS } = require('./skills/file-parser');
const { chunkText, retrieve, answerFromHits, selectCandidates, synthesizeAnswer } = require('./skills/rag');
const { buildReport, saveReport, prepareReportData, synthesizeNarrative, getReportProfile } = require('./skills/report');
const { SANDBOX_SYSTEMS, createPlan, interpretInstruction, executeSandbox, executeHttp, hash, getTrainingPolicy } = require('./skills/training');
const { inspectMedia, recognizeMedia } = require('./skills/multimodal');
const tasks = require('./llm/tasks');
const llm = require('./llm/provider');

const app = express();
const port = Number(process.env.SKILL_PORT || 8090);
const apiKey = String(process.env.SKILL_API_KEY || '');
const runtimeDir = path.resolve(__dirname, '..', 'runtime');
const uploadDir = path.join(runtimeDir, 'uploads');
const reportDir = path.join(runtimeDir, 'reports');
const statePath = path.join(runtimeDir, 'state.json');
const uuid = () => crypto.randomUUID();

function loadConfig(envName) {
  const configPath = process.env[envName];
  if (!configPath) return {};
  try { return JSON.parse(fs.readFileSync(path.resolve(configPath), 'utf8')); }
  catch (error) { console.warn(`${envName} 配置读取失败：${error.message}`); return {}; }
}

const trainingSystems = loadConfig('TRAINING_SYSTEM_CONFIG');
/* 多模态不再有"本地演示通道"：能力状态完全取决于是否配置了可用的视觉/转写模型。
   未配置即为 not_configured，接口调用时返回明确错误，而不是返回任何演示数据。 */
const llmConfig = llm.readConfig();
const multimodalMode = (llmConfig.visionModel || llmConfig.asrModel) && llm.isConfigured(llmConfig) ? 'live' : 'not_configured';

/* 模型增强层：解析/检索/报告的核心结果由代码产出，模型只做"说清楚"。
   模型不可用时**不伪造内容**，只在结果里如实标注 model_error，核心功能照常可用。 */
async function attachModelInsights(run, attach) {
  try {
    return await attach();
  } catch (error) {
    return {
      model_error: {
        code: error.code || 'LLM_ERROR',
        message: error.message,
        hint: error.hint || '',
        note: '核心结果仍为真实解析/检索/计算所得，仅缺少模型生成的说明文字。'
      }
    };
  }
}

for (const directory of [runtimeDir, uploadDir, reportDir]) fs.mkdirSync(directory, { recursive: true });

function readState() {
  try { return JSON.parse(fs.readFileSync(statePath, 'utf8')); }
  catch (_) { return { runs: {}, documents: [], chunks: [], reports: {} }; }
}

let state = readState();
state.runs = state.runs || {};
state.documents = state.documents || [];
state.chunks = state.chunks || [];
state.reports = state.reports || {};
state.training = state.training || { plans: {}, executions: {}, sandbox: {} };
state.training.plans = state.training.plans || {};
state.training.executions = state.training.executions || {};
state.training.sandbox = state.training.sandbox || {};
function saveState() {
  const temp = `${statePath}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(state, null, 2), 'utf8');
  fs.renameSync(temp, statePath);
}

function envelope(skill, runId, input, output, evidence = [], mode = 'live') {
  return { skill, version: '1.0.0', ok: true, code: 'ok', mode, input, output, evidence, error: '', meta: { run_id: runId, at: new Date().toISOString(), adapter: 'SmartBridge Standalone Skill Service' } };
}

function startRun(skill, input) {
  const id = uuid();
  state.runs[id] = { id, skill, status: 'running', input, started_at: new Date().toISOString() };
  saveState();
  return id;
}

function finishRun(id, result, error) {
  state.runs[id] = { ...state.runs[id], status: error ? 'failed' : 'success', result: result || null, error: error || '', finished_at: new Date().toISOString() };
  saveState();
}

function sendOk(res, data, status = 200) { res.status(status).json({ code: 'OK', message: 'success', data, request_id: res.locals.requestId }); }
function sendError(res, status, code, message) { res.status(status).json({ code, message, data: null, request_id: res.locals.requestId }); }
const asyncRoute = handler => (req, res, next) => Promise.resolve(handler(req, res, next)).catch(next);

app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: false, contentSecurityPolicy: false }));
app.use((req, res, next) => {
  res.locals.requestId = uuid();
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Skill-Api-Key, Idempotency-Key');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  if (apiKey && req.headers['x-skill-api-key'] !== apiKey) return sendError(res, 401, 'INVALID_SKILL_KEY', 'Skill API Key 无效');
  next();
});
app.use(express.json({ limit: '4mb' }));

const upload = multer({
  storage: multer.diskStorage({
    destination: uploadDir,
    filename: (_req, file, callback) => callback(null, `${Date.now()}-${uuid()}${path.extname(file.originalname).toLowerCase()}`)
  }),
  limits: { fileSize: 20 * 1024 * 1024, files: 20 }
});

/* multer 默认按 latin1 解码 multipart 文件名，中文名会变成乱码，这里还原为 UTF-8 */
function decodeName(name) {
  const raw = String(name || '');
  return /[\u00c0-\u00ff]/.test(raw) ? Buffer.from(raw, 'latin1').toString('utf8') : raw;
}

function uploadedFiles(req) {
  return (req.files || []).map(file => ({
    id: uuid(), original_name: decodeName(file.originalname), storage_path: file.path, mime_type: file.mimetype,
    size_bytes: file.size, sha256: crypto.createHash('sha256').update(fs.readFileSync(file.path)).digest('hex')
  }));
}

app.get('/api/skills/status', (_req, res) => {
  const reportProfile = getReportProfile();
  const config = llm.readConfig();
  const textReady = llm.isConfigured(config);
  sendOk(res, {
  required: 5, available: 5,
  live: 4 + (multimodalMode === 'live' ? 1 : 0),
  storage: '独立本地运行目录',
  model: {
    state: textReady ? 'live' : 'not_configured',
    base_url: config.baseUrl || '',
    model: config.model || '',
    vision_model: config.visionModel || '',
    asr_model: config.asrModel || '',
    keys: config.apiKeys.length,
    masked_keys: config.apiKeys.map(key => llm.maskKey(key)),
    missing: llm.missingFields(config)
  },
  skills: [
    { key: 'parse-batch', state: 'live', model: textReady, formats: ['xlsx', 'csv', 'tsv', 'json', 'txt', 'md', 'docx', 'pdf'] },
    { key: 'rag', state: 'live', model: textReady, engine: '可追溯本地检索 + 大模型组织作答' },
    { key: 'report', state: reportProfile ? 'trained' : 'live', model: textReady, formats: ['html'], training: reportProfile ? reportProfile.training_summary : null },
    { key: 'training', state: Object.keys(trainingSystems).length ? 'live' : (getTrainingPolicy() ? 'local' : 'not_configured'), model: textReady, systems: [...Object.keys(SANDBOX_SYSTEMS), ...Object.keys(trainingSystems)] },
    { key: 'multimodal', state: multimodalMode, model: multimodalMode === 'live', kinds: ['image', 'audio'], mode: multimodalMode }
  ]
  });
});

/* 模型连通性自检：返回真实 request_id 与首段回答，用于当场证明"确实调到了模型" */
app.get('/api/skills/model/ping', asyncRoute(async (_req, res) => {
  const config = llm.readConfig();
  if (!llm.isConfigured(config)) {
    return sendError(res, 503, llm.LLMError ? 'MODEL_NOT_CONFIGURED' : 'MODEL_NOT_CONFIGURED',
      `大模型未配置完整，缺失：${llm.missingFields(config).join('、') || '未知'}`);
  }
  try {
    const call = await llm.ping();
    const probe = Number(process.env.LLM_MAX_TOKENS || 0);
    if (!call.ok) {
      return sendError(res, 502, (call.error && call.error.code) || 'MODEL_UNREACHABLE',
        `模型调用失败：${(call.error && call.error.message) || '未知原因'}`);
    }
    sendOk(res, {
      state: 'live',
      base_url: config.baseUrl,
      model: call.model,
      request_id: call.request_id,
      latency_ms: call.latency_ms,
      usage: call.usage,
      key_masked: call.key_masked,
      max_tokens: probe || null,
      reply: String(call.text || '').slice(0, 200)
    });
  } catch (error) {
    sendError(res, 502, error.code || 'MODEL_UNREACHABLE', `模型调用失败：${error.message}`);
  }
}));

app.get('/api/skills/report/profile', (_req, res) => {
  const profile = getReportProfile();
  if (!profile) return sendError(res, 404, 'REPORT_PROFILE_NOT_FOUND', '报告 Skill 尚未导入训练数据');
  sendOk(res, { version: profile.version, generated_at: profile.generated_at, periods: profile.periods, training_summary: profile.training_summary, sources: profile.sources.map(item => ({ file: item.file, sha256: item.sha256 })) });
});

app.get('/api/skills/training/systems', (_req, res) => sendOk(res, {
  policy: getTrainingPolicy(),
  systems: [
    ...Object.entries(SANDBOX_SYSTEMS).map(([id, system]) => ({ id, label: system.label, mode: 'local', actions: system.actions })),
    ...Object.entries(trainingSystems).map(([id, system]) => ({ id, label: system.label || id, mode: 'live', actions: system.actions || {} }))
  ]
}));

app.post('/api/skills/training/plan', asyncRoute(async (req, res) => {
  const body = req.body || {};
  const instruction = String(body.instruction || '').trim();
  let interpreted = null;
  let planInput = body;

  if (instruction) {
    /* 自然语言指令：真实大模型解析成结构化意图，再交给 createPlan 做确定性校验。
       模型只负责"听懂人话"，能不能做由白名单与策略说了算。 */
    interpreted = await attachModelInsights(null, () => interpretInstruction(instruction, trainingSystems));
    if (interpreted.model_error) {
      return sendError(res, 502, interpreted.model_error.code || 'LLM_ERROR',
        `大模型未能解析该指令：${interpreted.model_error.message}`);
    }
    if (!interpreted.parsed.system || !interpreted.parsed.action) {
      return sendError(res, 400, 'INSTRUCTION_UNRESOLVED',
        `大模型未能把指令匹配到已授权的动作：${interpreted.parsed.reason || '未给出理由'}`);
    }
    /* 模型给出的 payload 与 op 一律不直接采信：op 由动作白名单重算，payload 只用于补全缺失字段 */
    planInput = {
      system: interpreted.parsed.system,
      action: interpreted.parsed.action,
      payload: { ...(body.payload || {}), ...(interpreted.parsed.payload || {}) }
    };
  }

  const plan = createPlan(planInput, trainingSystems);
  const planId = uuid();
  const stored = { ...plan, id: planId, status: 'planned', instruction, created_at: new Date().toISOString(), expires_at: new Date(Date.now() + 30 * 60 * 1000).toISOString() };
  state.training.plans[planId] = stored;
  saveState();
  sendOk(res, {
    plan_id: planId, summary: plan.summary, system: plan.system, action: plan.action, op: plan.op,
    risk: plan.risk, approval_required: plan.approval_required, verify_required: plan.verify_required,
    plan_hash: plan.plan_hash, expires_at: stored.expires_at,
    model: interpreted
      ? { parsed: interpreted.parsed, model_evidence: interpreted.model_evidence, note: '意图由大模型解析，执行参数由白名单与策略二次校验后确定' }
      : null
  }, 201);
}));

app.post('/api/skills/training/plans/:id/approve', asyncRoute(async (req, res) => {
  const plan = state.training.plans[req.params.id];
  if (!plan) return sendError(res, 404, 'PLAN_NOT_FOUND', '操作计划不存在');
  if (Date.parse(plan.expires_at) < Date.now()) return sendError(res, 409, 'PLAN_EXPIRED', '操作计划已过期');
  const approvedBy = String(req.body.approved_by || '').trim();
  if (!approvedBy) return sendError(res, 400, 'APPROVER_REQUIRED', '请记录审批人');
  const token = crypto.randomBytes(24).toString('hex');
  plan.status = 'approved';
  plan.approved_by = approvedBy;
  plan.approval_reason = String(req.body.reason || '');
  plan.approved_at = new Date().toISOString();
  plan.approval_token_hash = hash(token);
  plan.approval_expires_at = new Date(Date.now() + 10 * 60 * 1000).toISOString();
  saveState();
  sendOk(res, { plan_id: plan.id, approval_token: token, approved_by: approvedBy, expires_at: plan.approval_expires_at });
}));

app.post('/api/skills/training/execute', asyncRoute(async (req, res) => {
  const plan = state.training.plans[String(req.body.plan_id || '')];
  if (!plan) return sendError(res, 404, 'PLAN_NOT_FOUND', '操作计划不存在');
  if (Date.parse(plan.expires_at) < Date.now()) return sendError(res, 409, 'PLAN_EXPIRED', '操作计划已过期');
  if (plan.plan_hash !== createPlan(plan, trainingSystems).plan_hash) return sendError(res, 409, 'PLAN_CHANGED', '操作计划校验失败');
  const idempotencyKey = String(req.headers['idempotency-key'] || req.body.idempotency_key || '');
  if (plan.op === 'write' && !idempotencyKey) return sendError(res, 400, 'IDEMPOTENCY_KEY_REQUIRED', '写操作必须提供 Idempotency-Key');
  const executionKey = idempotencyKey ? `${plan.id}:${idempotencyKey}` : '';
  if (executionKey && state.training.executions[executionKey]) return sendOk(res, state.training.executions[executionKey].result);
  if (plan.approval_required) {
    if (plan.status !== 'approved' || Date.parse(plan.approval_expires_at) < Date.now() || hash(String(req.body.approval_token || '')) !== plan.approval_token_hash) return sendError(res, 403, 'APPROVAL_REQUIRED', '写操作需要有效的人工审批令牌');
  }
  const input = { plan_id: plan.id, system: plan.system, action: plan.action, op: plan.op, plan_hash: plan.plan_hash, idempotency_key: idempotencyKey };
  const runId = startRun('training', input);
  try {
    const external = trainingSystems[plan.system];
    const execution = external ? await executeHttp(plan, external) : executeSandbox(plan, state.training.sandbox, uuid);
    const mode = 'live';
    const connector = external ? 'external' : 'local';
    const evidence = [{ plan_id: plan.id, plan_hash: plan.plan_hash, approved_by: plan.approved_by || '', idempotency_key: idempotencyKey, connector, verify: execution.verify, target: execution.target || { system: plan.system } }];
    const output = { ...execution.output, verification: execution.verify };
    const result = envelope('training', runId, input, output, evidence, mode);
    if (executionKey) state.training.executions[executionKey] = { at: new Date().toISOString(), result };
    plan.status = 'executed';
    plan.executed_at = new Date().toISOString();
    finishRun(runId, result, null);
    sendOk(res, result);
  } catch (error) {
    finishRun(runId, null, error.message);
    throw error;
  }
}));

app.get('/api/skills/multimodal/status', (_req, res) => {
  const config = llm.readConfig();
  const visionReady = Boolean(config.baseUrl && config.apiKeys.length && config.visionModel);
  const asrReady = Boolean(config.baseUrl && config.apiKeys.length && config.asrModel);
  sendOk(res, {
    state: (visionReady || asrReady) ? 'live' : 'not_configured',
    mode: (visionReady || asrReady) ? 'live' : 'not_configured',
    provider: (visionReady || asrReady) ? (config.visionModel || config.asrModel) : null,
    vision: visionReady ? { ready: true, model: config.visionModel } : { ready: false, reason: '未配置 LLM_VISION_MODEL，当前模型服务只提供纯文本能力' },
    asr: asrReady ? { ready: true, model: config.asrModel } : { ready: false, reason: '未配置 LLM_ASR_MODEL，且当前模型服务未提供 /audio/transcriptions' },
    note: '已移除本地演示通道。能力未配置时接口返回明确错误，不会返回任何演示数据。',
    supported: { image: ['png', 'jpeg', 'webp'], audio: ['wav', 'mp3', 'mp4', 'webm', 'ogg'] }
  });
});

app.post('/api/skills/multimodal/recognize', upload.single('file'), asyncRoute(async (req, res) => {
  if (!req.file) return sendError(res, 400, 'FILE_REQUIRED', '请通过 file 字段上传图片或音频');
  const input = { kind: String(req.body.kind || ''), purpose: String(req.body.purpose || ''), language: String(req.body.language || 'zh-CN') };
  const runId = startRun('multimodal', input);
  try {
    const media = inspectMedia(req.file, input.kind);
    input.kind = media.kind;
    const recognized = await recognizeMedia(media, req.file, input);
    const evidence = [{ file: media.name, sha256: media.sha256, mime_type: media.mime_type, size_bytes: media.size_bytes, width: media.width, height: media.height, duration_seconds: media.duration_seconds }, recognized.provider_evidence];
    const output = { ...recognized.output, media };
    const result = envelope('multimodal', runId, input, output, evidence, 'live');
    finishRun(runId, result, null);
    sendOk(res, result);
  } catch (error) {
    finishRun(runId, null, error.message);
    throw error;
  }
}));

app.post('/api/skills/parse-batch', upload.array('files', 20), asyncRoute(async (req, res) => {
  const files = uploadedFiles(req);
  if (!files.length) return sendError(res, 400, 'FILES_REQUIRED', '请通过 multipart/form-data 的 files 字段上传文件');
  const purpose = String(req.body.purpose || '');
  const input = { purpose, files: files.map(file => ({ name: file.original_name, size: file.size_bytes, sha256: file.sha256 })) };
  const runId = startRun('parse-batch', input);
  try {
    /* 第一步：规则引擎真实解析（字段、行数、异常全部来自文件本身） */
    const parsed = await parseBatch(files);
    /* 第二步：真实大模型给每份文件写业务摘要与处置建议（失败不致命，核心结果照常返回） */
    const enriched = await attachModelInsights(runId, () => enrichBatch(parsed, { purpose }));
    const output = enriched.model_error ? { ...parsed, model_error: enriched.model_error } : enriched;
    const result = envelope('parse-batch', runId, input, output, [...(output.evidence || []), output.model_evidence].filter(Boolean));
    finishRun(runId, result, null);
    sendOk(res, result);
  } catch (error) {
    finishRun(runId, null, error.message);
    throw error;
  }
}));

/* 内置样例解析：接入位没有真实文件时用它跑通批量解析，返回真实解析结果与证据。
   页面接入位可以在 data-args.files 里声明自己那一批业务文件（例如
   ["inspection-sample-last-4-weeks.xlsx","equipment-inspection-work-instructions.pdf"]），这里按声明挑文件；
   声明里有本地不存在的文件时不再整批 404，而是照常解析可得的文件并回报未命中清单，
   保证接入位不会因为一个文件名对不上就变成死界面。 */
const samplesDir = path.resolve(__dirname, '..', 'samples');
const SAMPLE_EXTS = [...TEXT_LIKE_EXTS, '.xlsx', '.docx', '.pdf'];
/* 接入位完全没声明文件时的默认批量：平台当前项目（PRJ-0917-001）的原始资料与阶段产物 */
const DEFAULT_SAMPLE_FILES = [
  'inspection-sample-last-4-weeks.xlsx',
  'equipment-inspection-requirements.docx',
  'equipment-register-guide.docx',
  'equipment-inspection-work-instructions.pdf',
  'exception_list.xlsx',
  'pending-review-unit-mismatch.md'
];

function listSampleFiles() {
  if (!fs.existsSync(samplesDir)) return [];
  return fs.readdirSync(samplesDir).filter(name => SAMPLE_EXTS.includes(path.extname(name).toLowerCase()));
}

function sampleFileEntry(name) {
  const filePath = path.join(samplesDir, name);
  return {
    id: uuid(), original_name: name, storage_path: filePath, mime_type: 'application/octet-stream',
    size_bytes: fs.statSync(filePath).size, sha256: crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex')
  };
}

app.get('/api/skills/parse-batch/samples', (_req, res) => {
  const files = listSampleFiles();
  sendOk(res, {
    directory: samplesDir,
    default_files: DEFAULT_SAMPLE_FILES.filter(name => files.includes(name)),
    files: files.map(name => ({ name, size_bytes: fs.statSync(path.join(samplesDir, name)).size }))
  });
});
app.post('/api/skills/parse-batch/samples', asyncRoute(async (req, res) => {
  const available = listSampleFiles();
  if (!available.length) return sendError(res, 404, 'SAMPLES_NOT_FOUND', '内置样例目录不存在或为空');
  const requested = (Array.isArray(req.body.files) ? req.body.files : []).map(name => String(name).trim()).filter(Boolean);
  const wanted = requested.length ? requested : DEFAULT_SAMPLE_FILES.filter(name => available.includes(name));
  const unavailable = requested.filter(name => !available.includes(name));
  const picked = available.filter(name => wanted.includes(name));
  /* 声明的文件一个都不存在时回退到默认批量，并如实回报未命中清单 */
  const chosen = picked.length ? picked : available.filter(name => DEFAULT_SAMPLE_FILES.includes(name));
  const files = chosen.map(sampleFileEntry);
  const input = {
    purpose: req.body.purpose || '内置样例批量解析',
    source: 'built-in-samples',
    requested: wanted,
    unavailable,
    files: files.map(file => ({ name: file.original_name, size: file.size_bytes, sha256: file.sha256 }))
  };
  const runId = startRun('parse-batch', input);
  try {
    const parsed = await parseBatch(files);
    const enriched = await attachModelInsights(runId, () => enrichBatch(parsed, { purpose: input.purpose }));
    const output = enriched.model_error ? { ...parsed, model_error: enriched.model_error } : enriched;
    output.requested = wanted;
    output.unavailable = unavailable;
    const result = envelope('parse-batch', runId, input, output, [...(output.evidence || []), output.model_evidence].filter(Boolean));
    finishRun(runId, result, null);
    sendOk(res, result);
  } catch (error) {
    finishRun(runId, null, error.message);
    throw error;
  }
}));

/* 内置样例媒体：四端多模态接入位没有用户上传文件时，用内置图片/音频把识别链路真实跑通 */
const mediaDir = path.join(samplesDir, 'media');
const MEDIA_MIME = { '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.wav': 'audio/wav', '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.ogg': 'audio/ogg' };
function listMediaSamples() {
  if (!fs.existsSync(mediaDir)) return [];
  return fs.readdirSync(mediaDir)
    .filter(name => MEDIA_MIME[path.extname(name).toLowerCase()])
    .map(name => ({
      name,
      kind: MEDIA_MIME[path.extname(name).toLowerCase()].startsWith('image/') ? 'image' : 'audio',
      mime_type: MEDIA_MIME[path.extname(name).toLowerCase()],
      size_bytes: fs.statSync(path.join(mediaDir, name)).size
    }));
}
app.get('/api/skills/multimodal/samples', (_req, res) => sendOk(res, { directory: mediaDir, files: listMediaSamples() }));
app.post('/api/skills/multimodal/samples', asyncRoute(async (req, res) => {
  const samples = listMediaSamples();
  if (!samples.length) return sendError(res, 404, 'SAMPLES_NOT_FOUND', '内置样例媒体目录为空');
  const wanted = String(req.body.source || req.body.file || '').trim();
  const preferredKind = String(req.body.kind || '');
  let picked = samples.find(item => item.name === wanted);
  if (!picked) picked = samples.find(item => wanted && (item.name.includes(wanted) || wanted.includes(item.name.replace(/\.[^.]+$/, ''))));
  if (!picked && preferredKind) picked = samples.find(item => item.kind === preferredKind);
  if (!picked) picked = samples[0];
  const filePath = path.join(mediaDir, picked.name);
  const pseudoFile = { originalname: picked.name, mimetype: picked.mime_type, size: picked.size_bytes, path: filePath };
  const input = { kind: preferredKind || picked.kind, purpose: String(req.body.purpose || ''), language: String(req.body.language || 'zh-CN'), source: picked.name, sample: true };
  const runId = startRun('multimodal', input);
  try {
    const media = inspectMedia(pseudoFile, input.kind);
    input.kind = media.kind;
    const recognized = await recognizeMedia(media, pseudoFile, input);
    const evidence = [{ file: media.name, sha256: media.sha256, mime_type: media.mime_type, size_bytes: media.size_bytes, width: media.width, height: media.height, duration_seconds: media.duration_seconds, source: '内置样例素材' }, recognized.provider_evidence];
    const output = { ...recognized.output, media };
    const result = envelope('multimodal', runId, input, output, evidence, 'live');
    finishRun(runId, result, null);
    sendOk(res, result);
  } catch (error) {
    finishRun(runId, null, error.message);
    throw error;
  }
}));

app.post('/api/skills/rag/index', upload.array('files', 20), asyncRoute(async (req, res) => {
  const files = uploadedFiles(req);
  if (!files.length) return sendError(res, 400, 'FILES_REQUIRED', '请上传需要建立索引的文档');
  const input = { scope: req.body.scope || 'project', project_id: req.body.project_id || '', version: req.body.version || 'v1.0' };
  const runId = startRun('rag-index', input);
  try {
    const parsed = await parseBatch(files);
    const indexed = [];
    for (const item of parsed.files) {
      const sources = Array.isArray(item.sheets) && item.sheets.length
        ? item.sheets.map(sheet => ({ title: `${item.name} / ${sheet.name}`, text: sheet.text, sheet: sheet.name, range: sheet.range }))
        : [{ title: item.name, text: item.text, sheet: '', range: '' }];
      const staleIds = new Set(state.documents.filter(existing => existing.sha256 === item.sha256 && existing.scope === input.scope && existing.project_id === input.project_id).map(existing => existing.id));
      state.documents = state.documents.filter(existing => !staleIds.has(existing.id));
      state.chunks = state.chunks.filter(chunk => !staleIds.has(chunk.document_id));
      for (const source of sources) {
        const documentId = uuid();
        const document = { id: documentId, title: source.title, scope: input.scope, project_id: input.project_id, version: input.version, sha256: item.sha256, indexed_at: new Date().toISOString(), sheet: source.sheet, range: source.range };
        const chunks = chunkText(source.text, 420).map((text, index) => ({ document_id: documentId, chunk_no: index + 1, text_content: text, title: source.title, scope: input.scope, project_id: input.project_id, version: input.version, sheet: source.sheet, range: source.range }));
        state.documents.push(document);
        state.chunks.push(...chunks);
        indexed.push({ document_id: documentId, title: source.title, chunks: chunks.length, scope: input.scope, project_id: input.project_id, sheet: source.sheet, range: source.range });
      }
    }
    saveState();
    const output = { indexed, failed: parsed.errors };
    const result = envelope('rag', runId, input, output, indexed);
    finishRun(runId, result, null);
    sendOk(res, result, 201);
  } catch (error) {
    finishRun(runId, null, error.message);
    throw error;
  }
}));

app.post('/api/skills/rag/query', asyncRoute(async (req, res) => {
  const query = String(req.body.query || '').trim();
  if (!query) return sendError(res, 400, 'QUERY_REQUIRED', '请输入检索问题');
  const input = { query, scopes: Array.isArray(req.body.scopes) ? req.body.scopes : [], project_id: req.body.project_id || '', top_k: Number(req.body.top_k) || 5 };
  const runId = startRun('rag', input);
  try {
    const selected = selectCandidates(state.chunks, input.scopes, input.project_id);
    /* 召回：词面打分，可复现、可解释（不交给模型） */
    const hits = retrieve(query, selected.chunks, input.top_k);
    /* 作答：真实大模型依据命中片段组织，逐条带 [序号] 引用 */
    const synthesized = await attachModelInsights(runId, () => synthesizeAnswer(query, hits));
    const output = synthesized.model_error
      ? { ...answerFromHits(query, hits), model_error: synthesized.model_error }
      : synthesized;
    if (selected.scope_fallback && hits.length) {
      output.scope_fallback = true;
      output.scope_note = `请求的知识范围「${input.scopes.join('、')}」在本库暂无独立语料，已回退到全库检索，命中结果来自 ${[...new Set(hits.map(hit => hit.scope))].join('、')}。`;
    }
    const citations = output.citations || [];
    output.hits = citations.map(citation => ({ doc: citation.title, page: citation.chunk_no, snippet: citation.snippet, score: citation.score, scope: citation.scope }));
    const result = envelope('rag', runId, input, output, [...citations, output.model_evidence].filter(Boolean));
    finishRun(runId, result, null);
    sendOk(res, result);
  } catch (error) {
    finishRun(runId, null, error.message);
    throw error;
  }
}));

app.post('/api/skills/report', asyncRoute(async (req, res) => {
  const data = req.body.data || {};
  const kind = String(req.body.kind || '项目执行报告');
  const title = String(req.body.title || kind);
  const prepared = prepareReportData({ title, kind, data });
  const { metrics, sections, charts, evidence } = prepared;
  if (!metrics.length && !sections.length && !charts.length) return sendError(res, 400, 'REPORT_DATA_REQUIRED', '请传入真实 metrics、sections、charts 或有效 report_period');
  const input = { kind, title, data };
  const runId = startRun('report', input);
  try {
    const reportId = uuid();
    /* 数字由 prepareReportData 算好，模型只写结论/发现/建议三段叙述 */
    const narrative = await attachModelInsights(runId, () => synthesizeNarrative(prepared));
    const modelSections = narrative.model_error ? [] : (narrative.sections || []);
    const mergedSections = [
      ...sections.map(item => ({ ...item, h: item.h || item.heading, p: item.p || item.text })),
      ...modelSections.map(item => ({ h: item.heading, p: item.text, source: 'model' }))
    ];
    const html = buildReport({ ...prepared, sections: mergedSections.map(item => ({ heading: item.h, text: item.p })) });
    const saved = saveReport(reportDir, reportId, html);
    const output = {
      report_id: reportId, title, kind, format: 'html', download_url: `/api/skills/reports/${reportId}/download`, file: saved.fileName,
      metrics: metrics.map(item => ({ ...item, k: item.k || item.label, v: item.v ?? item.value, d: item.d || item.note || '' })),
      sections: mergedSections, charts,
      training_profile: prepared.training_profile, validation: prepared.validation
    };
    if (narrative.model_error) output.model_error = narrative.model_error;
    state.reports[reportId] = { id: reportId, title, file_path: saved.filePath, created_at: new Date().toISOString() };
    const result = envelope('report', runId, input, output, [...(evidence || []), narrative.model_evidence].filter(Boolean));
    finishRun(runId, result, null);
    sendOk(res, result, 201);
  } catch (error) {
    finishRun(runId, null, error.message);
    throw error;
  }
}));

app.get('/api/skills/runs/:id', (req, res) => {
  const run = state.runs[req.params.id];
  if (!run) return sendError(res, 404, 'RUN_NOT_FOUND', 'Skill 运行记录不存在');
  sendOk(res, run);
});

app.get('/api/skills/reports/:id/download', (req, res) => {
  const report = state.reports[req.params.id];
  if (!report || !fs.existsSync(report.file_path)) return sendError(res, 404, 'REPORT_NOT_FOUND', '报告不存在');
  const resolved = path.resolve(report.file_path);
  if (!resolved.startsWith(path.resolve(reportDir) + path.sep)) return sendError(res, 403, 'INVALID_REPORT_PATH', '报告路径不合法');
  res.download(resolved, `${report.title}.html`);
});

app.use((error, _req, res, _next) => {
  console.error(error);
  if (error.code === 'LIMIT_FILE_SIZE') return sendError(res, 413, 'FILE_TOO_LARGE', '单个文件不能超过20MB');
  sendError(res, error.status || 500, error.code || 'SKILL_ERROR', error.message || 'Skill 执行失败');
});

app.listen(port, '127.0.0.1', () => {
  console.log(`SmartBridge Skills 已启动：http://127.0.0.1:${port}`);
  console.log('能力：parse-batch / rag / report / training / multimodal');
  if (!apiKey) console.warn('当前未设置 SKILL_API_KEY，仅适合本机联调。');
});
