const fs = require('fs');
const path = require('path');
const ExcelJS = require('exceljs');
const mammoth = require('mammoth');
const pdfParse = require('pdf-parse');

const TEXT_LIMIT = 30000;
const DEFAULT_RULES = {
  field_aliases: {
    '温度': '运行温度(℃)',
    '运行温度': '运行温度(℃)',
    '振动值': '振动值(mm/s)'
  }
};

function loadParseProfile() {
  const profilePath = process.env.PARSE_PROFILE_CONFIG || path.join(__dirname, '..', '..', 'runtime', 'parse-profile.json');
  try { return JSON.parse(fs.readFileSync(profilePath, 'utf8')); }
  catch (_) { return null; }
}

function cleanText(value) {
  return String(value == null ? '' : value).replace(/\u0000/g, '').replace(/\r\n/g, '\n').trim();
}

function parseDelimited(text, delimiter) {
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (ch === '"') {
      if (quoted && text[i + 1] === '"') { cell += '"'; i += 1; }
      else quoted = !quoted;
    } else if (ch === delimiter && !quoted) {
      row.push(cell.trim()); cell = '';
    } else if ((ch === '\n' || ch === '\r') && !quoted) {
      if (ch === '\r' && text[i + 1] === '\n') i += 1;
      row.push(cell.trim()); cell = '';
      if (row.some(value => value !== '')) rows.push(row);
      row = [];
    } else cell += ch;
  }
  row.push(cell.trim());
  if (row.some(value => value !== '')) rows.push(row);
  return rows;
}

function normalizeDate(value) {
  const text = cleanText(value);
  let match = text.match(/^(\d{4})[.\/-](\d{1,2})[.\/-](\d{1,2})$/);
  if (match) return `${match[1]}-${match[2].padStart(2, '0')}-${match[3].padStart(2, '0')}`;
  match = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (match) return `${match[3]}-${match[1].padStart(2, '0')}-${match[2].padStart(2, '0')}`;
  return text;
}

function analyzeRows(matrix, profile = null) {
  if (!matrix.length) return { fields: [], rows: 0, sample: [], anomalies: [] };
  const rules = profile?.rules || DEFAULT_RULES;
  const width = Math.max(...matrix.map(row => row.length));
  const rawFields = Array.from({ length: width }, (_, index) => cleanText(matrix[0][index]) || `字段${index + 1}`);
  const fields = rawFields.map(field => rules.field_aliases?.[field] || field);
  const body = matrix.slice(1).filter(row => row.some(value => cleanText(value) !== ''));
  const missingByField = fields.map(() => 0);
  const seen = new Set();
  let duplicates = 0;
  const anomalies = [];
  const normalizedRows = [];
  const add = (type, field, row, original, normalized, note) => anomalies.push({ type, field, row, count: 1, original, normalized, note });
  for (let rowIndex = 0; rowIndex < body.length; rowIndex += 1) {
    const row = body[rowIndex];
    const normalized = [];
    fields.forEach((field, index) => {
      const original = cleanText(row[index]);
      if (original === '') missingByField[index] += 1;
      let value = original;
      if ((rules.date_fields || []).includes(field)) {
        value = normalizeDate(value);
        if (value && value !== original) add('日期格式标准化', field, rowIndex + 2, original, value, '已统一为 YYYY-MM-DD');
      }
      const numeric = rules.numeric_fields?.[field];
      if (numeric && value) {
        const ocrFixed = value.replace(/(?<=\d)O|O(?=\d)/gi, '0');
        const match = ocrFixed.match(/-?\d+(?:\.\d+)?/);
        if (match) {
          const number = Number(match[0]);
          if (ocrFixed !== value) add('OCR疑似错误', field, rowIndex + 2, original, String(number), '已将数字上下文中的字母 O 修正为 0');
          if (/[a-zA-Z℃°/%]/.test(value.replace(match[0], ''))) add('数值与单位混用', field, rowIndex + 2, original, String(number), `已分离单位 ${numeric.unit || ''}`.trim());
          value = String(number);
          if (numeric.max != null && number > numeric.max) add('数值超阈值', field, rowIndex + 2, original, value, `最大允许值 ${numeric.max}${numeric.unit || ''}`);
          if (numeric.min != null && number < numeric.min) add('数值低于阈值', field, rowIndex + 2, original, value, `最小允许值 ${numeric.min}${numeric.unit || ''}`);
        } else add('数值格式错误', field, rowIndex + 2, original, original, '未识别到有效数值');
      }
      const allowed = rules.enums?.[field];
      if (value && Array.isArray(allowed) && !allowed.includes(value)) add('枚举值异常', field, rowIndex + 2, original, value, `允许值：${allowed.join('、')}`);
      const pattern = rules.patterns?.[field];
      if (value && pattern && !(new RegExp(pattern.regex).test(value))) add('编码格式错误', field, rowIndex + 2, original, value, pattern.message || '不符合编码规则');
      const maxLength = rules.max_lengths?.[field];
      if (maxLength && value.length > maxLength) add('文本长度超限', field, rowIndex + 2, original, value.slice(0, maxLength), `最大长度 ${maxLength}`);
      normalized.push(value);
    });
    normalizedRows.push(normalized);
    const configuredKeys = (rules.duplicate_key_fields || []).map(field => fields.indexOf(field)).filter(index => index >= 0);
    const signatureIndexes = configuredKeys.length ? configuredKeys : fields.map((_field, index) => index);
    const signature = signatureIndexes.map(index => normalized[index]).join('\u241f');
    if (seen.has(signature)) duplicates += 1;
    else seen.add(signature);
  }
  missingByField.forEach((count, index) => {
    if (count) anomalies.push({ type: '缺失值', field: fields[index], count });
  });
  if (duplicates) anomalies.push({ type: '重复记录', count: duplicates });
  rawFields.forEach((field, index) => {
    if (field !== fields[index]) anomalies.push({ type: '字段名称标准化', field, normalized: fields[index], count: 1 });
  });
  return {
    fields,
    rows: body.length,
    sample: normalizedRows.slice(0, 5).map(row => Object.fromEntries(fields.map((field, index) => [field, row[index]]))),
    normalized_rows: normalizedRows.map(row => Object.fromEntries(fields.map((field, index) => [field, row[index]]))),
    anomalies
  };
}

function workbookText(sheetName, matrix) {
  const lines = matrix.slice(0, 200).map(row => {
    const cells = row.map(value => cleanText(value).replace(/\n+/g, '；')).filter(Boolean);
    return cells.filter((value, index) => index === 0 || value !== cells[index - 1]).join(' | ');
  }).filter(Boolean);
  return `Sheet: ${sheetName}\n${lines.join('\n')}`;
}

function excelCellText(value) {
  if (value == null) return '';
  if (value instanceof Date) return value.toISOString();
  if (typeof value === 'object') {
    if (value.result != null) return cleanText(value.result);
    if (Array.isArray(value.richText)) return value.richText.map(item => item.text || '').join('');
    if (value.text != null) return cleanText(value.text);
    if (value.error != null) return cleanText(value.error);
  }
  return cleanText(value);
}

function excelColumnName(index) {
  let result = '';
  for (let value = index; value > 0; value = Math.floor((value - 1) / 26)) result = String.fromCharCode(65 + ((value - 1) % 26)) + result;
  return result || 'A';
}

async function parseSpreadsheet(filePath, name) {
  const profile = loadParseProfile();
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(filePath);
  const sheets = workbook.worksheets.map(sheet => {
    const matrix = [];
    sheet.eachRow({ includeEmpty: true }, row => {
      const values = [];
      for (let index = 1; index <= Math.max(1, sheet.columnCount); index += 1) values.push(excelCellText(row.getCell(index).value));
      matrix.push(values);
    });
    const analysis = analyzeRows(matrix, profile);
    return {
      name: sheet.name,
      range: `A1:${excelColumnName(Math.max(1, sheet.columnCount))}${Math.max(1, sheet.rowCount)}`,
      ...analysis,
      text: workbookText(sheet.name, matrix).slice(0, TEXT_LIMIT)
    };
  });
  return {
    name,
    type: '表格',
    rows: sheets.reduce((sum, sheet) => sum + sheet.rows, 0),
    fields: [...new Set(sheets.flatMap(sheet => sheet.fields))],
    sheets,
    text: sheets.map(sheet => sheet.text).join('\n\n').slice(0, TEXT_LIMIT),
    anomalies: sheets.flatMap(sheet => sheet.anomalies.map(item => ({ ...item, sheet: sheet.name }))),
    evidence: sheets.map(sheet => ({ file: name, sheet: sheet.name, range: sheet.range }))
  };
}

async function parseTextLike(filePath, name, ext) {
  const profile = loadParseProfile();
  let text = cleanText(fs.readFileSync(filePath, 'utf8'));
  if (ext === '.json') {
    const parsed = JSON.parse(text);
    const list = Array.isArray(parsed) ? parsed : [parsed];
    const fields = [...new Set(list.flatMap(item => item && typeof item === 'object' ? Object.keys(item) : []))];
    const matrix = [fields, ...list.map(item => fields.map(field => item?.[field] ?? ''))];
    const analysis = analyzeRows(matrix, profile);
    return { name, type: 'JSON', ...analysis, text: text.slice(0, TEXT_LIMIT), evidence: [{ file: name, range: `items:0-${Math.max(0, list.length - 1)}` }] };
  }
  if (ext === '.csv' || ext === '.tsv') {
    const matrix = parseDelimited(text, ext === '.tsv' ? '\t' : ',');
    const analysis = analyzeRows(matrix, profile);
    return { name, type: '表格', ...analysis, text: text.slice(0, TEXT_LIMIT), evidence: [{ file: name, range: `A1:${analysis.fields.length || 1}x${analysis.rows + 1}` }] };
  }
  return { name, type: '文本', rows: 0, fields: [], text: text.slice(0, TEXT_LIMIT), anomalies: [], evidence: [{ file: name, line: 1 }] };
}

async function parseDocument(filePath, name, ext) {
  if (ext === '.docx') {
    const result = await mammoth.extractRawText({ path: filePath });
    return { name, type: 'Word', rows: 0, fields: [], text: cleanText(result.value).slice(0, TEXT_LIMIT), anomalies: [], warnings: result.messages, evidence: [{ file: name, section: '正文' }] };
  }
  const result = await pdfParse(fs.readFileSync(filePath));
  return { name, type: 'PDF', pages: result.numpages, rows: 0, fields: [], text: cleanText(result.text).slice(0, TEXT_LIMIT), anomalies: [], evidence: [{ file: name, pages: `1-${result.numpages}` }] };
}

/* 纯文本类产物：除文档格式外，学生交付的脚本与日志同样按文本纳入批量解析，
   例如 rule_check.py、run.log、clean.sql，避免「本阶段产物完整性检查」漏项。 */
const TEXT_LIKE_EXTS = ['.csv', '.tsv', '.txt', '.md', '.json', '.py', '.sql', '.log', '.yaml', '.yml'];

async function parseFile(file) {
  const filePath = file.storage_path || file.path;
  const name = file.original_name || file.name || path.basename(filePath);
  const ext = path.extname(name).toLowerCase();
  if (!fs.existsSync(filePath)) throw new Error(`文件不存在：${name}`);
  if (ext === '.xlsx') return parseSpreadsheet(filePath, name);
  if (TEXT_LIKE_EXTS.includes(ext)) return parseTextLike(filePath, name, ext);
  if (['.docx', '.pdf'].includes(ext)) return parseDocument(filePath, name, ext);
  throw Object.assign(new Error(`暂不支持 ${ext || '未知'} 文件`), { code: 'UNSUPPORTED_FILE_TYPE' });
}

async function parseBatch(files) {
  const results = [];
  const errors = [];
  for (const file of files) {
    try {
      const parsed = await parseFile(file);
      results.push({ id: file.id, sha256: file.sha256, ...parsed });
    } catch (error) {
      errors.push({ id: file.id, name: file.original_name || file.name, code: error.code || 'PARSE_FAILED', message: error.message });
    }
  }
  const fields = [...new Set(results.flatMap(item => item.fields || []))];
  return {
    total: files.length,
    count: results.length,
    succeeded: results.length,
    failed: errors.length,
    fields,
    rows: results.reduce((sum, item) => sum + (item.rows || 0), 0),
    files: results,
    anomalies: results.flatMap(item => (item.anomalies || []).map(anomaly => ({ file: item.name, ...anomaly }))),
    errors,
    evidence: results.flatMap(item => item.evidence || [])
  };
}

/* --------------------------------------------------------------------------
   真实模型增强：结构化摘要与异常解读
   --------------------------------------------------------------------------
   字段识别、缺失值/重复/阈值判定全部由上面的规则引擎完成——规则可审计、
   可复现，这是数据质量的底线。模型只做两件事：
     1. 用业务语言概括每份文件"是什么、用来干什么"；
     2. 解释规则引擎报出的异常"为什么是问题、该怎么处理"。
   模型不参与任何字段判定，因此它出错也不会污染结构化数据。
   -------------------------------------------------------------------------- */
async function enrichBatch(result, options = {}) {
  const llm = require('../llm/provider');
  const files = Array.isArray(result.files) ? result.files : [];
  if (!files.length) return { ...result, model_evidence: null };

  const digest = files.map((file, index) => {
    const anomalyTypes = [...new Set((file.anomalies || []).map(item => item.type))].slice(0, 8);
    return [
      `[${index}] 文件名：${file.name}`,
      `    类型：${file.type}　行数：${file.rows ?? 0}　字段：${(file.fields || []).slice(0, 20).join(' / ') || '无'}`,
      `    规则引擎报出的异常类型：${anomalyTypes.join('、') || '无'}`,
      `    正文片段：${String(file.text || '').slice(0, 400).replace(/\n+/g, ' ')}`
    ].join('\n');
  }).join('\n\n');

  const call = await llm.chatJson({
    system: '你是产教融合实训平台的数据治理助手。只依据给定的解析结果作答，不得编造文件里没有的内容。',
    prompt: `以下是批量文件解析的结果（字段与异常由规则引擎判定，已确认无误）：

${digest}

请输出 JSON：
{
  "files": [
    {"index": 0, "summary": "一句话说明这份文件是什么、用来干什么（不超过 60 字）",
     "insights": ["针对已报出的异常，给出一条具体处理建议（每条不超过 40 字）"]}
  ],
  "batch_summary": "一句话概括这批文件整体反映了什么业务场景（不超过 80 字）"
}
要求：覆盖每一个 index；不得新增规则引擎没报出的异常；不得编造具体数值。`,
    purpose: 'parse-enrich'
  });

  const summaries = new Map();
  for (const item of Array.isArray(call.json?.files) ? call.json.files : []) {
    summaries.set(Number(item.index), item);
  }
  const enrichedFiles = files.map((file, index) => {
    const item = summaries.get(index);
    if (!item) return file;
    return {
      ...file,
      summary: String(item.summary || '').trim(),
      insights: Array.isArray(item.insights) ? item.insights.map(text => String(text).trim()).filter(Boolean) : []
    };
  });

  return {
    ...result,
    files: enrichedFiles,
    batch_summary: String(call.json?.batch_summary || '').trim(),
    model_evidence: {
      model: call.model,
      request_id: call.request_id,
      usage: call.usage,
      latency_ms: call.latency_ms,
      key_masked: call.key_masked,
      response_hash: call.response_hash
    }
  };
}

module.exports = { parseBatch, parseFile, parseDelimited, analyzeRows, normalizeDate, loadParseProfile, enrichBatch, TEXT_LIKE_EXTS };
