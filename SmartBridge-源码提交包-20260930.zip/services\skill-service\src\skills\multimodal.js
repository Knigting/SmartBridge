const fs = require('fs');
const crypto = require('crypto');

const IMAGE_TYPES = new Set(['image/png', 'image/jpeg', 'image/webp']);
const AUDIO_TYPES = new Set(['audio/wav', 'audio/x-wav', 'audio/mpeg', 'audio/mp4', 'audio/webm', 'audio/ogg']);

function sha256(filePath) {
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function pngSize(buffer) {
  if (buffer.length >= 24 && buffer.subarray(1, 4).toString('ascii') === 'PNG') return { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) };
  return null;
}

function jpegSize(buffer) {
  if (buffer.length < 4 || buffer[0] !== 0xff || buffer[1] !== 0xd8) return null;
  let offset = 2;
  while (offset + 9 < buffer.length) {
    if (buffer[offset] !== 0xff) { offset += 1; continue; }
    const marker = buffer[offset + 1];
    const length = buffer.readUInt16BE(offset + 2);
    if ([0xc0, 0xc1, 0xc2, 0xc3, 0xc5, 0xc6, 0xc7, 0xc9, 0xca, 0xcb, 0xcd, 0xce, 0xcf].includes(marker)) return { height: buffer.readUInt16BE(offset + 5), width: buffer.readUInt16BE(offset + 7) };
    if (!length || length < 2) break;
    offset += 2 + length;
  }
  return null;
}

function wavInfo(buffer) {
  if (buffer.length < 44 || buffer.subarray(0, 4).toString('ascii') !== 'RIFF' || buffer.subarray(8, 12).toString('ascii') !== 'WAVE') return null;
  let offset = 12;
  let byteRate = 0;
  let dataSize = 0;
  let sampleRate = 0;
  let channels = 0;
  while (offset + 8 <= buffer.length) {
    const id = buffer.subarray(offset, offset + 4).toString('ascii');
    const size = buffer.readUInt32LE(offset + 4);
    if (id === 'fmt ' && offset + 16 <= buffer.length) {
      channels = buffer.readUInt16LE(offset + 10);
      sampleRate = buffer.readUInt32LE(offset + 12);
      byteRate = buffer.readUInt32LE(offset + 16);
    }
    if (id === 'data') { dataSize = size; break; }
    offset += 8 + size + (size % 2);
  }
  return { channels, sample_rate: sampleRate, duration_seconds: byteRate ? Number((dataSize / byteRate).toFixed(3)) : null };
}

function inspectMedia(file, requestedKind) {
  const mime = String(file.mimetype || '').toLowerCase();
  const kind = requestedKind || (mime.startsWith('image/') ? 'image' : mime.startsWith('audio/') ? 'audio' : '');
  if (!['image', 'audio'].includes(kind)) throw Object.assign(new Error('只支持 image 或 audio'), { code: 'INVALID_MEDIA_KIND', status: 400 });
  if (kind === 'image' && !IMAGE_TYPES.has(mime)) throw Object.assign(new Error(`不支持的图片类型：${mime || '未知'}`), { code: 'UNSUPPORTED_MEDIA_TYPE', status: 415 });
  if (kind === 'audio' && !AUDIO_TYPES.has(mime)) throw Object.assign(new Error(`不支持的音频类型：${mime || '未知'}`), { code: 'UNSUPPORTED_MEDIA_TYPE', status: 415 });
  const buffer = fs.readFileSync(file.path);
  const metadata = kind === 'image' ? (pngSize(buffer) || jpegSize(buffer) || {}) : (wavInfo(buffer) || {});
  return { kind, name: file.originalname, mime_type: mime, size_bytes: file.size, sha256: sha256(file.path), ...metadata };
}

/* 保留：外部供应商若返回自定义协议结构，仍可用它归一化 */
function normalizeProviderResponse(raw, kind) {
  const root = raw && raw.data ? raw.data : (raw || {});
  const text = root.text || root.transcript || root.ocr_text || root.result_content || root.output || '';
  const confidence = root.confidence == null ? null : Number(root.confidence);
  return {
    kind,
    text: typeof text === 'string' ? text : JSON.stringify(text),
    fields: root.fields && typeof root.fields === 'object' ? root.fields : {},
    confidence: Number.isFinite(confidence) ? confidence : null,
    language: root.language || '',
    provider_request_id: root.request_id || root.id || '',
    raw_summary: root.summary || ''
  };
}

/* --------------------------------------------------------------------------
   真实大模型识别
   --------------------------------------------------------------------------
   原先的实现里有一条"本地演示通道"：按素材文件名正则匹配，返回预先写好的业务结论。
   它保证界面永远有东西可显示，代价是**没有任何真实识别发生**——已被彻底删除。

   现在两条路径都必须真正调用模型：
     · 图片 → 视觉大模型（需 LLM_VISION_MODEL）
     · 音频 → 语音转写（Whisper 协议，需 LLM_ASR_MODEL 或本地 ASR）
   任一条不可用时返回明确错误与处理建议，绝不返回伪造内容。
   -------------------------------------------------------------------------- */
function evidenceOf(call) {
  return {
    provider: call.model || 'unknown',
    mode: 'live',
    model: call.model || '',
    request_id: call.request_id || '',
    latency_ms: call.latency_ms,
    usage: call.usage || null,
    key_masked: call.key_masked || '',
    response_hash: call.response_hash || ''
  };
}

async function recognizeImage(media, file, input) {
  const llm = require('../llm/provider');
  const buffer = fs.readFileSync(file.path);
  const call = await llm.visionJson({
    buffer,
    mime: media.mime_type,
    prompt: `这是一张产教融合实训现场的图片（${media.name}）。业务场景提示：${input.purpose || '未指定'}。

请输出 JSON：
{
  "text": "用一到三句话描述图片里实际能看到的内容",
  "fields": {"字段名": "识别到的值"},
  "confidence": 0 到 1 之间的数字，
  "summary": "一句话概括这份材料反映的业务情况"
}
要求：只描述图片中确实存在的内容；看不清或不确定的字段不要编，直接省略该字段；不要杜撰设备编号、数值或人名。`,
    purpose: 'multimodal-image'
  });

  const json = call.json || {};
  const fields = json.fields && typeof json.fields === 'object' ? json.fields : {};
  return {
    output: {
      kind: 'image',
      text: String(json.text || '').trim(),
      fields,
      confidence: Number.isFinite(Number(json.confidence)) ? Math.max(0, Math.min(1, Number(json.confidence))) : null,
      language: '',
      provider_request_id: call.request_id,
      raw_summary: String(json.summary || '').trim()
    },
    provider_evidence: evidenceOf(call)
  };
}

async function recognizeAudio(media, file, input) {
  const llm = require('../llm/provider');
  const buffer = fs.readFileSync(file.path);
  const asr = await llm.transcribe({
    buffer,
    filename: media.name,
    mime: media.mime_type,
    language: String(input.language || 'zh-CN').replace(/-.*$/, '') || 'zh',
    purpose: 'multimodal-audio'
  });

  /* 转写是真实音频产出；再用一次模型把转写稿结构化为业务字段（同样禁止编造） */
  const call = await llm.chatJson({
    system: '你是产教融合实训平台的语音内容结构化助手。只能依据给定的转写文本作答，不得添加转写里没有的信息。',
    prompt: `以下是真实语音转写文本（来自 ${media.name}）：

${asr.text}

请输出 JSON：
{
  "fields": {"字段名": "值"},
  "summary": "一句话概括这段语音说的核心诉求",
  "confidence": 0 到 1 之间的数字
}
要求：只使用转写文本中明确出现的信息；转写里没说的不要补。`,
    purpose: 'multimodal-audio-structure'
  });

  const json = call.json || {};
  const fields = json.fields && typeof json.fields === 'object' ? json.fields : {};
  return {
    output: {
      kind: 'audio',
      text: asr.text,
      fields,
      confidence: Number.isFinite(Number(json.confidence)) ? Math.max(0, Math.min(1, Number(json.confidence))) : null,
      language: input.language || 'zh-CN',
      provider_request_id: asr.request_id || call.request_id,
      raw_summary: String(json.summary || '').trim()
    },
    provider_evidence: {
      ...evidenceOf(call),
      transcript: {
        model: asr.model,
        request_id: asr.request_id,
        latency_ms: asr.latency_ms,
        response_hash: asr.response_hash
      }
    }
  };
}

async function recognizeMedia(media, file, input) {
  return media.kind === 'audio' ? recognizeAudio(media, file, input) : recognizeImage(media, file, input);
}

module.exports = { inspectMedia, normalizeProviderResponse, recognizeMedia, recognizeImage, recognizeAudio, pngSize, jpegSize, wavInfo, IMAGE_TYPES, AUDIO_TYPES };
