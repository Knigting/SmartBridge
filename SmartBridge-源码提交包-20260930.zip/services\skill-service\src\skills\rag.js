/* 知识范围别名 → 规范名。四端页面接入位里写的 scope 是业务中文名，
   这里统一收敛到索引时使用的规范 scope，避免同名不同写法导致检索无命中。 */
const SCOPE_ALIASES = {
  '企业工艺文档': '企业工艺文档库',
  '企业工艺文档库': '企业工艺文档库',
  '工艺规范': '企业工艺文档库',
  'sop': '企业工艺文档库',
  '企业验收规范': '企业验收规范',
  '验收规范': '验收规范',
  '验收标准': '验收规范',
  '岗位能力标准': '岗位能力标准',
  '岗位标准': '岗位能力标准',
  '学校课程标准': '学校课程标准',
  '课程标准': '学校课程标准',
  '历史任务库': '历史任务库',
  '微课知识库': '微课知识库',
  '微课': '微课知识库',
  '企业公开任务库': '企业公开任务库',
  '企业公开任务': '企业公开任务库'
};

function normalizeScope(scope) {
  return SCOPE_ALIASES[String(scope || '').trim()] || String(scope || '').trim();
}

/* 按 scope 过滤候选分块。若指定范围内确无语料，回退到全库并在结果中标注，
   避免接入位因为范围写法差异而显示「没有找到足够可靠的依据」。 */
function selectCandidates(chunks, scopes, projectId) {
  const wanted = (Array.isArray(scopes) ? scopes : []).map(normalizeScope).filter(Boolean);
  const byProject = projectId ? chunks.filter(chunk => !chunk.project_id || chunk.project_id === projectId) : chunks;
  if (!wanted.length) return { chunks: byProject, scope_fallback: false, matched: [] };
  const matched = byProject.filter(chunk => wanted.includes(normalizeScope(chunk.scope)));
  if (matched.length) return { chunks: matched, scope_fallback: false, matched: wanted };
  return { chunks: byProject, scope_fallback: true, matched: [] };
}

function normalize(text) {
  return String(text || '').toLowerCase().replace(/\s+/g, ' ').trim();
}

function tokenize(text) {
  const normalized = normalize(text);
  const tokens = new Set(normalized.match(/[a-z0-9_.%-]+/g) || []);
  const chinese = (normalized.match(/[\u3400-\u9fff]+/g) || []).join('');
  for (let i = 0; i < chinese.length; i += 1) tokens.add(chinese[i]);
  for (let i = 0; i < chinese.length - 1; i += 1) tokens.add(chinese.slice(i, i + 2));
  return [...tokens];
}

function chunkText(text, maxChars = 700) {
  const clean = String(text || '').replace(/\r\n/g, '\n').trim();
  if (!clean) return [];
  const paragraphs = clean.split(/\n+|(?<=[。！？；])\s*/).map(part => part.trim()).filter(Boolean);
  const chunks = [];
  let current = '';
  for (const paragraph of paragraphs) {
    if (paragraph.length > maxChars) {
      if (current) { chunks.push(current); current = ''; }
      for (let index = 0; index < paragraph.length; index += maxChars) chunks.push(paragraph.slice(index, index + maxChars));
    } else if (!current || current.length + paragraph.length + 1 <= maxChars) {
      current += (current ? '\n' : '') + paragraph;
    } else {
      chunks.push(current); current = paragraph;
    }
  }
  if (current) chunks.push(current);
  return chunks;
}

function scoreChunk(query, chunk) {
  const queryTokens = tokenize(query);
  if (!queryTokens.length) return 0;
  const chunkTokens = new Set(tokenize(chunk.text_content || chunk.text || ''));
  let hits = 0;
  for (const token of queryTokens) if (chunkTokens.has(token)) hits += token.length > 1 ? 2 : 0.35;
  const phraseBoost = normalize(chunk.text_content || chunk.text).includes(normalize(query)) ? 3 : 0;
  return Number(((hits + phraseBoost) / Math.max(1, queryTokens.length * 1.5)).toFixed(4));
}

function retrieve(query, chunks, topK = 5) {
  return chunks
    .map(chunk => ({ ...chunk, score: scoreChunk(query, chunk) }))
    .filter(hit => hit.score >= 0.08)
    .sort((a, b) => b.score - a.score)
    .slice(0, Math.max(1, Math.min(Number(topK) || 5, 10)));
}

function answerFromHits(query, hits) {
  if (!hits.length) {
    return {
      answer: '当前知识库中没有找到足够可靠的依据，请提交教师或企业负责人确认。',
      requires_confirmation: true,
      citations: []
    };
  }
  const citations = hits.map((hit, index) => ({
    index: index + 1,
    document_id: hit.document_id,
    title: hit.title,
    version: hit.version,
    scope: hit.scope,
    chunk_no: hit.chunk_no,
    snippet: String(hit.text_content || hit.text).slice(0, 260),
    score: hit.score
  }));
  const answer = citations.slice(0, 3).map(citation => `${citation.snippet} [${citation.index}]`).join('\n');
  return { query, answer, requires_confirmation: false, citations, scope_fallback: false };
}

/* --------------------------------------------------------------------------
   真实模型作答
   --------------------------------------------------------------------------
   召回仍由上面的词面打分完成（可解释、可复现），大模型只负责把命中的原文
   组织成一段通顺的回答。三条硬约束：
     1. 只能使用下面传入的片段，不得凭自身知识补充事实；
     2. 每个结论后面必须带 [序号] 引用，引用号对应传入片段的编号；
     3. 片段不足以支撑时，必须明说"依据不足"，不许编。
   这样模型输出与引用证据一一对应，教师可逐条核对。
   -------------------------------------------------------------------------- */
async function synthesizeAnswer(query, hits, options = {}) {
  const llm = require('../llm/provider');
  if (!hits.length) {
    return {
      answer: '当前知识库中没有找到足够可靠的依据，请提交教师或企业负责人确认。',
      requires_confirmation: true,
      citations: [],
      model_evidence: null
    };
  }
  const citations = hits.map((hit, index) => ({
    index: index + 1,
    document_id: hit.document_id,
    title: hit.title,
    version: hit.version,
    scope: hit.scope,
    chunk_no: hit.chunk_no,
    snippet: String(hit.text_content || hit.text).slice(0, 260),
    score: hit.score
  }));

  const context = citations
    .map(item => `[${item.index}] 来源：${item.title || '未命名文档'}（${item.scope || '未分类'}）\n${item.snippet}`)
    .join('\n\n');

  const call = await llm.chatJson({
    system: '你是产教融合实训平台的知识助手。只能依据用户提供的片段作答，不得使用片段之外的知识，不得编造。',
    prompt: `问题：${query}

可用片段（这是你唯一可用的依据）：
${context}

请输出 JSON：{"answer": "用中文回答，每个结论后标注 [序号]", "sufficient": true 或 false}
若片段不足以回答问题，"answer" 写清依据不足并说明还缺什么，sufficient 填 false。`,
    purpose: 'rag-answer'
  });

  const json = call.json || {};
  const answer = String(json.answer || '').trim();
  if (!answer) {
    throw new llm.LLMError('LLM_EMPTY_CONTENT', '模型未返回有效回答', 502, '检查模型返回内容或调整提示词。', { raw: call.text });
  }
  return {
    query,
    answer,
    requires_confirmation: json.sufficient === false,
    citations,
    model_evidence: {
      model: call.model,
      request_id: call.request_id,
      usage: call.usage,
      latency_ms: call.latency_ms,
      key_masked: call.key_masked,
      response_hash: call.response_hash
    }
  };
}

module.exports = { tokenize, chunkText, scoreChunk, retrieve, answerFromHits, synthesizeAnswer, normalizeScope, selectCandidates, SCOPE_ALIASES };
