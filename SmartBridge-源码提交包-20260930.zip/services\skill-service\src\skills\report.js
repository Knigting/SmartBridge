const fs = require('fs');
const path = require('path');

const profilePath = path.resolve(__dirname, '..', '..', 'runtime', 'report-profile.json');
function escapeHtml(value) { return String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function getReportProfile() { try { return JSON.parse(fs.readFileSync(profilePath, 'utf8')); } catch (_) { return null; } }

function formatMetric(value, unit, rules = {}) {
  if (value == null || Number.isNaN(Number(value))) return rules.missing_value || 'N/A';
  const number = Number(value);
  if (unit === '%') return `${(number * 100).toFixed(rules.percent_decimals ?? 2)}%`;
  if (unit === '小时') return `${number.toFixed(rules.time_decimals ?? 1)} 小时`;
  if (unit === '元') return `${number.toFixed(rules.money_decimals ?? 3)} 元`;
  if (unit === '—') return String(number);
  return `${Number.isInteger(number) ? number : number.toFixed(2)}${unit ? ` ${unit}` : ''}`;
}

function lineChart(chart) {
  const series = (Array.isArray(chart.series) ? chart.series : []).filter(item => Number.isFinite(Number(item.value)));
  if (series.length < 3) return `<section class="chart"><h2>${escapeHtml(chart.title || '趋势')}</h2><p>有效数据不足 3 个报告期，不生成趋势线。</p></section>`;
  const values = series.map(item => Number(item.value)); const min = Math.min(...values); const max = Math.max(...values); const range = Math.max(max - min, 0.0001);
  const points = series.map((item, index) => `${70 + index * (470 / Math.max(1, series.length - 1))},${190 - ((Number(item.value) - min) / range) * 130}`).join(' ');
  const labels = series.map((item, index) => `<text x="${70 + index * (470 / Math.max(1, series.length - 1))}" y="220" text-anchor="middle" font-size="12">${escapeHtml(item.name)}</text>`).join('');
  return `<section class="chart"><h2>${escapeHtml(chart.title || '趋势')}</h2><svg viewBox="0 0 610 240" role="img"><line x1="60" y1="195" x2="560" y2="195" stroke="#d0d5dd"/><polyline points="${points}" fill="none" stroke="#6558d3" stroke-width="4"/>${labels}</svg></section>`;
}

function barChart(chart) {
  const series = Array.isArray(chart.series) ? chart.series : []; const max = Math.max(1, ...series.map(item => Number(item.value) || 0));
  const rows = series.map((item, index) => { const width = Math.round(((Number(item.value) || 0) / max) * 420); const y = 30 + index * 42; return `<text x="0" y="${y + 17}" font-size="13" fill="#344054">${escapeHtml(item.name)}</text><rect x="120" y="${y}" width="${width}" height="24" rx="5" fill="#6558d3"/><text x="${130 + width}" y="${y + 17}" font-size="13" fill="#344054">${escapeHtml(item.value)}</text>`; }).join('');
  return `<section class="chart"><h2>${escapeHtml(chart.title || '数据图表')}</h2><svg viewBox="0 0 620 ${Math.max(90, series.length * 42 + 45)}" role="img">${rows}</svg></section>`;
}

function prepareReportData({ title, kind, data = {} }, profile = getReportProfile()) {
  const supplied = { metrics: Array.isArray(data.metrics) ? data.metrics : [], sections: Array.isArray(data.sections) ? data.sections : [], charts: Array.isArray(data.charts) ? data.charts : [], evidence: Array.isArray(data.evidence) ? data.evidence : [] };
  const period = String(data.report_period || data.period || '').trim();
  if (!period || !profile) return { title, kind, ...supplied, training_profile: null, validation: { trained: false, valid_period: false } };
  if (!profile.periods.includes(period)) return {
    title, kind, metrics: profile.metrics.slice(0, 11).map(metric => ({ label: metric.name, value: profile.display_rules.missing_value, note: `${period} 暂无数据` })),
    sections: [{ heading: '数据完整性说明', text: `报告期 ${period} 不在已校验数据范围内，按边界规则输出 N/A，未生成趋势结论。` }], charts: [],
    evidence: profile.sources.map(source => ({ title: source.file, location: `SHA-256 ${source.sha256.slice(0, 12)}` })),
    training_profile: { version: profile.version, period }, validation: { trained: true, valid_period: false, warnings: ['报告期无数据', '已跳过趋势图'] }
  };
  const names = ['提交率', '通过率', '错误率', '异常率', '返修率', '验收通过率', '节省工时小时', '效率提升率', '成本节约率', '单份成本元', 'SLA达成率'];
  const metrics = profile.metrics.filter(metric => names.includes(metric.name)).map(metric => ({ label: metric.name, value: formatMetric(metric.values[period], metric.unit, profile.display_rules), note: metric.direction === '负指标' ? '数值下降表示改善' : (metric.direction === '正指标' ? '数值上升表示改善' : '') }));
  const monthlyPeriods = profile.periods.filter(item => /^\d{4}-\d{2}$/.test(item));
  const charts = ['提交率', '错误率', '验收通过率', '效率提升率', '单份成本元'].map(name => {
    const metric = profile.metrics.find(item => item.name === name);
    return metric ? { type: 'line', title: `${name}月度趋势`, series: monthlyPeriods.map(item => ({ name: item, value: metric.values[item] })) } : null;
  }).filter(Boolean);
  const evidence = profile.sources.map(source => ({ title: source.file, location: `版本校验 ${source.sha256.slice(0, 12)}` }));
  const sections = [
    { heading: '报告结论', text: `${period} 指标已按金标准口径计算。正向指标按上升判定改善，错误率、异常率、返修率等负向指标按下降判定改善。` },
    { heading: '计算与展示口径', text: '百分比保留两位小数，工时保留一位小数，金额保留三位小数；多期趋势仅在不少于三个有效数据点时展示。' }
  ];
  return { title, kind, metrics, sections, charts, evidence, training_profile: { version: profile.version, period, samples: profile.training_summary.samples, metrics: profile.training_summary.metrics }, validation: { trained: true, valid_period: true, warnings: [] } };
}

function buildReport({ title, kind, metrics = [], sections = [], charts = [], evidence = [], generatedAt = new Date().toISOString(), training_profile = null }) {
  const metricHtml = metrics.map(item => `<article class="metric"><span>${escapeHtml(item.label || item.k)}</span><strong>${escapeHtml(item.value ?? item.v)}</strong><small>${escapeHtml(item.note || item.d || '')}</small></article>`).join('');
  const sectionHtml = sections.map(item => `<section><h2>${escapeHtml(item.heading || item.h)}</h2><p>${escapeHtml(item.text || item.p)}</p></section>`).join('');
  const evidenceHtml = evidence.map((item, index) => `<li><b>[${index + 1}]</b> ${escapeHtml(item.title || item.file || item.source || '业务数据')} ${escapeHtml(item.location || item.range || item.page || '')}</li>`).join('');
  const chartsHtml = charts.map(chart => chart.type === 'line' ? lineChart(chart) : barChart(chart)).join('');
  const profileNote = training_profile ? ` · 口径版本：${escapeHtml(training_profile.version)} · 报告期：${escapeHtml(training_profile.period)}` : '';
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${escapeHtml(title)}</title><style>
body{margin:0;background:#f5f7fb;color:#182230;font:15px/1.7 "Microsoft YaHei",sans-serif}.page{max-width:980px;margin:32px auto;background:#fff;padding:44px;border-radius:18px;box-shadow:0 12px 40px #172b4d18}header{border-bottom:2px solid #6558d3;padding-bottom:18px}h1{margin:0 0 8px;font-size:30px}h2{font-size:18px;margin:28px 0 10px}.meta{color:#667085}.metrics{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:14px;margin:24px 0}.metric{border:1px solid #e4e7ec;border-radius:12px;padding:16px}.metric span,.metric small{display:block;color:#667085}.metric strong{display:block;font-size:24px;color:#513fc8;margin:4px 0}.chart{border:1px solid #e4e7ec;border-radius:14px;padding:10px 18px;margin:18px 0}.chart svg{width:100%;height:auto}footer{margin-top:34px;border-top:1px solid #e4e7ec;padding-top:16px;color:#667085}@media print{body{background:#fff}.page{box-shadow:none;margin:0;max-width:none}}
</style></head><body><main class="page"><header><h1>${escapeHtml(title)}</h1><div class="meta">报告类型：${escapeHtml(kind)} · 生成时间：${escapeHtml(generatedAt)}${profileNote}</div></header><div class="metrics">${metricHtml}</div>${sectionHtml}${chartsHtml}<section><h2>数据与证据来源</h2><ol>${evidenceHtml || '<li>本报告使用当前业务库实时统计数据。</li>'}</ol></section><footer>本报告由智训桥报告生成 Skill 自动生成，指标口径、数据版本和原始业务记录应一并审核。</footer></main></body></html>`;
}

function saveReport(directory, id, html) { fs.mkdirSync(directory, { recursive: true }); const fileName = `${id}.html`; const filePath = path.join(directory, fileName); fs.writeFileSync(filePath, html, 'utf8'); return { fileName, filePath }; }

/* --------------------------------------------------------------------------
   真实模型撰写报告叙述
   --------------------------------------------------------------------------
   数字一律来自 prepareReportData 用代码算好的指标，模型只负责"把它们说清楚"。
   这是刻意的：让模型自己编统计值，必然与后台真实数据对不上，一核对就穿帮。
   提示词里明确禁止出现片段之外的数字。
   -------------------------------------------------------------------------- */
async function synthesizeNarrative(prepared, options = {}) {
  const llm = require('../llm/provider');
  const metricLines = (prepared.metrics || [])
    .map(item => `- ${item.label}：${item.value}${item.note ? `（${item.note}）` : ''}`)
    .join('\n');
  if (!metricLines) {
    throw new llm.LLMError('REPORT_DATA_REQUIRED', '没有可撰写叙述的指标数据', 400, '请先传入有效 metrics 或 report_period。');
  }

  const call = await llm.chatJson({
    system: '你是产教融合实训平台的数据分析师。只依据给定的指标撰写结论，绝不编造任何数字。',
    prompt: `报告标题：${prepared.title}（类型：${prepared.kind}）
报告期：${prepared.training_profile?.period || '未指定'}

已计算指标（这是唯一可用的数字来源，禁止出现这些之外的任何数值）：
${metricLines}

请输出 JSON：
{
  "sections": [
    {"heading": "报告结论", "text": "不超过 200 字，说明整体情况"},
    {"heading": "关键发现", "text": "不超过 200 字，指出最值得关注的 2-3 点"},
    {"heading": "改进建议", "text": "不超过 150 字，给出可执行的下一步"}
  ]
}
要求：只使用上面给出的数字；不得杜撰趋势、原因或外部事实；语言务实，不空泛。`,
    purpose: 'report-narrative'
  });

  const sections = Array.isArray(call.json?.sections) ? call.json.sections : [];
  const cleaned = sections
    .filter(item => item && (item.heading || item.text))
    .map(item => ({ heading: String(item.heading || '').trim() || '分析说明', text: String(item.text || '').trim() }))
    .filter(item => item.heading && item.text);

  if (!cleaned.length) {
    throw new llm.LLMError('LLM_BAD_JSON', '模型未返回有效的报告段落', 502, '检查模型返回内容。', { raw: call.text });
  }
  return {
    sections: cleaned,
    model_evidence: {
      model: call.model,
      request_id: call.request_id,
      usage: call.usage,
      latency_ms: call.latency_ms,
      key_masked: call.key_masked,
      response_hash: call.response_hash
    }
  };
}

module.exports = { buildReport, saveReport, escapeHtml, prepareReportData, synthesizeNarrative, getReportProfile, formatMetric };
