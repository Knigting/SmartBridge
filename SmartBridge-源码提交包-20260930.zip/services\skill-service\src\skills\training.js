const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

/* 动作名 → 安全策略动作标识。
   前半段是四端页面接入位实际使用的业务动作名（与前端 data-args 对齐），
   后半段映射到 training-policy.json 的 allowed_actions。 */
const POLICY_ACTIONS = {
  'lms/create-task': 'lms.create_training_task',
  'lms/get-task': 'lms.query_task',
  'lms/list-submissions': 'lms.query_student_submissions',
  'lms/record-score': 'lms.write_back_scores_or_comments',
  'edge/read-device-status': 'gateway.query_device_status',
  'edge/read-operation-logs': 'gateway.query_operation_logs',
  'edge/apply-training-parameter': 'gateway.push_test_params',
  'lms/publish-task-stages': 'lms.create_training_task',
  'lms/read-class-progress': 'lms.query_student_submissions',
  'lms/levels': 'lms.query_task',
  'lms/submit': 'lms.write_back_scores_or_comments',
  'edge/read-fixed-sample-result': 'gateway.query_collected_data',
  'edge/device-log': 'gateway.query_operation_logs'
};

function getTrainingPolicy() {
  const policyPath = process.env.TRAINING_POLICY_CONFIG || path.join(__dirname, '..', '..', 'runtime', 'training-policy.json');
  try { return JSON.parse(fs.readFileSync(policyPath, 'utf8')); }
  catch (_) { return null; }
}

const SANDBOX_SYSTEMS = {
  lms: {
    label: '校内实训教学平台',
    actions: {
      'create-task': { op: 'write', risk: 'medium', required: ['title'] },
      'get-task': { op: 'read', risk: 'low', required: ['task_id'] },
      'list-submissions': { op: 'read', risk: 'low', required: ['task_id'] },
      'record-score': { op: 'write', risk: 'medium', required: ['task_id', 'student_id', 'score'] },
      /* 四端接入位使用的业务动作 */
      'publish-task-stages': { op: 'write', risk: 'medium', required: [] },
      'read-class-progress': { op: 'read', risk: 'low', required: [] },
      'levels': { op: 'read', risk: 'low', required: [] },
      'submit': { op: 'write', risk: 'medium', required: [] }
    }
  },
  edge: {
    label: '实训硬件数据网关',
    actions: {
      'read-device-status': { op: 'read', risk: 'low', required: ['device_id'] },
      'read-operation-logs': { op: 'read', risk: 'low', required: ['device_id'] },
      'apply-training-parameter': { op: 'write', risk: 'high', required: ['device_id', 'parameter', 'value'] },
      /* 四端接入位使用的业务动作 */
      'read-fixed-sample-result': { op: 'read', risk: 'low', required: [] },
      'device-log': { op: 'read', risk: 'low', required: [] }
    }
  }
};

function stableJson(value) {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(',')}]`;
  if (value && typeof value === 'object') return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableJson(value[key])}`).join(',')}}`;
  return JSON.stringify(value);
}

function hash(value) {
  return crypto.createHash('sha256').update(typeof value === 'string' ? value : stableJson(value)).digest('hex');
}

function validatePayload(payload, required) {
  const missing = required.filter(field => payload[field] === undefined || payload[field] === null || payload[field] === '');
  if (missing.length) throw Object.assign(new Error(`缺少必填字段：${missing.join(', ')}`), { code: 'INVALID_OPERATION_PAYLOAD', status: 400 });
}

function createPlan(input, externalSystems = {}) {
  const systemId = String(input.system || '');
  const action = String(input.action || '');
  const payload = input.payload && typeof input.payload === 'object' ? input.payload : {};
  const external = externalSystems[systemId];
  const system = external || SANDBOX_SYSTEMS[systemId];
  if (!system) throw Object.assign(new Error(`未配置目标系统：${systemId}`), { code: 'SYSTEM_NOT_CONFIGURED', status: 400 });
  const actionRule = system.actions && system.actions[action];
  if (!actionRule) throw Object.assign(new Error(`操作不在白名单中：${systemId}/${action}`), { code: 'ACTION_NOT_ALLOWED', status: 403 });
  const policy = getTrainingPolicy();
  const policyAction = POLICY_ACTIONS[`${systemId}/${action}`];
  if (policyAction && Array.isArray(policy?.forbidden_actions) && policy.forbidden_actions.includes(policyAction)) throw Object.assign(new Error(`安全策略禁止操作：${policyAction}`), { code: 'ACTION_FORBIDDEN_BY_POLICY', status: 403 });
  if (policyAction && Array.isArray(policy?.allowed_actions) && policy.allowed_actions.length && !policy.allowed_actions.includes(policyAction)) throw Object.assign(new Error(`操作不在训练策略白名单：${policyAction}`), { code: 'ACTION_NOT_ALLOWED_BY_POLICY', status: 403 });
  const op = actionRule.op || input.op || 'read';
  if (input.op && input.op !== op) throw Object.assign(new Error(`操作类型不匹配，${action} 必须使用 ${op}`), { code: 'OPERATION_MISMATCH', status: 400 });
  validatePayload(payload, actionRule.required || []);
  const normalized = { system: systemId, action, op, payload, connector: external ? 'http' : 'sandbox' };
  return {
    ...normalized,
    risk: actionRule.risk || (op === 'write' ? 'medium' : 'low'),
    approval_required: op === 'write',
    verify_required: op === 'write',
    plan_hash: hash(normalized),
    summary: `${op === 'write' ? '写入' : '读取'} ${system.label || systemId}：${action}`,
    policy: policy ? { source: policy.source_file, action: policyAction, test_only: true } : null
  };
}

/* --------------------------------------------------------------------------
   真实模型解析自然语言操作意图
   --------------------------------------------------------------------------
   只让模型做"理解人话 → 填结构化参数"这一步，解析结果必须再过 createPlan：
   系统是否存在、动作是否在白名单、op 是否匹配、必填字段是否齐全，全部由
   createPlan 用确定性规则判断。**模型输出永不被直接执行**——写操作还要过
   审批令牌与幂等键。这是安全底线，不是保守。
   -------------------------------------------------------------------------- */
async function interpretInstruction(instruction, externalSystems = {}) {
  const llm = require('../llm/provider');
  const catalog = [];
  for (const [systemId, system] of Object.entries(SANDBOX_SYSTEMS)) {
    for (const [action, rule] of Object.entries(system.actions || {})) {
      catalog.push(`- ${systemId}/${action}　op=${rule.op}　风险=${rule.risk}　必填=${(rule.required || []).join(',') || '无'}　说明：${system.label || systemId}`);
    }
  }
  for (const [systemId, system] of Object.entries(externalSystems || {})) {
    for (const [action, rule] of Object.entries((system && system.actions) || {})) {
      catalog.push(`- ${systemId}/${action}　op=${rule.op || 'read'}　风险=${rule.risk || 'medium'}　外部系统：${system.label || systemId}`);
    }
  }

  const call = await llm.chatJson({
    system: '你是实训系统操作意图解析器。只能从给定的动作清单中选择，不得发明新动作。',
    prompt: `可用动作清单：
${catalog.join('\n')}

用户指令：${String(instruction || '').trim()}

请输出 JSON：{"system": "", "action": "", "op": "read 或 write", "payload": {}, "reason": "一句话说明为什么这么选"}
要求：system/action 必须严格取自清单；无法确定时 system 与 action 填空字符串；payload 只填清单里声明的必填字段。`,
    purpose: 'training-interpret'
  });

  const json = call.json || {};
  return {
    parsed: {
      system: String(json.system || '').trim(),
      action: String(json.action || '').trim(),
      op: String(json.op || '').trim(),
      payload: json.payload && typeof json.payload === 'object' ? json.payload : {},
      reason: String(json.reason || '').trim()
    },
    model_evidence: {
      model: call.model,
      request_id: call.request_id,
      usage: call.usage,
      latency_ms: call.latency_ms,
      key_masked: call.key_masked,
      response_hash: call.response_hash
    }
  };
}

/* 沙箱预置数据：首次使用时写入，之后可读写，保证「拉得到真实结构的数据」。
   数据口径与业务库演示数据逐字段对齐（2026-09-23 生成）：
     班级 2024级数据科学班（DATA-2024-01，6 人 / 3 组，48 个任务分配、11 个已提交、均分 82）
     班级 2024级数控技术班（NC-2024-01，3 人 / 2 组，12 个任务分配、6 个已提交、均分 79）
     阶段为项目 PRJ-0917-001 设备点检台账整理与异常周报生成的四个真实阶段 */
function seedSandbox(sandbox) {
  if (sandbox.seeded) return sandbox;
  const at = new Date().toISOString();
  sandbox.project = { code: 'PRJ-0917-001', name: '设备点检台账整理与异常周报生成', company: '华明制造', school: '山东智能制造职业学院' };
  sandbox.classes = [
    { cls: '2024级数据科学班', code: 'DATA-2024-01', submitted: 11, total: 48, avg: 82, status: '进行中', groups: 3 },
    { cls: '2024级数控技术班', code: 'NC-2024-01', submitted: 6, total: 12, avg: 79, status: '进行中', groups: 2 }
  ];
  sandbox.stages = [
    { stage_no: 1, name: '数据整理：统一字段、唯一标识与去重', status: 'passed', score: 86, task_id: 'LMS-PRJ0917-S1', acceptance: '字段统一、重复记录去重、缺失项单独标记' },
    { stage_no: 2, name: '规则实现：输出异常及缺失值清单', status: 'running', score: null, task_id: 'LMS-PRJ0917-S2', acceptance: '>80℃异常；=80℃正常；缺失值待核查' },
    { stage_no: 3, name: '成果呈现：按周统计与可追溯明细', status: 'locked', score: null, task_id: 'LMS-PRJ0917-S3', acceptance: '统计可回溯到明细行' },
    { stage_no: 4, name: '交付复用：操作说明与复现检查', status: 'locked', score: null, task_id: 'LMS-PRJ0917-S4', acceptance: '他人可按说明复现' }
  ];
  sandbox.fixedSamples = [
    { case_id: 'FS-01', name: '温度 79.9℃ 正常记录', expected: '正常', actual: '正常', result: 'pass' },
    { case_id: 'FS-02', name: '温度 80.0℃ 边界值', expected: '边界正常', actual: '边界正常', result: 'pass' },
    { case_id: 'FS-03', name: '温度 80.1℃ 异常记录', expected: '异常', actual: '异常', result: 'pass' },
    { case_id: 'FS-04', name: '温度缺失 → 待核查', expected: '待核查', actual: '待核查', result: 'pass' },
    { case_id: 'FS-05', name: '设备+日期+班组重复去重', expected: '保留 1 条', actual: '保留 1 条', result: 'pass' }
  ];
  sandbox.devices = {
    'CNC-02': { id: 'CNC-02', name: '数控实训台（PRJ-0917-001）', status: 'online', parameters: { feed_rate: 120, spindle_speed: 1800, spindle_temp: 80.0 }, logs: [
      { at, device_id: 'CNC-02', event: '主轴启动', duration_seconds: 1420, operator: '第2组' },
      { at, device_id: 'CNC-02', event: '固定样例回放', result: 'pass', operator: '第2组' }
    ] },
    'RB-11': { id: 'RB-11', name: '机器人工作站', status: 'online', parameters: { teach_points: 38 }, logs: [
      { at, device_id: 'RB-11', event: '示教轨迹回放', points: 38, result: 'pass', operator: '第1组' }
    ] },
    'GW-07': { id: 'GW-07', name: '工业物联网网关（PRJ-0924-003）', status: 'online', parameters: { online_rate: 0.992, timezone: 'UTC+8' }, logs: [
      { at, device_id: 'GW-07', event: '采集点位巡检', online_points: 246, total_points: 248, operator: '系统' },
      { at, device_id: 'GW-07', event: '日志时间戳对齐', aligned: 1860, total: 1864, operator: '系统' }
    ] },
    'TM-05': { id: 'TM-05', name: '温度采集模块', status: 'online', parameters: { unit: '℃', threshold: 80 }, logs: [
      { at, device_id: 'TM-05', event: '固定样例回放', result: '5 / 5 pass', operator: '系统' },
      { at, device_id: 'TM-05', event: '阈值校验', threshold: 80, result: 'pass', operator: '系统' }
    ] },
    'TC-09': { id: 'TC-09', name: '数控刀具寿命监测单元（PRJ-0924-002）', status: 'online', parameters: { warn_ratio: 0.2, tool_no: 'T-2207' }, logs: [
      { at, device_id: 'TC-09', event: '刀具寿命采集', remaining_ratio: 0.18, result: 'warning', operator: '第1组' },
      { at, device_id: 'TC-09', event: '临界值校验', remaining_ratio: 0.2, result: 'boundary', operator: '第1组' }
    ] }
  };
  sandbox.tasks = sandbox.tasks || {};
  sandbox.submissions = sandbox.submissions || {};
  sandbox.seeded = true;
  return sandbox;
}

function ensureSandbox(sandbox) {
  sandbox.lms = sandbox.lms || { tasks: {}, submissions: {} };
  sandbox.edge = sandbox.edge || { devices: {} };
  return seedSandbox(sandbox);
}

function executeSandbox(plan, sandbox, uuid) {
  ensureSandbox(sandbox);
  const now = new Date().toISOString();
  if (plan.system === 'lms') {
    if (plan.action === 'levels') {
      const rows = sandbox.stages.map(stage => ({ stage_no: stage.stage_no, name: stage.name, status: stage.status, score: stage.score, task_id: stage.task_id }));
      return { before: null, after: null, output: { system: 'lms', action: plan.action, ref: 'LMS-PRJ-0917-001', rows }, verify: { ok: rows.length > 0, read_back: rows } };
    }
    if (plan.action === 'read-class-progress') {
      const rows = sandbox.classes.map(item => ({ ...item }));
      return { before: null, after: null, output: { system: 'lms', action: plan.action, ref: 'LMS-CLASS-2024-DS', rows }, verify: { ok: rows.length > 0, read_back: rows } };
    }
    if (plan.action === 'publish-task-stages') {
      const ref = plan.payload.task_id || `LMS-${uuid().slice(0, 8)}`;
      const record = { id: ref, project: plan.payload.project || 'PRJ-0917-001', cls: plan.payload.cls || '2024级数据科学班', stages: plan.payload.stages || sandbox.stages.length, status: 'published', updated_at: now };
      sandbox.tasks[ref] = record;
      const rows = sandbox.stages.map(stage => ({ stage_no: stage.stage_no, name: stage.name, task_id: stage.task_id, status: 'published' }));
      return { before: null, after: record, output: { system: 'lms', action: plan.action, ref, rows, receipt: `${record.stages} 个任务阶段已下发至 ${record.cls}` }, verify: { ok: sandbox.tasks[ref].status === 'published', read_back: record } };
    }
    if (plan.action === 'submit') {
      const stageNo = Number(plan.payload.stage_no || plan.payload.level || 1);
      const stage = sandbox.stages.find(item => item.stage_no === stageNo) || sandbox.stages[0];
      const record = { stage_no: stage.stage_no, task_id: stage.task_id, status: plan.payload.status || 'submitted', submitted_at: now };
      stage.status = 'submitted';
      const rows = sandbox.submissions[stage.task_id] || (sandbox.submissions[stage.task_id] = []);
      rows.push(record);
      return { before: null, after: record, output: { system: 'lms', action: plan.action, ref: `${stage.task_id}`, rows: [record], receipt: `阶段 ${stage.stage_no} 提交结果已回写教学平台` }, verify: { ok: rows.some(item => item.task_id === stage.task_id), read_back: record } };
    }
  }
  if (plan.system === 'edge') {
    if (plan.action === 'read-fixed-sample-result') {
      const rows = sandbox.fixedSamples.map(item => ({ ...item }));
      const passed = rows.filter(item => item.result === 'pass').length;
      return { before: null, after: null, output: { system: 'edge', action: plan.action, ref: 'EDGE-FIXED-SAMPLE-V1', rows }, verify: { ok: passed === rows.length, read_back: { passed, total: rows.length } } };
    }
    if (plan.action === 'device-log') {
      const rows = Object.values(sandbox.devices).flatMap(device => device.logs.map(log => ({ device: device.id, name: device.name, ...log })));
      return { before: null, after: null, output: { system: 'edge', action: plan.action, ref: 'EDGE-OP-LOG', rows }, verify: { ok: rows.length > 0, read_back: { count: rows.length } } };
    }
  }
  if (plan.system === 'lms') {
    if (plan.action === 'create-task') {
      const taskId = plan.payload.task_id || `LMS-${uuid().slice(0, 8)}`;
      const before = sandbox.lms.tasks[taskId] || null;
      sandbox.lms.tasks[taskId] = { id: taskId, title: plan.payload.title, class_id: plan.payload.class_id || '', due_at: plan.payload.due_at || null, status: 'published', updated_at: now };
      return { before, after: sandbox.lms.tasks[taskId], output: { system: 'lms', action: plan.action, ref: taskId, receipt: '任务已写入本地实训系统沙箱' }, verify: { ok: sandbox.lms.tasks[taskId].title === plan.payload.title, read_back: sandbox.lms.tasks[taskId] } };
    }
    if (plan.action === 'get-task') {
      const task = sandbox.lms.tasks[plan.payload.task_id] || null;
      return { before: null, after: null, output: { system: 'lms', action: plan.action, rows: task ? [task] : [] }, verify: { ok: true, read_back: task } };
    }
    if (plan.action === 'list-submissions') {
      const rows = sandbox.lms.submissions[plan.payload.task_id] || [];
      return { before: null, after: null, output: { system: 'lms', action: plan.action, rows }, verify: { ok: true, count: rows.length } };
    }
    if (plan.action === 'record-score') {
      const taskId = plan.payload.task_id;
      const rows = sandbox.lms.submissions[taskId] || (sandbox.lms.submissions[taskId] = []);
      const index = rows.findIndex(row => row.student_id === plan.payload.student_id);
      const before = index >= 0 ? { ...rows[index] } : null;
      const record = { student_id: plan.payload.student_id, score: Number(plan.payload.score), comment: plan.payload.comment || '', updated_at: now };
      if (index >= 0) rows[index] = record; else rows.push(record);
      return { before, after: record, output: { system: 'lms', action: plan.action, ref: `${taskId}/${record.student_id}`, receipt: '成绩已写入本地沙箱' }, verify: { ok: rows.some(row => row.student_id === record.student_id && row.score === record.score), read_back: record } };
    }
  }
  if (plan.system === 'edge') {
    const deviceId = plan.payload.device_id;
    const device = sandbox.edge.devices[deviceId] || (sandbox.edge.devices[deviceId] = { id: deviceId, status: 'online', parameters: {}, logs: [] });
    if (plan.action === 'read-device-status') return { before: null, after: null, output: { system: 'edge', action: plan.action, rows: [{ device_id: deviceId, status: device.status, parameters: device.parameters }] }, verify: { ok: true, read_back: device } };
    if (plan.action === 'read-operation-logs') return { before: null, after: null, output: { system: 'edge', action: plan.action, rows: device.logs }, verify: { ok: true, count: device.logs.length } };
    if (plan.action === 'apply-training-parameter') {
      const before = device.parameters[plan.payload.parameter];
      device.parameters[plan.payload.parameter] = plan.payload.value;
      device.logs.push({ at: now, action: plan.action, parameter: plan.payload.parameter, value: plan.payload.value });
      return { before, after: plan.payload.value, output: { system: 'edge', action: plan.action, ref: `${deviceId}/${plan.payload.parameter}`, receipt: '参数已写入本地硬件网关沙箱' }, verify: { ok: device.parameters[plan.payload.parameter] === plan.payload.value, read_back: device.parameters[plan.payload.parameter] } };
    }
  }
  throw Object.assign(new Error('沙箱操作未实现'), { code: 'SANDBOX_ACTION_NOT_IMPLEMENTED', status: 501 });
}

function interpolate(template, values) {
  return String(template || '').replace(/\{([a-zA-Z0-9_]+)\}/g, (_match, key) => encodeURIComponent(values[key] == null ? '' : values[key]));
}

async function executeHttp(plan, system, timeoutMs = 15000) {
  const rule = system.actions[plan.action];
  const url = new URL(interpolate(rule.path, plan.payload), system.base_url).toString();
  const headers = { Accept: 'application/json', ...(system.headers || {}) };
  if (system.auth_env && process.env[system.auth_env]) headers.Authorization = `${system.auth_scheme || 'Bearer'} ${process.env[system.auth_env]}`;
  if (plan.op === 'write') headers['Content-Type'] = 'application/json';
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const response = await fetch(url, { method: rule.method || (plan.op === 'write' ? 'POST' : 'GET'), headers, body: plan.op === 'write' ? JSON.stringify(plan.payload) : undefined, signal: controller.signal });
  clearTimeout(timer);
  const raw = await response.text();
  let body; try { body = raw ? JSON.parse(raw) : null; } catch (_) { body = { text: raw.slice(0, 2000) }; }
  if (!response.ok) throw Object.assign(new Error(`目标系统返回 HTTP ${response.status}`), { code: 'TARGET_SYSTEM_ERROR', status: 502, details: body });
  return {
    before: null,
    after: plan.op === 'write' ? body : null,
    output: { system: plan.system, action: plan.action, ref: body && (body.id || body.ref), rows: Array.isArray(body) ? body : undefined, result: body },
    verify: { ok: true, response_status: response.status, response_hash: hash(raw) },
    target: { url, method: rule.method || (plan.op === 'write' ? 'POST' : 'GET') }
  };
}

module.exports = { SANDBOX_SYSTEMS, createPlan, interpretInstruction, executeSandbox, executeHttp, hash, stableJson, getTrainingPolicy };
