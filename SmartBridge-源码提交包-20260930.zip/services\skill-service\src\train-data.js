const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const ExcelJS = require('exceljs');
const { parseFile, parseDelimited } = require('./skills/file-parser');
const { chunkText, normalizeScope } = require('./skills/rag');
const { CORPUS, VERSION: CORPUS_VERSION } = require('./knowledge-corpus');

/* 训练工作簿工作表 → 规范知识范围 */
const SHEET_SCOPES = {
  'SOP-设备日常点检作业指导书': '企业工艺文档库',
  '工艺规范-智能制造产线设备运维工艺': '企业工艺文档库',
  '设备操作手册-核心设备安全操作规范': '企业工艺文档库',
  '验收标准-实训项目交付验收规范': '验收规范',
  '异常判定规则-设备异常判定标准库': '验收规范',
  '岗位标准-设备点检员岗位能力标准': '岗位能力标准',
  'FAQ-设备点检与实训常见问题解答': '历史任务库'
};

const packageRoot = path.resolve(__dirname, '..');
const trainDir = path.resolve(packageRoot, '..', '..', 'data', 'training');
const runtimeDir = path.join(packageRoot, 'runtime');
const statePath = path.join(runtimeDir, 'state.json');
const ragName = 'manufacturing-rag-knowledge-base.xlsx';
const parseName = 'batch-file-parser-training-data.xlsx';
const trainingName = 'training-systems.example.json';
const reportDirName = 'reporting';
const reportSamplesName = 'sample-manifest.csv';
const reportGoldName = 'metric-golden-answers.csv';
const reportTemplateName = 'report-template.html';
const reportCriteriaName = 'metric-definitions.html';
const reportBoundaryName = 'negative-cases-and-boundaries.html';

function sha256(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function atomicJson(file, value) { const temp = `${file}.tmp`; fs.writeFileSync(temp, JSON.stringify(value, null, 2), 'utf8'); fs.renameSync(temp, file); }
function extractId(value) { const match = String(value || '').match(/[（(]([^）)]+)[）)]/); return match ? match[1] : String(value || ''); }

async function buildParseProfile(file) {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.readFile(file);
  const gold = workbook.getWorksheet('人工标注标准答案');
  const coverage = workbook.getWorksheet('异常场景覆盖说明');
  if (!gold || !coverage) throw new Error('解析训练工作簿缺少“人工标注标准答案”或“异常场景覆盖说明”工作表');
  const profile = {
    version: '1.0.0', source_file: parseName, source_sha256: sha256(file), generated_at: new Date().toISOString(),
    training_summary: { labeled_examples: Math.max(0, gold.rowCount - 1), covered_scenarios: Math.max(0, coverage.rowCount - 1) },
    rules: {
      field_aliases: { '运行温度': '运行温度(℃)', '温度': '运行温度(℃)', '振动值': '振动值(mm/s)' },
      date_fields: ['点检日期'],
      numeric_fields: { '运行温度(℃)': { unit: '℃', max: 85 }, '振动值(mm/s)': { unit: 'mm/s', max: 12 } },
      enums: { '油位状态': ['正常', '偏低', '偏高'], '点检结果': ['正常', '待观察', '故障'] },
      patterns: { '设备编号': { regex: '^SB\\d{6}$', message: '设备编号必须为 SB 加 6 位数字' } },
      max_lengths: { '备注': 200 },
      duplicate_key_fields: ['点检编号']
    }
  };
  atomicJson(path.join(runtimeDir, 'parse-profile.json'), profile);
  return profile;
}

async function indexRag(file, state) {
  const digest = sha256(file);
  const parsed = await parseFile({ id: 'training-rag', original_name: ragName, storage_path: file, sha256: digest });
  const staleIds = new Set((state.documents || []).filter(doc => doc.training_source === ragName || String(doc.title || '').startsWith(`${ragName} /`)).map(doc => doc.id));
  state.documents = (state.documents || []).filter(doc => !staleIds.has(doc.id));
  state.chunks = (state.chunks || []).filter(chunk => !staleIds.has(chunk.document_id));
  const indexed = [];
  for (let index = 0; index < parsed.sheets.length; index += 1) {
    const sheet = parsed.sheets[index];
    const documentId = `train-${digest.slice(0, 12)}-${String(index + 1).padStart(2, '0')}`;
    const title = `${ragName} / ${sheet.name}`;
    const scope = normalizeScope(SHEET_SCOPES[sheet.name] || 'platform');
    const document = { id: documentId, title, scope, project_id: '', version: 'train-v1', sha256: digest, indexed_at: new Date().toISOString(), training_source: ragName, sheet: sheet.name, range: sheet.range };
    const chunks = chunkText(sheet.text, 420).map((text, chunkIndex) => ({ document_id: documentId, chunk_no: chunkIndex + 1, text_content: text, title, scope, project_id: '', version: 'train-v1', sheet: sheet.name, range: sheet.range }));
    state.documents.push(document); state.chunks.push(...chunks);
    indexed.push({ document_id: documentId, sheet: sheet.name, scope, chunks: chunks.length, range: sheet.range });
  }
  return { source_sha256: digest, documents: indexed.length, chunks: indexed.reduce((sum, item) => sum + item.chunks, 0), indexed };
}

/* 索引本地中文语料库：为四端接入位实际使用的知识范围提供可检索内容。
   语料版本号变更时按前缀清理旧版本分块，避免同一篇文档在新旧版本下重复入库。 */
function indexCorpus(state) {
  const staleIds = new Set((state.documents || []).filter(doc => /^corpus-v/.test(String(doc.training_source || ''))).map(doc => doc.id));
  state.documents = (state.documents || []).filter(doc => !staleIds.has(doc.id));
  state.chunks = (state.chunks || []).filter(chunk => !staleIds.has(chunk.document_id));
  const indexed = [];
  CORPUS.forEach((doc, docIndex) => {
    const documentId = `corpus-${String(docIndex + 1).padStart(2, '0')}`;
    const scope = normalizeScope(doc.scope);
    const text = doc.sections.map(section => `${section.heading}\n${section.text}`).join('\n');
    const title = doc.title;
    const digest = crypto.createHash('sha256').update(text).digest('hex');
    const document = { id: documentId, title, scope, project_id: '', version: doc.version, sha256: digest, indexed_at: new Date().toISOString(), training_source: CORPUS_VERSION, sheet: '', range: '' };
    const chunks = chunkText(text, 420).map((content, chunkIndex) => ({ document_id: documentId, chunk_no: chunkIndex + 1, text_content: content, title, scope, project_id: '', version: doc.version, sheet: '', range: '' }));
    state.documents.push(document); state.chunks.push(...chunks);
    indexed.push({ document_id: documentId, scope, title, chunks: chunks.length });
  });
  return { documents: indexed.length, chunks: indexed.reduce((sum, item) => sum + item.chunks, 0), scopes: [...new Set(indexed.map(item => item.scope))], indexed };
}

/* 索引公开爬取语料：scripts/crawl-public-corpus.js 从公开网页（遵守 robots 与频率限制）
   抓取的百科条目，落盘为 data/training/crawled/*.json。来源 URL、许可与署名随文档
   一起进 evidence，RAG 引用时可逐条溯源到原始网页。语料整体替换（crawled-v1 前缀），
   重跑不会重复入库。 */
function indexCrawled(state) {
  const crawledDir = path.join(trainDir, 'crawled');
  const staleIds = new Set((state.documents || []).filter(doc => /^crawled-v/.test(String(doc.training_source || ''))).map(doc => doc.id));
  state.documents = (state.documents || []).filter(doc => !staleIds.has(doc.id));
  state.chunks = (state.chunks || []).filter(chunk => !staleIds.has(chunk.document_id));
  if (!fs.existsSync(crawledDir)) return { documents: 0, chunks: 0, sources: [] };
  const files = fs.readdirSync(crawledDir).filter(name => name.endsWith('.json') && name !== 'manifest.json');
  const indexed = [];
  for (const name of files) {
    let doc;
    try { doc = JSON.parse(fs.readFileSync(path.join(crawledDir, name), 'utf8')); } catch (_) { continue; }
    if (!doc || !Array.isArray(doc.sections)) continue;
    const text = doc.sections.map(section => `${section.heading}\n${section.text}`).join('\n');
    if (text.trim().length < 100) continue;
    const documentId = doc.id || `crawled-${name.replace(/\.json$/, '')}`;
    const title = String(doc.title || name);
    const scope = normalizeScope(doc.scope || '公开资料库');
    const digest = crypto.createHash('sha256').update(text).digest('hex');
    const document = {
      id: documentId, title, scope, project_id: '', version: 'crawled-v1', sha256: digest,
      indexed_at: new Date().toISOString(), training_source: 'crawled-v1', sheet: '', range: '',
      source_url: doc.source_url || '', license: doc.license || '', attribution: doc.attribution || ''
    };
    const chunks = chunkText(text, 420).map((content, chunkIndex) => ({
      document_id: documentId, chunk_no: chunkIndex + 1, text_content: content, title, scope,
      project_id: '', version: 'crawled-v1', sheet: '', range: '',
      source_url: doc.source_url || '', license: doc.license || ''
    }));
    state.documents.push(document); state.chunks.push(...chunks);
    indexed.push({ document_id: documentId, scope, title, chunks: chunks.length, source_url: doc.source_url });
  }
  return { documents: indexed.length, chunks: indexed.reduce((sum, item) => sum + item.chunks, 0), sources: indexed };
}

function buildTrainingPolicy(file) {
  const source = JSON.parse(fs.readFileSync(file, 'utf8'));
  const system = source.training_systems?.[0];
  if (!system) throw new Error('training 配置中没有 training_systems');
  const policy = {
    version: '1.0.0', source_file: trainingName, source_sha256: sha256(file), generated_at: new Date().toISOString(),
    system_name: system.system_name, environment: 'test', enabled: !!system.enabled,
    allowed_actions: system.permissions?.allowed_actions || [], forbidden_actions: system.permissions?.forbidden_actions || [],
    test_scope: {
      class_ids: (system.test_data?.test_classes || []).map(extractId), task_ids: (system.test_data?.test_tasks || []).map(extractId), device_ids: (system.test_data?.test_devices || []).map(extractId)
    },
    rate_limit: system.rate_limit || {}, verification: system.verification || {},
    external_connector_ready: false,
    external_connector_reason: '示例地址和占位凭据仅用于定义接口与安全策略，本地运行继续使用可验证沙箱。'
  };
  atomicJson(path.join(runtimeDir, 'training-policy.json'), policy);
  return policy;
}

function rowsToObjects(rows) {
  const [headers = [], ...body] = rows;
  return body.filter(row => row.some(value => String(value || '').trim())).map(row => Object.fromEntries(headers.map((header, index) => [String(header || '').replace(/^\uFEFF/, '').trim(), String(row[index] ?? '').trim()])));
}

function buildReportProfile(directory) {
  const samplePath = path.join(directory, reportSamplesName);
  const goldPath = path.join(directory, reportGoldName);
  const templatePath = path.join(directory, reportTemplateName);
  const required = [samplePath, goldPath, templatePath, path.join(directory, reportCriteriaName), path.join(directory, reportBoundaryName)];
  for (const file of required) if (!fs.existsSync(file)) throw new Error(`报告 Skill 训练文件不存在：${file}`);
  const samples = rowsToObjects(parseDelimited(fs.readFileSync(samplePath, 'utf8').replace(/^\uFEFF/, ''), ','));
  const goldRows = rowsToObjects(parseDelimited(fs.readFileSync(goldPath, 'utf8').replace(/^\uFEFF/, ''), ','));
  const periods = Object.keys(goldRows[0] || {}).filter(key => /^\d{4}-\d{2}$/.test(key) || key === '学期合计');
  const metrics = goldRows.map(row => ({
    name: row['指标'], unit: row['单位'], direction: row['方向'], formula: row['公式'],
    values: Object.fromEntries(periods.map(period => [period, row[period] === '' ? null : Number(row[period])]))
  }));
  const countByType = type => samples.filter(item => item['样本类型'] === type).length;
  const profile = {
    version: '1.0.0', generated_at: new Date().toISOString(),
    sources: required.map(file => ({ file: path.basename(file), sha256: sha256(file) })),
    training_summary: {
      samples: samples.length, positive: countByType('正向'), boundary: countByType('边界'), negative: countByType('负向'),
      scenarios: new Set(samples.map(item => item['场景编号']).filter(Boolean)).size, metrics: metrics.length, periods: periods.length
    },
    periods, metrics,
    boundary_rules: samples.filter(item => item['样本类型'] === '边界').map(item => ({ id: item['样本ID'], scenario: item['场景'], rule: item['标签含义'], validation: item['判定规则'] })),
    negative_rules: samples.filter(item => item['样本类型'] === '负向').map(item => ({ id: item['样本ID'], scenario: item['场景'], rule: item['标签含义'], validation: item['判定规则'] })),
    display_rules: { percent_decimals: 2, time_decimals: 1, money_decimals: 3, month_over_month_unit: 'pp', minimum_trend_points: 3, first_period_comparison: '—', missing_value: 'N/A' }
  };
  atomicJson(path.join(runtimeDir, 'report-profile.json'), profile);
  fs.copyFileSync(templatePath, path.join(runtimeDir, 'report-template.html'));
  return profile;
}

/* 清理历史遗留的乱码文档：文件名曾被 multer 按 latin1 解码，标题出现 é¢ 之类字符 */
function purgeMojibake(state) {
  const bad = new Set((state.documents || []).filter(doc => /[\u00c0-\u00ff]{2,}|[ÂÃ]/.test(String(doc.title || ''))).map(doc => doc.id));
  if (!bad.size) return 0;
  state.documents = (state.documents || []).filter(doc => !bad.has(doc.id));
  state.chunks = (state.chunks || []).filter(chunk => !bad.has(chunk.document_id));
  return bad.size;
}

async function main() {
  fs.mkdirSync(runtimeDir, { recursive: true });
  const paths = { rag: path.join(trainDir, ragName), parse: path.join(trainDir, parseName), training: path.join(trainDir, trainingName), report: path.join(trainDir, reportDirName) };
  for (const file of Object.values(paths)) if (!fs.existsSync(file)) throw new Error(`训练文件不存在：${file}`);
  const state = (() => { try { return JSON.parse(fs.readFileSync(statePath, 'utf8')); } catch (_) { return {}; } })();
  state.runs = state.runs || {}; state.documents = state.documents || []; state.chunks = state.chunks || []; state.reports = state.reports || {}; state.training = state.training || { plans: {}, executions: {}, sandbox: {} };
  const purged = purgeMojibake(state);
  const parseProfile = await buildParseProfile(paths.parse);
  const rag = await indexRag(paths.rag, state);
  const corpus = indexCorpus(state);
  const crawled = indexCrawled(state);
  const trainingPolicy = buildTrainingPolicy(paths.training);
  const reportProfile = buildReportProfile(paths.report);
  state.training.policy = { source_file: trainingPolicy.source_file, source_sha256: trainingPolicy.source_sha256, allowed_actions: trainingPolicy.allowed_actions.length, test_only: true };
  atomicJson(statePath, state);
  const manifest = {
    generated_at: new Date().toISOString(),
    assignments: [
      { file: ragName, skill: 'rag', result: `${rag.documents} 个工作表文档、${rag.chunks} 个检索分块` },
      { file: `本地中文语料库（${CORPUS_VERSION}）`, skill: 'rag', result: `${corpus.documents} 篇文档、${corpus.chunks} 个检索分块，覆盖知识范围：${corpus.scopes.join('、')}` },
      { file: '公开网页爬取语料（data/training/crawled，含来源与许可）', skill: 'rag', result: `${crawled.documents} 篇文档、${crawled.chunks} 个检索分块，来源：${crawled.sources.map(item => item.source_url).filter(Boolean).join('、') || '无'}` },
      { file: parseName, skill: 'parse-batch', result: `${parseProfile.training_summary.labeled_examples} 个标注样本、${parseProfile.training_summary.covered_scenarios} 类异常规则` },
      { file: trainingName, skill: 'training', result: `${trainingPolicy.allowed_actions.length} 个允许动作、${trainingPolicy.forbidden_actions.length} 个禁止动作，测试沙箱策略` }
      ,{ file: reportDirName, skill: 'report', result: `${reportProfile.training_summary.samples} 个样本、${reportProfile.training_summary.metrics} 项指标、${reportProfile.training_summary.periods} 个报告期、${reportProfile.training_summary.boundary} 个边界样本、${reportProfile.training_summary.negative} 个负样本` }
    ],
    no_training_data_required: ['multimodal']
  };
  atomicJson(path.join(runtimeDir, 'training-manifest.json'), manifest);
  console.log(JSON.stringify(manifest, null, 2));
}

main().catch(error => { console.error(error); process.exit(1); });
