const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const ExcelJS = require('exceljs');
const { parseBatch } = require('../src/skills/file-parser');
const { chunkText, retrieve, answerFromHits } = require('../src/skills/rag');
const { buildReport, prepareReportData } = require('../src/skills/report');
const { createPlan, executeSandbox } = require('../src/skills/training');
const { inspectMedia, normalizeProviderResponse, wavInfo } = require('../src/skills/multimodal');

function tempDir() { return fs.mkdtempSync(path.join(os.tmpdir(), 'smartbridge-skills-')); }

test('批量解析 CSV 并识别缺失值与重复记录', async t => {
  const dir = tempDir(); t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const filePath = path.join(dir, 'inspection.csv');
  fs.writeFileSync(filePath, '设备编号,温度,单位\nCNC-01,79,℃\nCNC-02,,℃\nCNC-01,79,℃\n', 'utf8');
  const result = await parseBatch([{ id: 'f1', original_name: '点检.csv', storage_path: filePath, sha256: 'a' }]);
  assert.equal(result.succeeded, 1);
  assert.equal(result.rows, 3);
  assert.ok(result.anomalies.some(item => item.type === '缺失值' && item.field === '运行温度(℃)'));
  assert.ok(result.anomalies.some(item => item.type === '重复记录' && item.count === 1));
});

test('批量解析按标注规则标准化日期、单位并识别业务异常', () => {
  const profile = { rules: {
    field_aliases: { '运行温度': '运行温度(℃)', '振动值': '振动值(mm/s)' },
    date_fields: ['点检日期'], numeric_fields: { '运行温度(℃)': { unit: '℃', max: 85 }, '振动值(mm/s)': { unit: 'mm/s', max: 12 } },
    enums: { '油位状态': ['正常', '偏低', '偏高'] }, patterns: { '设备编号': { regex: '^SB\\d{6}$' } }, duplicate_key_fields: ['点检编号']
  } };
  const result = require('../src/skills/file-parser').analyzeRows([
    ['点检编号','点检日期','设备编号','运行温度','振动值','油位状态'],
    ['D1','2026.09.21','SB001276','55.2℃','4.3mm/s','正常'],
    ['D2','9/22/2026','SB1285','86.2','12.5','轻微渗漏']
  ], profile);
  assert.equal(result.normalized_rows[0]['点检日期'], '2026-09-21');
  assert.equal(result.normalized_rows[0]['运行温度(℃)'], '55.2');
  for (const type of ['日期格式标准化','数值与单位混用','数值超阈值','枚举值异常','编码格式错误']) assert.ok(result.anomalies.some(item => item.type === type), type);
});

test('真实解析 XLSX 工作簿和证据范围', async t => {
  const dir = tempDir(); t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const filePath = path.join(dir, 'inspection.xlsx');
  const book = new ExcelJS.Workbook();
  const sheet = book.addWorksheet('点检记录');
  sheet.addRows([['设备编号', '温度'], ['CNC-01', 81], ['CNC-02', 78]]);
  await book.xlsx.writeFile(filePath);
  const result = await parseBatch([{ id: 'f2', original_name: '点检.xlsx', storage_path: filePath, sha256: 'b' }]);
  assert.equal(result.files[0].sheets[0].name, '点检记录');
  assert.equal(result.rows, 2);
  assert.match(result.evidence[0].range, /^A1:/);
});

test('RAG 只用命中片段生成带引用的回答', () => {
  const text = '设备点检规范。温度超过80℃判为异常，等于80℃为边界正常值。\n\n缺失的温度数据进入待核查清单。';
  const chunks = chunkText(text).map((value, index) => ({ document_id: 'd1', chunk_no: index + 1, text_content: value, title: '设备点检规范', version: 'v1', scope: 'project' }));
  const hits = retrieve('80℃等于阈值时怎么处理', chunks, 3);
  const answer = answerFromHits('80℃等于阈值时怎么处理', hits);
  assert.equal(answer.requires_confirmation, false);
  assert.match(answer.answer, /80℃/);
  assert.equal(answer.citations[0].title, '设备点检规范');
});

test('RAG 无依据时要求人工确认', () => {
  const answer = answerFromHits('保密工艺参数是什么', []);
  assert.equal(answer.requires_confirmation, true);
  assert.equal(answer.citations.length, 0);
});

test('报告生成器输出可视化 HTML 并转义输入', () => {
  const html = buildReport({ title: '项目<script>alert(1)</script>', kind: '执行报告', metrics: [{ label: '完成率', value: '88%' }], charts: [{ title: '阶段', series: [{ name: '阶段一', value: 88 }] }] });
  assert.match(html, /<svg/);
  assert.match(html, /88%/);
  assert.doesNotMatch(html, /<script>alert/);
});

test('报告 Skill 按训练指标生成指定报告期结果', () => {
  const profile = { version: '1', periods: ['2026-03', '2026-04', '2026-05', '2026-06'], display_rules: { percent_decimals: 2, time_decimals: 1, money_decimals: 3, missing_value: 'N/A' }, training_summary: { samples: 46, metrics: 2 }, sources: [{ file: 'gold.csv', sha256: 'abcdef1234567890' }], metrics: [
    { name: '提交率', unit: '%', direction: '正指标', values: { '2026-03': 0.9629, '2026-04': 0.9728, '2026-05': 0.9774, '2026-06': 0.9837 } },
    { name: '单份成本元', unit: '元', direction: '—', values: { '2026-03': 2.2971, '2026-04': 1.7158, '2026-05': 1.2608, '2026-06': 0.97 } }
  ] };
  const prepared = prepareReportData({ title: '六月报告', kind: '月报', data: { report_period: '2026-06' } }, profile);
  assert.equal(prepared.validation.valid_period, true);
  assert.equal(prepared.metrics.find(item => item.label === '提交率').value, '98.37%');
  assert.equal(prepared.metrics.find(item => item.label === '单份成本元').value, '0.970 元');
  assert.match(buildReport(prepared), /<polyline/);
});

test('报告 Skill 对未知报告期输出 N\/A 且不伪造趋势', () => {
  const profile = { version: '1', periods: ['2026-06'], display_rules: { missing_value: 'N/A' }, training_summary: { samples: 1, metrics: 1 }, sources: [], metrics: [{ name: '提交率', unit: '%', direction: '正指标', values: { '2026-06': 0.98 } }] };
  const prepared = prepareReportData({ title: '七月报告', kind: '月报', data: { report_period: '2026-07' } }, profile);
  assert.equal(prepared.validation.valid_period, false);
  assert.equal(prepared.metrics[0].value, 'N/A');
  assert.equal(prepared.charts.length, 0);
});

test('实训系统 Skill 拒绝白名单外操作', () => {
  assert.throws(() => createPlan({ system: 'lms', action: 'delete-all', op: 'write', payload: {} }), error => error.code === 'ACTION_NOT_ALLOWED');
});

test('实训系统 Skill 对写操作生成审批计划并回读验证', () => {
  const plan = createPlan({ system: 'lms', action: 'create-task', op: 'write', payload: { title: '设备点检实训' } });
  assert.equal(plan.approval_required, true);
  const sandbox = {};
  const execution = executeSandbox(plan, sandbox, () => '12345678-abcd');
  assert.equal(execution.verify.ok, true);
  assert.equal(execution.after.title, '设备点检实训');
});

test('多模态 Skill 检查图片类型、尺寸和摘要', t => {
  const dir = tempDir(); t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const filePath = path.join(dir, 'sample.png');
  const png = Buffer.alloc(24);
  png.writeUInt8(0x89, 0); png.write('PNG', 1, 'ascii'); png.writeUInt32BE(640, 16); png.writeUInt32BE(480, 20);
  fs.writeFileSync(filePath, png);
  const media = inspectMedia({ path: filePath, originalname: 'sample.png', mimetype: 'image/png', size: png.length }, 'image');
  assert.equal(media.width, 640);
  assert.equal(media.height, 480);
  assert.equal(media.sha256.length, 64);
});

test('多模态 Skill 规范化 OCR/ASR 供应商返回', () => {
  const image = normalizeProviderResponse({ data: { ocr_text: '设备编号 CNC-01', confidence: 0.93, fields: { device_id: 'CNC-01' } } }, 'image');
  const audio = normalizeProviderResponse({ transcript: '设备温度异常', confidence: 0.88 }, 'audio');
  assert.equal(image.fields.device_id, 'CNC-01');
  assert.equal(audio.text, '设备温度异常');
});

test('多模态 Skill 可读取 WAV 时长元数据', () => {
  const wav = Buffer.alloc(48);
  wav.write('RIFF', 0); wav.writeUInt32LE(40, 4); wav.write('WAVE', 8); wav.write('fmt ', 12); wav.writeUInt32LE(16, 16);
  wav.writeUInt16LE(1, 20); wav.writeUInt16LE(1, 22); wav.writeUInt32LE(8000, 24); wav.writeUInt32LE(16000, 28); wav.writeUInt16LE(2, 32); wav.writeUInt16LE(16, 34);
  wav.write('data', 36); wav.writeUInt32LE(16000, 40);
  const info = wavInfo(wav);
  assert.equal(info.sample_rate, 8000);
  assert.equal(info.duration_seconds, 1);
});
