@echo off
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\first-run.ps1"
if errorlevel 1 (
  echo.
  echo Setup failed. Check docs\local-development.md.
  pause
)
