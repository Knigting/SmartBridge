# -*- coding: utf-8 -*-
"""
build_platform_assets.py —— 生成「贴合智训桥平台」的 Skill 输入素材

背景：四端页面（教师端/企业端/学生端/平台端）的能力接入位里声明了一批业务文件
      （data-args.files / source），但 Skill 的 samples 目录里没有对应文件，接入位
      只能落到 404 或拿到无关样表。本脚本按平台真实业务口径生成这批素材：

  业务基线（与业务库一致）：
    项目 PRJ-0917-001 设备点检台账整理与异常周报生成（华明制造 / 山东智能制造职业学院）
    规则 R1 温度 > 80℃ 记异常；R2 = 80℃ 为边界正常；R3 缺失值列入待核查；R4 重复去重保留 1 条
    班级 2024级数据科学班（6 人 3 组）、2024级数控技术班（3 人 2 组）
    点检人 王浩宇 / 刘子豪 / 陈晓雨 / 孙梦洁 / 赵一鸣 / 周佳怡（均为平台在册学生）

产物：
    samples/inspection-sample-last-4-weeks.xlsx            4 周点检台账（含单位混用/缺失/重复/超阈值/编码不规范）
    samples/exception_list.xlsx             学生阶段二产物：异常与缺失值清单
    samples/pending-review-unit-mismatch.md       学生提交的待核查说明
    samples/rule_check.py                   学生规则实现脚本（文本类产物）
    samples/equipment-inspection-requirements.docx           企业原始需求说明
    samples/equipment-register-guide.docx               台账字段口径说明
    samples/equipment-inspection-work-instructions.pdf          SOP
    samples/data-processing-course-standard.docx      学校课程标准
    samples/media/*.jpg|png                 四端多模态接入位声明的图片素材
    samples/media/*.wav                     四端多模态接入位声明的音频素材（真实 RIFF，时长各异）

运行： <managed venv python> tools/build_platform_assets.py
"""
import os
import sys
import wave
import struct
import math
import zipfile

from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from PIL import Image, ImageDraw, ImageFont
from fpdf import FPDF

FONT_TTF = r'C:\Windows\Fonts\simhei.ttf'

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SAMPLES = os.path.join(ROOT, 'skill', 'smartbridge-skills', 'samples')
MEDIA = os.path.join(SAMPLES, 'media')

STUDENTS = ['王浩宇', '刘子豪', '陈晓雨', '孙梦洁', '赵一鸣', '周佳怡']
HEAD = ['点检编号', '设备编号', '点检日期', '运行温度(℃)', '振动值(mm/s)', '油位状态', '班组', '点检人', '备注']

created = []


def touch(path):
    created.append((path, os.path.getsize(path)))


# --------------------------------------------------------------------------
# 1. inspection-sample-last-4-weeks.xlsx —— 4 周点检台账
# --------------------------------------------------------------------------
def week1_rows():
    """第 1 周（三号线，问题最多）：覆盖 parse-profile 里定义的全部异常类型。"""
    return [
        ['DJ0301', 'SB030101', '2026-09-15', '72.4', '3.1', '正常', '三组', '王浩宇', '常规点检'],
        ['DJ0302', 'SB030102', '2026/9/15', '80.0', '4.2', '正常', '三组', '王浩宇', '边界值需单独标注，不得四舍五入'],
        ['DJ0303', 'SB030103', '2026-09-15', '86.7', '5.8', '正常', '三组', '王浩宇', '温度超阈值待观察'],
        ['DJ0304', 'SB030104', '2026-09-15', '', '2.9', '正常', '三组', '王浩宇', '读数缺失，转待核查清单'],
        ['DJ0305', 'SB030105', '2026-09-15', '176.0', '6.1', '正常', '三组', '王浩宇', '疑似华氏度记录待换算'],
        ['DJ0306', 'SB030106', '2026-09-15', '74.8', '3.6', '偏低', '三组', '刘子豪', '油位偏低已登记'],
        ['DJ0307', 'SB030107', '2026-09-15', '77.2', '3.0', '正常', '三组', '刘子豪', '常规点检'],
        ['DJ0308', 'SB030108', '2026-09-15', '79.9', '2.8', '正常', '三组', '刘子豪', '接近阈值'],
        ['DJ0309', 'SB030109', '2026-09-15', '80.1', '3.4', '正常', '三组', '刘子豪', '超过阈值判为异常'],
        ['DJ0310', 'SB030110', '2026-09-15', '78.6', '3.2', '异常', '三组', '刘子豪', '油位状态取值不在允许枚举内'],
        ['DJ0311', 'SB-030111', '2026-09-15', '73.5', '2.7', '正常', '三组', '陈晓雨', '设备编号格式待规范'],
        ['DJ0312', 'SB030112', '2026-09-15', '71.9', '2.5', '正常', '三组', '陈晓雨', '常规点检'],
        ['DJ0312', 'SB030112', '2026-09-15', '71.9', '2.5', '正常', '三组', '陈晓雨', '重复提交记录'],
        ['DJ0313', 'SB030113', '2026-09-15', '6O.2', '2.2', '正常', '三组', '陈晓雨', '疑似 OCR 把 0 识别为 O'],
        ['DJ0314', 'SB030114', '2026-09-15', '75.3', '2.9', '正常', '三组', '陈晓雨', '常规点检'],
        ['DJ0315', 'SB030115', '2026-09-15', '76.1', '3.3', '正常', '三组', '陈晓雨', '常规点检'],
        ['DJ0316', 'SB030116', '2026-09-15', '79.4', '3.9', '正常', '三组', '王浩宇', '常规点检'],
    ]


def other_week_rows(week, people, teams, temp_base, anomalies):
    """第 2~4 周：整体正常，按需注入少量异常，形成周报可对比的趋势。"""
    rows = []
    for index in range(1, 13):
        seq = week * 100 + index
        code = 'DJ%04d' % seq
        device_no = 'SB0301%02d' % (index + 20)
        temp = '%.1f' % (temp_base + ((index * 7) % 30) / 10.0)
        vib = '%.1f' % (2.2 + ((index * 3) % 16) / 10.0)
        oil = '正常'
        note = '常规点检'
        team = teams[(index - 1) % len(teams)]
        who = people[(index - 1) % len(people)]
        if index in anomalies:
            note = anomalies[index]
            if note.startswith('__MISSING__'):
                temp = ''
                note = note.replace('__MISSING__', '')
            if note.startswith('__FAHR__'):
                temp = '%.1f' % (temp_base * 2 + 8.5)
                note = note.replace('__FAHR__', '')
            if note.startswith('__DUP__'):
                code = 'DJ%04d' % (seq - 1)
                note = note.replace('__DUP__', '')
            if note.startswith('__OVER__'):
                temp = '%.1f' % (temp_base + 9.6)
                note = note.replace('__OVER__', '')
            if note.startswith('__LOWOIL__'):
                oil = '偏低'
                note = note.replace('__LOWOIL__', '')
        rows.append([code, device_no, '2026-%02d-%02d' % (9 if week < 4 else 10, 22 + (week - 2) * 7), temp, vib, oil, team, who, note])
    return rows


def build_checklist_workbook():
    path = os.path.join(SAMPLES, 'inspection-sample-last-4-weeks.xlsx')
    wb = Workbook()
    wb.remove(wb.active)
    head_fill = PatternFill('solid', fgColor='DCE9F7')
    thin = Side(style='thin', color='9AB6CC')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    sheets = [
        ('第1周', week1_rows()),
        ('第2周', other_week_rows(2, STUDENTS[:3], ['三组', '二组'], 74.0, {4: '__MISSING__读数缺失，转待核查清单', 9: '__FAHR__疑似华氏度记录待换算'})),
        ('第3周', other_week_rows(3, STUDENTS[2:5], ['二组'], 74.6, {7: '__OVER__温度超阈值待观察'})),
        ('第4周', other_week_rows(4, STUDENTS[3:], ['二组', '一组'], 73.8, {11: '__DUP__重复提交记录'})),
    ]
    for name, rows in sheets:
        ws = wb.create_sheet(name)
        ws.append(HEAD)
        for row in rows:
            ws.append(row)
        for col in range(1, len(HEAD) + 1):
            cell = ws.cell(row=1, column=col)
            cell.font = Font(bold=True, size=10)
            cell.fill = head_fill
            cell.alignment = Alignment(horizontal='center', vertical='center')
            ws.column_dimensions[get_column_letter(col)].width = 13
        for r in range(1, len(rows) + 2):
            for col in range(1, len(HEAD) + 1):
                ws.cell(row=r, column=col).border = border
        ws.freeze_panes = 'A2'
    wb.save(path)
    touch(path)
    return sheets


def build_exception_workbook():
    """学生阶段二产物：异常与缺失值清单。行来源于第 1 周的判定结果。"""
    path = os.path.join(SAMPLES, 'exception_list.xlsx')
    head = ['序号', '点检编号', '设备编号', '点检日期', '问题类型', '原始值', '规范值', '处理建议', '是否需企业确认']
    rows = [
        [1, 'DJ0303', 'SB030103', '2026-09-15', '温度超阈值', '86.7', '86.7', '记为温度异常，推送设备维护岗', '否'],
        [2, 'DJ0304', 'SB030104', '2026-09-15', '数值缺失', '', '', '列入待核查清单，待班组当日补录', '否'],
        [3, 'DJ0305', 'SB030105', '2026-09-15', '单位混用', '176.0', '80.0', '按 ℉→℃ 换算并标注换算来源', '是'],
        [4, 'DJ0309', 'SB030109', '2026-09-15', '温度超阈值', '80.1', '80.1', '大于 80℃ 记为异常', '否'],
        [5, 'DJ0310', 'SB030110', '2026-09-15', '枚举值异常', '异常', '', '油位状态仅允许 正常/偏低/偏高，转企业确认', '是'],
        [6, 'DJ0311', 'SB-030111', '2026-09-15', '编码格式错误', 'SB-030111', 'SB030111', '去除分隔符后规范化入台账', '否'],
        [7, 'DJ0312', 'SB030112', '2026-09-15', '重复记录', 'DJ0312 ×2', 'DJ0312', '同设备+同日+同班组视为重复，保留 1 条', '否'],
        [8, 'DJ0313', 'SB030113', '2026-09-15', 'OCR疑似错误', '6O.2', '60.2', '数字上下文中的字母 O 修正为 0，复核后入账', '否'],
        [9, 'DJ0302', 'SB030102', '2026-09-15', '边界值', '80.0', '80.0', '等于阈值判为边界正常，备注标注', '否'],
        [10, 'DJ0306', 'SB030106', '2026-09-15', '观察项', '偏低', '偏低', '油位偏低不计入异常，周报单列', '否'],
    ]
    wb = Workbook()
    ws = wb.active
    ws.title = '异常与缺失值清单'
    ws.append(head)
    for row in rows:
        ws.append(row)
    head_fill = PatternFill('solid', fgColor='FBE4D5')
    for col in range(1, len(head) + 1):
        cell = ws.cell(row=1, column=col)
        cell.font = Font(bold=True, size=10)
        cell.fill = head_fill
        cell.alignment = Alignment(horizontal='center', vertical='center')
        ws.column_dimensions[get_column_letter(col)].width = 14
    ws.column_dimensions['H'].width = 34
    ws.freeze_panes = 'A2'
    wb.save(path)
    touch(path)


# --------------------------------------------------------------------------
# 2. 文本类产物
# --------------------------------------------------------------------------
def build_texts():
    md = os.path.join(SAMPLES, 'pending-review-unit-mismatch.md')
    with open(md, 'w', encoding='utf-8') as fh:
        fh.write("""# 待核查清单 · 温度单位混用与缺失值

- 提交人：陈晓雨（第2组，2024级数据科学班）
- 项目：PRJ-0917-001 设备点检台账整理与异常周报生成
- 阶段：阶段二 规则实现：输出异常及缺失值清单
- 对应规则：R1 温度 > 80℃ 记为异常；R2 温度 = 80℃ 为边界正常值；R3 缺失值列入待核查清单

## 一、需要企业确认的问题

1. **单位混用**：第 1 周台账中 `DJ0305` 温度记为 `176.0`，与同批次 70~80 区间差异过大，
   判断为华氏度混入。已按 `(℉ - 32) / 1.8` 换算为 `80.0℃`，但原始记录未标注单位，
   **换算来源请企业确认**。
2. **无法确认原始单位**：第 2 周 `DJ0209` 温度记为 `158.3`，换算后为 `70.2℃`，
   同样缺少单位标注，请确认是否按华氏度处理。

## 二、按现行口径已处理、不需企业确认

| 情形 | 记录 | 处理方式 | 依据 |
|---|---|---|---|
| 缺失值 | DJ0304 温度为空 | 列入待核查，不补正常值、不按 0 处理 | 规则 R3 |
| 边界值 | DJ0302 温度 80.0 | 判为边界正常，不四舍五入 | 规则 R2 |
| 超阈值 | DJ0303 温度 86.7 | 判为异常并推送维护岗 | 规则 R1 |
| 重复记录 | DJ0312 出现两次 | 保留 1 条，备注标注去重依据 | 规则 R4 |

## 三、待核查与异常的口径区别

- **异常数量**只统计判定为异常的记录（当前 3 条：DJ0303 / DJ0309 / DJ0103）。
- **待核查数量**单独统计（当前 2 条：DJ0304 缺失、DJ0305 单位待确认），
  不计入异常数量，避免周报口径混用。
""")
    touch(md)

    py = os.path.join(SAMPLES, 'rule_check.py')
    with open(py, 'w', encoding='utf-8') as fh:
        fh.write('''# -*- coding: utf-8 -*-
"""rule_check.py —— 点检台账异常判定规则实现（学生阶段二产物）

项目：PRJ-0917-001 设备点检台账整理与异常周报生成
规则（与企业确认版一致）：
    R1 温度 > 80℃         -> 记为异常
    R2 温度 = 80℃         -> 边界正常值，不得四舍五入
    R3 温度为空           -> 待核查清单，不得补成正常值、不按 0 处理
    R4 设备+日期+班组相同  -> 重复记录，去重后保留 1 条
    ℉→℃ 换算：(f - 32) / 1.8，保留一位小数，并标注换算来源
"""
from decimal import Decimal

TEMP_LIMIT = Decimal('80')
VIB_LIMIT = Decimal('12')


def to_celsius(value):
    """华氏度换算为摄氏度，保留一位小数。"""
    return round((Decimal(str(value)) - 32) / Decimal('1.8'), 1)


def classify_temperature(raw):
    """温度三分支判定：异常 / 边界正常 / 正常 / 待核查。"""
    if raw is None or str(raw).strip() == '':
        return '待核查'                      # R3：空值先分流，禁止参与数值比较
    value = Decimal(str(raw).strip())
    if value > TEMP_LIMIT:
        return '异常'                        # R1
    if value == TEMP_LIMIT:
        return '边界正常'                    # R2
    return '正常'


def classify_vibration(raw):
    if raw is None or str(raw).strip() == '':
        return '待核查'
    value = Decimal(str(raw).strip())
    if value > VIB_LIMIT:
        return '异常'
    if value == VIB_LIMIT:
        return '边界正常'
    return '正常'


def dedup_key(row):
    """R4：设备编号 + 点检日期 + 班组 三者相同视为重复。"""
    return (row['设备编号'], row['点检日期'], row['班组'])


def dedup(rows):
    kept, seen = [], set()
    for row in rows:
        key = dedup_key(row)
        if key in seen:
            continue
        seen.add(key)
        kept.append(row)
    return kept


def summarize(rows):
    """统计口径：异常数量与待核查数量分开统计，待核查不计入异常。"""
    abnormal, pending, boundary = 0, 0, 0
    for row in rows:
        verdict = classify_temperature(row.get('运行温度(℃)'))
        if verdict == '异常':
            abnormal += 1
        elif verdict == '待核查':
            pending += 1
        elif verdict == '边界正常':
            boundary += 1
    return {'异常数量': abnormal, '待核查数量': pending, '边界正常数量': boundary}


if __name__ == '__main__':
    sample = [
        {'设备编号': 'SB030108', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': '79.9'},
        {'设备编号': 'SB030102', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': '80.0'},
        {'设备编号': 'SB030109', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': '80.1'},
        {'设备编号': 'SB030104', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': ''},
        {'设备编号': 'SB030112', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': '71.9'},
        {'设备编号': 'SB030112', '点检日期': '2026-09-15', '班组': '三组', '运行温度(℃)': '71.9'},
    ]
    print(summarize(dedup(sample)))
''')
    touch(py)


# --------------------------------------------------------------------------
# 3. docx（最小 OOXML，mammoth 可提取正文）
# --------------------------------------------------------------------------
def _xml_escape(text):
    return (str(text).replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;'))


def build_docx(path, title, blocks):
    """blocks: [(level, text)]，level 0=标题 1=小节标题 2=正文"""
    body = []
    for level, text in blocks:
        sizes = {0: 36, 1: 26, 2: 21}
        bold = '<w:b/>' if level < 2 else ''
        color = '' if level < 2 else '<w:color w:val="333333"/>'
        body.append(
            '<w:p><w:pPr><w:spacing w:before="%d" w:after="%d"/></w:pPr>'
            '<w:r><w:rPr><w:sz w:val="%d"/>%s%s<w:rFonts w:eastAsia="SimHei"/></w:rPr>'
            '<w:t xml:space="preserve">%s</w:t></w:r></w:p>'
            % (60 if level < 2 else 20, 60 if level < 2 else 20, sizes.get(level, 21), bold, color, _xml_escape(text))
        )
    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>'
        + ''.join(body) + '<w:sectPr/></w:body></w:document>'
    )
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '</Types>'
    )
    rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        '</Relationships>'
    )
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('[Content_Types].xml', content_types)
        zf.writestr('_rels/.rels', rels)
        zf.writestr('word/document.xml', document)
    touch(path)
    return title


def build_docx_set():
    build_docx(
        os.path.join(SAMPLES, 'equipment-inspection-requirements.docx'),
        '设备点检需求说明',
        [
            (0, '设备点检需求说明'),
            (2, '需求编号：REQ-0917-001　　提出方：华明制造　　承接方：山东智能制造职业学院'),
            (2, '紧急程度：紧急　　提交时间：2026-09-17'),
            (1, '一、业务背景'),
            (2, '华明制造三号线、二号线、一号线全部在册设备实行每班点检，点检结果由班组手工填写样表后交回。'
                '当前存在三个问题：字段名与单位不统一、同一记录重复提交、温度读数缺失或混用华氏度。'),
            (1, '二、需求描述'),
            (2, '按周汇总多个班组点检表，处理字段不统一、重复记录和缺失值，形成统一台账、异常清单与周报。'),
            (1, '三、业务目标'),
            (2, '形成统一台账、异常清单与周报，人工整理工时从 15.2 小时/月降至 6.0 小时/月以内。'),
            (1, '四、判定口径（我方确认版，不得自行更改）'),
            (2, 'R1　温度 > 80℃ 记为异常。'),
            (2, 'R2　温度 = 80℃ 为边界正常值，边界值不得四舍五入。'),
            (2, 'R3　缺失值列入待核查清单，不得自行补成正常值，也不得按 0 处理。'),
            (2, 'R4　设备编号、点检日期、班组三者相同的记录视为重复，去重后保留 1 条。'),
            (1, '五、交付物'),
            (2, '汇总表、异常明细、周报、操作说明，共四项，缺任一项不予验收。'),
            (1, '六、数据脱敏要求'),
            (2, '对外提供的点检数据需去除设备采购编号、供应商名称、联系人与联系方式，'
                '保留设备编号、点检日期、班组与测量结果。'),
        ],
    )
    build_docx(
        os.path.join(SAMPLES, 'equipment-register-guide.docx'),
        '设备台账字段口径说明',
        [
            (0, '设备台账字段口径说明'),
            (2, '版本：v1.1　　适用范围：PRJ-0917-001 及同类点检台账整理任务'),
            (1, '一、统一字段清单'),
            (2, '统一台账字段为：点检编号、设备编号、点检日期、运行温度(℃)、振动值(mm/s)、'
                '油位状态、班组、点检人、备注。'),
            (2, '字段名不得使用别名，“温度”与“运行温度”统一为 运行温度(℃)，'
                '“振动值”统一为 振动值(mm/s)。'),
            (1, '二、字段取值口径'),
            (2, '设备编号：SB 加 6 位数字，例如 SB030101；台账中出现的简写、空格或全角字符需先规范化。'),
            (2, '点检日期：统一为 YYYY-MM-DD，斜杠与点分隔的写法需标准化。'),
            (2, '运行温度(℃)：保留一位小数，正常区间 20℃ 至 80℃。'),
            (2, '振动值(mm/s)：正常区间 0 至 12 mm/s。'),
            (2, '油位状态：枚举值仅允许 正常、偏低、偏高；出现其他取值需转企业确认。'),
            (1, '三、重复与备注'),
            (2, '点检编号重复，或设备编号、点检日期、班组三者同时相同的记录视为重复，'
                '去重后保留最新一条，并在备注中标注去重来源。'),
            (2, '备注字段不超过 200 字，超出部分截断并在待核查清单中登记。'),
        ],
    )
    build_docx(
        os.path.join(SAMPLES, 'data-processing-course-standard.docx'),
        '数据处理实务课程标准',
        [
            (0, '数据处理实务课程标准'),
            (2, '版本：v3.0　　适用专业：数据科学 / 智能制造　　总课时：48'),
            (1, '一、课程目标'),
            (2, '学生能够完成数据清洗、异常判定与结果呈现三个层级的实训任务，'
                '能够说明每一步处理规则的依据，不凭经验自行定义口径。'),
            (1, '二、实训内容'),
            (2, '实训内容覆盖数据清洗、异常判定、结果呈现三个层级，并安排至少一次企业真实任务演练。'
                '真实任务来自合作企业在产数据（脱敏后使用）。'),
            (1, '三、阶段划分'),
            (2, '实训划分为四个阶段：数据整理、规则实现、成果呈现、交付复用。'
                '阶段按顺序解锁，前一阶段通过后开放下一阶段。'),
            (1, '四、边界条件教学要求'),
            (2, '边界值判断与异常规则是阶段二常见问题，需单独安排课时讲解大于、大于等于与空值的三种分支。'
                '空值必须先分流到待核查清单，不得参与数值比较。'),
            (1, '五、考核方式'),
            (2, '考核以过程证据为主：提交记录、固定样例测试结果、返修轨迹与运行说明，不采用单一期末试卷。'
                '过程分由提交完整性、固定样例通过情况与返修次数构成。'),
        ],
    )


# --------------------------------------------------------------------------
# 4. pdf（fpdf2 + SimHei）
# --------------------------------------------------------------------------
def build_pdf(path, title, blocks):
    pdf = FPDF(format='A4')
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.add_font('hei', '', FONT_TTF)
    pdf.add_page()
    for level, text in blocks:
        pdf.set_font('hei', '', 16 if level == 0 else (12 if level == 1 else 10.5))
        pdf.ln(3 if level == 0 else (2 if level == 1 else 1))
        pdf.multi_cell(0, 7 if level == 0 else (6 if level == 1 else 5.6), text)
    pdf.output(path)
    touch(path)


def build_pdf_set():
    build_pdf(
        os.path.join(SAMPLES, 'equipment-inspection-work-instructions.pdf'),
        '设备点检作业指导书',
        [
            (0, '设备点检作业指导书（脱敏版）'),
            (2, '文件编号：SOP-QC-014　　版本：v2.0　　受控状态：受控'),
            (1, '1 点检范围与周期'),
            (2, '设备点检覆盖一号线、二号线、三号线全部在册设备。班组每班点检一次，'
                '点检结果当日 18:00 前录入台账。点检项目包括运行温度、振动值、油位状态与外观检查。'),
            (1, '2 温度记录口径'),
            (2, '运行温度统一使用摄氏度（℃）记录，保留一位小数，禁止在同一台账内混用华氏度。'
                '三号线历史数据中存在华氏度记录，需在整理阶段统一换算并标注换算来源。'
                '温度超过 80℃ 判为异常；等于 80℃ 为边界正常值，边界值不得四舍五入。'),
            (1, '3 振动与油位判定'),
            (2, '振动值正常区间 0 至 12 mm/s，大于 12 mm/s 判为振动异常。'
                '油位状态为偏低时需 24 小时内补油并记录；油位状态只允许填写 正常、偏低、偏高。'),
            (1, '4 缺失值与待核查'),
            (2, '温度列为空的记录不得自行补成正常值，也不得按 0 处理，必须列入待核查清单，'
                '由班组在点检当日补录后重新判定。周报中待核查数量单独统计，不计入异常数量。'),
            (1, '5 设备编号规则'),
            (2, '设备编号统一为 SB 加 6 位数字，例如 SB030101。'
                '台账中出现的简写、空格或全角字符需先规范化再入库。'),
            (1, '6 异常处置流程'),
            (2, '异常记录需在 2 小时内推送至设备维护岗，维护岗在 8 小时内反馈处置结果，'
                '处置结果回写台账，形成异常发现到处置闭环。'),
        ],
    )


# --------------------------------------------------------------------------
# 5. 多模态图片素材（按接入位业务场景绘制）
# --------------------------------------------------------------------------
def font(size):
    return ImageFont.truetype(FONT_TTF, size)


def build_image_checklist(path):
    """现场点检表照片：9 列表头 + 数据行，含 1 处单位混用与 1 处缺失。"""
    W, H = 1400, 900
    img = Image.new('RGB', (W, H), (250, 249, 245))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, W, 74], fill=(31, 92, 140))
    d.text((34, 22), '三号线设备日常点检表（第 2 组 · 2026-09-15 夜班）', font=font(30), fill=(255, 255, 255))
    cols = HEAD
    x0, y0, rh = 30, 120, 48
    widths = [120, 150, 150, 165, 165, 130, 100, 130, 216]
    x = x0
    for i, c in enumerate(cols):
        d.rectangle([x, y0, x + widths[i], y0 + rh], fill=(220, 233, 247), outline=(140, 170, 195))
        d.text((x + 8, y0 + 13), c, font=font(20), fill=(24, 42, 62))
        x += widths[i]
    rows = [
        ('DJ0301', 'SB030101', '2026-09-15', '72.4', '3.1', '正常', '三组', '王浩宇', '常规点检'),
        ('DJ0302', 'SB030102', '2026-09-15', '80.0', '4.2', '正常', '三组', '王浩宇', '边界值需单独标注'),
        ('DJ0303', 'SB030103', '2026-09-15', '86.7', '5.8', '正常', '三组', '王浩宇', '温度偏高待观察'),
        ('DJ0304', 'SB030104', '2026-09-15', '', '2.9', '正常', '三组', '王浩宇', '读数缺失'),
        ('DJ0305', 'SB030105', '2026-09-15', '176.0', '6.1', '正常', '三组', '王浩宇', '疑似华氏度记录'),
        ('DJ0306', 'SB030106', '2026-09-15', '74.8', '3.6', '偏低', '三组', '刘子豪', '油位偏低已登记'),
        ('DJ0307', 'SB030107', '2026-09-15', '77.2', '3.0', '正常', '三组', '刘子豪', '常规点检'),
        ('DJ0308', 'SB030108', '2026-09-15', '79.9', '2.8', '正常', '三组', '刘子豪', '接近阈值'),
        ('DJ0309', 'SB030109', '2026-09-15', '80.1', '3.4', '正常', '三组', '刘子豪', '超过阈值判为异常'),
        ('DJ0310', 'SB030110', '2026-09-15', '78.6', '3.2', '异常', '三组', '刘子豪', '油位取值不在枚举内'),
    ]
    y = y0 + rh
    for ri, row in enumerate(rows):
        x = x0
        bg = (255, 253, 248) if ri % 2 == 0 else (246, 249, 252)
        for i, value in enumerate(row):
            d.rectangle([x, y, x + widths[i], y + rh], fill=bg, outline=(180, 195, 208))
            color = (24, 42, 62)
            if value == '176.0':
                color = (198, 60, 40)
            if value == '86.7' or value == '80.1':
                color = (198, 96, 30)
            d.text((x + 8, y + 13), value, font=font(19), fill=color)
            x += widths[i]
        y += rh
    d.rectangle([30, y + 18, W - 30, y + 96], outline=(120, 140, 160))
    d.text((44, y + 30), '班组签字：三组　点检人：王浩宇　复核：刘子豪　　交表时间：2026-09-15 17:40',
           font=font(21), fill=(60, 72, 88))
    d.text((44, y + 60), '注：遇“华氏度记录待换算”与“读数缺失”两行，先转待核查清单，不得直接补值。',
           font=font(20), fill=(150, 60, 40))
    img.save(path, quality=88)
    touch(path)


def build_image_meter(path):
    """仪表读数照片：CNC-02 温度仪表，主读数 80.0℃。"""
    W, H = 1200, 900
    img = Image.new('RGB', (W, H), (36, 38, 42))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([90, 70, W - 90, H - 90], radius=26, fill=(58, 61, 66), outline=(96, 100, 108), width=3)
    d.text((140, 110), 'CNC-02 数控实训台 · 主轴温度', font=font(30), fill=(200, 208, 216))
    d.rounded_rectangle([180, 200, W - 180, 520], radius=18, fill=(12, 14, 16), outline=(88, 92, 100), width=3)
    d.text((250, 258), '80.0', font=font(190), fill=(96, 240, 160))
    d.text((W - 420, 350), '℃', font=font(78), fill=(96, 240, 160))
    d.text((210, 560), '量程 0 - 120 ℃　　采样间隔 5 s　　通道 T1', font=font(26), fill=(178, 186, 196))
    d.text((210, 610), '报警阈值 > 80 ℃　　边界值 = 80.0 ℃ 记为边界正常', font=font(26), fill=(240, 190, 90))
    d.rounded_rectangle([180, 680, W - 180, 770], radius=12, fill=(70, 74, 80))
    d.text((215, 706), '判定提示：读数等于阈值，按边界正常处理，需人工复核是否四舍五入',
           font=font(24), fill=(228, 232, 238))
    img.save(path, quality=88)
    touch(path)


def build_image_screenshot(path):
    """运行截图：脚本输出区 + 异常清单区，固定样例 4/5 通过。"""
    W, H = 1400, 900
    img = Image.new('RGB', (W, H), (18, 20, 24))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, W, 52], fill=(40, 42, 48))
    for i, color in enumerate([(240, 96, 88), (242, 191, 84), (98, 200, 120)]):
        d.ellipse([22 + i * 30, 18, 40 + i * 30, 36], fill=color)
    d.text((140, 14), 'rule_check.py — 固定样例自检', font=font(20), fill=(210, 214, 220))
    lines = [
        ('$ python rule_check.py --samples fixed_sample_cases.csv', (150, 220, 160)),
        ('[1/5] 79.9℃  -> 正常        PASS', (150, 220, 160)),
        ('[2/5] 80.0℃  -> 边界正常    PASS', (150, 220, 160)),
        ('[3/5] 80.1℃  -> 异常        PASS', (150, 220, 160)),
        ('[4/5] 空值   -> 待核查      FAIL  ← 空值被当成 0 参与比较', (250, 120, 110)),
        ('[5/5] 重复记录 -> 保留 1 条 PASS', (150, 220, 160)),
        ('', (200, 200, 200)),
        ('固定样例通过：4 / 5      异常清单：3 条      待核查：1 条', (240, 200, 110)),
        ('结论：需补充缺失值分支后复检', (240, 200, 110)),
    ]
    y = 96
    for text, color in lines:
        d.text((34, y), text, font=font(24), fill=color)
        y += 44
    d.rectangle([30, 520, W - 30, 860], outline=(90, 96, 104))
    d.text((48, 534), '异常与缺失值清单 exception_list.xlsx', font=font(24), fill=(190, 200, 210))
    tbl = [
        ('序号', '点检编号', '问题类型', '原始值', '规范值', '处理建议'),
        ('1', 'DJ0303', '温度超阈值', '86.7', '86.7', '记为异常并推送维护岗'),
        ('2', 'DJ0304', '数值缺失', '（空）', '（空）', '列入待核查清单'),
        ('3', 'DJ0305', '单位混用', '176.0', '80.0', '按 ℉→℃ 换算并标注来源'),
    ]
    ty = 576
    for ri, row in enumerate(tbl):
        tx = 48
        for ci, value in enumerate(row):
            d.text((tx, ty), value, font=font(21), fill=(226, 232, 240) if ri == 0 else (198, 206, 216))
            tx += [90, 150, 190, 130, 130, 380][ci]
        ty += 40
    img.save(path)
    touch(path)


def build_image_question(path):
    """学生提问截图：点检表局部 + 红笔圈注 + 手写问题。"""
    W, H = 1300, 880
    img = Image.new('RGB', (W, H), (252, 251, 247))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, W, 70], fill=(180, 60, 52))
    d.text((30, 18), '第 2 组提问截图 · 边界值到底算不算异常？', font=font(28), fill=(255, 255, 255))
    cols = ['点检编号', '设备编号', '运行温度(℃)', '振动值(mm/s)', '备注']
    widths = [190, 230, 230, 230, 320]
    x0, y0, rh = 40, 120, 56
    x = x0
    for i, c in enumerate(cols):
        d.rectangle([x, y0, x + widths[i], y0 + rh], fill=(232, 238, 246), outline=(150, 170, 190))
        d.text((x + 12, y0 + 16), c, font=font(22), fill=(30, 44, 62))
        x += widths[i]
    rows = [
        ('DJ0301', 'SB030101', '72.4', '3.1', '常规'),
        ('DJ0302', 'SB030102', '80.0', '4.2', '边界值需单独标注'),
        ('DJ0303', 'SB030103', '86.7', '5.8', '温度偏高'),
        ('DJ0304', 'SB030104', '', '2.9', '读数缺失'),
    ]
    y = y0 + rh
    circle_box = None
    for ri, row in enumerate(rows):
        x = x0
        for i, value in enumerate(row):
            d.rectangle([x, y, x + widths[i], y + rh], fill=(255, 255, 255), outline=(190, 202, 214))
            d.text((x + 12, y + 16), value, font=font(22), fill=(30, 44, 62))
            x += widths[i]
        if row[2] == '80.0':
            circle_box = (x0 + widths[0] + widths[1] + 6, y + 4, x0 + widths[0] + widths[1] + widths[2] - 6, y + rh - 4)
        y += rh
    if circle_box:
        for offset in range(3):
            d.ellipse([circle_box[0] - offset, circle_box[1] - offset, circle_box[2] + offset, circle_box[3] + offset],
                      outline=(210, 52, 44))
        d.line([circle_box[2], circle_box[1], circle_box[2] + 150, circle_box[1] - 70], fill=(210, 52, 44), width=3)
    d.text((980, y0 + rh - 74), '80℃ 到底算', font=font(30), fill=(210, 52, 44))
    d.text((980, y0 + rh - 34), '异常还是正常？', font=font(30), fill=(210, 52, 44))
    d.text((40, y + 40), '问题：温度正好等于阈值 80.0℃，作业指导书写“超过 80℃ 判异常”，', font=font(24), fill=(40, 52, 68))
    d.text((40, y + 78), '那我到底该记异常还是正常？缺失的那一格能不能先按正常填？', font=font(24), fill=(40, 52, 68))
    d.text((40, y + 130), '提出人：周佳怡（第2组）　　时间：2026-09-22 21:10', font=font(21), fill=(110, 122, 138))
    img.save(path, quality=88)
    touch(path)


def build_image_operation(path):
    """学生实操照片：CNC-02 操作场景 + 仪表读数步骤。"""
    W, H = 1300, 900
    img = Image.new('RGB', (W, H), (206, 214, 220))
    d = ImageDraw.Draw(img)
    for gy in range(0, 620, 40):
        d.line([0, gy, W, gy], fill=(196, 204, 212))
    d.rectangle([0, 620, W, H], fill=(150, 152, 156))
    d.rounded_rectangle([160, 150, 700, 600], radius=14, fill=(96, 106, 118), outline=(70, 78, 88), width=3)
    d.rounded_rectangle([210, 200, 660, 470], radius=10, fill=(28, 32, 38))
    d.text((248, 244), 'CNC-02', font=font(54), fill=(150, 220, 255))
    d.text((248, 320), 'SPINDLE  1800 r/min', font=font(30), fill=(160, 230, 190))
    d.text((248, 372), 'TEMP     80.0 ℃', font=font(30), fill=(250, 200, 110))
    d.rounded_rectangle([236, 500, 640, 566], radius=10, fill=(58, 64, 72))
    d.text((262, 518), '固定样例回放 10 / 12 通过', font=font(26), fill=(230, 234, 240))
    # 学生 + 记录板
    d.ellipse([820, 150, 940, 270], fill=(226, 196, 168))
    d.rounded_rectangle([790, 280, 970, 560], radius=30, fill=(52, 104, 176))
    d.line([800, 340, 700, 400], fill=(52, 104, 176), width=26)
    d.rounded_rectangle([960, 330, 1240, 560], radius=12, fill=(250, 249, 244), outline=(160, 168, 178), width=3)
    d.text((984, 348), '点检记录（手写）', font=font(24), fill=(40, 52, 68))
    for i, text in enumerate(['1. 读主轴温度 80.0 ℃', '2. 读振动值 3.4 mm/s', '3. 查油位 正常', '4. 与标准比对：边界值']):
        d.text((984, 392 + i * 40), text, font=font(21), fill=(60, 72, 88))
    d.text((60, 660), '第 2 组 陈晓雨 · 2026-09-15 · CNC-02 实操步骤留痕', font=font(26), fill=(248, 250, 252))
    d.text((60, 706), '判定要点：读数等于阈值 80.0℃ 记为边界正常，不四舍五入；缺失读数转待核查。',
           font=font(23), fill=(250, 226, 176))
    img.save(path, quality=88)
    touch(path)


# --------------------------------------------------------------------------
# 6. 音频素材（真实 RIFF，时长各异，便于 ASR 元数据展示）
# --------------------------------------------------------------------------
def build_wav(path, seconds, seed):
    rate = 16000
    total = int(rate * seconds)
    with wave.open(path, 'w') as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(rate)
        frames = bytearray()
        for i in range(total):
            env = 0.35 * (0.5 + 0.5 * math.sin(2 * math.pi * (i / rate) * 1.6))
            tone = math.sin(2 * math.pi * (140 + seed * 25) * (i / rate))
            formant = 0.4 * math.sin(2 * math.pi * (620 + seed * 90) * (i / rate))
            value = int(9000 * env * (0.6 * tone + formant))
            frames += struct.pack('<h', max(-32768, min(32767, value)))
        wf.writeframes(bytes(frames))
    touch(path)


def main():
    os.makedirs(SAMPLES, exist_ok=True)
    os.makedirs(MEDIA, exist_ok=True)
    build_checklist_workbook()
    build_exception_workbook()
    build_texts()
    build_docx_set()
    build_pdf_set()
    build_image_checklist(os.path.join(MEDIA, 'on-site-inspection-sheet-line-3.jpg'))
    build_image_meter(os.path.join(MEDIA, 'instrument-reading-cnc-02.jpg'))
    build_image_screenshot(os.path.join(MEDIA, 'exception-list-screenshot.png'))
    build_image_question(os.path.join(MEDIA, 'inspection-sheet-group-2-question.jpg'))
    build_image_operation(os.path.join(MEDIA, 'student-practical-photo-cnc02.jpg'))
    build_wav(os.path.join(MEDIA, 'frontline-supervisor-voice-notes.wav'), 7.4, 1)
    build_wav(os.path.join(MEDIA, 'student-voice-question.wav'), 5.2, 2)
    build_wav(os.path.join(MEDIA, 'unit-mismatch-voice-question.wav'), 6.1, 3)
    print('生成 %d 个素材：' % len(created))
    for path, size in created:
        print('  %8d B  %s' % (size, os.path.relpath(path, ROOT)))


if __name__ == '__main__':
    main()
