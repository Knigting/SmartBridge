'use strict';
/* 提取每个页面上的「能力接入位」具体是哪项 Skill —— 演示分镜「点哪里」的唯一依据 */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..', 'apps');

const SKILL_LABEL = {
  'parse-batch': '批量文件解析',
  rag: '可追溯知识检索',
  report: '可视化报告生成',
  training: '实训系统操作',
  multimodal: '多模态识别',
  'rag/query': '可追溯知识检索'
};

for (const app of fs.readdirSync(ROOT)) {
  const dir = path.join(ROOT, app);
  if (!fs.statSync(dir).isDirectory()) continue;
  const lines = [];
  for (const file of fs.readdirSync(dir)) {
    if (!file.endsWith('.html')) continue;
    const src = fs.readFileSync(path.join(dir, file), 'utf8');
    const caps = [...src.matchAll(/data-(?:cap|skill)="([^"]+)"/g)].map(m => m[1]);
    const uniq = [...new Set(caps)];
    if (!uniq.length) continue;
    lines.push(`  ${app}/${file}\n      ${uniq.map(c => `${c}${SKILL_LABEL[c] ? '（' + SKILL_LABEL[c] + '）' : ''}`).join('\n      ')}`);
  }
  if (lines.length) { console.log(`== ${app} ==`); console.log(lines.join('\n')); }
}
