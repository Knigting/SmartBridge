# -*- coding: utf-8 -*-
"""智训桥演示素材生成器

产出一份「同一批业务数据的不同格式版本」，专门用于演示「批量文件解析」能力：
一次全选 8 个文件上传，覆盖 xlsx / csv / tsv / json / txt / md / docx / pdf 八种受支持格式。

数据里刻意埋了三类问题，让解析结果面板有东西可展示：
  - 缺失值：JC-20260922-007 缺温度、JC-20260922-009 缺备注
  - 重复项：JC-20260922-004 整行重复一次
  - 异常值：JC-20260922-006 温度 999℃（明显越界）

用法：python tools/gen-demo-files.py
"""
import csv
import json
import os
import zipfile

OUT = r'C:\Users\THUNDER\Desktop\演示素材'

HEADER = ['点检单号', '设备编号', '设备名称', '点检日期', '点检人', '温度(℃)', '振动(mm/s)', '状态', '备注']

ROWS = [
    ['JC-20260922-001', 'SB091701', '数控冲压机', '2026-09-22', '孙梦洁', 62.5, 2.1, '正常', '例行点检无异常'],
    ['JC-20260922-002', 'SB091702', '装配线传送带', '2026-09-22', '孙梦洁', 58.0, 1.8, '正常', '例行点检无异常'],
    ['JC-20260922-003', 'SB091703', '冷却水泵', '2026-09-22', '陈晓雨', 71.3, 3.4, '关注', '振动值接近上限，建议复测'],
    ['JC-20260922-004', 'SB091704', '空压机', '2026-09-22', '陈晓雨', 64.1, 2.6, '正常', '例行点检无异常'],
    ['JC-20260922-004', 'SB091704', '空压机', '2026-09-22', '陈晓雨', 64.1, 2.6, '正常', '例行点检无异常'],   # 重复项
    ['JC-20260922-005', 'SB091705', '烘干箱', '2026-09-23', '周佳怡', 88.7, 2.9, '关注', '温度偏高，已通知设备组'],
    ['JC-20260922-006', 'SB091706', '注塑机温控段', '2026-09-23', '周佳怡', 999.0, 5.2, '异常', '温度读数明显异常，疑为传感器故障'],  # 越界读数
    ['JC-20260922-007', 'SB091707', '视觉检测工位', '2026-09-23', '李振国', '', 1.5, '正常', '温度探头未回传读数'],   # 缺失值
    ['JC-20260922-008', 'SB091708', '除尘风机', '2026-09-24', '刘子豪', 55.4, 2.0, '正常', '例行点检无异常'],
    ['JC-20260922-009', 'SB091709', '老化测试台', '2026-09-24', '王浩宇', 79.2, 3.1, '关注', ''],   # 缺失备注
]

CSV_ROWS = [
    ['异常编号', '设备编号', '发现时间', '异常描述', '处理状态', '责任人'],
    ['ABN-20260922-01', 'SB091706', '2026-09-23 09:12', '温控读数 999℃，超出量程上限', '待复核', '设备组'],
    ['ABN-20260922-02', 'SB091703', '2026-09-22 14:35', '振动 3.4mm/s，接近报警阈值', '已安排复测', '孙梦洁'],
    ['ABN-20260922-03', 'SB091705', '2026-09-23 16:02', '烘干箱温度持续高于 85℃', '处理中', '周佳怡'],
]

TSV_ROWS = [
    ['班组', '交接日期', '当班点检数', '遗留问题', '交接人', '接班人'],
    ['甲班', '2026-09-22', '5', '无', '孙梦洁', '陈晓雨'],
    ['乙班', '2026-09-23', '3', '注塑机温控读数异常待复核', '陈晓雨', '周佳怡'],
    ['甲班', '2026-09-24', '2', '待设备组出具复核结论', '周佳怡', '孙梦洁'],
]

JSON_DATA = {
    '采集任务': 'TASK-0917-001',
    '设备类型': '温度传感器',
    '采样间隔': '30 分钟',
    '数据范围': {'开始': '2026-09-22 08:00', '结束': '2026-09-22 18:00'},
    '读数': [
        {'时间': '08:00', '设备编号': 'SB091705', '温度': 82.1},
        {'时间': '10:00', '设备编号': 'SB091705', '温度': 85.6},
        {'时间': '12:00', '设备编号': 'SB091705', '温度': 88.7},
        {'时间': '14:00', '设备编号': 'SB091705', '温度': None},
        {'时间': '16:00', '设备编号': 'SB091705', '温度': 86.4},
        {'时间': '18:00', '设备编号': 'SB091705', '温度': 83.9}
    ],
    '说明': '14:00 点位数据缺失，系采集网关重启所致'
}

TXT = """设备点检作业指导书（节选）
版本：v2.0　　适用项目：PRJ-0917-001 设备点检台账整理与异常周报生成

一、作业准备
1. 点检人员须佩戴防护用具，携带红外测温仪与测振仪。
2. 点检前核对设备编号与台账一致，防止串号记录。

二、数据记录
1. 温度读数保留一位小数，单位为摄氏度。
2. 振动读数保留一位小数，单位为毫米每秒。
3. 读数缺失时，必须在备注栏写明原因，不得留空不注。

三、判定标准
1. 温度不超过 85 摄氏度，判为正常。
2. 温度在 85 至 90 摄氏度之间，判为关注，需在 24 小时内复测。
3. 温度超过 90 摄氏度，判为异常，立即上报设备组并暂停设备运行。
4. 振动值不得超过 4.0 毫米每秒。

四、异常处置
1. 读数明显超出量程（如 999 摄氏度）时，优先怀疑传感器故障，
   先更换探头复测，再决定是否上报，避免误报占用维修资源。
2. 所有异常须在异常记录表中登记，并在周报中汇总。
"""

MD = """# 周报口径说明（第 38 周）

> 适用数据：2026-09-22 至 2026-09-28 的设备点检记录
> 编制人：李慧敏（山东智能制造职业学院）

## 1. 统计范围

本周纳入统计的点检单共 **10 条**，覆盖 3 个设备区域、8 台设备。

## 2. 指标口径

| 指标 | 计算方式 | 说明 |
| --- | --- | --- |
| 点检完成率 | 已完成点数 / 应完成点数 | 缺失温度的条目计入未完成字段数 |
| 异常率 | 状态为「异常」的条数 / 总条数 | 不含因传感器故障导致的无效读数 |
| 重复记录率 | 重复点检单号条数 / 总条数 | 同一单号重复录入需人工确认后去重 |

## 3. 数据质量问题处理约定

1. **重复录入**：以最后一次修改的记录为准，重复行在周报中单列，不做静默丢弃。
2. **字段缺失**：缺失字段不参与平均值计算，但在「数据质量」章节计数披露。
3. **越界读数**：先走设备故障复核流程，复核结论未出之前，不计入异常率。

## 4. 本周结论

本周数据质量存在三处待处理项：1 条重复记录、2 处字段缺失、1 处疑似传感器故障读数。
"""

DOCX_TEXT = [
    ('标题', '设备点检异常申诉与复核说明'),
    ('正文', '文件编号：REV-0917-001　　项目：PRJ-0917-001 设备点检台账整理与异常周报生成'),
    ('正文', ''),
    ('正文', '一、申诉事项'),
    ('正文', '2026 年 9 月 23 日，注塑机温控段（设备编号 SB091706）点检记录温度为 999 摄氏度，'),
    ('正文', '超出量程上限，被系统判定为异常。现就该读数提出复核申诉。'),
    ('正文', ''),
    ('正文', '二、申诉理由'),
    ('正文', '1. 该设备前一日点检读数为 63.8 摄氏度，24 小时内读数跃升不符合设备运行规律。'),
    ('正文', '2. 同期同车间其它设备读数均在正常区间，不存在车间级异常工况。'),
    ('正文', '3. 初步判断为温度传感器接线松动导致的无效读数。'),
    ('正文', ''),
    ('正文', '三、复核诉求'),
    ('正文', '1. 在复核结论出具前，该条记录暂不计入本周异常率统计。'),
    ('正文', '2. 请设备组于两个工作日内完成探头更换与复测，并回填温度读数。'),
    ('正文', ''),
    ('正文', '申请人：陈晓雨　　　　复核人：华明制造设备部'),
]

README = """智训桥演示素材包
=================
用途：演示「批量文件解析」能力的上传文件，以及各输入框该填的演示文本。
生成脚本：项目 tools/gen-demo-files.py（可随时重跑重建）

【一】批量解析演示（企业端 demand 页 / 学生端 task 页）
------------------------------------------------------
把下面 7 个文件一次性全选上传，即俗称的“批量”。
它们支持格式各不相同，解析后字段名能够对齐——这就是要讲的“归一化”。

01_设备点检台账_2026-09.xlsx   Excel 台账主表，含全部字段
02_点检异常记录_20260922.csv   异常登记表
03_交接班记录_2026W38.tsv      班组交接记录（制表符分隔）
04_温度传感器读数.json         采集网关下发的半结构化数据
05_设备点检作业指导.txt        纯文本文档
06_周报口径说明.md             Markdown 文档，含表格
07_异常申诉与复核.docx         Word 说明文档

实测结论（2026-09-30 用真实 Skill 服务跑过）：
  7 个文件全部解析成功，共抽出 25 个字段、17 行数据，失败 0 个。
  耗时波动较大，实测 12 秒到 37 秒不等 —— 正式录制前务必先跑一遍热身。

为什么不放 PDF：图片版 PDF（内容渲染成图再封装）没有文本层，
解析器抽不到正文，画面会显示“0 行 0 字段”，反而减分。

文件分类说明（避免现场被问住）：
  01 xlsx / 02 csv / 03 tsv / 04 json 属于结构化文件，能看到行数和字段名；
  05 txt / 06 md / 07 docx 属于文本类文件，系统抽取的是正文内容，
  面板上显示“行数 0、字段 0”是正常的，不是没解出来。

【二】素材里特意埋的数据质量问题
--------------------------------
上传后，解析面板上应当出现这两类——这是镜头要停留的地方：

  1. 缺失值 2 处：JC-20260922-007 缺少温度；JC-20260922-009 缺少备注
  2. 重复项 1 条：JC-20260922-004 整行重复一次

注意两点，别在解说里承诺错：
  - 「温度 999℃」这条越界读数不会被自动列成异常项，
    它是通过“状态=异常”这一列体现的，由后续业务规则处理。
  - 设备编号必须写成 SB + 6 位数字（如 SB091701）。
    早期版本写成 EQ-A-017 这种，系统按业务规则判成了十几条“编码格式错误”，
    面板刷屏很难看——现在的素材已经全部改成合规编号。

【三】演示台词卡
----------------
见同目录《演示台词与输入卡.md》，里面有每一幕要点哪个位置、输入框填什么。
"""


def ensure_dir():
    os.makedirs(OUT, exist_ok=True)


def write_xlsx():
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws.title = '点检台账'
    ws.append(HEADER)
    for r in ROWS:
        ws.append(r)
    # 让列宽好看一点，避免录屏时内容挤在一起
    for col in 'ABCDEFGHI':
        ws.column_dimensions[col].width = 18
    ws.freeze_panes = 'A2'
    path = os.path.join(OUT, '01_设备点检台账_2026-09.xlsx')
    wb.save(path)
    return path


def write_csv():
    path = os.path.join(OUT, '02_点检异常记录_20260922.csv')
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        csv.writer(f).writerows(CSV_ROWS)
    return path


def write_tsv():
    path = os.path.join(OUT, '03_交接班记录_2026W38.tsv')
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w = csv.writer(f, delimiter='\t')
        w.writerows(TSV_ROWS)
    return path


def write_json():
    path = os.path.join(OUT, '04_温度传感器读数.json')
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(JSON_DATA, f, ensure_ascii=False, indent=2)
    return path


def write_txt():
    path = os.path.join(OUT, '05_设备点检作业指导.txt')
    with open(path, 'w', encoding='utf-8') as f:
        f.write(TXT)
    return path


def write_md():
    path = os.path.join(OUT, '06_周报口径说明.md')
    with open(path, 'w', encoding='utf-8') as f:
        f.write(MD)
    return path


def write_docx():
    """不依赖 python-docx：手写最小 OOXML 包（docx 本质是 zip + xml）"""
    paras = []
    for kind, text in DOCX_TEXT:
        size = 32 if kind == '标题' else 22
        bold = '<w:b/>' if kind == '标题' else ''
        paras.append(
            '<w:p><w:pPr><w:spacing w:line="320" w:lineRule="auto"/></w:pPr>'
            '<w:r><w:rPr>%s<w:sz w:val="%d"/><w:rFonts w:ascii="Microsoft YaHei" w:eastAsia="Microsoft YaHei"/></w:rPr>'
            '<w:t xml:space="preserve">%s</w:t></w:r></w:p>' % (bold, size, _xml_escape(text))
        )
    document = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
        '<w:body>' + ''.join(paras) + '<w:sectPr/></w:body></w:document>'
    )
    content_types = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
        '</Types>'
    )
    rels = (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
        '</Relationships>'
    )
    path = os.path.join(OUT, '07_异常申诉与复核.docx')
    with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', content_types)
        z.writestr('_rels/.rels', rels)
        z.writestr('word/document.xml', document)
    return path


def _xml_escape(s):
    return s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')


def write_pdf():
    """不依赖 reportlab：先用 PIL 把中文渲染成图，再包一层最小 PDF"""
    from PIL import Image, ImageDraw, ImageFont

    W, H = 1240, 1754
    img = Image.new('RGB', (W, H), 'white')
    d = ImageDraw.Draw(img)
    font_title = ImageFont.truetype('C:/Windows/Fonts/msyhbd.ttc', 40)
    font_text = ImageFont.truetype('C:/Windows/Fonts/msyh.ttc', 24)
    font_small = ImageFont.truetype('C:/Windows/Fonts/msyh.ttc', 20)

    x, y = 90, 90
    d.text((x, y), '设备点检周报（第 38 周）', font=font_title, fill=(20, 30, 60))
    y += 70
    d.text((x, y), '项目：PRJ-0917-001 设备点检台账整理与异常周报生成', font=font_small, fill=(90, 100, 115))
    y += 36
    d.text((x, y), '统计区间：2026-09-22 至 2026-09-28　　编制：李慧敏（山东智能制造职业学院）', font=font_small, fill=(90, 100, 115))
    y += 60
    d.line((x, y, W - x, y), fill=(200, 208, 220), width=2)
    y += 34

    lines = [
        '一、本周概览',
        '',
        '本周共完成点检单 10 条，覆盖 3 个设备区域、8 台设备。其中状态判为正常 5 条、',
        '关注 4 条、异常 1 条。点检打卡时间为每日 08:30 与 16:30 两个班次。',
        '',
        '二、异常与处置',
        '',
        'ABN-20260922-01　注塑机温控段（EQ-C-034）读数 999℃，超出量程上限，',
        '　　　　　　　　　初判为传感器故障，已转设备组复核（REV-0917-001）。',
        'ABN-20260922-02　冷却水泵（EQ-B-021）振动 3.4mm/s，接近报警阈值，已安排复测。',
        'ABN-20260922-03　烘干箱（EQ-C-033）温度持续高于 85℃，处理中。',
        '',
        '三、数据质量披露',
        '',
        '重复记录 1 条（JC-20260922-004）；字段缺失 2 处（缺温度 1 处、缺备注 1 处）；',
        '越界读数 1 处，复核结论未出之前不计入本周异常率。',
        '',
        '四、下周安排',
        '',
        '完成 EQ-C-034 探头更换与复测回填；对重复录入流程做一次源头排查。',
    ]
    for line in lines:
        if line.startswith(('一、', '二、', '三、', '四、')):
            d.text((x, y), line, font=ImageFont.truetype('C:/Windows/Fonts/msyhbd.ttc', 26), fill=(30, 60, 120))
            y += 44
        else:
            d.text((x, y), line, font=font_text, fill=(40, 48, 60))
            y += 38

    tmp = os.path.join(OUT, '_tmp_weekly.jpg')
    img.save(tmp, 'JPEG', quality=90)

    data = open(tmp, 'rb').read()
    iw, ih = Image.open(tmp).size
    pw, ph = 595, 842
    content = ('q %d 0 0 %d 0 0 cm /Im0 Do Q' % (pw, ph)).encode('latin-1')

    objs = [
        b'<< /Type /Catalog /Pages 2 0 R >>',
        b'<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
        ('<< /Type /Page /Parent 2 0 R /MediaBox [0 0 %d %d] /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R >>' % (pw, ph)).encode('latin-1'),
        ('<< /Type /XObject /Subtype /Image /Width %d /Height %d /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length %d >>\nstream\n' % (iw, ih, len(data))).encode('latin-1') + data + b'\nendstream',
        (b'<< /Length %d >>\nstream\n' % len(content)) + content + b'\nendstream',
    ]

    out = b'%PDF-1.4\n'
    offsets = []
    for i, obj in enumerate(objs, start=1):
        offsets.append(len(out))
        out += (b'%d 0 obj\n' % i) + obj + b'\nendobj\n'
    xref = len(out)
    out += b'xref\n0 %d\n0000000000 65535 f \n' % (len(objs) + 1)
    for off in offsets:
        out += b'%010d 00000 n \n' % off
    out += b'trailer\n<< /Size %d /Root 1 0 R >>\nstartxref\n%d\n%%%%EOF\n' % (len(objs) + 1, xref)

    path = os.path.join(OUT, '08_点检周报_第38周.pdf')
    with open(path, 'wb') as f:
        f.write(out)
    os.remove(tmp)
    return path


def write_readme():
    path = os.path.join(OUT, 'README_素材说明.txt')
    with open(path, 'w', encoding='utf-8') as f:
        f.write(README)
    return path


def write_script_card():
    card = """# 演示台词与输入卡

> 配合《SmartBridge-演示视频方案与解说词》使用。
> 这里只写「输入框该填什么、按钮该点哪里」，解说词见方案正文。

## 幕② 企业端 demand —— 批量文件解析（上传）

- 上传位置：企业端需求页 → 新增/查看需求 → 附件上传区
- 上传文件：**全选** 演示素材目录中的 7 个文件（01～07），一次拖进去
- 目的说明填：`2026 年 9 月设备点检台账与异常记录，用于需求附件归档与字段核对`
- 镜头停留点：解析结果里的「字段」「缺失值」「重复项」「证据」四个区块
- 预期看到：共 7 个文件、约 25 个字段、17 行数据，缺失 2 处、重复 1 条
- **必须热身**：实测耗时 12～37 秒波动不小，正式录制前先跑一遍把结果跑热，
  否则镜头前会干等半分钟

## 幕③ 教师端 qa —— 可追溯知识检索

- 待回复提问：选 `孙梦洁` 或 `李振国` 的 pending 提问
- 检索框推荐输入（任选一句，都是本项目真实内容）：

  1. `点检温度超过多少摄氏度需要上报设备组？`
  2. `振值超标的判定标准是多少？`
  3. `周报里重复的点检记录该怎么处理？`

- 镜头停留点：回答里的引用编号 `[1]` `[2]`，点开看原文出处
- 随后点「归档为知识条目」（今天已修复并验证，可放心点）

## 幕④ 学生端 tasks —— 实训系统操作

- 进入任务页，选当前阶段任务
- 触发「实训系统操作」接入位（B1）
- 镜头停留点：计划哈希、需要审批、校验结果、证据链四行
- 若系统要求选择系统/动作：选 `lms` + 只读类查询动作（如 query_task / query_scores），
  演示写操作会多一步审批，时间可能不够

## 幕⑤ 教师端 evaluation → library —— 可视化报告

- 评价页：选任意一条真实评价（如 72 分、状态「已调整」那条）
- 进入案例库，选 `设备点检台账整理（脱敏版）v2.0`
- 触发报告生成（E3），等 HTML 报告出来后展示下载

## 幕⑥ 企业端 acceptance → talent —— 验收与隐私授权

- 验收页：指向本项目（PRJ-0917-001，阶段「过程监督」，进度 63%）
- 人才页：**停在状态为「未发起授权」的候选人身上**（周佳怡 2024010221）
- 演示发起授权 → 切到学生端 company.html 展示可见性开关由本人控制

## 幕⑦ 平台管理端 —— 运营审计

- 首页念当天的真实数字（组织 4 / 项目 3 / 审批 7 / 风险 1）
- 运营页展示 Skill 健康与后台任务队列
- 隐私页强调每次敏感查看都有审计留痕

## 幕⑧ 结尾 —— 能力诚实声明

- 打开 `http://localhost:8090/api/skills/status`（required 5 / available 5 / live 4）
- 打开 `http://localhost:8090/api/skills/multimodal/status`（not_configured）

---

## 开录前 30 秒自查

1. `node tools/record-precheck.js` → 26/26
2. 后端业务服务 8080、Skill 服务 8090 均在监听
3. 手动点一次「归档为知识条目」确认成功
4. 素材目录这 8 个文件都在桌面的「演示素材」文件夹里
"""
    path = os.path.join(OUT, '演示台词与输入卡.md')
    with open(path, 'w', encoding='utf-8') as f:
        f.write(card)
    return path


def main():
    ensure_dir()
    made = [
        write_xlsx(), write_csv(), write_tsv(), write_json(), write_txt(),
        write_md(), write_docx(), write_readme(), write_script_card()
    ]
    # 说明：write_pdf() 生成的 PDF 是「图片版」（PIL 渲染后再封成 PDF），没有文本层，
    # 解析器抽不到正文，只会显示为「PDF，0 行 0 字段」，反而不利于演示。
    # 要生成真正的文本层 PDF 需要嵌入中文字体，代价不划算，故演示包不放 PDF。
    # 需要时单独调用：python -c "import sys;sys.path.insert(0,'tools');import gen_demo_files as g;g.write_pdf()"
    print('生成目录：' + OUT)
    for p in made:
        print('  %-46s %8.1f KB' % (os.path.basename(p), os.path.getsize(p) / 1024))
    print('合计 %d 个文件' % len(made))


if __name__ == '__main__':
    main()
