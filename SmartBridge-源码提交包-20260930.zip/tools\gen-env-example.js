'use strict';
/* 由真实 .env 生成 .env.example（占位符版本），用于提交源码时随包提供配置模板。
   两条硬规则：
     1) 不泄露任何真实值——密钥、内部地址、内部运维备注一律不进模板；
     2) 原 .env 的注释全部丢弃（作者的运维备注常含内部信息），改用中性说明。
   用法：node tools/gen-env-example.js */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const TARGETS = [
  { rel: 'services/api/.env', title: '业务后端 · 数据库与鉴权配置' },
  { rel: 'services/skill-service/.env', title: 'Skill 服务 · 大模型配置（OpenAI 兼容协议）' }
];

/* 按变量名给默认值 / 占位符。注意顺序：先匹配明确的功能性变量，最后才判定为密钥。 */
function value(key) {
  if (/MAX_TOKENS$/i.test(key)) return '4096';
  if (/TEMPERATURE$/i.test(key)) return '0.2';
  if (/TIMEOUT_MS$/i.test(key)) return '60000';
  if (/MAX_RETRIES$/i.test(key)) return '2';
  if (/^PORT$/i.test(key)) return '8080';
  if (/^DB_PORT$/i.test(key)) return '3306';
  if (/^DB_NAME$/i.test(key)) return 'smartbridge';
  if (/^DB_HOST$/i.test(key)) return '127.0.0.1';
  if (/^DB_USER$/i.test(key)) return 'root';
  if (/^DB_ADMIN_USER$/i.test(key)) return 'root';
  if (/^DB_PASSWORD$|^DB_ADMIN_PASSWORD$/i.test(key)) return '请填写数据库密码';
  if (/JWT_SECRET/i.test(key)) return '请填写一段足够长的随机字符串';
  if (/DEMO_MODE/i.test(key)) return 'false';
  if (/UPLOAD_DIR/i.test(key)) return './uploads';
  if (/BASE_URL|ENDPOINT/i.test(key)) return 'https://你的模型服务地址/v1';
  if (/_MODEL$/i.test(key)) return '';
  if (/API_KEY/i.test(key)) return 'sk-请填写你的密钥，多个用英文逗号分隔';
  if (/SECRET|PASSWORD|_TOKEN$/i.test(key)) return '请填写';
  return '请填写';
}

function hint(key) {
  if (/LLM_API_KEYS?$/i.test(key)) return '服务端密钥，多个用英文逗号分隔，可轮询分摊额度并自动跳过失效密钥';
  if (/LLM_MODEL$/i.test(key)) return '文本任务的模型名，填服务商提供的 OpenAI 兼容模型标识，例如 qwen/deepseek-v4-flash-0731';
  if (/MAX_TOKENS$/i.test(key)) return '推理模型会先输出思考过程，此处预算必须给足，否则正文可能为空';
  if (/JWT_SECRET/i.test(key)) return '登录令牌签名密钥，务必改成只有自己知道的值';
  if (/DEMO_MODE/i.test(key)) return '演示模式开关';
  if (/UPLOAD_DIR/i.test(key)) return '上传文件落盘目录';
  if (/DB_/i.test(key)) return '数据库连接参数，建库脚本见 services/api/database/schema.sql';
  return '';
}

let total = 0;
for (const { rel, title } of TARGETS) {
  const src = path.join(ROOT, rel);
  if (!fs.existsSync(src)) { console.log('跳过（不存在）：' + rel); continue; }
  const lines = fs.readFileSync(src, 'utf8').split(/\r?\n/);
  const keys = [];
  const body = [];
  for (const line of lines) {
    const eq = line.indexOf('=');
    if (eq < 0) continue;                     // 丢弃原注释与空行（避免带出内部运维信息）
    const key = line.slice(0, eq).trim();
    if (!key || key.startsWith('#')) continue;
    keys.push(key);
    const h = hint(key);
    if (h) body.push('# ' + h);
    body.push(key + '=' + value(key));
    body.push('');
  }
  const out = [
    '# ' + rel + '.example —— 配置模板',
    '# 由 tools/gen-env-example.js 自动生成，所有真实值均已替换为占位符。',
    '# 用法：复制本文件为同目录下的 .env，逐项填写后启动服务。',
    '# 注意：填好的 .env 已被 .gitignore 忽略，请勿提交到版本库。',
    '',
    '# ' + title,
    ''
  ].concat(body);
  const dest = src.replace(/\.env$/, '.env.example');
  fs.writeFileSync(dest, out.join('\n').replace(/\n{3,}/g, '\n\n'));
  total++;
  console.log('已生成 ' + path.relative(ROOT, dest).replace(/\\/g, '/') + '（' + keys.length + ' 项）');
  console.log('   ' + keys.join(', '));
}
console.log('\n完成，共 ' + total + ' 个模板文件。');
