'use strict';
/* 页面「能不能拍」体检：逐个 HTML 判断它是接后端真实数据，还是直接渲染本地 Mock。
   同时列出页面上的 Skill 接入位（data-cap / data-skill），用于挑选演示镜头。 */
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..', 'apps');

const rows = [];
for (const app of fs.readdirSync(ROOT)) {
  const dir = path.join(ROOT, app);
  if (!fs.statSync(dir).isDirectory()) continue;
  for (const file of fs.readdirSync(dir)) {
    if (!file.endsWith('.html')) continue;
    const full = path.join(dir, file);
    const src = fs.readFileSync(full, 'utf8');
    const count = re => (src.match(re) || []).length;
    rows.push({
      page: app + '/' + file,
      hasStoreJs: /assets\/store\.js|assets\/core\.js/.test(src),
      storeCalls: count(/Store\.get\s*\(|await Store\./g),
      mockRefs: count(/window\.MOCK/g),
      capSlots: count(/data-cap=/g),
      skillSlots: count(/data-skill=/g),
      fetchCalls: count(/fetch\s*\(/g),
      mockScript: /mock\.js|MOCK_DATA/.test(src)
    });
  }
}

const pad = (s, n) => String(s).padEnd(n);
console.log(pad('页面', 26) + pad('store.js', 9) + pad('Store调用', 9) + pad('MOCK直引用', 11) + pad('能力位', 7) + pad('Skill位', 8) + '结论');
rows.forEach(r => {
  let verdict;
  if (r.storeCalls > 0 && r.mockRefs <= 2) verdict = '真数据';
  else if (r.storeCalls > 0) verdict = '混合（部分 Mock）';
  else if (r.mockRefs > 0) verdict = '★纯前端 Mock';
  else verdict = '静态/无数据';
  console.log(pad(r.page, 26) + pad(r.hasStoreJs ? '有' : '无', 9) + pad(r.storeCalls, 9) + pad(r.mockRefs, 11) + pad(r.capSlots, 7) + pad(r.skillSlots, 8) + verdict);
});

console.log('\n== 纯前端 Mock 页面（录屏需回避或需先接通）==');
const mockPages = rows.filter(r => r.mockRefs > 0 && r.storeCalls === 0).map(r => r.page);
console.log(mockPages.length ? mockPages.join('\n') : '（无）');

console.log('\n== Skill 接入位分布（演示「智能体运行」的主战场）==');
rows.filter(r => r.capSlots + r.skillSlots > 0).forEach(r => console.log(`${r.page}  能力位 ${r.capSlots}  Skill位 ${r.skillSlots}`));
