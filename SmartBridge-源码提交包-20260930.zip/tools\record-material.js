'use strict';
/* 为录屏方案取材：把「镜头里会出现什么」的真实内容抓出来（只读），
   同时确认五个 Skill 各自的可用性，避免解说词念出不存在的东西。 */
const fs = require('fs');
const path = require('path');
const API = 'http://127.0.0.1:8080';
const SKILL = 'http://127.0.0.1:8090';

async function get(base, url) {
  try {
    const r = await fetch(base + url, { headers: { Accept: 'application/json' } });
    const t = await r.text();
    let j = null; try { j = JSON.parse(t); } catch (e) { return { status: r.status, raw: t.slice(0, 120) }; }
    return { status: r.status, data: j && j.data !== undefined ? j.data : j, message: j && j.message };
  } catch (e) { return { status: 0, error: e.message }; }
}
const pick = (obj, keys) => { const o = {}; keys.forEach(k => { if (obj && obj[k] !== undefined) o[k] = obj[k]; }); return o; };
const head = (arr, n, keys) => (Array.isArray(arr) ? arr.slice(0, n) : []).map(x => (keys ? pick(x, keys) : x));

(async () => {
  const out = { at: new Date().toISOString(), spotlight: {}, skills: {} };
  const show = (label, v) => { console.log('\n### ' + label + '\n' + JSON.stringify(v, null, 2).slice(0, 1400)); };

  const projects = await get(API, '/api/company/projects');
  out.spotlight.projects = head(projects.data, 3, ['id', 'code', 'name', 'status', 'progress', 'stage', 'school', 'teacher']);
  show('企业侧项目（可直接念名字）', out.spotlight.projects);

  const req = await get(API, '/api/teacher/requests');
  out.spotlight.requests = head(req.data, 5, ['id', 'code', 'title', 'status', 'company', 'urgent']);
  show('待评审的企业需求', out.spotlight.requests);

  const questions = await get(API, '/api/teacher/questions');
  out.spotlight.questions = head(questions.data, 6, ['id', 'title', 'status', 'student', 'project_id']);
  show('学生提问（用于释义/答疑演示）', out.spotlight.questions);

  const evals = await get(API, '/api/teacher/evaluations');
  out.spotlight.evaluations = head(evals.data, 3, ['id', 'student_user_id', 'score', 'status']);
  show('教学评价', out.spotlight.evaluations);

  const kpi = await get(API, '/api/teacher/kpis');
  out.spotlight.teacherKpis = kpi.data;
  show('教师端真实 KPI（不要念首页硬编码数字）', out.spotlight.teacherKpis);

  const cands = await get(API, '/api/company/candidates');
  out.spotlight.candidates = head(cands.data, 5, ['id', 'name', 'student_no', 'score', 'authorization']);
  show('候选人（隐私可见性演示）', out.spotlight.candidates);

  const adm = await get(API, '/api/admin/kpis');
  out.spotlight.adminKpis = adm.data;
  show('平台运营指标', out.spotlight.adminKpis);

  const lib = await get(API, '/api/teacher/library');
  out.spotlight.library = head(lib.data, 4, ['id', 'name', 'type', 'version', 'status']);
  show('案例/知识库', out.spotlight.library);

  out.skills.status = await get(SKILL, '/api/skills/status');
  show('Skill 状态', out.skills.status);

  out.skills.multimodal = await get(SKILL, '/api/skills/multimodal/status');
  show('多模态能力（短板确认）', out.skills.multimodal);

  out.skills.systems = await get(SKILL, '/api/skills/training/systems');
  show('两套实训系统', out.skills.systems);

  out.skills.reportProfile = await get(SKILL, '/api/skills/report/profile');
  show('报告画像', out.skills.reportProfile);

  const chat = await get(API, '/api/inagent/chat');
  out.skills.inagentChat = { status: chat.status, note: 'GET 探测，405/400 亦说明路由存在' };
  show('内置答疑助手路由', out.skills.inagentChat);

  const dir = path.join(__dirname, '..', 'reports');
  const file = path.join(dir, 'record-material-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json');
  fs.writeFileSync(file, JSON.stringify(out, null, 2));
  console.log('\n素材JSON：' + file);
})();
