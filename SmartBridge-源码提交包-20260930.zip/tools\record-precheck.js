'use strict';
/* 录屏前置自检：只读地摸一遍「镜头里能出现什么数据」，据此决定演示分镜能拍哪些镜头。
   不做任何写操作，不改动业务数据。
   用法：node tools/record-precheck.js            （输出到 reports/record-precheck-<时间>.json）
        node tools/record-precheck.js --ping      （额外打一次模型自检，会消耗少量 token）
*/
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const API = 'http://127.0.0.1:8080';
const SKILL = process.env.SMARTBRIDGE_SKILL_BASE || 'http://127.0.0.1:8090';

const READ_APIS = [
  ['GET', '/api/health', '服务存活'],
  ['GET', '/api/teacher/profile', '教师资料'],
  ['GET', '/api/teacher/kpis', '教师端 KPI'],
  ['GET', '/api/teacher/requests', '企业需求列表'],
  ['GET', '/api/teacher/tasks', '任务阶段'],
  ['GET', '/api/teacher/students', '班级学生'],
  ['GET', '/api/teacher/questions', '学生提问'],
  ['GET', '/api/teacher/evaluations', '教学评价'],
  ['GET', '/api/teacher/library', '案例/知识库'],
  ['GET', '/api/teacher/notifications', '消息中心'],
  ['GET', '/api/company/profile', '企业资料'],
  ['GET', '/api/company/projects', '企业项目'],
  ['GET', '/api/company/requirements', '企业需求'],
  ['GET', '/api/company/candidates', '候选人池'],
  ['GET', '/api/company/acceptance', '验收单'],
  ['GET', '/api/company/artifacts', '交付物'],
  ['GET', '/api/company/templates', '模板库'],
  ['GET', '/api/company/messages', '企业消息'],
  ['GET', '/api/admin/kpis', '平台运营指标'],
  ['GET', '/api/admin/organizations', '组织'],
  ['GET', '/api/admin/users', '用户'],
  ['GET', '/api/admin/projects', '项目'],
  ['GET', '/api/admin/approvals', '审批'],
  ['GET', '/api/admin/resources', '资源'],
  ['GET', '/api/admin/jobs', '任务队列'],
  ['GET', '/api/admin/audits', '审计日志']
];

const SKILL_APIS = [
  ['GET', '/api/skills/status', '五 Skill 状态'],
  ['GET', '/api/skills/catalog', 'Skill 目录'],
  ['GET', '/api/skills/report/profile', '报告画像'],
  ['GET', '/api/skills/multimodal/status', '多模态能力状态'],
  ['GET', '/api/skills/training/systems', '两套实训系统']
];

async function probe(method, base, url, label) {
  const started = Date.now();
  try {
    const res = await fetch(base + url, { method, headers: { Accept: 'application/json' } });
    const text = await res.text();
    let json = null;
    try { json = JSON.parse(text); } catch (e) { /* 非 JSON（静态页/HTML） */ }
    const data = json && json.data !== undefined ? json.data : json;
    const count = Array.isArray(data) ? data.length : (data && typeof data === 'object' ? Object.keys(data).length : (data === null || data === undefined ? 0 : 1));
    return {
      label, url, status: res.status, ms: Date.now() - started, count,
      ok: res.ok,
      message: json && json.message ? json.message : '',
      sampleKeys: Array.isArray(data) ? (data[0] ? Object.keys(data[0]).slice(0, 6) : []) : (data && typeof data === 'object' ? Object.keys(data).slice(0, 8) : [])
    };
  } catch (e) {
    return { label, url, status: 0, ms: Date.now() - started, count: 0, ok: false, message: e.message, sampleKeys: [] };
  }
}

(async () => {
  const withPing = process.argv.includes('--ping');
  const report = { at: new Date().toISOString(), api: API, skill: SKILL, read: [], skill_probe: [], model_ping: null };

  console.log('== 只读接口摸底 ==');
  for (const [m, u, label] of READ_APIS) {
    const r = await probe(m, API, u, label);
    report.read.push(r);
    console.log(`${r.ok ? 'OK  ' : 'FAIL'} ${String(r.status).padEnd(4)} ${String(r.count).padStart(3)} 条  ${String(r.ms).padStart(5)}ms  ${label}  ${u}${r.message ? '  ' + r.message : ''}`);
  }

  console.log('\n== Skill 服务摸底 ==');
  for (const [m, u, label] of SKILL_APIS) {
    const r = await probe(m, SKILL, u, label);
    report.skill_probe.push(r);
    console.log(`${r.ok ? 'OK  ' : 'FAIL'} ${String(r.status).padEnd(4)} ${String(r.ms).padStart(5)}ms  ${label}  ${u}`);
  }

  if (withPing) {
    console.log('\n== 模型自检（消耗少量 token）==');
    const r = await probe('GET', SKILL, '/api/skills/model/ping', '模型连通性');
    report.model_ping = r;
    console.log(`${r.ok ? 'OK  ' : 'FAIL'} ${String(r.status).padEnd(4)} ${String(r.ms).padStart(5)}ms  ${JSON.stringify(r.sampleKeys)}`);
  }

  const empty = report.read.filter(r => r.ok && r.count === 0);
  const broken = [...report.read, ...report.skill_probe].filter(r => !r.ok);
  report.summary = {
    read_total: report.read.length,
    read_ok: report.read.filter(r => r.ok).length,
    empty_pages: empty.map(r => r.label),
    broken: broken.map(r => r.label + ' ' + r.url)
  };
  console.log('\n== 汇总 ==');
  console.log(`可读通 ${report.summary.read_ok}/${report.summary.read_total}`);
  console.log(`录屏会「没内容」的接口：${empty.map(r => r.label).join('、') || '无'}`);
  console.log(`不可用的                    ：${report.summary.broken.join('；') || '无'}`);

  const dir = path.join(ROOT, 'reports');
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const out = path.join(dir, 'record-precheck-' + new Date().toISOString().replace(/[:.]/g, '-') + '.json');
  fs.writeFileSync(out, JSON.stringify(report, null, 2));
  console.log('\n报告：' + out);
})();
