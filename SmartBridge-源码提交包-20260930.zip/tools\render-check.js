/* ==========================================================================
   render-check.js —— 真浏览器渲染断言（无头 Edge）
   --------------------------------------------------------------------------
   仿真脚本只能证明「接口通」，不能证明「页面把接入位画出来了」。这里用系统 Edge
   无头打开四端页面，等 JS 跑完后 dump DOM，断言每个 [data-cap] 都被渲染成结果卡
   （shell.js 渲染完成会打上 data-cap-done 标记），并统计 live / simulated 数量。

   运行： node tools/render-check.js
   ========================================================================== */
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const EDGE = process.env.EDGE_PATH || 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const BASE = process.env.PLATFORM_BASE || 'http://127.0.0.1:8080';
const profileRoot = process.env.TEMP ? path.join(process.env.TEMP, 'sb-edge-profiles') : path.join(require('os').tmpdir(), 'sb-edge-profiles');

const PAGES = [
  { pf: '教师端', url: '/teacher/review.html', expect: ['A1', 'D2'] },
  { pf: '教师端', url: '/teacher/evaluation.html', expect: ['A3', 'C2', 'D3'] },
  { pf: '教师端', url: '/teacher/students.html', expect: ['B2', 'B3', 'E2'] },
  { pf: '教师端', url: '/teacher/index.html', expect: ['E1'] },
  { pf: '企业端', url: '/company/acceptance.html', expect: ['A3', 'C2', 'D2'] },
  { pf: '企业端', url: '/company/demand.html', expect: ['C1', 'A1', 'C3'] },
  { pf: '学生端', url: '/student/tasks.html', expect: ['B1', 'A1', 'B2'] },
  { pf: '学生端', url: '/student/task.html', expect: ['A2', 'C1', 'D1'] }
];

function render(url) {
  const profile = path.join(profileRoot, 'p' + Math.abs(url.length * 7919) % 99991);
  const args = [
    '--headless=new', '--disable-gpu', '--no-first-run', '--disable-extensions',
    '--disable-features=Translate,BackForwardCache', '--run-all-compositor-stages-before-draw',
    '--virtual-time-budget=8000', '--user-data-dir=' + profile, '--window-size=1440,2000',
    '--dump-dom', url
  ];
  const result = spawnSync(EDGE, args, { encoding: 'utf8', maxBuffer: 64 * 1024 * 1024, timeout: 90000 });
  return String(result.stdout || '');
}

let pass = 0, fail = 0;
for (const page of PAGES) {
  const url = BASE + page.url;
  const dom = render(url);
  if (!dom) { console.log(`✗ ${page.pf} ${page.url} —— 未取到 DOM`); fail++; continue; }
  const caps = [...dom.matchAll(/data-cap="([^"]+)"[^>]*data-cap-done="([^"]*)"/g)].map(m => ({ id: m[1], mode: m[2] }));
  const declared = [...dom.matchAll(/data-cap="([^"]+)"/g)].map(m => m[1]);
  const doneIds = caps.map(c => c.id);
  const live = caps.filter(c => c.mode === 'live').length;
  const sim = caps.filter(c => c.mode === 'simulated').length;
  const none = caps.filter(c => !c.mode || c.mode === 'none').length;
  const missing = page.expect.filter(id => !doneIds.includes(id));
  const ok = caps.length >= page.expect.length && missing.length === 0 && none === 0;
  console.log(`${ok ? '✓' : '✗'} ${page.pf} ${page.url}  声明接入位 ${declared.length} 个 · 已渲染 ${caps.length} 个（live ${live} / simulated ${sim} / 未接入 ${none}）`);
  if (!ok) { console.log(`     期望渲染：${page.expect.join('、')}｜实际：${doneIds.join('、') || '无'}${missing.length ? '｜缺失：' + missing.join('、') : ''}`); fail++; }
  else pass++;
}
console.log(`\n页面渲染断言：通过 ${pass} / ${PAGES.length}`);
