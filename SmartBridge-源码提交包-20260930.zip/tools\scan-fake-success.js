'use strict';
/* 扫描后端所有写路由：凡是 UPDATE / INSERT...SELECT 之后既没判 affectedRows、
   也没做事前存在性 SELECT 的，就是「假成功」嫌疑点（改 0 行仍返回 200）。 */
const fs = require('fs');
const path = require('path');

const SRC_DIR = path.join(__dirname, '..', 'services/api/src');
const serverPath = path.join(SRC_DIR, process.argv[2] || 'server.js');
const src = fs.readFileSync(serverPath, 'utf8');
const fileTag = process.argv[2] || 'server.js';
const lines = src.split(/\r?\n/);

// 以 app.<method>(' 开头的路由起点
const starts = [];
lines.forEach((line, i) => {
  const m = line.match(/\bapp\.(get|post|put|patch|delete)\('([^']+)'/);
  if (m) starts.push({ i, method: m[1], route: m[2] });
});

const suspicious = [];
const safe = [];

starts.forEach((s, idx) => {
  const end = idx + 1 < starts.length ? starts[idx + 1].i : lines.length;
  const body = lines.slice(s.i, end).join('\n');
  if (!/^(post|put|patch|delete)$/.test(s.method)) return;
  const hasUpdate = /\bUPDATE\b/i.test(body);
  const hasInsertSelect = /INSERT\b[\s\S]*?\bSELECT\b/i.test(body);
  if (!hasUpdate && !hasInsertSelect) return;
  const hasAffected = /affectedRows/.test(body);
  // 事前存在性校验：SELECT ... LIMIT 1 且后面跟着 if (!xxx) return fail(4xx)
  const hasPreCheck = /if\s*\(\s*!\s*\w[\w?.]*\s*\)\s*return\s+fail\(\s*res\s*,\s*4\d\d/.test(body)
    || /throw Object\.assign\(new Error\([^)]*\),\s*\{\s*status:\s*4\d\d/.test(body);
  const record = { line: s.i + 1, method: s.method.toUpperCase(), route: s.route, hasUpdate, hasInsertSelect, hasAffected, hasPreCheck };
  (hasAffected || hasPreCheck ? safe : suspicious).push(record);
});

const render = list => list.map(r => `${fileTag}:${String(r.line).padStart(5)}  ${r.method.padEnd(6)} ${r.route}`).join('\n');
console.log(`== 嫌疑「假成功」路由 ${suspicious.length} 条 ==\n${render(suspicious) || '(无)'}`);
console.log(`\n== 已有命中/存在性校验 ${safe.length} 条 ==\n${render(safe) || '(无)'}`);
console.log(`\n== 写路由合计 ${suspicious.length + safe.length} 条 ==`);
