/* ==========================================================================
   smoke-all.js —— 四端全量页面冒烟（36 页）
   --------------------------------------------------------------------------
   逐页用无头 Edge 渲染，去掉 <script>/<style> 后只检查「用户可见文本」里的
   破损标记；同时统计 DOM 体积（识别空白页）并捕获控制台 ERROR。
   运行： node tools/smoke-all.js
   ========================================================================== */
const { spawnSync } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

const EDGE = process.env.EDGE_PATH || 'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe';
const BASE = process.env.PLATFORM_BASE || 'http://127.0.0.1:8080';
const profileRoot = path.join(os.tmpdir(), 'sb-smoke-profiles');

const PAGES = [
  ['教师端', '/teacher/index.html'], ['教师端', '/teacher/project.html'], ['教师端', '/teacher/tasks.html'],
  ['教师端', '/teacher/students.html'], ['教师端', '/teacher/evaluation.html'], ['教师端', '/teacher/review.html'],
  ['教师端', '/teacher/library.html'], ['教师端', '/teacher/qa.html'], ['教师端', '/teacher/settings.html'],
  ['企业端', '/company/index.html'], ['企业端', '/company/demand.html'], ['企业端', '/company/project.html'],
  ['企业端', '/company/acceptance.html'], ['企业端', '/company/artifacts.html'], ['企业端', '/company/talent.html'],
  ['企业端', '/company/report.html'], ['企业端', '/company/templates.html'], ['企业端', '/company/messages.html'],
  ['企业端', '/company/settings.html'],
  ['学生端', '/student/index.html'], ['学生端', '/student/tasks.html'], ['学生端', '/student/task.html'],
  ['学生端', '/student/learning.html'], ['学生端', '/student/report.html'], ['学生端', '/student/inagent.html'],
  ['学生端', '/student/company.html'], ['学生端', '/student/settings.html'],
  ['平台端', '/admin/index.html'], ['平台端', '/admin/organizations.html'], ['平台端', '/admin/projects.html'],
  ['平台端', '/admin/resources.html'], ['平台端', '/admin/operations.html'], ['平台端', '/admin/data.html'],
  ['平台端', '/admin/privacy.html'], ['平台端', '/admin/settings.html'],
  ['统一登录', '/login/index.html'],
];

const MARKERS = [
  '接口不存在或尚未接入', 'API_NOT_FOUND',
  'Skill 服务不可用', 'SKILL_SERVICE_UNAVAILABLE', 'SKILL_NOT_REGISTERED',
  '调用失败', '加载失败', '请求失败', '获取失败', '读取失败', '保存失败', '提交失败',
  'not_connected', '未接入平台能力',
  '[object Object]',
  'undefined</', '>undefined', 'NaN</', '>NaN',
  'Cannot read', 'is not a function', 'is not defined',
  'HTTP 404', 'HTTP 500', 'HTTP 502',
];

function render(url) {
  const profile = path.join(profileRoot, 'p' + (Math.abs([...url].reduce((a, c) => a + c.charCodeAt(0), 0)) % 99991));
  const args = [
    '--headless', '--disable-gpu', '--disable-software-rasterizer', '--disable-gpu-compositing',
    '--no-sandbox', '--no-first-run', '--disable-extensions',
    '--disable-features=Translate,BackForwardCache', '--run-all-compositor-stages-before-draw',
    '--virtual-time-budget=8000', '--user-data-dir=' + profile, '--window-size=1440,2200',
    '--enable-logging=stderr', '--log-level=1',
    '--dump-dom', url,
  ];
  const r = spawnSync(EDGE, args, { encoding: 'utf8', maxBuffer: 96 * 1024 * 1024, timeout: 120000 });
  return { dom: String(r.stdout || ''), err: String(r.stderr || '') };
}

function visibleText(dom) {
  return dom
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ');
}

const out = [];
let pass = 0, fail = 0, blank = 0;
const problems = [];

for (const [pf, url] of PAGES) {
  const full = BASE + url;
  const { dom, err } = render(full);
  if (!dom) { out.push(`[✗] ${pf} ${url}  未取到 DOM`); fail++; problems.push({ pf, url, kind: 'no-dom' }); continue; }

  const text = visibleText(dom);
  const hits = MARKERS.filter(m => text.includes(m));
  /* 只保留「页面自身」的 JS 报错；Edge 自带的网络同步 / 导入器 / 任务管理器噪声一律忽略 */
  const conErr = (err.match(/ERROR:[^\n]*/g) || [])
    .map(s => s.replace(/\s+/g, ' ').trim())
    .filter(s => /CONSOLE|Uncaught|TypeError|ReferenceError|SyntaxError|net::ERR/i.test(s))
    .filter(s => !/favicon|DevTools|QQBrowser|task_manager|sync\\|edge_china_browsers|importer|get_updates_processor|fallback_task_provider/i.test(s));

  const isBlank = text.replace(/[\s\u00a0]/g, '').length < 120;
  const ok = hits.length === 0 && conErr.length === 0 && !isBlank;
  if (isBlank) blank++;
  if (ok) pass++; else { fail++; problems.push({ pf, url, hits, conErr, isBlank, len: text.length }); }

  out.push(`${ok ? '✓' : '✗'} ${pf} ${url}  DOM ${(dom.length / 1024).toFixed(0)}KB · 可见文本 ${text.length} 字` +
    (hits.length ? `\n      破损标记: ${hits.join(' | ')}` : '') +
    (conErr.length ? `\n      控制台: ${conErr.slice(0, 3).join(' ; ')}` : '') +
    (isBlank ? '\n      ⚠ 疑似空白页' : ''));
}

out.push('');
out.push(`===== 汇总：通过 ${pass} / ${PAGES.length}　失败 ${fail}　空白页 ${blank} =====`);
const reportDir = path.join(__dirname, '..', 'reports', 'verification');
fs.mkdirSync(reportDir, { recursive: true });
fs.writeFileSync(path.join(reportDir, 'page-smoke.txt'), out.join('\r\n'), 'utf8');
fs.writeFileSync(path.join(reportDir, 'page-smoke-problems.json'), JSON.stringify(problems, null, 2), 'utf8');
console.log(out.join('\n'));
