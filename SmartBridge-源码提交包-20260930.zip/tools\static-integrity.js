/* ==========================================================================
   static-integrity.js —— 四端页面静态完整性检查
   --------------------------------------------------------------------------
   1) 本地 href/src 引用的文件是否真实存在（死链）
   2) 外链数量（本地交付应为 0）
   3) inline onclick/onchange 调用的全局函数是否在同页 <script> 或已加载 js 中定义
   4) 每个页面 body 是否有 data-page 且 shell.js 支持该页
   运行： node tools/static-integrity.js
   ========================================================================== */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const FE = ['apps/teacher', 'apps/company', 'apps/student', 'apps/admin', 'apps/login'];

function walk(dir, acc = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    if (e.name === 'node_modules') continue;
    const fp = path.join(dir, e.name);
    if (e.isDirectory()) walk(fp, acc); else acc.push(fp);
  }
  return acc;
}

const out = [];
let totalIssues = 0;
const allPages = [];

for (const rel of FE) {
  const dir = path.join(ROOT, rel);
  if (!fs.existsSync(dir)) { out.push(`!! 目录不存在: ${rel}`); continue; }
  const pages = walk(dir).filter(f => /\.html$/i.test(f));
  for (const page of pages) {
    allPages.push(page);
    const html = fs.readFileSync(page, 'utf8');
    const issues = [];
    const relPage = path.relative(ROOT, page);

    // ---- 1. 本地引用存在性 ----
    const refs = [...html.matchAll(/(?:href|src)\s*=\s*["']([^"']+)["']/gi)].map(m => m[1]);
    let externals = 0;
    for (const r of refs) {
      if (/^(?:https?:)?\/\//i.test(r) || /^data:/i.test(r) || /^mailto:|^tel:|^javascript:/i.test(r)) { if (/^https?:/i.test(r) || /^\/\//.test(r)) externals++; continue; }
      if (r.startsWith('#')) continue;
      const clean = r.split('?')[0].split('#')[0];
      const target = clean.startsWith('/shared/')
        ? path.join(ROOT, 'apps', clean.slice(1))
        : path.resolve(path.dirname(page), clean);
      if (!fs.existsSync(target)) issues.push(`死链: ${r}`);
    }
    if (externals > 0) issues.push(`外链 ${externals} 处`);

    // ---- 2. inline 事件处理函数是否存在 ----
    const inlineCalls = [...html.matchAll(/\bon(?:click|change|input|submit)\s*=\s*["']([^"']+)["']/gi)]
      .map(m => m[1]).join('; ');
    const fnNames = [...inlineCalls.matchAll(/([A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)*)\s*\(/g)]
      .map(m => m[1]).filter(n => !/^(?:this|window|document|console|JSON|Math|Object|Array|String|Number|Boolean|Date|Promise|alert|confirm|encodeURIComponent|decodeURIComponent|parseInt|parseFloat|setTimeout|clearTimeout|if|for|while|return|function|typeof|new)$/.test(n));

    // 收集本页可用的全局定义：inline script + 已加载的本地 js
    const localJs = refs.filter(r => /\.js$/i.test(r) && !/^https?:/i.test(r))
      .map(r => path.resolve(path.dirname(page), r.split('?')[0]));
    let jsSource = '';
    for (const jp of localJs) if (fs.existsSync(jp)) jsSource += fs.readFileSync(jp, 'utf8');
    const inlineScripts = [...html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/gi)].map(m => m[1]).join('\n');
    jsSource += inlineScripts;

    for (const fn of new Set(fnNames)) {
      const root = fn.split('.')[0];
      // 定义形式：function X / X = function / X: function / var|let|const X / window.X = / class X
      const re = new RegExp(
        `(?:function\\s+${root}\\b)` +
        `|(?:\\b${root}\\s*=\\s*(?:function|\\())` +
        `|(?:\\b${root}\\s*:\\s*function)` +
        `|(?:\\b(?:var|let|const)\\s+${root}\\b)` +
        `|(?:window\\.${root}\\s*=)` +
        `|(?:class\\s+${root}\\b)`
      );
      if (!re.test(jsSource)) issues.push(`onclick 未定义函数: ${fn}`);
    }

    if (issues.length) { totalIssues += issues.length; out.push(`✗ ${relPage}`); issues.forEach(i => out.push(`      ${i}`)); }
  }
}

out.push('');
out.push(`===== 页面 ${allPages.length} 个 · 问题 ${totalIssues} 处 =====`);
const reportDir = path.join(ROOT, 'reports', 'verification');
fs.mkdirSync(reportDir, { recursive: true });
fs.writeFileSync(path.join(reportDir, 'static-integrity.txt'), out.join('\r\n'), 'utf8');
console.log(out.join('\n'));
