/* ==========================================================================
   verify-data-crud.js —— 平台端「数据维护」能力验证
   --------------------------------------------------------------------------
   覆盖：导出 → 新增 → 修改 → 导出核对 → 批量导入（CSV 与 JSON 两种） → 删除 → 审计留痕
   运行： node tools/verify-data-crud.js
   ========================================================================== */
const fs = require('fs');
const path = require('path');
const BASE = process.env.PLATFORM_BASE || 'http://127.0.0.1:8080';
const out = [];
let pass = 0, fail = 0;
function rec(ok, t, d) { if (ok) pass++; else fail++; out.push(`${ok ? '✓' : '✗'} ${t}${d ? '\n      ' + d : ''}`); }
async function jp(res) { const t = await res.text(); try { return JSON.parse(t); } catch { return { _raw: t }; } }

(async () => {
  /* 数据要求：先确认数据集总览 */
  let datasets = [];
  try {
    const res = await fetch(BASE + '/api/data/datasets');
    const b = await jp(res);
    datasets = b.data || [];
    const writable = datasets.filter(d => d.editable).length;
    rec(res.ok && datasets.length > 0,
      '① 数据集总览（GET /api/data/datasets）',
      `HTTP ${res.status}｜${datasets.length} 个数据集（可写 ${writable} 个）｜示例：${datasets.slice(0, 4).map(d => `${d.label}(${d.rows})`).join(', ')}`);
  } catch (e) { rec(false, '① 数据集总览', 'EXCEPTION ' + e.message); }

  /* 选一个可写数据集做往返：notifications（通知） */
  const DS = 'notifications';
  const meta = datasets.find(d => d.name === DS);
  out.push(`\n  —— 往返数据集：${DS}（${meta ? meta.label + '，字段 ' + (meta.fields || []).join('/') : '未在总览中'}）`);

  let newId = null;
  /* 新增 */
  try {
    const payload = { user_id: 'user-student-chen', title: '本地验证-数据维护往返', body: '由 verify-data-crud.js 创建', level: 'info', href: '' };
    const res = await fetch(`${BASE}/api/data/${DS}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const b = await jp(res);
    newId = b.data?.id;
    rec(res.status === 201 && !!newId, '② 新增一行（POST /api/data/:dataset）', `HTTP ${res.status}｜id=${newId}｜title=${b.data?.title}`);
  } catch (e) { rec(false, '② 新增一行', 'EXCEPTION ' + e.message); }

  /* 导出并核对能读到 */
  try {
    const res = await fetch(`${BASE}/api/export/${DS}?limit=200`);
    const b = await jp(res);
    const found = (b.data?.rows || []).find(r => r.id === newId);
    rec(res.ok && !!found, '③ 导出核对（新行已可导出）', `HTTP ${res.status}｜命中=${!!found}｜总 ${b.data?.count} 行`);
  } catch (e) { rec(false, '③ 导出核对', 'EXCEPTION ' + e.message); }

  /* 修改 */
  try {
    const res = await fetch(`${BASE}/api/data/${DS}/${encodeURIComponent(newId)}`, {
      method: 'PUT', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: '本地验证-已修改', level: 'warning' }),
    });
    const b = await jp(res);
    rec(res.ok && b.data?.title === '本地验证-已修改', '④ 修改一行（PUT /api/data/:dataset/:id）', `HTTP ${res.status}｜title=${b.data?.title}｜level=${b.data?.level}`);
  } catch (e) { rec(false, '④ 修改一行', 'EXCEPTION ' + e.message); }

  /* 批量导入 JSON */
  try {
    const rows = [
      { user_id: 'user-student-chen', title: '本地验证-导入A', body: 'JSON 导入', level: 'info' },
      { user_id: 'user-student-chen', title: '本地验证-导入B', body: 'JSON 导入', level: 'info' },
    ];
    const res = await fetch(`${BASE}/api/import/${DS}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ rows }) });
    const b = await jp(res);
    rec((res.ok || res.status === 201) && (b.data?.created || 0) >= 2, '⑤ 批量导入 JSON（POST /api/import/:dataset）', `HTTP ${res.status}｜成功 ${b.data?.created} 条｜失败 ${b.data?.failed || 0} 条`);
  } catch (e) { rec(false, '⑤ 批量导入 JSON', 'EXCEPTION ' + e.message); }

  /* 批量导入 CSV */
  try {
    const csv = 'user_id,title,body,level\nuser-student-chen,本地验证-导入C,CSV 导入,info\n';
    const res = await fetch(`${BASE}/api/import/${DS}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ csv }) });
    const b = await jp(res);
    rec(res.ok && (b.data?.created || 0) >= 1, '⑥ 批量导入 CSV', `HTTP ${res.status}｜成功 ${b.data?.created} 条｜失败 ${b.data?.failed || 0} 条`);
  } catch (e) { rec(false, '⑥ 批量导入 CSV', 'EXCEPTION ' + e.message); }

  /* 清理：删掉本次创建的行 */
  try {
    const res = await fetch(`${BASE}/api/export/${DS}?limit=500`);
    const b = await jp(res);
    const mine = (b.data?.rows || []).filter(r => String(r.title || '').startsWith('本地验证'));
    let del = 0;
    for (const r of mine) {
      const d = await fetch(`${BASE}/api/data/${DS}/${encodeURIComponent(r.id)}`, { method: 'DELETE' });
      if (d.ok) del++;
    }
    rec(del === mine.length && mine.length > 0, '⑦ 删除清理（DELETE /api/data/:dataset/:id）', `清理 ${del}/${mine.length} 条本次验证数据`);
  } catch (e) { rec(false, '⑦ 删除清理', 'EXCEPTION ' + e.message); }

  /* 审计留痕 */
  try {
    const res = await fetch(BASE + '/api/admin/audits');
    const b = await jp(res);
    const rows = b.data || [];
    const mine = rows.filter(r => /附件|通知|导入|删除|新增/.test(r.action || ''));
    rec(res.ok && mine.length > 0, '⑧ 审计留痕（操作已记录）', `HTTP ${res.status}｜命中 ${mine.length} 条｜示例：${mine.slice(0, 3).map(m => m.action).join(' / ')}`);
  } catch (e) { rec(false, '⑧ 审计留痕', 'EXCEPTION ' + e.message); }

  out.push('');
  out.push(`===== 数据维护能力：通过 ${pass} / ${pass + fail} =====`);
  const reportDir = path.join(__dirname, '..', 'reports', 'verification');
  fs.mkdirSync(reportDir, { recursive: true });
  fs.writeFileSync(path.join(reportDir, 'database-crud.txt'), out.join('\r\n'), 'utf8');
  console.log(out.join('\n'));
})();
