'use strict';
/* 用真实 Skill 服务解析桌面的演示素材，确认「演示时面板到底会出现什么」。
   这一步是必需的：素材是自己造的，必须证明系统真的能解析出承诺的那种结果。
   用法：node tools/verify-demo-files.js */
const fs = require('fs');
const path = require('path');

const DIR = 'C:/Users/THUNDER/Desktop/演示素材';
const BASE = process.env.SMARTBRIDGE_SKILL_BASE || 'http://127.0.0.1:8090';

const FILES = [
  '01_设备点检台账_2026-09.xlsx',
  '02_点检异常记录_20260922.csv',
  '03_交接班记录_2026W38.tsv',
  '04_温度传感器读数.json',
  '05_设备点检作业指导.txt',
  '06_周报口径说明.md',
  '07_异常申诉与复核.docx'
  // 不放 PDF：图片版 PDF 无文本层，解析出来只有 0 行 0 字段，演示会减分
];

(async () => {
  const form = new FormData();
  let existed = 0;
  for (const name of FILES) {
    const p = path.join(DIR, name);
    if (!fs.existsSync(p)) { console.log('缺少文件：' + name); continue; }
    existed++;
    form.append('files', new Blob([fs.readFileSync(p)], { type: 'application/octet-stream' }), name);
  }
  form.append('purpose', '演示素材：设备点检台账与异常记录批量解析');

  console.log(`上传 ${existed}/${FILES.length} 个文件 → ${BASE}/api/skills/parse-batch`);
  const started = Date.now();
  const res = await fetch(BASE + '/api/skills/parse-batch', { method: 'POST', body: form });
  const json = await res.json().catch(() => null);
  console.log(`HTTP ${res.status}　耗时 ${((Date.now() - started) / 1000).toFixed(1)}s`);
  if (!res.ok) { console.log('返回：' + JSON.stringify(json).slice(0, 800)); return; }

  const data = json && json.data ? json.data : json;
  const out = data.output || {};
  console.log('\n== 解析总览 ==');
  console.log('模式：' + data.mode + '　成功：' + out.succeeded + '/' + out.total + '　失败：' + out.failed + '　总行数：' + out.rows);
  console.log('output 字段：' + JSON.stringify(Object.keys(out)));
  console.log('字段清单：' + JSON.stringify(out.fields));
  if (data.error) console.log('错误：' + JSON.stringify(data.error));
  const meta = data.meta || {};
  console.log('元信息：' + JSON.stringify(meta).slice(0, 300));

  console.log('\n== 逐文件结果 ==');
  (out.files || []).forEach(f => {
    console.log(`  ${String(f.name).padEnd(28)} 类型:${f.type}  行数:${f.rows}  字段${(f.fields || []).length}个  ${f.parse_error ? '失败:' + f.parse_error : ''}`);
  });

  console.log('\n== 数据质量问题（镜头要停留的地方）==');
  /* 不同版本字段名不同，这里把所有像「质量/缺失/重复/异常」的字段都翻出来 */
  const candidates = Object.keys(out).filter(k => /miss|dupl|anom|issue|quality|异常|缺失|重复/i.test(k));
  let found = 0;
  candidates.forEach(k => {
    const v = out[k];
    const arr = Array.isArray(v) ? v : [v];
    arr.forEach(item => { found++; console.log(`  [${k}] ` + JSON.stringify(item).slice(0, 220)); });
  });
  if (!found) console.log('  （output 层未出现质量类字段，逐份文件再看）');
  (out.files || []).forEach(f => {
    Object.keys(f).filter(k => /miss|dupl|anom|issue|quality|异常|缺失|重复/i.test(k)).forEach(k => {
      console.log(`  ${f.name} [${k}] ` + JSON.stringify(f[k]).slice(0, 200));
    });
  });

  console.log('\n== 证据链 ==');
  (data.evidence || []).slice(0, 6).forEach(e => console.log('  ' + JSON.stringify(e).slice(0, 200)));

  console.log('\n== 模型给出的结论 ==');
  const summary = out.batch_summary || out.summary || out.insights || out.model_summary;
  console.log(typeof summary === 'string' ? summary.slice(0, 600) : JSON.stringify(summary).slice(0, 600));
})().catch(e => console.log('调用失败：' + e.message));
