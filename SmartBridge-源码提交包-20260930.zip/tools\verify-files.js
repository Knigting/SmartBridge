/* ==========================================================================
   verify-files.js —— 文件类功能专项验证
   --------------------------------------------------------------------------
   覆盖：① 业务附件上传（/api/files，中文名 + 多格式）
         ② 上传即解析（/api/skills/parse-batch）
         ③ 上传即识别（/api/skills/multimodal/recognize）
         ④ 数据导出 CSV（校验 BOM / Content-Disposition / 可解析）
         ⑤ 数据导出 JSON
         ⑥ CSV 导入落库（round-trip）
         ⑦ 报告生成 → 下载 HTML
   运行： node tools/verify-files.js
   ========================================================================== */
const fs = require('fs');
const path = require('path');

const BASE = process.env.PLATFORM_BASE || 'http://127.0.0.1:8080';
const ROOT = path.join(__dirname, '..');
const SAMPLES = path.join(ROOT, 'services', 'skill-service', 'samples');
const MEDIA = path.join(SAMPLES, 'media');
const out = [];
let pass = 0, fail = 0;

function rec(ok, title, detail) {
  if (ok) pass++; else fail++;
  out.push(`${ok ? '✓' : '✗'} ${title}${detail ? '\n      ' + detail : ''}`);
}
async function j(res) { const t = await res.text(); try { return JSON.parse(t); } catch { return { _raw: t }; } }

const MIME = { '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', '.pdf': 'application/pdf', '.py': 'text/x-python', '.md': 'text/markdown', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.wav': 'audio/wav' };
const mimeOf = n => MIME[(n.match(/\.[A-Za-z0-9]+$/) || [''])[0].toLowerCase()] || 'application/octet-stream';

(async () => {
  /* ---------- ① 业务附件上传 ---------- */
  let uploaded = [];
  try {
    const picks = ['equipment-inspection-requirements.docx', 'inspection-sample-last-4-weeks.xlsx', 'equipment-inspection-work-instructions.pdf', 'rule_check.py']
      .map(n => path.join(SAMPLES, n)).filter(fs.existsSync);
    const media = ['on-site-inspection-sheet-line-3.jpg', 'frontline-supervisor-voice-notes.wav'].map(n => path.join(MEDIA, n)).filter(fs.existsSync);
    const form = new FormData();
    form.append('purpose', '本地功能验证-业务附件');
    for (const f of [...picks, ...media]) {
      const buf = fs.readFileSync(f);
      form.append('files', new Blob([buf], { type: mimeOf(f) }), path.basename(f));
    }
    const res = await fetch(BASE + '/api/files', { method: 'POST', body: form });
    const body = await j(res);
    const saved = body.data || [];
    uploaded = saved;
    const allHash = saved.length > 0 && saved.every(x => /^[0-9a-f]{64}$/.test(x.sha256 || ''));
    const expectedNames = [...picks, ...media].map(file => path.basename(file));
    const namesOk = expectedNames.every(name => saved.some(x => x.name === name));
    rec(res.status === 201 && allHash && namesOk,
      `① 业务附件上传（${saved.length} 个文件）`,
      `HTTP ${res.status}｜原始文件名保留=${namesOk}｜sha256 齐备=${allHash}｜示例：${saved.map(s => `${s.name}(${s.size}B)`).slice(0, 3).join(', ')}`);
    if (saved.length) {
      const dir = path.join(ROOT, 'services', 'api', 'uploads');
      const disk = fs.existsSync(dir) ? fs.readdirSync(dir) : [];
      rec(disk.length > 0, '①b 上传文件已落盘', `services/api/uploads/ 文件数=${disk.length}`);
    }
  } catch (e) { rec(false, '① 业务附件上传', 'EXCEPTION ' + e.message); }

  /* ---------- ①c 附件列表 / ①d 附件下载 ---------- */
  try {
    const res = await fetch(BASE + '/api/files');
    const body = await j(res);
    const list = body.data || [];
    rec(res.ok && Array.isArray(list) && list.length > 0,
      '①c 附件列表（GET /api/files）',
      `HTTP ${res.status}｜${list.length} 条｜首条=${list[0]?.name}（${list[0]?.size_bytes}B, ${list[0]?.mime_type}）`);
  } catch (e) { rec(false, '①c 附件列表', 'EXCEPTION ' + e.message); }

  try {
    const id = uploaded[0]?.id;
    if (!id) throw new Error('无可用附件 id（上一步未成功）');
    const res = await fetch(`${BASE}/api/files/${encodeURIComponent(id)}`);
    const buf = Buffer.from(await res.arrayBuffer());
    const cd = res.headers.get('content-disposition') || '';
    const sha = res.headers.get('x-content-sha256') || '';
    const shaOk = sha && sha === uploaded[0].sha256;
    rec(res.ok && buf.length > 0 && shaOk,
      '①d 附件下载（GET /api/files/:id）',
      `HTTP ${res.status}｜${(buf.length / 1024).toFixed(1)}KB｜Content-Disposition=${decodeURIComponent(cd).slice(0, 70)}｜sha256 一致=${shaOk}`);
  } catch (e) { rec(false, '①d 附件下载', 'EXCEPTION ' + e.message); }

  /* ---------- ② 上传即解析 ---------- */
  try {
    const names = ['inspection-sample-last-4-weeks.xlsx', 'equipment-inspection-requirements.docx', 'rule_check.py', 'pending-review-unit-mismatch.md'];
    const form = new FormData();
    form.append('purpose', '本地功能验证-批量解析');
    for (const n of names) {
      const f = path.join(SAMPLES, n); if (!fs.existsSync(f)) continue;
      form.append('files', new Blob([fs.readFileSync(f)], { type: mimeOf(n) }), n);
    }
    const res = await fetch(BASE + '/api/skills/parse-batch', { method: 'POST', body: form });
    const body = await j(res);
    const d = body.data || {};
    const o = d.output || {};
    const parsed = o.files || o.results || [];
    rec(res.ok && parsed.length >= 3,
      `② 上传即解析（parse-batch）`,
      `HTTP ${res.status}｜解析 ${parsed.length} 个｜异常 ${(o.anomalies || []).length} 项｜mode=${d.mode || o.mode || '-'}`);
  } catch (e) { rec(false, '② 上传即解析（parse-batch）', 'EXCEPTION ' + e.message); }

  /* ---------- ③ 上传即识别（多模态） ---------- */
  try {
    const img = path.join(MEDIA, 'on-site-inspection-sheet-line-3.jpg');
    if (!fs.existsSync(img)) throw new Error('样例图片不存在');
    const form = new FormData();
    form.append('kind', 'image');
    form.append('purpose', '本地功能验证-图片识别');
    form.append('file', new Blob([fs.readFileSync(img)], { type: mimeOf(img) }), path.basename(img));
    const res = await fetch(BASE + '/api/skills/multimodal/recognize', { method: 'POST', body: form });
    const body = await j(res);
    const d = body.data || {};
    const o = d.output || {};
    const txt = o.text || o.summary || o.transcript || '';
    rec(res.ok && String(txt).length > 0,
      '③ 上传即识别（multimodal 图片）',
      `HTTP ${res.status}｜mode=${d.mode || '-'}｜置信度=${o.confidence ?? '-'}｜识别文本 ${String(txt).length} 字：${String(txt).slice(0, 60)}…`);
  } catch (e) { rec(false, '③ 上传即识别（multimodal）', 'EXCEPTION ' + e.message); }

  /* ---------- ④ 导出 CSV ---------- */
  try {
    const res = await fetch(BASE + '/api/export/organizations?format=csv');
    const buf = Buffer.from(await res.arrayBuffer());
    const hasBOM = buf[0] === 0xEF && buf[1] === 0xBB && buf[2] === 0xBF;
    const txt = buf.toString('utf8');
    const lines = txt.replace(/^\uFEFF/, '').trim().split(/\r?\n/);
    const cd = res.headers.get('content-disposition') || '';
    rec(res.ok && hasBOM && lines.length > 1 && /attachment/.test(cd),
      '④ 导出 CSV（含 BOM / 下载头 / 可解析）',
      `HTTP ${res.status}｜BOM=${hasBOM}｜${lines.length} 行（表头+${lines.length - 1} 条）｜Content-Disposition=${cd.slice(0, 80)}`);
  } catch (e) { rec(false, '④ 导出 CSV', 'EXCEPTION ' + e.message); }

  /* ---------- ⑤ 导出 JSON ---------- */
  try {
    const res = await fetch(BASE + '/api/export/projects');
    const body = await j(res);
    const d = body.data || {};
    rec(res.ok && Array.isArray(d.rows) && d.rows.length > 0,
      '⑤ 导出 JSON', `HTTP ${res.status}｜数据集=${d.dataset}｜${d.count} 行｜首行键=${Object.keys(d.rows?.[0] || {}).slice(0, 5).join(',')}`);
  } catch (e) { rec(false, '⑤ 导出 JSON', 'EXCEPTION ' + e.message); }

  /* ---------- ⑦ 报告生成 → 下载 ---------- */
  try {
    const gen = await fetch(BASE + '/api/skills/report', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: '2026-06 运营月报（本地验证）', kind: '运营月报', data: { report_period: '2026-06' } }),
    });
    const gb = await j(gen);
    const d = gb.data || {};
    const o = d.output || {};
    const rid = o.report_id || d.report_id;
    const metrics = (o.metrics || []).length, charts = (o.charts || []).length;
    rec(gen.ok && !!rid && metrics > 0,
      '⑦a 报告生成（report Skill · 运营月报）',
      `HTTP ${gen.status}｜report_id=${rid}｜指标 ${metrics} 项｜章节 ${(o.sections || []).length} 段｜图表 ${charts} 个`);
    if (rid) {
      const dl = await fetch(`${BASE}/api/skills/reports/${encodeURIComponent(rid)}/download`);
      const html = await dl.text();
      const cd = dl.headers.get('content-disposition') || '';
      rec(dl.ok && /<html/i.test(html) && html.length > 800,
        '⑦b 报告下载（HTML 文件）',
        `HTTP ${dl.status}｜${(html.length / 1024).toFixed(1)}KB｜Content-Type=${dl.headers.get('content-type')}｜含 <html>=${/<html/i.test(html)}｜下载头=${cd.slice(0, 60)}`);
      const saveDir = path.join(ROOT, 'reports', 'verification');
      fs.mkdirSync(saveDir, { recursive: true });
      const fp = path.join(saveDir, 'file-export-report.html');
      fs.writeFileSync(fp, html, 'utf8');
      out.push(`      → 已另存：${fp}（${(fs.statSync(fp).size / 1024).toFixed(1)}KB）`);
    }
  } catch (e) { rec(false, '⑦ 报告生成/下载', 'EXCEPTION ' + e.message); }

  out.push('');
  out.push(`===== 文件类功能：通过 ${pass} / ${pass + fail} =====`);
  fs.writeFileSync(path.join(ROOT, 'reports', 'verification', 'file-verification.txt'), out.join('\r\n'), 'utf8');
  console.log(out.join('\n'));
})();
