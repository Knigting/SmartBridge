'use strict';
/* 用最小 DOM 桩加载教师端/学生端数据层，验证「后端真实报错能否透到页面」。
   核心回归点：以前所有异常被吞成 null，页面只会显示「业务服务不可用」。 */
const fs = require('fs');
const vm = require('vm');
const path = require('path');
const PROJECT_ROOT = path.join(__dirname, '..');
const APP_STORES = {
  teacher: path.join(PROJECT_ROOT, 'apps/teacher/assets/store.js'),
  student: path.join(PROJECT_ROOT, 'apps/student/assets/store.js')
};

function makeSandbox(fetchImpl) {
  const store = {};
  const sandbox = {
    console,
    setTimeout, clearTimeout, Promise, Object, Array, JSON, String, Number, Error, Date,
    AbortController,
    fetch: fetchImpl,
    localStorage: {
      getItem: k => (k in store ? store[k] : null),
      setItem: (k, v) => { store[k] = String(v); },
      removeItem: k => { delete store[k]; }
    }
  };
  sandbox.window = sandbox;
  sandbox.MOCK = { settings: {}, project_id: 'PRJ-0917-001' };
  vm.createContext(sandbox);
  return sandbox;
}

function httpResponse(status, body) {
  return Promise.resolve({
    ok: status >= 200 && status < 300,
    status,
    text: () => Promise.resolve(JSON.stringify(body)),
    json: () => Promise.resolve(body)
  });
}

(async () => {
  const src = fs.readFileSync(APP_STORES.teacher, 'utf8');
  const results = [];

  const check = async (label, status, body, action, expectContains) => {
    const sb = makeSandbox(() => httpResponse(status, body));
    vm.runInContext(src, sb, { filename: 'store.js' });
    const fn = { '归档案例': 'saveCase', '提交评价复核': 'submitEvaluation', '发布任务阶段': 'submitTaskDraft' }[action];
    let msg = '';
    try {
      await sb.Store[fn]({ title: 'x' });
      msg = '(未抛错 ← 假成功)';
    } catch (e) { msg = e.message; }
    const ok = expectContains.every(s => msg.indexOf(s) >= 0);
    results.push({ ok, label, msg });
    console.log(`${ok ? 'PASS' : 'FAIL'}  ${label}\n        ${msg}`);
  };

  await check('后端 400 参数错误 → 页面应看到原文', 400, { code: 'NAME_REQUIRED', message: '请提供归档名称（name 或 title）', data: null }, '归档案例', ['请提供归档名称', 'HTTP 400']);
  await check('后端 404 记录不存在 → 页面应看到原文', 404, { code: 'EVALUATION_NOT_FOUND', message: '未找到评价记录：abc', data: null }, '提交评价复核', ['未找到评价记录', 'HTTP 404']);
  await check('后端 500 数据库错误 → 页面应看到原文而非「业务服务不可用」', 500, { code: 'INTERNAL_ERROR', message: 'bind parameters must not contain undefined', data: null }, '发布任务阶段', ['bind parameters', 'HTTP 500']);

  const pass = results.filter(r => r.ok).length;
  console.log(`\n合计 ${pass}/${results.length} 通过`);
})().catch(e => { console.log('HARNESS ERROR', e); });
