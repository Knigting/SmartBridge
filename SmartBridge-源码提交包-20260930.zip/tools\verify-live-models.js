'use strict';

/* ==========================================================================
   verify-live-models.js —— 五个 Skill 的真实大模型端到端验证
   --------------------------------------------------------------------------
   不是测接口通不通，而是逐 Skill 断言：
     1. 返回体里带真实模型证据（request_id / model_evidence），证明确实调到了模型；
     2. 模型产出的内容落在该 Skill 该在的位置上（摘要/引用回答/报告叙述/意图解析）；
     3. 多模态如实回报能力状态（该模型服务只有纯文本，未配置视觉/转写则 not_configured）。

   用法（Skill 服务已在 127.0.0.1:8090 运行时）：
     node tools/verify-live-models.js
   环境变量：
     SKILL_BASE_URL   默认 http://127.0.0.1:8090
     SKILL_API_KEY    若服务端配置了 SKILL_API_KEY 则必须同值
   ========================================================================== */
const fs = require('fs');
const path = require('path');

const BASE = String(process.env.SKILL_BASE_URL || 'http://127.0.0.1:8090').replace(/\/+$/, '');
const API_KEY = String(process.env.SKILL_API_KEY || '');
const SAMPLES_DIR = path.resolve(__dirname, '..', 'services', 'skill-service', 'samples');

const results = [];
let failures = 0;

function record(name, ok, detail) {
  results.push({ name, ok, detail });
  if (!ok) failures += 1;
  const mark = ok ? 'PASS' : 'FAIL';
  console.log(`[${mark}] ${name}${detail ? ` — ${detail}` : ''}`);
}

function headers(extra = {}) {
  return { ...(API_KEY ? { 'X-Skill-Api-Key': API_KEY } : {}), ...extra };
}

async function httpJson(url, init = {}, timeoutMs = 180000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    const text = await response.text();
    let body = null;
    try { body = JSON.parse(text); } catch (_) { body = { parse_error: text.slice(0, 300) }; }
    return { status: response.status, body, raw: text };
  } finally {
    clearTimeout(timer);
  }
}

async function getJson(apiPath) {
  return httpJson(`${BASE}${apiPath}`, { headers: headers() });
}

async function postJson(apiPath, payload, extraHeaders = {}) {
  return httpJson(`${BASE}${apiPath}`, {
    method: 'POST',
    headers: headers({ 'Content-Type': 'application/json', ...extraHeaders }),
    body: JSON.stringify(payload || {})
  });
}

function hasModelEvidence(evidence) {
  if (!Array.isArray(evidence)) return false;
  return evidence.some(item => item && item.request_id && item.model);
}

/* ---------------------------------------------------------------- 1. 状态 */
async function checkStatus() {
  const { status, body } = await getJson('/api/skills/status');
  const model = body?.data?.model || {};
  record('status/model 状态为 live', status === 200 && model.state === 'live',
    `state=${model.state} model=${model.model} keys=${model.keys}`);
  const skills = body?.data?.skills || [];
  record('status/五个 Skill 全部列出', skills.length === 5, `count=${skills.length}`);
}

/* ------------------------------------------------------------ 2. 连通性探针 */
async function checkPing() {
  const { status, body } = await getJson('/api/skills/model/ping');
  const data = body?.data || {};
  record('model/ping 返回真实 request_id', status === 200 && !!data.request_id,
    `request_id=${data.request_id} latency=${data.latency_ms}ms`);
  record('model/ping 返回非空回答（推理模型正文未被吃光）', Boolean(String(data.reply || '').trim()),
    `reply=${JSON.stringify(String(data.reply || '').slice(0, 40))} tokens=${data.usage?.total_tokens || '?'}`);
}

/* ---------------------------------------------------- 3. 批量文件解析 + 模型摘要 */
async function checkParseBatch() {
  const { status, body } = await postJson('/api/skills/parse-batch/samples', {
    files: ['inspection-sample-last-4-weeks.xlsx', 'exception_list.xlsx'],
    purpose: '验证真实模型批量解析'
  });
  const data = body?.data?.output || {};
  const evidence = body?.data?.evidence || [];
  record('parse-batch/解析成功且文件数正确', status === 200 && (data.count || data.files?.length) >= 2,
    `files=${(data.files || []).map(f => f.name).join(',')}`);
  if (data.model_error) {
    record('parse-batch/模型摘要生成（有 model_error 即失败）', false,
      `code=${data.model_error.code} ${data.model_error.message}`);
    return;
  }
  record('parse-batch/模型 batch_summary 非空', Boolean(String(data.batch_summary || '').trim()),
    `summary=${JSON.stringify(String(data.batch_summary || '').slice(0, 50))}`);
  record('parse-batch/每份文件有模型 summary', (data.files || []).every(f => String(f.summary || '').trim().length > 0),
    (data.files || []).map(f => `${f.name}:${String(f.summary || '').slice(0, 20)}`).join(' | '));
  record('parse-batch/evidence 含模型证据', hasModelEvidence(evidence), `evidence_count=${evidence.length}`);
}

/* ------------------------------------------------------- 4. RAG 建索引 + 检索 */
async function checkRag() {
  /* 4.1 先确认/补建索引：用样例 docx 走真实 multipart 上传 */
  const candidate = path.join(SAMPLES_DIR, 'equipment-inspection-requirements.docx');
  if (fs.existsSync(candidate)) {
    const form = new FormData();
    form.append('files', new Blob([fs.readFileSync(candidate)]), 'equipment-inspection-requirements.docx');
    form.append('scope', 'project');
    const { status, body } = await httpJson(`${BASE}/api/skills/rag/index`, {
      method: 'POST',
      headers: headers(),
      body: form
    });
    const indexed = body?.data?.output?.indexed || [];
    record('rag/index 样例文档建索引成功', status === 201 && indexed.length > 0,
      `indexed=${indexed.map(i => `${i.title}(${i.chunks})`).join(',')}`);
  } else {
    record('rag/index 样例文档存在', false, `missing ${candidate}`);
  }

  /* 4.2 检索并断言模型作答 */
  const { status, body } = await postJson('/api/skills/rag/query', {
    query: '设备点检的字段和异常判定要求是什么？',
    top_k: 5
  });
  const data = body?.data?.output || {};
  if (data.model_error) {
    record('rag/模型作答（有 model_error 即失败）', false, `code=${data.model_error.code} ${data.model_error.message}`);
    return;
  }
  const answer = String(data.answer || '');
  record('rag/回答非空', answer.length > 10, `len=${answer.length} preview=${JSON.stringify(answer.slice(0, 60))}`);
  record('rag/回答带 [序号] 引用', /\[\d+\]/.test(answer), `citations=${(data.citations || []).length}`);
  record('rag/引用可追溯（有标题与片段）', (data.citations || []).every(c => c.title && c.snippet),
    `citations=${JSON.stringify((data.citations || []).map(c => c.title).slice(0, 3))}`);
  record('rag/evidence 含模型证据', hasModelEvidence(body?.data?.evidence || []), '');

  /* 4.3 公开爬取语料：scope=公开资料库 应直接命中（不 fallback），且引用带来源 */
  const crawled = await postJson('/api/skills/rag/query', {
    query: '预测性维护和传统维护方式有什么区别？',
    scopes: ['公开资料库'],
    top_k: 3
  });
  const cOut = crawled.body?.data?.output || {};
  const cCites = cOut.citations || [];
  record('rag/公开资料库范围命中爬取语料（无 fallback）', cOut.scope_fallback !== true && cCites.length > 0,
    `fallback=${cOut.scope_fallback} citations=${cCites.length}`);
  record('rag/爬取引用全部来自公开资料库', cCites.every(c => c.scope === '公开资料库'),
    cCites.map(c => c.title).slice(0, 2).join(' | '));
}

/* --------------------------------------------------------- 5. 可视化报告生成 */
async function checkReport() {
  const metricsPayload = [
    { label: '点检记录总数', value: 312, note: '四周合计' },
    { label: '异常记录数', value: 17, note: '含 6 条字段缺失' },
    { label: '异常率', value: '5.4%', note: '17/312' }
  ];
  const { status, body } = await postJson('/api/skills/report', {
    kind: '项目执行报告',
    title: '设备点检台账整理异常周报（模型验证）',
    data: {
      metrics: metricsPayload,
      charts: [{ type: 'bar', title: '各周异常数', items: [{ label: '第1周', value: 3 }, { label: '第2周', value: 5 }, { label: '第3周', value: 4 }, { label: '第4周', value: 5 }] }]
    }
  });
  const data = body?.data?.output || {};
  if (data.model_error) {
    record('report/模型叙述生成（有 model_error 即失败）', false, `code=${data.model_error.code} ${data.model_error.message}`);
    return;
  }
  record('report/生成 HTML 报告', status === 201 && !!data.report_id && !!data.file,
    `report_id=${data.report_id} file=${data.file}`);
  const modelSections = (data.sections || []).filter(s => s.source === 'model');
  record('report/含模型撰写段落（结论/发现/建议）', modelSections.length >= 2,
    `model_sections=${modelSections.map(s => s.h).join('、')}`);
  const modelText = modelSections.map(s => s.p).join(' ');
  /* 白名单从输入数据里动态提取：metrics 的 value/note 中出现的所有数字（含小数）。
     另加两类「非编造」数字：
       1. 枚举序号（"1." "2、" 这类行首编号只是排版，不是统计值），先整体剔除；
       2. 由白名单数字两两相除得到的百分比（如 6/17≈35.3%），属于从给定数字
          直接推导，允许出现；凭空出现的其它数字才算编造。 */
  const allowedSource = metricsPayload.map(m => `${m.value} ${m.note || ''}`).join(' ');
  const baseNumbers = (allowedSource.match(/\d+(?:\.\d+)?/g) || []);
  const allowed = new Set(baseNumbers);
  /* 允许的派生形式：白名单数字的各精度取整（5.4→5.4/5），
     以及两两相除的百分比及其取整（6/17→35.29/35.3/35，5.4%→约5条/百条） */
  function addRoundings(value) {
    for (const decimals of [0, 1, 2]) {
      allowed.add(value.toFixed(decimals).replace(/\.0+$/, '').replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, ''));
    }
  }
  for (const num of baseNumbers) addRoundings(Number(num));
  for (const a of baseNumbers) {
    for (const b of baseNumbers) {
      const divisor = Number(b);
      if (!divisor) continue;
      addRoundings((Number(a) / divisor) * 100);
    }
  }
  const allowedNumbers = [...allowed].sort((x, y) => y.length - x.length);
  let stripped = modelText.replace(/(?:^|[\n。；;：:]\s*)\d{1,2}[.、)]/g, m => m.replace(/\d{1,2}[.、)]/, ''));
  for (const num of allowedNumbers) stripped = stripped.split(num).join('');
  stripped = stripped.replace(/20\d\d/g, '');
  const leakedNumbers = stripped.match(/\d+(?:\.\d+)?/g) || [];
  record('report/模型叙述未编造指标外数字', leakedNumbers.length === 0,
    leakedNumbers.length ? `leaked=${leakedNumbers.join(',')} text=${JSON.stringify(modelText.slice(0, 120))}` : 'ok（含推导值与枚举序号的豁免）');
  record('report/evidence 含模型证据', hasModelEvidence(body?.data?.evidence || []), '');
}

/* ------------------------------------------------------- 6. 实训操作意图解析 */
async function checkTraining() {
  const { status, body } = await postJson('/api/skills/training/plan', {
    instruction: '帮我查看 2024级数据科学班 目前的实训任务提交进度'
  });
  const data = body?.data || {};
  record('training/自然语言指令被解析成计划', status === 201 && !!data.plan_id,
    `system=${data.system} action=${data.action} op=${data.op}`);
  record('training/模型解析落在白名单动作上', ['lms', 'edge'].includes(data.system),
    `system=${data.system}`);
  record('training/返回模型解析理由与凭据', Boolean(data.model?.parsed?.reason && data.model?.model_evidence?.request_id),
    `reason=${JSON.stringify(String(data.model?.parsed?.reason || '').slice(0, 50))}`);
}

/* ----------------------------------------------------- 7. 多模态状态如实回报 */
async function checkMultimodal() {
  const { status, body } = await getJson('/api/skills/multimodal/status');
  const data = body?.data || {};
  record('multimodal/状态如实（无演示通道）', status === 200 && ['live', 'not_configured'].includes(data.state),
    `state=${data.state} vision=${data.vision?.ready} asr=${data.asr?.ready}`);
}

/* ----------------------------------------------------------------- 主流程 */
(async () => {
  console.log(`Skill 服务：${BASE}`);
  const started = Date.now();
  try {
    await checkStatus();
    await checkPing();
    await checkParseBatch();
    await checkRag();
    await checkReport();
    await checkTraining();
    await checkMultimodal();
  } catch (error) {
    record('全局未捕获异常', false, error.message);
  }
  const elapsed = ((Date.now() - started) / 1000).toFixed(1);
  console.log(`\n共 ${results.length} 项断言，失败 ${failures} 项，用时 ${elapsed}s`);
  const reportPath = path.resolve(__dirname, '..', 'reports', `verify-live-models-${new Date().toISOString().replace(/[:.]/g, '-')}.json`);
  fs.mkdirSync(path.dirname(reportPath), { recursive: true });
  fs.writeFileSync(reportPath, JSON.stringify({ base: BASE, at: new Date().toISOString(), failures, results }, null, 2), 'utf8');
  console.log(`验证报告已写入：${reportPath}`);
  process.exit(failures ? 1 : 0);
})();
