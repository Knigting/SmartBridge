/* ==========================================================================
   verify-platform-skills.js —— 四端「能力接入位 × 五个 Skill」全链路仿真
   --------------------------------------------------------------------------
   把四端页面里声明过的每一个接入位（data-cap / data-skill / data-args）按
   适配器完全相同的调用路径打一遍 8080 网关，输出每个接入位的真实返回形态：
     mode（live/simulated/none）、ok、以及结果摘要或错误码。
   用途：
     1) 找出「页面声明了但 Skill 跑不出真实结果」的接入位；
     2) 作为喂数据之后的回归基线（同一脚本前后各跑一次对比）。

   运行： node tools/verify-platform-skills.js
   ========================================================================== */
const BASE = process.env.PLATFORM_BASE || 'http://127.0.0.1:8080';

const SLOTS = [
  /* ---------------- 教师端 ---------------- */
  { pf: '教师端', page: 'review.html',     id: 'A1', skill: 'parse-batch', args: { purpose: '批量解析企业上传的样表与说明，抽出需求卡要点与教学适配提示', files: [{ name: 'equipment-inspection-requirements.docx' }, { name: 'inspection-sample-last-4-weeks.xlsx' }] } },
  { pf: '教师端', page: 'project.html',    id: 'A2', skill: 'parse-batch', args: { files: [{ name: 'inspection-sample-last-4-weeks.xlsx' }, { name: 'equipment-inspection-work-instructions.pdf' }, { name: 'data-processing-course-standard.docx' }], purpose: '批量解析教学参考资料' } },
  { pf: '教师端', page: 'evaluation.html', id: 'A3', skill: 'parse-batch', args: { purpose: '批量解析学生提交的成果材料，核对必交项与字段完整性' } },
  { pf: '教师端', page: 'tasks.html',      id: 'B1', skill: 'training', args: { system: 'lms', op: 'write', action: 'publish-task-stages', payload: { project: 'PRJ-0917-001', cls: '2024级数据科学班', stages: 4 } } },
  { pf: '教师端', page: 'students.html',   id: 'B2', skill: 'training', args: { system: 'lms', op: 'read', action: 'read-class-progress', query: 'PRJ-0917-001' } },
  { pf: '教师端', page: 'students.html',   id: 'B3', skill: 'training', args: { system: 'edge', op: 'read', action: 'read-fixed-sample-result', query: 'PRJ-0917-001' } },
  { pf: '教师端', page: 'qa.html',         id: 'C1', skill: 'multimodal', args: { kind: 'image', source: 'inspection-sheet-group-2-question.jpg', purpose: '学生提问截图识别为文字与要点' } },
  { pf: '教师端', page: 'evaluation.html', id: 'C2', skill: 'multimodal', args: { kind: 'image', source: 'student-practical-photo-cnc02.jpg', purpose: '实操照片与仪表读数步骤判定' } },
  { pf: '教师端', page: 'qa.html',         id: 'C3', skill: 'multimodal', args: { kind: 'audio', source: 'student-voice-question.wav', purpose: '学生语音提问转写为问题条目' } },
  { pf: '教师端', page: 'project.html',    id: 'D1', skill: 'rag', args: { query: '设备点检 台账整理 异常识别 岗位能力标准 课程标准 先修条件', scopes: ['岗位能力标准', '学校课程标准'] } },
  { pf: '教师端', page: 'review.html',     id: 'D2', skill: 'rag', args: { query: '设备点检台账整理 教学适配性与脱敏处理经验', scopes: ['历史任务库', '学校课程标准', '企业工艺文档库'] } },
  { pf: '教师端', page: 'evaluation.html', id: 'D3', skill: 'rag', args: { query: '边界值判定 返修后评分口径 团队贡献核验 教学评价标准', scopes: ['学校课程标准', '历史任务库'] } },
  { pf: '教师端', page: 'qa.html',         id: 'D4', skill: 'rag', args: { query: '去重保留策略 温度阈值边界值 缺失值是否计入异常', scopes: ['历史任务库', '学校课程标准'] } },
  { pf: '教师端', page: 'index.html',      id: 'E1', skill: 'report', args: { kind: '教学周报' } },
  { pf: '教师端', page: 'students.html',   id: 'E2', skill: 'report', args: { kind: '班级画像', data: { cls: '2024级数据科学班', project: 'PRJ-0917-001' } } },
  { pf: '教师端', page: 'library.html',    id: 'E3', skill: 'report', args: { kind: '任务包说明', data: { project: 'PRJ-0917-001', stages: 4, hours: 12 } } },
  { pf: '教师端', page: 'library.html',    id: 'E4', skill: 'report', args: { kind: '复核记录', data: { project: 'PRJ-0917-001', week: 4 } } },

  /* ---------------- 企业端 ---------------- */
  { pf: '企业端', page: 'demand.html',     id: 'A1', skill: 'parse-batch', args: { purpose: '企业需求资料批量解析', files: [{ name: 'equipment-inspection-requirements.docx' }, { name: 'inspection-sample-last-4-weeks.xlsx' }] } },
  { pf: '企业端', page: 'project.html',    id: 'A2', skill: 'parse-batch', args: { files: [{ name: 'equipment-inspection-requirements.docx' }, { name: 'inspection-sample-last-4-weeks.xlsx' }, { name: 'equipment-register-guide.docx' }], purpose: '企业侧原始资料批量解析为需求卡草稿' } },
  { pf: '企业端', page: 'acceptance.html', id: 'A3', skill: 'parse-batch', args: { purpose: '成果包 4 项必交材料完整性批量检查' } },
  { pf: '企业端', page: 'project.html',    id: 'B1', skill: 'training', args: { system: 'lms', op: 'write', action: 'publish-task-stages', payload: { project: 'PRJ-0917-001', cls: '2024级数据科学班', stages: 4 } } },
  { pf: '企业端', page: 'report.html',     id: 'B2', skill: 'training', args: { system: 'lms', op: 'read', action: 'read-class-progress', query: 'PRJ-0917-001' } },
  { pf: '企业端', page: 'demand.html',     id: 'C1', skill: 'multimodal', args: { kind: 'image', source: 'on-site-inspection-sheet-line-3.jpg', purpose: '现场点检表照片识别为结构化表格' } },
  { pf: '企业端', page: 'acceptance.html', id: 'C2', skill: 'multimodal', args: { kind: 'image', source: 'instrument-reading-cnc-02.jpg', purpose: '验收材料的仪表读数与实操照片判定' } },
  { pf: '企业端', page: 'demand.html',     id: 'C3', skill: 'multimodal', args: { kind: 'audio', source: 'frontline-supervisor-voice-notes.wav', purpose: '需求口述转写为需求正文' } },
  { pf: '企业端', page: 'project.html',    id: 'D1', skill: 'rag', args: { query: '设备点检 台账整理 异常识别 岗位能力要求 课程标准', scopes: ['岗位能力标准', '学校课程标准'] } },
  { pf: '企业端', page: 'acceptance.html', id: 'D2', skill: 'rag', args: { query: '设备点检 验收规范 温度阈值 缺失值 去重', scopes: ['验收规范', '岗位能力标准'] } },
  { pf: '企业端', page: 'report.html',     id: 'D3', skill: 'rag', args: { query: '设备点检台账类 历史任务 人工工时 返修率', scopes: ['历史任务库'] } },
  { pf: '企业端', page: 'talent.html',     id: 'D4', skill: 'rag', args: { query: '设备数据维护岗 岗位能力标准 待验证能力 点检台账', scopes: ['岗位能力标准'] } },
  { pf: '企业端', page: 'report.html',     id: 'E1', skill: 'report', args: { kind: '量化效益', data: { project: 'PRJ-0917-001', baselineHours: 15.2, actualHours: 6.0, savedHours: 9.2, passRate: 100, rework: 1 } } },
  { pf: '企业端', page: 'talent.html',     id: 'E2', skill: 'report', args: { kind: '人才获取', data: { candidates: 4, authorized: 2, topScore: 92 } } },
  { pf: '企业端', page: 'report.html',     id: 'E3', skill: 'report', args: { kind: '执行进度', data: { project: 'PRJ-0917-001', done: 6, total: 14 } } },

  /* ---------------- 学生端 ---------------- */
  { pf: '学生端', page: 'tasks.html',      id: 'A1', skill: 'parse-batch', args: { files: [{ name: 'rule_check.py' }, { name: 'exception_list.xlsx' }, { name: 'pending-review-unit-mismatch.md' }], purpose: '提交前批量检查' } },
  { pf: '学生端', page: 'task.html',       id: 'A2', skill: 'parse-batch', args: { files: [{ name: 'rule_check.py' }, { name: 'exception_list.xlsx' }], purpose: '本阶段产物完整性检查' } },
  { pf: '学生端', page: 'tasks.html',      id: 'B1', skill: 'training', args: { system: 'lms', op: 'read', action: 'levels' } },
  { pf: '学生端', page: 'tasks.html',      id: 'B2', skill: 'training', args: { system: 'lms', op: 'write', action: 'submit', payload: { status: 'running' } } },
  { pf: '学生端', page: 'report.html',     id: 'B3', skill: 'training', args: { system: 'edge', op: 'read', action: 'device-log' } },
  { pf: '学生端', page: 'task.html',       id: 'C1', skill: 'multimodal', args: { kind: 'image', source: 'exception-list-screenshot.png', purpose: '读数与步骤判定' } },
  { pf: '学生端', page: 'inagent.html',    id: 'C2', skill: 'multimodal', args: { kind: 'audio', source: 'unit-mismatch-voice-question.wav', purpose: '转写为文字' } },
  { pf: '学生端', page: 'task.html',       id: 'D1', skill: 'rag', args: { query: '本阶段验收标准与温度阈值、缺失值处理要求', scopes: ['企业验收规范', '企业工艺文档'] } },
  { pf: '学生端', page: 'report.html',     id: 'D2', skill: 'rag', args: { query: '数据处理岗能力标准与课程标准中的边界条件、缺失值处理要求', scopes: ['岗位能力标准', '学校课程标准'] } },
  { pf: '学生端', page: 'inagent.html',    id: 'D3', skill: 'rag', args: { query: '80℃ 边界值判定与缺失值分流的标准依据', scopes: ['学校课程标准', '微课知识库'] } },
  { pf: '学生端', page: 'learning.html',   id: 'D4', skill: 'rag', args: { query: '边界条件 80℃ 误判 缺失值处理 周报口径', scopes: ['微课知识库', '企业公开任务库'] } },
  { pf: '学生端', page: 'report.html',     id: 'E1', skill: 'report', args: { kind: '能力画像', data: { levelsPassed: 1, processScore: 268 } } },
  { pf: '学生端', page: 'index.html',      id: 'E2', skill: 'report', args: { kind: '成长周报', data: { week: 4, processScore: 268 } } },
  { pf: '学生端', page: 'company.html',    id: 'E3', skill: 'report', args: { kind: '能力材料包', data: { anonymous: true, openToCompany: false } } },

  /* ---------------- 平台管理系统（注册面 + 报告档案） ---------------- */
  { pf: '平台端', page: 'settings.html',   id: 'S1', skill: 'registry',  args: { path: '/api/skills/status' } },
  { pf: '平台端', page: 'settings.html',   id: 'S2', skill: 'registry',  args: { path: '/api/skills/catalog' } },
  { pf: '平台端', page: 'settings.html',   id: 'S3', skill: 'registry',  args: { path: '/api/workflows/bindings' } },
  { pf: '平台端', page: 'settings.html',   id: 'S4', skill: 'registry',  args: { path: '/api/skills/training/systems' } },
  { pf: '平台端', page: 'settings.html',   id: 'S5', skill: 'registry',  args: { path: '/api/skills/multimodal/status' } },
  { pf: '平台端', page: 'operations.html', id: 'S6', skill: 'report', args: { kind: '运维', data: { metrics: [{ label: '组织数', value: 5 }, { label: '项目数', value: 3 }, { label: '后台任务数', value: 5 }], evidence: [{ source: '平台管理系统本地数据库' }] } } },
  { pf: '平台端', page: 'operations.html', id: 'S7', skill: 'report', args: { kind: '运营月报', report_period: '2026-05' } }
];

async function postJson(path, body) {
  const r = await fetch(BASE + path, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body || {}) });
  const j = await r.json().catch(() => ({}));
  return { status: r.status, j };
}
async function getJson(path) {
  const r = await fetch(BASE + path, { headers: { Accept: 'application/json' } });
  const j = await r.json().catch(() => ({}));
  return { status: r.status, j };
}

function digest(skill, data) {
  const o = data && (data.output || data);
  if (!o) return '无 output';
  if (skill === 'parse-batch') {
    const files = (o.files || []).map(f => `${f.name}(${f.type}${f.rows ? ' ' + f.rows + '行' : ''}${f.pages ? ' ' + f.pages + '页' : ''})`);
    return `解析 ${files.length} 个：${files.join(' / ').slice(0, 150)}｜异常 ${(o.anomalies || []).length} 项｜缺失 ${(o.missing_values || []).length || 0}`;
  }
  if (skill === 'rag') return `命中 ${(o.hits || []).length} 条｜最高分 ${(o.hits && o.hits[0] && o.hits[0].score) || '—'}｜scope 回退 ${o.scope_fallback ? '是' : '否'}｜answer ${String(o.answer || '').slice(0, 60)}`;
  if (skill === 'multimodal') return `kind=${o.kind}｜置信度 ${o.confidence}｜text ${String(o.text || '').replace(/\s+/g, ' ').slice(0, 70)}`;
  if (skill === 'report') return `report_id=${o.report_id ? '有' : '无'}｜指标 ${(o.metrics || []).length} 项｜章节 ${(o.sections || []).length} 段｜图表 ${(o.charts || []).length} 个｜${o.title}`;
  if (skill === 'training') return `ref=${o.ref || o.receipt || '—'}｜rows ${(o.rows || []).length}｜verify=${o.verification ? (o.verification.ok ? 'ok' : 'fail') : '—'}`;
  return JSON.stringify(o).slice(0, 120);
}

async function runSlot(s) {
  const out = { pf: s.pf, page: s.page, id: s.id, skill: s.skill, mode: '', ok: false, note: '' };
  try {
    if (s.skill === 'parse-batch') {
      /* 适配器行为：没有真实 File 对象时走内置样例通道，并把声明的文件名一并带上，
         让 Skill 能按声明挑选平台对应的样例（喂数据后应能命中） */
      const names = (s.args.files || []).map(f => f.name);
      const body = { purpose: s.args.purpose || '' };
      if (names.length) body.files = names;
      const r = await postJson('/api/skills/parse-batch/samples', body);
      if (r.status >= 300) { out.note = `HTTP ${r.status} ${r.j.message || ''}`; return out; }
      out.mode = r.j.data.mode; out.ok = true; out.note = digest(s.skill, r.j.data);
      const got = (r.j.data.output.files || []).map(f => f.name);
      const miss = names.filter(n => !got.includes(n));
      if (miss.length) out.note += ` ⚠声明但未解析：${miss.join('、')}`;
      return out;
    }
    if (s.skill === 'rag') {
      const r = await postJson('/api/skills/rag/query', { query: s.args.query, scopes: s.args.scopes || [], project_id: s.args.project_id || '', top_k: 5 });
      if (r.status >= 300) { out.note = `HTTP ${r.status} ${r.j.message || ''}`; return out; }
      out.mode = r.j.data.mode; out.ok = true; out.note = digest(s.skill, r.j.data);
      if (r.j.data.output.scope_fallback) out.note += ' ⚠scope 回退';
      return out;
    }
    if (s.skill === 'multimodal') {
      const r = await postJson('/api/skills/multimodal/samples', { source: s.args.source || '', kind: s.args.kind || '', purpose: s.args.purpose || '', language: 'zh-CN' });
      if (r.status >= 300) { out.note = `HTTP ${r.status} ${r.j.message || ''}`; return out; }
      out.mode = r.j.data.mode; out.ok = true; out.note = digest(s.skill, r.j.data);
      const src = r.j.data.input && r.j.data.input.source;
      if (s.args.source && src !== s.args.source) out.note = `⚠声明的 ${s.args.source} 未命中，实取 ${src}｜` + out.note;
      return out;
    }
    if (s.skill === 'report') {
      /* 接入位只声明 kind 时，先从业务库取真实聚合数据再交给报告 Skill；
         声明了 report_period 则直接走报告 Skill 的已校验报告档案。 */
      let body;
      if (s.args.report_period) {
        body = { title: `${s.args.report_period} 运营月报`, kind: s.args.kind, data: { report_period: s.args.report_period } };
      } else {
        const rd = await postJson('/api/report-data', { kind: s.args.kind, data: s.args.data || {} });
        const enriched = rd.j && rd.j.data ? rd.j.data : {};
        body = { title: enriched.title || s.args.kind, kind: s.args.kind, data: Object.assign({}, enriched, s.args.data || {}) };
      }
      const r = await postJson('/api/skills/report', body);
      if (r.status >= 300) { out.note = `HTTP ${r.status} ${r.j.message || ''}`; return out; }
      out.mode = r.j.data.mode; out.ok = true; out.note = digest(s.skill, r.j.data);
      const v = r.j.data.output.validation;
      if (v) out.note += `｜口径校验 ${v.trained ? (v.valid_period ? '已训练+报告期有效' : '报告期无数据') : '未使用训练档案'}`;
      return out;
    }
    if (s.skill === 'registry') {
      const r = await getJson(s.args.path);
      if (r.status >= 300) { out.note = `HTTP ${r.status} ${r.j.message || ''}`; return out; }
      const d = r.j.data;
      out.mode = 'live'; out.ok = true;
      if (s.args.path.endsWith('/multimodal/status')) {
        out.note = `多模态：state=${d.state} mode=${d.mode} provider=${d.provider}｜支持 ${Object.entries(d.supported || {}).map(([k, v]) => k + ':' + v.join('/')).join(' ')}`;
      } else if (s.args.path.endsWith('/skills/status')) {
        out.note = `五项能力：${(d.skills || []).map(i => i.key + '(' + i.state + ')').join('、')}｜可用 ${d.available}/${d.required}`;
      } else if (s.args.path.endsWith('/catalog')) {
        out.note = `已注册能力 ${d.length} 项：${d.map(i => i.name).join('、')}`;
      } else if (s.args.path.endsWith('/bindings')) {
        const byPf = {}; d.forEach(i => { byPf[i.platform] = (byPf[i.platform] || 0) + 1; });
        out.note = `工作流绑定 ${d.length} 条：${Object.entries(byPf).map(([k, v]) => k + ' ' + v).join('、')}`;
      } else if (s.args.path.endsWith('/systems')) {
        out.note = `训练系统 ${(d.systems || []).length} 个：${(d.systems || []).map(i => i.id + '[' + i.mode + ' ' + Object.keys(i.actions || {}).length + '动作]').join('、')}`;
      } else {
        out.note = `多模态：state=${d.state} mode=${d.mode} provider=${d.provider}`;
      }
      return out;
    }
    if (s.skill === 'training') {
      const plan = await postJson('/api/skills/training/plan', { system: s.args.system, op: s.args.op, action: s.args.action, payload: s.args.payload || {} });
      if (plan.status >= 300) { out.note = `HTTP ${plan.status} ${plan.j.code || ''} ${plan.j.message || ''}`; return out; }
      const p = plan.j.data;
      if (p.approval_required) {
        /* 写操作：按治理策略生成计划，需人工审批后才执行（属于正常中间态） */
        const appr = await postJson(`/api/skills/training/plans/${p.plan_id}/approve`, { approved_by: 'verify-script', reason: '回归验证' });
        const token = appr.j && appr.j.data && appr.j.data.approval_token;
        const exec = await fetch(BASE + '/api/skills/training/execute', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'Idempotency-Key': 'verify-' + p.plan_id }, body: JSON.stringify({ plan_id: p.plan_id, approval_token: token }) });
        const ej = await exec.json().catch(() => ({}));
        if (exec.status >= 300) { out.note = `审批后执行失败 HTTP ${exec.status} ${ej.code || ''} ${ej.message || ''}`; return out; }
        out.mode = ej.data.mode; out.ok = true; out.note = '写操作 计划→审批→执行：' + digest(s.skill, ej.data);
        return out;
      }
      const exec = await postJson('/api/skills/training/execute', { plan_id: p.plan_id });
      if (exec.status >= 300) { out.note = `执行失败 HTTP ${exec.status} ${exec.j.code || ''} ${exec.j.message || ''}`; return out; }
      out.mode = exec.j.data.mode; out.ok = true; out.note = '读操作 计划→执行：' + digest(s.skill, exec.j.data);
      return out;
    }
    out.note = '未知 skill';
  } catch (e) { out.note = 'EXC ' + e.message; }
  return out;
}

(async () => {
  const results = [];
  for (const s of SLOTS) results.push(await runSlot(s));
  const bySkill = {};
  for (const r of results) {
    bySkill[r.skill] = bySkill[r.skill] || { total: 0, ok: 0 };
    bySkill[r.skill].total++; if (r.ok) bySkill[r.skill].ok++;
  }
  console.log('================ 接入位 × Skill 全链路结果 ================');
  let lastPf = '';
  for (const r of results) {
    if (r.pf !== lastPf) { console.log('\n---- ' + r.pf + ' ----'); lastPf = r.pf; }
    console.log(`${r.ok ? '✓' : '✗'} [${r.id}] ${r.skill.padEnd(12)} mode=${(r.mode || 'none').padEnd(10)} ${r.note}`);
  }
  console.log('\n================ 汇总 ================');
  for (const k of Object.keys(bySkill)) console.log(`${k.padEnd(12)} ${bySkill[k].ok}/${bySkill[k].total}`);
  const bad = results.filter(r => !r.ok);
  console.log(`\n失败/异常接入位：${bad.length} / ${results.length}`);
  bad.forEach(r => console.log(`  ✗ ${r.pf} ${r.page} [${r.id}] ${r.skill} —— ${r.note}`));
})();
