/* ==========================================================================
   verify-workflow-dispatch.js —— 平台工作流触发面 × 五个 Skill
   --------------------------------------------------------------------------
   不走「页面直连 Skill」，而是走平台登记的工作流触发事件：
       POST /api/workflows/:platform/:trigger/dispatch
   这是 8080 网关上真正的接入位分发层（skill_workflow_bindings，20 条启用绑定），
   分发后会把 platform 与 trigger_event 一并写入 skill_runs，便于审计归属。

   调用的载荷全部取自平台当前业务：项目 PRJ-0917-001、班级 2024级数据科学班、
   规则 R1~R4，以及平台自己的样例素材（真实 multipart 上传，走上传通道而非内置样例）。

   运行： node tools/verify-workflow-dispatch.js
   ========================================================================== */
const fs = require('fs');
const path = require('path');

const BASE = process.env.PLATFORM_BASE || 'http://127.0.0.1:8080';
const ROOT = path.resolve(__dirname, '..');
const SAMPLES = path.join(ROOT, 'services', 'skill-service', 'samples');
const MEDIA = path.join(SAMPLES, 'media');

function file(name, fromMedia) {
  const filePath = path.join(fromMedia ? MEDIA : SAMPLES, name);
  return { name, filePath, buffer: fs.readFileSync(filePath) };
}

const MIME = {
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.pdf': 'application/pdf',
  '.md': 'text/markdown',
  '.py': 'text/x-python',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.png': 'image/png',
  '.wav': 'audio/wav'
};
const mimeOf = name => MIME[path.extname(name).toLowerCase()] || 'application/octet-stream';

const CASES = [
  /* ---------------- 学生端 ---------------- */
  { pf: 'student', trigger: 'submission.uploaded', skill: 'parse-batch',
    purpose: '提交前批量检查本阶段产物',
    files: [file('exception_list.xlsx'), file('pending-review-unit-mismatch.md'), file('rule_check.py')] },
  { pf: 'student', trigger: 'evidence.media_uploaded', skill: 'multimodal',
    media: file('exception-list-screenshot.png', true), purpose: '读数与步骤判定' },
  { pf: 'student', trigger: 'assistant.knowledge_query', skill: 'rag',
    json: { query: '80℃ 边界值判定与缺失值分流的标准依据', scopes: ['学校课程标准', '微课知识库'], top_k: 5 } },
  { pf: 'student', trigger: 'capability.report_requested', skill: 'report',
    json: { title: '能力画像与证据摘要报告', kind: '能力画像', data: { levelsPassed: 1, processScore: 268 } } },
  { pf: 'student', trigger: 'training.operation_requested', skill: 'training',
    json: { system: 'lms', op: 'read', action: 'levels' } },

  /* ---------------- 教师端 ---------------- */
  { pf: 'teacher', trigger: 'teaching.materials_uploaded', skill: 'parse-batch',
    purpose: '批量解析教学参考资料，抽出可复用的阶段素材与技能标签',
    files: [file('inspection-sample-last-4-weeks.xlsx'), file('equipment-inspection-work-instructions.pdf'), file('data-processing-course-standard.docx')] },
  { pf: 'teacher', trigger: 'guidance.media_uploaded', skill: 'multimodal',
    media: file('inspection-sheet-group-2-question.jpg', true), purpose: '学生提问截图识别为文字与要点' },
  { pf: 'teacher', trigger: 'guidance.knowledge_query', skill: 'rag',
    json: { query: '去重保留策略 温度阈值边界值 缺失值是否计入异常', scopes: ['历史任务库', '学校课程标准'], top_k: 5 } },
  { pf: 'teacher', trigger: 'teaching.report_requested', skill: 'report',
    json: { title: '教学执行周报', kind: '教学周报', data: {} } },
  { pf: 'teacher', trigger: 'task.operation_requested', skill: 'training',
    json: { system: 'lms', op: 'write', action: 'publish-task-stages', payload: { project: 'PRJ-0917-001', cls: '2024级数据科学班', stages: 4 } } },

  /* ---------------- 企业端 ---------------- */
  { pf: 'company', trigger: 'requirement.uploaded', skill: 'parse-batch',
    purpose: '企业需求资料批量解析为需求卡草稿',
    files: [file('equipment-inspection-requirements.docx'), file('equipment-register-guide.docx'), file('inspection-sample-last-4-weeks.xlsx')] },
  { pf: 'company', trigger: 'evidence.media_uploaded', skill: 'multimodal',
    media: file('on-site-inspection-sheet-line-3.jpg', true), purpose: '现场点检表照片识别为结构化表格' },
  { pf: 'company', trigger: 'acceptance.knowledge_query', skill: 'rag',
    json: { query: '设备点检 验收规范 温度阈值 缺失值 去重', scopes: ['验收规范', '岗位能力标准'], top_k: 5 } },
  { pf: 'company', trigger: 'project.report_requested', skill: 'report',
    json: { title: '执行进度周报', kind: '执行进度', data: { project: 'PRJ-0917-001', done: 6, total: 14 } } },
  { pf: 'company', trigger: 'training.operation_requested', skill: 'training',
    json: { system: 'lms', op: 'read', action: 'read-class-progress', query: 'PRJ-0917-001' } },

  /* ---------------- 平台端 ---------------- */
  { pf: 'admin', trigger: 'resource.imported', skill: 'parse-batch',
    purpose: '平台侧资源导入批量解析',
    files: [file('inspection-sample-last-4-weeks.xlsx'), file('exception_list.xlsx')] },
  { pf: 'admin', trigger: 'media.review_requested', skill: 'multimodal',
    media: file('instrument-reading-cnc-02.jpg', true), purpose: '验收材料的仪表读数与实操步骤判定' },
  { pf: 'admin', trigger: 'policy.knowledge_query', skill: 'rag',
    json: { query: '台账字段口径 重复记录判定 备注长度 平台资源导入规范', scopes: [], top_k: 5 } },
  { pf: 'admin', trigger: 'operations.report_requested', skill: 'report',
    json: { title: '平台运维概览', kind: '运维', data: { metrics: [{ label: '组织数', value: 5 }, { label: '项目数', value: 3 }, { label: '后台任务数', value: 5 }], evidence: [{ source: '平台管理系统本地数据库' }] } } },
  { pf: 'admin', trigger: 'platform.operation_requested', skill: 'training',
    json: { system: 'edge', op: 'read', action: 'device-log' } }
];

async function dispatch(spec) {
  const form = new FormData();
  if (spec.files) {
    for (const item of spec.files) form.append('files', new Blob([item.buffer], { type: mimeOf(item.name) }), item.name);
    form.append('purpose', spec.purpose || '');
  } else if (spec.media) {
    form.append('file', new Blob([spec.media.buffer], { type: mimeOf(spec.media.name) }), spec.media.name);
    form.append('kind', mimeOf(spec.media.name).startsWith('audio/') ? 'audio' : 'image');
    form.append('purpose', spec.purpose || '');
  } else {
    form.append('payload', JSON.stringify(spec.json || {}));
    /* 无文件的接入位，8080 会把非 multipart 字段原样传给 Skill；这里用 JSON 直传更贴近适配器 */
    const r = await fetch(`${BASE}/api/workflows/${spec.pf}/${spec.trigger}/dispatch`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify(spec.json || {})
    });
    return { status: r.status, j: await r.json().catch(() => ({})) };
  }
  const r = await fetch(`${BASE}/api/workflows/${spec.pf}/${spec.trigger}/dispatch`, { method: 'POST', body: form });
  return { status: r.status, j: await r.json().catch(() => ({})) };
}

function note(spec, j) {
  const d = j.data || {};
  const o = d.output || {};
  if (spec.skill === 'parse-batch') {
    const names = (o.files || []).map(f => `${f.name}(${f.type}${f.rows ? ' ' + f.rows + '行' : ''}${f.pages ? ' ' + f.pages + '页' : ''})`);
    return `${d.mode}｜解析 ${names.length} 个：${names.join(' / ')}｜异常 ${(o.anomalies || []).length} 项｜失败 ${(o.errors || []).length} 个`;
  }
  if (spec.skill === 'multimodal') return `${d.mode}｜kind=${o.kind}｜场景=${o.scenario || '-'}｜置信度 ${o.confidence}｜${String(o.text || '').slice(0, 46)}`;
  if (spec.skill === 'rag') return `${d.mode}｜命中 ${(o.hits || []).length} 条｜最高分 ${(o.hits && o.hits[0] && o.hits[0].score) || '-'}｜${String(o.answer || '').replace(/\s+/g, ' ').slice(0, 54)}`;
  if (spec.skill === 'report') return `${d.mode}｜${o.title}｜指标 ${(o.metrics || []).length} 项｜图表 ${(o.charts || []).length} 个｜报告 ${o.report_id ? '已生成' : '无'}`;
  if (spec.skill === 'training') {
    const approval = d.approval_required ? '需审批' : '只读';
    return `${d.mode || 'planned'}｜${approval}｜计划 ${d.plan_id ? '已生成' : '无'}｜风险 ${d.risk}｜${d.summary || ''}`;
  }
  return JSON.stringify(o).slice(0, 80);
}

(async () => {
  const results = [];
  for (const spec of CASES) {
    const out = { pf: spec.pf, trigger: spec.trigger, skill: spec.skill, ok: false, note: '' };
    try {
      const { status, j } = await dispatch(spec);
      if (status >= 300) { out.note = `HTTP ${status} ${j.code || ''} ${j.message || ''}`; }
      else { out.ok = true; out.note = note(spec, j); }
    } catch (error) { out.note = 'EXC ' + error.message; }
    results.push(out);
  }
  console.log('=========== 工作流触发面（platform/trigger → Skill）===========');
  let last = '';
  for (const r of results) {
    if (r.pf !== last) { console.log('\n---- ' + r.pf + ' ----'); last = r.pf; }
    console.log(`${r.ok ? '✓' : '✗'} ${r.trigger.padEnd(30)} → ${r.skill.padEnd(12)} ${r.note}`);
  }
  const bad = results.filter(r => !r.ok);
  console.log(`\n通过 ${results.length - bad.length} / ${results.length}`);
  bad.forEach(r => console.log(`  ✗ ${r.pf}/${r.trigger} ${r.skill} —— ${r.note}`));
})();
