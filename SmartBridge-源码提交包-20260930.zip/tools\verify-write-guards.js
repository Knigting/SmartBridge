'use strict';
/* 复验：写接口在「命中不到数据 / 参数不合法」时必须给出可读错误，而不是假成功 */
const BASE = 'http://127.0.0.1:8080';

const cases = [
  ['POST', '/api/teacher/library', { type: '知识条目', title: '归档链路复验', desc: '验证 ENUM 归一化', project_id: 'PRJ-0917-001' }, 201],
  ['POST', '/api/teacher/library', { type: '知识条目' }, 400, '缺 name 必须报可读错误'],
  ['POST', '/api/teacher/evaluations/decide', { evaluation_id: 'no-such-id', decision: 'confirm' }, 404, '假评价 id 必须报不存在'],
  ['POST', '/api/teacher/tasks/publish', { stage_id: 'no-such-stage' }, 404, '假阶段 id 必须报不存在'],
  ['POST', '/api/company/candidate-decisions', { student_id: 'no-such-student', decision: 'approve' }, 404, '假候选人必须报不存在'],
  ['POST', '/api/company/acceptance/decide', { result: 'passed' }, 404, '未带项目应报项目不存在']
];

(async () => {
  let pass = 0;
  for (const [method, url, body, expect, note] of cases) {
    const r = await fetch(BASE + url, {
      method, headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify(body)
    });
    const text = await r.text();
    let msg = '';
    try { const j = JSON.parse(text); msg = j.message || j.code || ''; } catch (e) { msg = text.slice(0, 80); }
    const good = r.status === expect;
    if (good) pass++;
    console.log(`${good ? 'PASS' : 'FAIL'}  ${method} ${url} → ${r.status}（期望 ${expect}）${note ? '  // ' + note : ''}\n        ${msg}`);
  }
  console.log(`\n合计 ${pass}/${cases.length} 通过`);
})();
